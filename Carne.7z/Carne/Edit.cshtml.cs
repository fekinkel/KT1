﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Carne
{
    public class EditModel : PageModel
    {
        private readonly WebBoletoPP.Models.BoletoPpHomologContext _context;

        public EditModel(WebBoletoPP.Models.BoletoPpHomologContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PpCarne PpCarne { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.PpCarnes == null)
            {
                return NotFound();
            }

            var ppcarne =  await _context.PpCarnes.FirstOrDefaultAsync(m => m.Codigo == id);
            if (ppcarne == null)
            {
                return NotFound();
            }
            PpCarne = ppcarne;
           ViewData["Login"] = new SelectList(_context.PpUsuarios, "Login", "Login");
           ViewData["PpId"] = new SelectList(_context.PpPrecoPublicos, "Id", "Id");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(PpCarne).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PpCarneExists(PpCarne.Codigo))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool PpCarneExists(string id)
        {
          return (_context.PpCarnes?.Any(e => e.Codigo == id)).GetValueOrDefault();
        }
    }
}
