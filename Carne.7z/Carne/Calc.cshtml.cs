using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace WebBoletoPP.Pages.Carne
{
    public class CalcModel : PageModel
    {
        [BindProperty]
        public CalcModelView ModelView { get; set; }
        private WebBoletoPP.Models.BoletoPpHomologContext _context;
        //private IToastNotification _toastNotification;
        public CalcModel(WebBoletoPP.Models.BoletoPpHomologContext context)
        {
            _context = context;
            //_toastNotification = toastNotification;
        }
        public void OnGet()
        {
            ModelView = new CalcModelView();
            ModelView.Altura = 1.65;
            ModelView.Peso = 70;

            ModelView.Quantidade = 1;
            ModelView.DataVencimento = DateOnly.FromDateTime(DateTime.Now);
            ModelView.ListaPrecoPublicos = CarregarListaPP(0);


        }

        public ActionResult OnPostDrop(string command)
        {
            return Page();
        }
        public ActionResult OnPost(string command, string TipoGet)
        {
            if (command.IsNullOrEmpty())
            {
                return Page();
            }
            else
            {
                ModelView.Calc();
                if (command == "GararGuia")
                {

                }
                else
                {
                    int val = int.Parse(command);
                    ModelView.PpId = val;
                    ModelView.ListaPrecoPublicos = CarregarListaPP(val);
                    ValorPP valPP = BuscarValorUfir(ModelView.DataVencimento.ToString(), val);
                    ModelView.ValorUFIR = valPP.valorufirdia;
                    ModelView.ValorUfm = valPP.valorufmpp;
                    ModelView.ValorReal = Decimal.Multiply(Decimal.Multiply(valPP.valorufirdia, valPP.valorufmpp), ModelView.Quantidade);

                }
                //ModelView.TipoDeBebida = ModelView.SelectTipoBebida.ToString();
            }

            return Page();
        }
        public ValorPP BuscarValorUfir(string DataVencimento, int valIdPP)
        {
            if (valIdPP > 0)
            {
                string sSql = $"Select (Select convert(decimal(12,6), dbo.Valor_Ufir_dia(\'{DataVencimento}\')) as valorufirdia, convert(decimal(12,6), Valor_UFM) as valorufmpp From PP_PRECO_PUBLICO Where ID = {valIdPP} For Json Path) as value";

                var retorno = _context.Database.SqlQueryRaw<string>(sSql).FirstOrDefault();

                if (retorno != null)
                {
                    retorno = retorno.Trim(new char[] { ']', '[' });

                    ValorPP valPP = JsonConvert.DeserializeObject<ValorPP>(retorno);

                    return valPP;
                }
                else
                {
                    return new ValorPP();
                }
            }
            else
            {
                return new ValorPP();
            }
        }
        public List<SelectListItem> CarregarListaPP(int IdPP)
        {
            var lista = new List<SelectListItem>();

            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            var precopublico = PrecoPublicoQuery.ToList();


            try
            {
                foreach (var item in precopublico)
                {
                    var option = new SelectListItem()
                    {
                        Text = item.Descricao,
                        Value = item.Id.ToString(),
                        Selected = (item.Id == IdPP)
                    };
                    lista.Add(option);
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return lista;
        }


    }
    public class ValorPP
    {
        public decimal valorufirdia { get; set; }
        public decimal valorufmpp { get; set; }
    }
    public class CalcModelView
    {
        public double Altura { get; set; }
        public double Peso { get; set; } = double.MaxValue;
        public double IMC { get; set; } = double.MaxValue;
        public string TipoDeBebida { get; set; }

        public CalcModelView() { }
        public void Calc()
        {
            this.IMC = Altura * Peso;
        }
        private TipoBebida _tipoBebida { get; set; }
        public TipoBebida SelectTipoBebida
        {
            get
            { return _tipoBebida; }
            set
            {
                _tipoBebida = value;
                this.TipoDeBebida = value.ToString();
                this.IMC = 0;
            }

        }
        public enum TipoBebida
        {
            Tea, Coffee, GreenTea, BlackTea
        }
        [Display(Name = "C�digo")]
        public string Codigo { get; set; } = null!;
        [Display(Name = "Parcela")]
        public int Parcela { get; set; }
        [Display(Name = "Valor do Servi�o em UFM")]
        public decimal ValorUfm { get; set; }
        [Display(Name = "Valor da UFIR vencimento")]
        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        public decimal ValorUFIR { get; set; }
        public decimal Quantidade { get; set; }
        public decimal ValorReal { get; set; }
        public string Observacao { get; set; } = null!;
        public string Login { get; set; } = null!;
        [Display(Name = "Selecione o servi�o:")]
        public int PpId { get; set; }
        public IEnumerable<SelectListItem> ePPid { get; set; }

        [Display(Name = "Data de Vencimento")]
        public DateOnly DataVencimento { get; set; }
        public DateOnly? DataPagamento { get; set; } = null;
        public List<SelectListItem> ListaPrecoPublicos { get; set; }


    }
}