﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.IdentityModel.Tokens;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Carne
{
    public class CreateModel : PageModel
    {

        [BindProperty]
        public CreateModelView ModelView { get; set; } = default!;
        public PpCarne PpCarne { get; set; } = default!;
        public int IndexListaPP { get; set; }

        private readonly BoletoPpHomologContext _context;

        public CreateModel(BoletoPpHomologContext context)
        {
            _context = context;
        }
        public ActionResult Index(CalcularIMCModel model)
        {
            return NotFound();
        }
        public IActionResult OnGet(CreateModelView modelView, string indicelistapp)
        {

            if (indicelistapp.IsNullOrEmpty())
            {
                ModelView = new CreateModelView(_context);
                ModelView.Quantidade = 1;

            }
            else
            {
                ModelView = new CreateModelView(_context);
                ModelView.Quantidade = 7;
                var ID = int.Parse(indicelistapp.ToString());

                ModelView.ValorUfm = BuscarValorPP(ID);

            }

            return Page();
        }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public IActionResult OnPost(CreateModelView modelView)
        {
            if (!ModelState.IsValid || _context.PpCarnes == null || PpCarne == null)
            {
                ModelView.Codigo = ModelView.ListaPrecoPublicos.Count.ToString();
                return Page();
            }

            _context.PpCarnes.Add(PpCarne);
            _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
        public double BuscarValorPP(int valIdPP)
        {
            if (valIdPP > 0)
            {
                var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                        where d.Id == valIdPP // Sort by name.
                                        select d.ValorUfm;

                return PrecoPublicoQuery.FirstOrDefault();

            }
            else
            {
                return 0;
            }
        }
    }
    public class CreateModelView
    {        
        public string Codigo { get; set; } = null!;
        public int Parcela { get; set; }
        public double ValorUfm { get; set; }
        public double ValorReal { get; set; }
        public double Quantidade { get; set; }
        public string Observacao { get; set; } = null!;
        public string Login { get; set; } = null!;
        public int PpId { get; set; }
        public DateTime DataVencimento { get; set; }
        public DateTime? DataPagamento { get; set; } = null;

        private readonly BoletoPpHomologContext _contextview;
        public List<SelectListItem> ListaPrecoPublicos { get; set; }
        public CreateModelView() { }
        public CreateModelView(BoletoPpHomologContext _context)
        {
            /*            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                                orderby d.Id // Sort by name.
                                                select d;
                        ListaPrecoPublico = PrecoPublicoQuery.ToList();
            */
            _contextview = _context;

            ListaPrecoPublicos = CarregarListaPP(0);
        }

        #region Métodos

        public List<SelectListItem> CarregarListaPP(int IdPP)
        {
            var lista = new List<SelectListItem>();

            var PrecoPublicoQuery = from d in _contextview.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            var precopublico = PrecoPublicoQuery.ToList();


            try
            {
                foreach (var item in precopublico)
                {
                    var option = new SelectListItem()
                    {
                        Text = item.Descricao,
                        Value = item.Id.ToString(),
                        Selected = (item.Id == IdPP)
                    };
                    lista.Add(option);
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return lista;
        }

        #endregion
    }
}
