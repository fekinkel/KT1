﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.PrecoPublico
{
    public class DetailsModel : PageModel
    {
        private readonly WebBoletoPP.Models.BoletoPpHomologContext _context;
        private readonly IWebHostEnvironment _webHostEnv;
        public DetailsModel(WebBoletoPP.Models.BoletoPpHomologContext context, IWebHostEnvironment webHostEnv)
        {
            _context = context;
            _webHostEnv = webHostEnv;
        }
        public string ProfilePicture { get; set; }
        public IFormFile? ProfileImage { get; set; }
        public string ProfileName { get; set; } = string.Empty;
        public PpPrecoPublico PpPrecoPublico { get; set; } = default!;
        public async Task<ActionResult> OnPostDisplayImageAsync(string imageName)
        {
            string imagePath = "aaaa";
            return File(imagePath, "image/jpeg"); // Adjust the content type based on the image type
        }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.PpPrecoPublicos == null)
            {
                return NotFound();
            }

            var ppprecopublico = await _context.PpPrecoPublicos.FirstOrDefaultAsync(m => m.Id == id);
            if (ppprecopublico == null)
            {
                return NotFound();
            }
            else 
            {
                PpPrecoPublico = ppprecopublico;
            }

            string uniqueFileName = UploadedFile();


            return Page();
        }
        private string UploadedFile()
        {
            string uniqueFileName = null;

            
            string uploadsFolder = Path.Combine(_webHostEnv.WebRootPath, @"img\qrcode\");
            
            uniqueFileName = "150003242799.png";
            
            string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                       
            using (Stream ms = new FileStream(filePath, FileMode.Open))
            {
                new ProfileImage.CopyTo(ms);

                var bytes = ConverteStreamToByteArray(ms);

                ProfilePicture = String.Format("data:image/png;base64, {0}", Convert.ToBase64String(bytes));
            }
            return filePath;
        }
        public static byte[] ConverteStreamToByteArray(Stream stream)
        {
            byte[] byteArray = new byte[16 * 1024];
            using (MemoryStream mStream = new MemoryStream())
            {
                int bit;
                while ((bit = stream.Read(byteArray, 0, byteArray.Length)) > 0)
                {
                    mStream.Write(byteArray, 0, bit);
                }
                return mStream.ToArray();
            }
        }
    }
}

namespace ProfileImage
{
    class CopyTo
    {
        private Stream ms;

        public CopyTo(Stream ms)
        {
            this.ms = ms;
        }
    }
}