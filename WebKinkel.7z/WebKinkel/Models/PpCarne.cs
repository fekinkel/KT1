﻿using System;
using System.Collections.Generic;

namespace WebKinkel.Models;

public partial class PpCarne
{
    public string Codigo { get; set; } = null!;

    public int Parcela { get; set; }

    public double ValorUfm { get; set; }

    public double ValorReal { get; set; }

    public string Observacao { get; set; } = null!;

    public string Login { get; set; } = null!;

    public DateTime DataVencimento { get; set; }

    public DateTime? DataPagamento { get; set; }
}
