﻿namespace WebKinkel.Models
{
    public class ModeloCalc
    {
        public double A {  get; set; }
        public double B { get; set; }
        public double Resultado { get; set; }
    }
}
