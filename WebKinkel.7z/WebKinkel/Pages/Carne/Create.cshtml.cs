﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.IdentityModel.Tokens;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Carne
{
    public class CreateModel : NomePrecoPublicoPageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public CreateModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            CarneModel = new PpCarne();
            CarneModel.Codigo = "1";
            CarneModel.Login = "Teste";
            PupularPPDropDownLista(_context);

            return Page();
        }

        [BindProperty]
        public PpCarne CarneModel { get; set; } = default!;


        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync(string command)
        {
            if (command.IsNullOrEmpty())
            {
                var emptyCarne = new PpCarne();


                if (!ModelState.IsValid || _context.PpCarnes == null || CarneModel == null)
                {
                    return Page();
                }

                if (await TryUpdateModelAsync<PpCarne>(
                    emptyCarne,
                    "Carnê",
                    s => s.Codigo, s => s.Parcela, s => s.ValorUfm, s => s.ValorReal, s => s.Observacao, s => s.Login, s => s.DataVencimento))
                {

                    _context.PpCarnes.Add(CarneModel);
                    await _context.SaveChangesAsync();

                    return RedirectToPage("./Index");
                }

                PupularPPDropDownLista(_context, emptyCarne.Codigo);
                return Page();
            }
            else if (command == "Calcular")
            {
                CarneModel.ValorUfm = 10;
                return Page();
            }
            else
            {
                CarneModel.ValorUfm = Convert.ToDouble(command.ToString());
                return NotFound();

            }
        }
    }
}
