﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebBoletoPP.Models;

public partial class BoletoPpHomologContext : DbContext
{
    public BoletoPpHomologContext()
    {
    }

    public BoletoPpHomologContext(DbContextOptions<BoletoPpHomologContext> options)
        : base(options)
    {
    }

    public virtual DbSet<PpGuia> PpGuias { get; set; }

    public virtual DbSet<PpPrecoPublico> PpPrecoPublicos { get; set; }

    public virtual DbSet<PpTipoDescricao> PpTipoDescricaos { get; set; }

    public virtual DbSet<PpUsuario> PpUsuarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=187.103.145.68;Database=BoletoPP_HOMOLOG;user id=tecnosysnet;password=tecno1999;trustservercertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PpGuia>(entity =>
        {
            entity.HasKey(e => e.IdGuia);

            entity.ToTable("PP_GUIA");

            entity.Property(e => e.IdGuia).HasColumnName("Id_Guia");
            entity.Property(e => e.BancoPagamento).HasColumnName("Banco_Pagamento");
            entity.Property(e => e.CodigoBarra)
                .HasMaxLength(44)
                .IsUnicode(false);
            entity.Property(e => e.DataBaixa)
                .HasColumnType("datetime")
                .HasColumnName("Data_Baixa");
            entity.Property(e => e.DataPagamento)
                .HasColumnType("datetime")
                .HasColumnName("Data_Pagamento");
            entity.Property(e => e.DataProcessamento)
                .HasColumnType("datetime")
                .HasColumnName("Data_Processamento");
            entity.Property(e => e.DataVencimento)
                .HasColumnType("datetime")
                .HasColumnName("Data_Vencimento");
            entity.Property(e => e.LinhaDigitavel)
                .HasMaxLength(60)
                .IsUnicode(false);
            entity.Property(e => e.Login)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.NossoNumero)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.NumDocumento)
                .HasMaxLength(14)
                .IsUnicode(false);
            entity.Property(e => e.Observacao).HasColumnType("ntext");
            entity.Property(e => e.PpId).HasColumnName("PpID");
            entity.Property(e => e.ValorGuia).HasColumnName("Valor_Guia");
            entity.Property(e => e.ValorPago)
                .HasColumnType("decimal(9, 2)")
                .HasColumnName("Valor_Pago");

            entity.HasOne(d => d.LoginNavigation).WithMany(p => p.PpGuia)
                .HasForeignKey(d => d.Login)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PP_GUIA_PP_USUARIO");

            entity.HasOne(d => d.Pp).WithMany(p => p.PpGuia)
                .HasForeignKey(d => d.PpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PP_GUIA_PP_PRECO_PUBLICO");
        });

        modelBuilder.Entity<PpPrecoPublico>(entity =>
        {
            entity.ToTable("PP_PRECO_PUBLICO");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.CodOrcamentario).HasColumnName("Cod_Orcamentario");
            entity.Property(e => e.Descricao)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.IdTd).HasColumnName("ID_TD");
            entity.Property(e => e.ValorUfm).HasColumnName("Valor_UFM");
        });

        modelBuilder.Entity<PpTipoDescricao>(entity =>
        {
            entity.HasKey(e => e.IdTd);

            entity.ToTable("PP_TIPO_DESCRICAO");

            entity.Property(e => e.IdTd)
                .ValueGeneratedNever()
                .HasColumnName("ID_TD");
            entity.Property(e => e.Descricao)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<PpUsuario>(entity =>
        {
            entity.HasKey(e => e.Login);

            entity.ToTable("PP_USUARIO");

            entity.Property(e => e.Login)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.AlterarSenha)
                .HasDefaultValueSql("((1))")
                .HasColumnName("Alterar_Senha");
            entity.Property(e => e.Ativo)
                .IsRequired()
                .HasDefaultValueSql("((1))");
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Secretaria)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Senha)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValueSql("((1234))");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
