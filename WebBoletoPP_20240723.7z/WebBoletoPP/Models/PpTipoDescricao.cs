﻿using System;
using System.Collections.Generic;

namespace WebBoletoPP.Models;

public partial class PpTipoDescricao
{
    public int IdTd { get; set; }

    public string? Descricao { get; set; }
}
