﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebBoletoPP.Models;

public partial class PpGuia
{
    [Display(Name = "Guia")]
    public int IdGuia { get; set; }

    public string? CodigoBarra { get; set; }

    public string? LinhaDigitavel { get; set; }
    [Display(Name = "Nosso Número")]
    public string? NossoNumero { get; set; }

    [Display(Name = "Número Documento")]
    public string? NumDocumento { get; set; }
    [Display(Name = "Valor")]
    [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
    public double ValorGuia { get; set; }
    [Display(Name = "Observação")]
    public string Observacao { get; set; } = null!;

    public string Login { get; set; } = null!;

    public int PpId { get; set; }

    public DateTime DataVencimento { get; set; }

    public DateTime? DataPagamento { get; set; }

    public decimal? ValorPago { get; set; }

    public short? BancoPagamento { get; set; }

    public DateTime? DataBaixa { get; set; }

    public DateTime? DataProcessamento { get; set; }

    public virtual PpUsuario LoginNavigation { get; set; } = null!;

    public virtual PpPrecoPublico Pp { get; set; } = null!;
}
