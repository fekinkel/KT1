﻿using System;
using System.Collections.Generic;

namespace WebBoletoPP.Models;

public partial class PpPrecoPublico
{
    public int Id { get; set; }

    public string Descricao { get; set; } = null!;

    public double ValorUfm { get; set; }

    public int CodOrcamentario { get; set; }

    public int? IdTd { get; set; }

    public virtual ICollection<PpGuia> PpGuia { get; set; } = new List<PpGuia>();
}
