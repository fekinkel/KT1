﻿namespace WebBoletoPP
{
    internal class Utils
    {
    }
}