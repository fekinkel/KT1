﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Guia
{
    public class EditModel : PageModel
    {
        private readonly WebBoletoPP.Models.BoletoPpHomologContext _context;

        public EditModel(WebBoletoPP.Models.BoletoPpHomologContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PpGuia PpGuia { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.PpGuias == null)
            {
                return NotFound();
            }

            var ppguia =  await _context.PpGuias.FirstOrDefaultAsync(m => m.IdGuia == id);
            if (ppguia == null)
            {
                return NotFound();
            }
            PpGuia = ppguia;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(PpGuia).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PpGuiaExists(PpGuia.IdGuia))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool PpGuiaExists(int id)
        {
          return (_context.PpGuias?.Any(e => e.IdGuia == id)).GetValueOrDefault();
        }
    }
}
