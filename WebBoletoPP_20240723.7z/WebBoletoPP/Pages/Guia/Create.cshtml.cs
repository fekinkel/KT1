﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using NToastNotify;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Guia
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public CreateModelView ModelView { get; set; } = default!;
        public PpGuia PpGuia { get; set; } = default!;
        public int IndexListaPP { get; set; }

        private readonly BoletoPpHomologContext _context;
        private readonly IToastNotification _toastNotification;

        public CreateModel(BoletoPpHomologContext context, IToastNotification toastNotification)
        {
            _context = context;
            _toastNotification = toastNotification;
            ModelView = new CreateModelView();
            _toastNotification = toastNotification;
        }
        public IActionResult OnGet(CreateModelView modview, string TipoGet)
        {
            ModelView.Quantidade = 1;
            ModelView.DesQtde = "--";

            ModelView.DataVencimento = DateOnly.FromDateTime(DateTime.Now);
            ModelView.ListaPrecoPublicos = CarregarListaPP(0);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(string Action)
        {
            ModelView.ListaPrecoPublicos = CarregarListaPP(ModelView.PpId);
            ValorPP valPP = BuscarValorUfir(ModelView.DataVencimento.ToString(), ModelView.PpId);
            ModelView.ValorUFIR = valPP.valorufirdia;
            ModelView.ValorUfm = valPP.valorufmpp;
            ModelView.DesQtde = valPP.descricao;
            ModelView.ValorReal = CalcularValorReal();

            if (!Action.IsNullOrEmpty())
            {
                if (Action == "CriarCarne")
                {
                    PpGuia = new PpGuia();
                    int valComparar =  DateTime.Compare(ModelView.DataVencimento.ToDateTime(TimeOnly.MinValue), DateTime.Now);
                    if (valComparar > 4 || valComparar < 1 || ModelView.DataVencimento.ToDateTime(TimeOnly.MinValue).Year != DateTime.Now.Year)
                    {
                        _toastNotification.AddAlertToastMessage("Data de Vencimento fora da faixa",
                                                                new ToastrOptions() { Title = "Data de Vencimento" });
                        return Page();
                    }
                    if (!ModelState.IsValid || _context.PpGuias == null || PpGuia == null)
                    {

                        ModelView.ListaPrecoPublicos = CarregarListaPP(0);
                        return Page();
                    }
                    else
                    {
                        int valID = BuscarIDPP() + 1;
                        DateTime date = DateTime.Now;

                        PpGuia.Observacao = $"Preço Público : {ModelView.NomePPid}\n\r {ModelView.DesQtde} : {ModelView.Quantidade.ToString()}\n\r {ModelView.Observacao}"; 
                            
                        PpGuia.DataVencimento = ModelView.DataVencimento.ToDateTime(TimeOnly.MinValue);
                        PpGuia.DataProcessamento = date;
                        PpGuia.PpId = ModelView.PpId;
                        PpGuia.Login = User.Identity.Name;
                        PpGuia.ValorGuia = Convert.ToDouble(ModelView.ValorReal);
                        PpGuia.NumDocumento = "55" + valID.ToString().PadLeft(9,'0') + "99";
                        PpGuia.NossoNumero = date.Year.ToString() + 
                                             date.Month.ToString().PadLeft(2 - date.Month.ToString().Length, '0') + 
                                             date.Day.ToString().PadLeft(2 - date.Day.ToString().Length, '0');
                        PpGuia.NossoNumero = PpGuia.NossoNumero.PadRight(5, '0') + PpGuia.NumDocumento;
                        var cod = new ClasseCodigoBarras(1);

                        PpGuia.CodigoBarra = cod.CodBarrasArrecadacaoV4(Convert.ToDouble(ModelView.ValorReal), ModelView.DataVencimento.ToDateTime(TimeOnly.MinValue), PpGuia.NumDocumento);
                        PpGuia.LinhaDigitavel = cod.LinhaDigSigCB(PpGuia.CodigoBarra);
                        
                        _context.PpGuias.Add(PpGuia);
                        _context.SaveChangesAsync();

                        return RedirectToPage("./Index");
                    }
                }

            }
            return Page();
        }
        public Decimal CalcularValorReal()
        {
            return Decimal.Multiply(Decimal.Multiply(ModelView.ValorUFIR, ModelView.ValorUfm), ModelView.Quantidade);
        }
        public int BuscarIDPP()
        {
            string sSql = "Select IDENT_CURRENT('PP_GUIA') as Value";

            decimal retorno = _context.Database.SqlQueryRaw<decimal>(sSql).FirstOrDefault();

            if(retorno != null)
            {
                return Convert.ToInt16(retorno);
            }
            else
            {
                return 0;
            }
        }
        public ValorPP BuscarValorUfir(string DataVencimento, int valIdPP)
        {
            if (valIdPP > 0)
            {
                string sSql = $"Select (Select convert(decimal(12,6), dbo.Valor_Ufir_dia(\'{DataVencimento}\')) as valorufirdia, convert(decimal(12,6), Valor_UFM) as valorufmpp, B.Descricao From PP_PRECO_PUBLICO A INNER JOIN PP_TIPO_DESCRICAO B on B.ID_TD = A.ID_TD Where ID = {valIdPP} For Json Path) as value";

                var retorno = _context.Database.SqlQueryRaw<string>(sSql).FirstOrDefault();

                if (retorno != null)
                {
                    retorno = retorno.Trim(new char[] { ']', '[' });

                    ValorPP valPP = JsonConvert.DeserializeObject<ValorPP>(retorno);

                    return valPP;
                }
                else
                {
                    return new ValorPP();
                }
            }
            else
            {
                return new ValorPP();
            }
        }
        public List<SelectListItem> CarregarListaPP(int IdPP)
        {
            var lista = new List<SelectListItem>();

            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select new { d.Id, d.Descricao };
            var precopublico = PrecoPublicoQuery.ToList();

            try
            {
                foreach (var item in precopublico)
                {
                    var option = new SelectListItem()
                    {
                        Text = item.Descricao,
                        Value = item.Id.ToString(),
                        Selected = (item.Id == IdPP)
                    };
                    if (item.Id == IdPP) { ModelView.NomePPid = item.Descricao; }
                    lista.Add(option);
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            
            return lista;
        }
    }

    public class ValorPP
    {
        public decimal valorufirdia { get; set; }
        public decimal valorufmpp { get; set; }
        public string descricao { get; set; }
    }
    public class CreateModelView
    {
        [Display(Name = "Valor do Serviço")]
        [DisplayFormat(DataFormatString = "{0:N4}", ApplyFormatInEditMode = true)]
        public decimal ValorUfm { get; set; }
        [Display(Name = "Valor da Ufir")]
        [DisplayFormat(DataFormatString = "{0:N4}", ApplyFormatInEditMode = true)]
        public decimal ValorUFIR { get; set; }
        [IntegerValidator]
        public int Quantidade { get; set; }
        [ValidateNever]
        public string DesQtde { get; set; }
        [Display(Name = "Valor Total")]
        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        public decimal ValorReal { get; set; }
        [ValidateNever]
        [Display(Name = "Observação")]
        public string Observacao { get; set; }
        [ValidateNever]
        public string NomePPid {  get; set; }
        public int PpId { get; set; }
        [Display(Name = "Data de Vencimento")]
        public DateOnly DataVencimento { get; set; }
        [ValidateNever]
        public List<SelectListItem> ListaPrecoPublicos { get; set; }
        public CreateModelView() { }

    }
}
