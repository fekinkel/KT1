﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Guia
{
    public class DeleteModel : PageModel
    {
        private readonly WebBoletoPP.Models.BoletoPpHomologContext _context;

        public DeleteModel(WebBoletoPP.Models.BoletoPpHomologContext context)
        {
            _context = context;
        }

        [BindProperty]
      public PpGuia PpGuia { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.PpGuias == null)
            {
                return NotFound();
            }

            var ppguia = await _context.PpGuias.FirstOrDefaultAsync(m => m.IdGuia == id);

            if (ppguia == null)
            {
                return NotFound();
            }
            else 
            {
                PpGuia = ppguia;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.PpGuias == null)
            {
                return NotFound();
            }
            var ppguia = await _context.PpGuias.FindAsync(id);

            if (ppguia != null)
            {
                PpGuia = ppguia;
                _context.PpGuias.Remove(PpGuia);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
