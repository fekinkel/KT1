﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Guia
{
    public class IndexModel : PageModel
    {
        private readonly WebBoletoPP.Models.BoletoPpHomologContext _context;
        public IndexModelView ModelView { get; set; } = default!;

        public IndexModel(WebBoletoPP.Models.BoletoPpHomologContext context)
        {
            _context = context;
            ModelView = new IndexModelView();
        }

        public IList<IndexModelView> IndexView { get; set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.PpGuias != null)
            {
                IndexView = new List<IndexModelView>();

                var ListaPpGuiaQuery =  from d in _context.PpGuias
                                        orderby d.IdGuia descending // Sort by name.
                                        where d.Login == User.Identity.Name.ToString()
                                        select new { d.IdGuia, d.NumDocumento, d.ValorGuia, d.DataVencimento, d.DataPagamento };
                var listaPP = ListaPpGuiaQuery.ToList().Take(10);

                try
                {
                    foreach (var item in listaPP)
                    {
                        var option = new IndexModelView()
                        {
                            IdGuia = item.IdGuia,
                            NumDocumento = item.NumDocumento,
                            ValorGuia = item.ValorGuia,
                            DataVencimento = DateOnly.FromDateTime(item.DataVencimento),
                            Pagamento = item.DataPagamento.HasValue? true : false 
                        };
                        IndexView.Add(option);
                    }

                }
                catch (Exception ex)
                {
                    throw;
                }
                //IndexView = listaPP;// await _context.PpGuias.ToListAsync();
            }
        }
    }

    public class IndexModelView
    {
        [Display(Name = "Guia")]
        public int IdGuia { get; set; }
        [Display(Name = "Nosso Número")]
        public string NumDocumento { get; set; }

        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Valor em R$")]
        public double ValorGuia { get; set; }
        [Display(Name = "Vencimento")]
        public DateOnly DataVencimento { get; set; }
        [Display(Name = "Pago")]
        public bool Pagamento {  get; set; }
    }
}