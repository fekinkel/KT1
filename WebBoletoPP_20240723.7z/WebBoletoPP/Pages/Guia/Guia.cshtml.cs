using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Carne
{
    [NonViewComponent]
    public class GuiaModel : PageModel
    {
        private readonly BoletoPpHomologContext _context;
        public GuiaModelView ModelView { get; set; }
        public GuiaModel(BoletoPpHomologContext context) 
        { 
            _context = context;
        }
        public void OnGet(int valIdPP)
        {
            //ModelView = BuscarDadosGuia(valIdPP);
        }
        //public GuiaModelView BuscarDadosGuia(int valIdPP)
        //{
            //if (valIdPP > 0)
            //{
                //string sSql = $"Select (Select convert(decimal(12,6), dbo.Valor_Ufir_dia(\'{DataVencimento}\')) as valorufirdia, convert(decimal(12,6), Valor_UFM) as valorufmpp, B.Descricao From PP_PRECO_PUBLICO A INNER JOIN PP_TIPO_DESCRICAO B on B.ID_TD = A.ID_TD Where ID = {valIdPP} For Json Path) as value";

                //var retorno = _context.Database.SqlQueryRaw<string>(sSql).FirstOrDefault();

                //if (retorno != null)
                //{
                    //retorno = retorno.Trim(new char[] { ']', '[' });

                    //ValorPP valPP = JsonConvert.DeserializeObject<ValorPP>(retorno);

                    //return valPP;
                //}
                //else
                //{
                    //return new ValorPP();
                //}
            //}
            //else
            //{
                //return new ValorPP();
            //}
        //}


    }
    public class GuiaModelView 
    {
        public string txtCod { get; set; }
        public string txtCodigo { get; set; }
        public string txtVencimento {  get; set; }
        public decimal txtValorUnitario { get; set; }
        public decimal txtValorTotal {  get; set; }
        public string lblQuantidade {  get; set; }
        public string txtQuantidade { get; set; }
        public GuiaModelView() { }
    }
}
