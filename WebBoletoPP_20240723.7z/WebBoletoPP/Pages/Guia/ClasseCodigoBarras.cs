﻿using Microsoft.VisualBasic; // Install-Package Microsoft.VisualBasic
using Microsoft.VisualBasic.CompilerServices; // Install-Package Microsoft.VisualBasic

public partial class ClasseCodigoBarras
{

    #region Propriedades

    private string sAgencia;
    private string sCodigoBeneficiario;
    private string sDigitoBeneficiario;
    private string sConstanteModalidade;
    private string sConstanteEmissao;

    private const string C_ORGAO_FEBRABAN = "4792";
    private const string C_PRODUTO = "8";
    private const string C_SEGMENTO = "1";


    #endregion

    #region Constructor

    public ClasseCodigoBarras(int valIdPP)
    {
        sAgencia = "2196";
        sCodigoBeneficiario = "562341";
        sDigitoBeneficiario = "";
        sConstanteModalidade = "2";
        sConstanteEmissao = "4";
    }

    #endregion

    public string I25Encode(string pNumero)
    {
        try
        {
            var asPattern = new string[10];
            string sSTART;
            string sSTOP;
            string sEncodedSTR;
            string sUnit;
            string sDigit1;
            string sDigit2;

            // Padrões de Inicio e fim 
            sSTART = "NNNN";
            sSTOP = "WNN";

            // Padrões do código de barras 
            asPattern[0] = "NNWWN";
            asPattern[1] = "WNNNW";
            asPattern[2] = "NWNNW";
            asPattern[3] = "WWNNN";
            asPattern[4] = "NNWNW";
            asPattern[5] = "WNWNN";
            asPattern[6] = "NWWNN";
            asPattern[7] = "NNNWW";
            asPattern[8] = "WNNWN";
            asPattern[9] = "NWNWN";

            if (pNumero.Length % 2 != 0)
            {
                // O número de caracteres no 
                // argumento devem ser diferentes 
                return "";
                return default;
            }

            if (!Information.IsNumeric(pNumero))
            {
                // Argumento deve ser numérico 
                return "";
                return default;
            }
            else if (Strings.InStr(pNumero, ".") != 0 | Strings.InStr(pNumero, ",") != 0)
            {
                // O argumento é numero mais contem 
                // caracteres invalidos para nós 
                return "";
                return default;
            }

            sEncodedSTR = "";

            for (int iCharRead = 1, loopTo = pNumero.Length; iCharRead <= loopTo; iCharRead += 2)
            {
                sDigit1 = asPattern[Strings.Asc(Strings.Mid(pNumero, iCharRead, 1)) - 48];
                sDigit2 = asPattern[Strings.Asc(Strings.Mid(pNumero, iCharRead + 1, 1)) - 48];

                sUnit = "";
                for (byte i = 1; i <= 5; i++)
                    sUnit = sUnit + Strings.Mid(sDigit1, i, 1) + Strings.Mid(sDigit2, i, 1);

                sEncodedSTR += sUnit;
            }
            return sSTART + sEncodedSTR + sSTOP;
        }

        catch (Exception ex)
        {
            return "";
            throw new Exception("Erro geração do código: " + ex.Message);
        }
    }

    public string Formata_Data(DateTime pData)
    {
        try
        {
            string dia = System.Threading.Thread.CurrentThread.CurrentCulture.Calendar.GetDayOfMonth(pData).ToString();
            string mes = System.Threading.Thread.CurrentThread.CurrentCulture.Calendar.GetMonth(pData).ToString();
            string ano = System.Threading.Thread.CurrentThread.CurrentCulture.Calendar.GetYear(pData).ToString();
            if (Conversions.ToDouble(dia) < 9d)
                dia = "0" + dia;
            if (Conversions.ToDouble(mes) < 9d)
                mes = "0" + mes;
            return dia + "/" + mes + "/" + ano;
        }
        catch (Exception ex)
        {
            throw new Exception("Erro formato data: " + ex.Message);
        }

    }

    public short CalcDV10(string pSequencia)
    {
        try
        {
            // Funçao para Cálculo do Dígito Verificador MÓDULO 10
            // O MÓDULO 10 é utilizado para calcular o DV do 03 primeiros campos da LINHA DIGITÁVEL

            short intCont;
            short intNum;
            var intNumT = default(short);
            short intDoisUm;

            intDoisUm = 2;
            for (intCont = (short)pSequencia.Length; intCont >= 1; intCont += -1)
            {
                // pega o algarismo da sequencia
                intNum = Conversions.ToShort(Strings.Mid(pSequencia, intCont, 1));
                intNum = (short)(intNum * intDoisUm);
                if (intNum > 9)
                {
                    intNum = (short)(Conversions.ToShort(Strings.Mid(intNum.ToString(), 1, 1)) + Conversions.ToShort(Strings.Right(intNum.ToString(), 1)));
                }
                intNumT = (short)(intNumT + intNum);
                if (intDoisUm == 2)
                {
                    intDoisUm = 1;
                }
                else
                {
                    intDoisUm = 2;
                }
            }

            if (intNumT % 10 == 0)
            {
                return 0;
            }
            else
            {
                return (short)(10 - intNumT % 10);
            }
        }
        catch (Exception ex)
        {
            return 999;
            throw new Exception("Erro dv mod10: " + ex.Message);
        }

    }

    public short CalcDV11(string pSequencia, string pStatus)
    {
        try
        {
            // Funçao para Cálculo do Dígito Verificador MODULO 11
            // O MÓDULO 11 é utilizado para calcular o DV do 04 campo da LINHA DIGITÁVEL e do NOSSO NÚMERO

            short intCont;
            short intNum;
            var intNumT = default(short);
            short intNoveDois;
            short intRetorno;

            intNoveDois = 2;
            for (intCont = (short)pSequencia.Length; intCont >= 1; intCont += -1)
            {
                intNum = Conversions.ToShort(Strings.Mid(pSequencia, intCont, 1));
                intNum = (short)(intNum * intNoveDois);
                intNumT = (short)(intNumT + intNum);
                if (intNoveDois < 9)
                {
                    intNoveDois = (short)(intNoveDois + 1);
                }
                else
                {
                    intNoveDois = 2;
                }
            }
            if (pStatus == "NN")
            {
                if (11 - intNumT % 11 > 9)
                {
                    intRetorno = 0;
                }
                else
                {
                    intRetorno = (short)(11 - intNumT % 11);
                }
            }
            else if (pStatus == "CL")
            {
                if (intNumT < 11)
                {
                    intRetorno = (short)(11 - intNumT);
                    if (intRetorno > 9)
                    {
                        intRetorno = 0;
                    }
                }
                else if (11 - intNumT % 11 > 9)
                {
                    intRetorno = 0;
                }
                else
                {
                    intRetorno = (short)(11 - intNumT % 11);
                }
            }
            else if (11 - intNumT % 11 <= 1 | 11 - intNumT % 11 > 9)
            {
                intRetorno = 1;
            }
            else
            {
                intRetorno = (short)(11 - intNumT % 11);
            }
            return intRetorno;
        }
        catch (Exception ex)
        {
            return 999;
            throw new Exception("Erro dv mod11: " + ex.Message);
        }

    }

    public short calcula_DV_CodBarras(string pSequencia)
    {
        try
        {
            short fator = 2;
            short total = 0;
            short numero;
            short resto;
            short resultado;

            for (short i = 43; i >= 1; i += -1)
            {
                numero = Conversions.ToShort(Strings.Mid(pSequencia, i, 1));
                if (fator > 9)
                {
                    fator = 2;
                }
                numero = (short)(numero * fator);
                total = (short)(total + numero);
                fator = (short)(fator + 1);
            }
            resto = (short)(total % 11);
            resultado = (short)(11 - resto);
            if (resultado == 10 | resultado == 0)
            {
                return 1;
            }
            else
            {
                return resultado;
            }
        }
        catch (Exception ex)
        {
            return 999;
            throw new Exception("Erro dv cod.barras: " + ex.Message);
        }

    }

    public string FatorVenc(DateTime pVencimento)
    {
        try
        {
            var dtDataBase = DateAndTime.DateSerial(1997, 10, 7);

            return DateAndTime.DateDiff(DateInterval.Day, dtDataBase, pVencimento).ToString();
        }

        catch (Exception ex)
        {
            return 0.ToString();
            throw new Exception("Erro fator vencimento: " + ex.Message);
        }

    }

    public string CodBarras(double pValor, string pVencto, string pCampoLivre, string pBanco = "104")
    {
        try
        {
            // Funçao para Cálculo do dígito do código de barras
            // Forma-se o código de Barras da seguinte maneira:
            // 01 -> 03 (3): Banco (001 - Banco do Brasil)
            // 04 -> 04 (1): Moeda (9 - Real)
            // 05 -> 05 (1): DV (Dígito verificador módulo 11)
            // 06 -> 19 (12,2): Valor (Ex.: 14150 - sem vírgula decimal, Lê-se 141,50)
            // 20 -> 44 (25): Campo Livre (O conteúdo dependerá do banco)

            string strBanco = pBanco;
            string strMoeda = "9";
            string strSequencia;
            string strDv;
            string strCampoLivre;
            long dblValor;

            // Monta a Sequência
            dblValor = (long)Math.Round(pValor * 100d);
            if (Strings.Len(pCampoLivre) < 25)
            {
                strCampoLivre = pCampoLivre.Trim().PadLeft(25, '0');
            }
            else if (Strings.Len(pCampoLivre) > 25)
            {
                strCampoLivre = Strings.Mid(pCampoLivre, 1, 11) + Strings.Mid(pCampoLivre, 13, 14);
            }
            else
            {
                strCampoLivre = "0000000000000000000000000";
            }
            strSequencia = strBanco + strMoeda + FatorVenc(Conversions.ToDate(pVencto)) + dblValor.ToString("0000000000") + strCampoLivre;

            // Calcula o dígito de Autoconferência do Código de Barras
            strDv = CalcDV11(strSequencia, "CB").ToString();

            return Strings.Mid(strSequencia, 1, 4) + strDv + Strings.Right(strSequencia, 39);
        }
        catch (Exception ex)
        {
            return "";
            throw new Exception("Erro montando código de barras: " + ex.Message);
        }

    }

    public string LinhaDig(string pSequencia)
    {
        try
        {
            // Funçao para Cálculo da linha digitável
            // Recebe  "000000000", "0000000000", "0000000000", "0", "000.00"
            // retorna "00000.0000X 00000.00000X 00000.00000X Y 000"
            string strSeq1;
            string strSeq2;
            string strSeq3;
            string strSeq4;
            string strSeq5;
            string strSequencia = pSequencia;

            // Separa as sequências
            strSeq1 = Strings.Mid(strSequencia, 1, 4) + Strings.Mid(strSequencia, 20, 5);
            strSeq1 = strSeq1 + CalcDV10(strSeq1).ToString();
            strSeq2 = Strings.Mid(strSequencia, 25, 10);
            strSeq2 = strSeq2 + CalcDV10(strSeq2).ToString();
            strSeq3 = Strings.Mid(strSequencia, 35, 10);
            strSeq3 = strSeq3 + CalcDV10(strSeq3).ToString();
            strSeq4 = Strings.Mid(strSequencia, 5, 1);
            strSeq5 = Strings.Mid(strSequencia, 6, 4) + Strings.Mid(strSequencia, 10, 10);

            // Calcula e formata os  dígitos verificadores da Linha Digitável e Valor
            strSeq1 = Strings.Mid(strSeq1, 1, 5) + "." + Strings.Mid(strSeq1, 6, 5);
            strSeq2 = Strings.Mid(strSeq2, 1, 5) + "." + Strings.Mid(strSeq2, 6, 6);
            strSeq3 = Strings.Mid(strSeq3, 1, 5) + "." + Strings.Mid(strSeq3, 6, 6);
            return strSeq1 + " " + strSeq2 + " " + strSeq3 + " " + strSeq4 + " " + strSeq5;
        }

        catch (Exception ex)
        {
            return "";
            throw new Exception("Erro linha digitável: " + ex.Message);
        }

    }

    public string LinhaDigSigCB(string pSequencia)
    {
        try
        {
            // Funçao para Cálculo da linha digitável
            // Recebe  "0000000000", "0000000000", "0000000000", "0000000000"
            // retorna "0000000000-X  0000000000-X  0000000000-X  0000000000-X"
            string strSeq1;
            string strSeq2;
            string strSeq3;
            string strSeq4;
            string strSequencia = pSequencia;

            // Separa as sequências
            strSeq1 = Strings.Mid(strSequencia, 1, 11);
            strSeq1 = strSeq1 + "-" + CalcDV10(strSeq1).ToString();
            strSeq2 = Strings.Mid(strSequencia, 12, 11);
            strSeq2 = strSeq2 + "-" + CalcDV10(strSeq2).ToString();
            strSeq3 = Strings.Mid(strSequencia, 23, 11);
            strSeq3 = strSeq3 + "-" + CalcDV10(strSeq3).ToString();
            strSeq4 = Strings.Mid(strSequencia, 34, 11);
            strSeq4 = strSeq4 + "-" + CalcDV10(strSeq4).ToString();

            // Calcula e formata os  dígitos verificadores da Linha Digitável e Valor
            return strSeq1 + " " + strSeq2 + " " + strSeq3 + " " + strSeq4 ;
        }

        catch (Exception ex)
        {
            return "";
            throw new Exception("Erro linha digitável: " + ex.Message);
        }

    }
    #region Montagem da estrutura de Boleto de Cobrança CEF 16 posições

    /// <summary>
    /// Para uso com boleto bancário da CEF
    /// </summary>
    /// <param name="pSequencia"></param>
    /// <returns></returns>
    /// <remarks></remarks>
    public string NossoNumero(string pSequencia)
    {
        try
        {
            const string CodCli = "00062";
            const string CnpjAg = "2196";
            const string CodCar = "8";
            const string CodCon = "7";
            const string CodIni = "8";

            string strSequencia;
            strSequencia = CodIni + pSequencia.Trim().PadLeft(14, '0');

            return CodCli + CnpjAg + CodCar + CodCon + strSequencia + CalcDV11(strSequencia, "NN").ToString();
        }
        catch (Exception ex)
        {
            return "";
            throw new Exception("Erro nosso número: " + ex.Message);
        }
    }
    #endregion


    #region Montagem da estrutura de Boleto de Cobrança CEF SIGCB

    /// <summary>
    /// Funçao para Montar e Calcular o digito do codigo de barras de acordo com o padrao CEF SIGCB
    /// </summary>
    /// <param name="pValor">Valor do Documento</param>
    /// <param name="pVencto">Data de Vencimento</param>
    /// <param name="pIdentificador">Numero do Documento</param>
    /// <returns></returns>
    public string CodBarrasSIGCB(decimal pValor, DateTime pVencto, string pIdentificador)
    {
        try
        {
            string sBanco = "104";
            string sMoeda = "9";
            string sSequencia;
            string sDv;
            string sCampoLivre;
            long nValor = 0L;
            // Monta a Sequencia
            nValor = (long)Math.Round(pValor * 100m);
            if (pIdentificador.Length <= 15)
            {
                pIdentificador = pIdentificador.PadLeft(15, '0');
            }
            else
            {
                throw new Exception("Nosso Número inválido !");
            }
            sCampoLivre = sCodigoBeneficiario + CalcDV11(sCodigoBeneficiario, "CL").ToString() + pIdentificador.Substring(0, 3) + sConstanteModalidade + pIdentificador.Substring(3, 3) + sConstanteEmissao + pIdentificador.Substring(6, 9);




            sCampoLivre = sCampoLivre + CalcDV11(sCampoLivre, "CL").ToString();
            sSequencia = sBanco + sMoeda + FatorVenc(pVencto) + nValor.ToString("0000000000") + sCampoLivre;


            // Calcula o digito de Autoconferencia do Codigo de Barras
            sDv = Convert.ToString(CalcDV11(sSequencia, "CB"));

            return sSequencia.Substring(0, 4) + sDv + sSequencia.Substring(4, 39);
        }

        catch (Exception ex)
        {
            throw new Exception("Erro montando código de barras: " + ex.Message);
        }
    }

    /// <summary>
    /// Funcao para Montar e Calcular o digito do nosso numero de acordo com o padrao CEF SIGCB
    /// </summary>
    /// <param name="pIdentificador"></param>
    /// <returns></returns>
    public string NossoNumeroSIGCB(string pIdentificador)
    {
        try
        {
            string sSequencia;
            if (pIdentificador.Length <= 15)
            {
                pIdentificador = pIdentificador.PadLeft(15, '0');
            }
            else
            {
                throw new Exception("Identificador Inválido");
            }
            sSequencia = sConstanteModalidade + sConstanteEmissao + pIdentificador;
            return sSequencia + Convert.ToString(CalcDV11(sSequencia, "NN"));
        }
        catch (Exception ex)
        {
            throw new Exception("Erro nosso número: " + ex.Message);
        }
    }


    #endregion


    #region Montagem da estrutura de Boleto de Cobrança Banco do Brasil 17 posições - Carteira 18 (Nº Convenio 7 posições)
    /// <summary>
    /// Para uso com boleto bancário do Banco do Brasil
    /// </summary>
    /// <param name="pSequencia"></param>
    /// <returns></returns>
    /// <remarks></remarks>
    public string NossoNumeroBB(string pSequencia)
    {
        try
        {
            string strConvenio6posicoes = "000000";
            string strConvenio7posicoes = "999999";
            string strSequencia;
            strSequencia = strConvenio6posicoes + pSequencia.Trim().PadLeft(17, '0');

            return strSequencia;
        }
        catch (Exception ex)
        {
            return "";
            throw new Exception("Erro nosso número Banco do Brasil: " + ex.Message);
        }
    }


    #endregion

    #region Montagem da estrutura da Guia de Arrecadaçãoo de Tributos - Versão 4

    public string CodBarrasArrecadacaoV4(double pValor, DateTime pVencto, string pIdentificador)
    {
        string sSequencia;
        string sDv;
        string sCampoLivre;
        long nValor;
        string dataVencimento;
        string identificacaoValor = "6";
        // Monta a Sequencia
        nValor = (long)Math.Round(pValor * 100d);
        if (pIdentificador.Length <= 17)
        {
            pIdentificador = pIdentificador.PadLeft(17, '0');
        }
        else
        {
            return "0";
        }
        dataVencimento = pVencto.Year.ToString() + pVencto.Month.ToString().PadLeft(2, '0') + pVencto.Day.ToString().PadLeft(2, '0');

        sCampoLivre = dataVencimento + pIdentificador;

        sSequencia = C_PRODUTO + C_SEGMENTO + identificacaoValor + Strings.Format(nValor, "00000000000") + C_ORGAO_FEBRABAN + sCampoLivre;





        sDv = CalcDV10(sSequencia).ToString();

        return sSequencia.Substring(0, 3) + sDv.ToString().Trim() + sSequencia.Substring(3, 40);

    }

    public List<string> RepresentacaoArrecadacaoV4(string strSequencia)
    {
        string strSeq1, strSeq2, strSeq3, strSeq4;
        var blocoNumerico = new List<string>();

        // Separa as sequências
        strSeq1 = strSequencia.Substring(0, 11);
        strSeq2 = strSequencia.Substring(11, 11);
        strSeq3 = strSequencia.Substring(22, 11);
        strSeq4 = strSequencia.Substring(33, 11);

        // Calcula e formata os  dígitos verificadores da Linha Digitável e Valor
        blocoNumerico.Add(strSeq1 + "-" + CalcDV10(strSeq1).ToString().Trim());
        blocoNumerico.Add(strSeq2 + "-" + CalcDV10(strSeq2).ToString().Trim());
        blocoNumerico.Add(strSeq3 + "-" + CalcDV10(strSeq3).ToString().Trim());
        blocoNumerico.Add(strSeq4 + "-" + CalcDV10(strSeq4).ToString().Trim());

        return blocoNumerico;

    }

 
    #endregion


}