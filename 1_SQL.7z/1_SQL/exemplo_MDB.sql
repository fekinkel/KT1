select *--chvloclog, MIN(ceplog),max(ceplog)
from OPENROWSET('Microsoft.Jet.OLEDB.4.0', 'C:\1_Geral\Correios\GPB.MDB';;, [Tabela LogRS])
--group by chvloclog
order by chvbailog1

select * 
from OPENROWSET('Microsoft.Jet.OLEDB.4.0', 'C:\1_Geral\Correios\GPB.MDB';;, [Tabela de Bairros])
where UFBAI = 'RS'

--66389
select * 
from OPENROWSET('Microsoft.Jet.OLEDB.4.0', 'C:\1_Geral\Correios\GPB.MDB';;, [Tabela de Localidades])
where dr_local = 'RS'
order by chaveloc
