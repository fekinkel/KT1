select MTSW_SUBL
from MTSW
where MTSW_ANO = 2013
		and MTSW_MTAL = 'separa'
group by MTSW_SUBL
order by MTSW_SUBL desc

select *
from MTSW
where MTSW_ANO = 2013
		and MTSW_MTAL = 'separa'
		and MTSW_SUBL like '3/RCNF/001/9991/%'
