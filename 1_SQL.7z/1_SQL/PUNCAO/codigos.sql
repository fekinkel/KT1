
--5520
select *
from punc
where PUNC_MTPR_COD in(select mtpr_cod from mtpr)
--1451
select PUNC_MTPR_COD, *
from punc
where PUNC_MTPR_COD not in(select mtpr_cod from mtpr)
and len(PUNC_MTPR_COD) >= 5
--2970
select PUNC_MTPR_COD, *
from punc
where PUNC_MTPR_COD not in(select mtpr_cod from mtpr)
and len(PUNC_MTPR_COD) < 5
--1099


select *--PUNC_MDLB, PUNC_PREB--, fmt_PuncCodOld3(PUNC_PREB, PUNC_MDLB, PUNC_DIAB, PUNC_LENB, )
from punc
where PUNC_CODB LIKE 'DB-HMCB%'
--PUNC_MDLB in ('PCI','PCM')
ORDER BY PUNC_CODB

