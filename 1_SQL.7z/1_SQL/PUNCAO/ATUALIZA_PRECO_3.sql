/*
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
declare @open varchar(400)
--SET @PATH = N'\\192.168.3.3\Disco_W_TI'
SET @PATH = N'\\192.168.3.85\1_Delphi'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

set @dir='N:\Temp\'

set @pla='Lista_preco.xls'--MX_punc_v212_header.
set @aba='precos bl antes do ajuste'
--set @aba='Mexico list'
print @open IF OBJECT_ID('TempDB.dbo.##pre') IS NOT NULL DROP TABLE ##preset @sql = 'SELECT *'
set @sql = @sql +'into ##pre'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'

EXEC (@SQL)

select *from ##pre

Exec xp_cmdshell 'net use N: /delete'

*/


--147 TOTAL
select a.*, MTPC_PRE
--update [192.168.4.2\sqlexpress].[MDLMEX].[dbo].mtpc set mtpc_pre = mtpc_pre_old, mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--from #pre a, mtpc
--from #pre a, [192.168.3.40].[punc].[dbo].mtpc
from ##pre a, [192.168.4.2\sqlexpress].[MDLMEX].[dbo].mtpc
where mtpc_cod = [Producto antigo] collate SQL_Latin1_General_CP1_CI_AS
and [Preco novo] <>	MTPC_PRE

select a.*, MTPC_PRE
--update [192.168.4.2\sqlexpress].[MDLMEX].[dbo].mtpc set mtpc_pre = [Preco novo], mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--from #pre a, mtpc
--from #pre a, [192.168.3.40].[punc].[dbo].mtpc
from ##pre a, [192.168.4.2\sqlexpress].[MDLMEX].[dbo].mtpc
where mtpc_cod = [Cod novo] collate SQL_Latin1_General_CP1_CI_AS
and [Preco novo] <>	MTPC_PRE


select a.*--, MTPC_PRE
--update [192.168.4.2\sqlexpress].[MDLMEX].[dbo].mtpc set mtpc_pre = mtpc_pre_old, mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--from #pre a, mtpc
--from #pre a, [192.168.3.40].[punc].[dbo].mtpc
from ##pre a
where [Cod novo] collate SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT MTPC_COD FROM [192.168.4.2\sqlexpress].[MDLMEX].[dbo].mtpc)
--and [Preco novo] <>	MTPC_PRE
