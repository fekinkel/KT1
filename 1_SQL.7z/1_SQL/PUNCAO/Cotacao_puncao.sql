--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 14/03/2017--ASSUNTO      : COTA��ES MEXICO--DEPARTAMENTO : COTA�OES DO C�DIGO ANTIGO PARA O C�DIGO NOVO------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#CPCT') IS NOT NULL DROP TABLE #CPCTSELECT *, CPCT_COD CPCT_COD_OLD, IDENTITY(INT,1,1) NUM INTO #CPCT FROM CPCT WHERE 1 = 0INSERT INTO #CPCTSELECT 		CPCT_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') E(C�digo do estabelecimento)
	, CPCT_SIDO = CONVERT(varchar(4),'CPCT')      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPCT_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPCT_COD = CONVERT(int,'0')      --CONVERT(int(3),'') N�mero(N�mero da cota��o de compra)
	, CPCT_STA = CONVERT(char(2),'OK')      --CONVERT(char(2),'') Status(Situa��o da cota��o (EA, OK))
	, CPCT_CPSC_SIES --= Null      --CONVERT(int(6),'') E.(C�digo do estabelecimento)
	, CPCT_CPSC_SIDO --= Null      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPCT_CPSC_SISE --= Null      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPCT_CPSC_NPAI --= Null      --CONVERT(int(6),'') Solicita��o(N�mero da Solicita��o de Compra)
	, CPCT_CPSC --= Null      --CONVERT(int(3),'') Item(Item da solicita��o de compra)
	, CPCT_MTPR = CONVERT(varchar(20),PUNC_CODB)      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, CPCT_MTPC = CONVERT(varchar(20),PUNC_CODB)      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, CPCT_ESPE --= Null      --CONVERT(varchar(6000),'') Especifica��es(Especifica��es complementares do insumo)
	, CPCT_GLTX --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tipo(Indica o tipo do parceiro (cliente, fornecedor, etc...))
	, CPCT_GLXX --= CONVERT(int(6),'')      --CONVERT(int(6),'') Fornecedor(C�digo do parceiro)
	, CPCT_GLXX_DIG --= CONVERT(int(3),'')      --CONVERT(int(3),'') Digito(Digito do C�digo do Fornecedor)
	, CPCT_GLXX_GLPA --= CONVERT(int(6),'')      --CONVERT(int(6),'') C�d.Parceiro(C�digo do parceiro)
	, CPCT_GLXX_NRDZ --= Null      --CONVERT(varchar(15),'') Apelido(Nome reduzido (apelido) do Parceiro)
	, CPCT_REV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Destina��o(Define se item � para consumo (N) , revenda (S), revenda equiparada (E) ou industrializacao (I))
	, CPCT_QTD --= Null      --CONVERT(decimal(12),'') Quantidade(Quantidade total do item da cota��o)
	, CPCT_QTD_GLFO --= Null      --CONVERT(decimal(12),'') Qtd.Forn.(Quantidade cotada do item na unidade do fornecedor)
	, CPCT_CTO --= Null      --CONVERT(varchar(25),'') Contato(Nome do contato do fornecedor p/ a cota��o)
	, CPCT_TEL --= Null      --CONVERT(varchar(25),'') Fone(Telefone do fornecedor para a cota��o)
	, CPCT_FAX --= Null      --CONVERT(varchar(25),'') Fax(Fax do fornecedor para a cota��o)
	, CPCT_EMAIL --= Null      --CONVERT(varchar(50),'') Email(Email do fornecedor para a cota��o)
	, CPCT_GLCP --= CONVERT(int(6),'')      --CONVERT(int(6),'') Comprador(C�digo do comprador)
	, CPCT_CPID --= Null      --CONVERT(varchar(20),'') Ref. Forn.(C�digo utilizado pelo fornecedor do produto ou insumo)
	, CPCT_CPUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Un.Forn.(C�digo da unidade do insumo utilizado pelo fornecedor)
	, CPCT_CPFT --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do insumo em rela��o a unidade do fornecedor)
	, CPCT_PUN --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial expresso na moeda da cota��o)
	, CPCT_PUN_GLFO --= Null      --CONVERT(decimal(12),'') Pre�o Un. Forn.(Valor unit�rio do produto comercial na unidade do fornecedor)
	, CPCT_PUND --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o c/ Desc.(Valor unit�rio do produto comercial com desconto expresso na moeda da cota��o)
	, CPCT_PUND_GLFO --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.(Valor unit�rio do produto comercial com desconto na unidade do fornecedo)
	, CPCT_VACT = CONVERT(int,'9999')      --CONVERT(int(3),'') Validade (dias)(Validade do pre�o do fornecedor em dias)
	, CPCT_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, CPCT_IPI_ALI --= Null      --CONVERT(decimal(5),'') % IPI(Al�quota de IPI)
	, CPCT_ISS_ALI --= Null      --CONVERT(decimal(5),'') % ISS(Al�quota de ISS)
	, CPCT_ICM_ALI --= Null      --CONVERT(decimal(5),'') % ICMS(Al�quota de ICMS)
	, CPCT_VALT --= Null      --CONVERT(decimal(12),'') Total c/ IPI(Total com descontos e IPI)
	, CPCT_GLPG --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Pagamento(C�digo da condi��o de pagamento)
	, CPCT_PENT --= CONVERT(int(3),'')      --CONVERT(int(3),'') Entrega (dias �teis)(Prazo de entrega em dias �teis)
	, CPCT_DOCF = 'REF.03/2017'--Null      --CONVERT(varchar(20),'') Doc.Fornec.(Documento do fornecedor origem da cota��o)
	, CPCT_OBS = 'COPIA DO ITEM '+CPCT_MTPR+' DA COTA��O ANTERIOR '+CONVERT(VARCHAR(6),CPCT_COD)+'.'      --CONVERT(varchar(255),'') Obs.(Observa��o do item)
	, CPCT_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, CPCT_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em(Data de cadastro do registro)
	, CPCT_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, CPCT_DTU = Null      --CONVERT(datetime(10),'') Em(Data da �ltima atualiza��o do registro)
	, CPCT_CPID_NOM = Null      --CONVERT(varchar(50),'') Nome For.(Nome do insumo atribu�do pelo fornecedor)
	, CPCT_COD
	--SELECT *
FROM CPCT, MTPR, PUNC
WHERE CPCT_MTPR = MTPR_COD
AND MTPR_MTDV IN ('05', '06')
AND CPCT_STA = 'OK'
AND CPCT_MTPR = PUNC_MTPR_COD
AND CPCT_GLXX = 24AND PUNC_MTPR_MTTP = 'PA-PRODUCTO ACABADO'INSERT INTO #CPCTSELECT 		CPCT_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') E(C�digo do estabelecimento)
	, CPCT_SIDO = CONVERT(varchar(4),'CPCT')      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPCT_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPCT_COD = CONVERT(int,'0')      --CONVERT(int(3),'') N�mero(N�mero da cota��o de compra)
	, CPCT_STA = CONVERT(char(2),'OK')      --CONVERT(char(2),'') Status(Situa��o da cota��o (EA, OK))
	, CPCT_CPSC_SIES --= Null      --CONVERT(int(6),'') E.(C�digo do estabelecimento)
	, CPCT_CPSC_SIDO --= Null      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPCT_CPSC_SISE --= Null      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPCT_CPSC_NPAI --= Null      --CONVERT(int(6),'') Solicita��o(N�mero da Solicita��o de Compra)
	, CPCT_CPSC --= Null      --CONVERT(int(3),'') Item(Item da solicita��o de compra)
	, CPCT_MTPR = CONVERT(varchar(20),STUFF(PUNC_CODB,7,1,'1'))      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, CPCT_MTPC = CONVERT(varchar(20),PUNC_CODB)      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, CPCT_ESPE --= Null      --CONVERT(varchar(6000),'') Especifica��es(Especifica��es complementares do insumo)
	, CPCT_GLTX --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tipo(Indica o tipo do parceiro (cliente, fornecedor, etc...))
	, CPCT_GLXX --= CONVERT(int(6),'')      --CONVERT(int(6),'') Fornecedor(C�digo do parceiro)
	, CPCT_GLXX_DIG --= CONVERT(int(3),'')      --CONVERT(int(3),'') Digito(Digito do C�digo do Fornecedor)
	, CPCT_GLXX_GLPA --= CONVERT(int(6),'')      --CONVERT(int(6),'') C�d.Parceiro(C�digo do parceiro)
	, CPCT_GLXX_NRDZ --= Null      --CONVERT(varchar(15),'') Apelido(Nome reduzido (apelido) do Parceiro)
	, CPCT_REV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Destina��o(Define se item � para consumo (N) , revenda (S), revenda equiparada (E) ou industrializacao (I))
	, CPCT_QTD --= Null      --CONVERT(decimal(12),'') Quantidade(Quantidade total do item da cota��o)
	, CPCT_QTD_GLFO --= Null      --CONVERT(decimal(12),'') Qtd.Forn.(Quantidade cotada do item na unidade do fornecedor)
	, CPCT_CTO --= Null      --CONVERT(varchar(25),'') Contato(Nome do contato do fornecedor p/ a cota��o)
	, CPCT_TEL --= Null      --CONVERT(varchar(25),'') Fone(Telefone do fornecedor para a cota��o)
	, CPCT_FAX --= Null      --CONVERT(varchar(25),'') Fax(Fax do fornecedor para a cota��o)
	, CPCT_EMAIL --= Null      --CONVERT(varchar(50),'') Email(Email do fornecedor para a cota��o)
	, CPCT_GLCP --= CONVERT(int(6),'')      --CONVERT(int(6),'') Comprador(C�digo do comprador)
	, CPCT_CPID --= Null      --CONVERT(varchar(20),'') Ref. Forn.(C�digo utilizado pelo fornecedor do produto ou insumo)
	, CPCT_CPUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Un.Forn.(C�digo da unidade do insumo utilizado pelo fornecedor)
	, CPCT_CPFT --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do insumo em rela��o a unidade do fornecedor)
	, CPCT_PUN --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial expresso na moeda da cota��o)
	, CPCT_PUN_GLFO --= Null      --CONVERT(decimal(12),'') Pre�o Un. Forn.(Valor unit�rio do produto comercial na unidade do fornecedor)
	, CPCT_PUND --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o c/ Desc.(Valor unit�rio do produto comercial com desconto expresso na moeda da cota��o)
	, CPCT_PUND_GLFO --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.(Valor unit�rio do produto comercial com desconto na unidade do fornecedo)
	, CPCT_VACT = CONVERT(int,'9999')      --CONVERT(int(3),'') Validade (dias)(Validade do pre�o do fornecedor em dias)
	, CPCT_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, CPCT_IPI_ALI --= Null      --CONVERT(decimal(5),'') % IPI(Al�quota de IPI)
	, CPCT_ISS_ALI --= Null      --CONVERT(decimal(5),'') % ISS(Al�quota de ISS)
	, CPCT_ICM_ALI --= Null      --CONVERT(decimal(5),'') % ICMS(Al�quota de ICMS)
	, CPCT_VALT --= Null      --CONVERT(decimal(12),'') Total c/ IPI(Total com descontos e IPI)
	, CPCT_GLPG --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Pagamento(C�digo da condi��o de pagamento)
	, CPCT_PENT --= CONVERT(int(3),'')      --CONVERT(int(3),'') Entrega (dias �teis)(Prazo de entrega em dias �teis)
	, CPCT_DOCF = 'REF.03/2017'--Null      --CONVERT(varchar(20),'') Doc.Fornec.(Documento do fornecedor origem da cota��o)
	, CPCT_OBS = 'COPIA DO ITEM '+CPCT_MTPR+' DA COTA��O ANTERIOR '+CONVERT(VARCHAR(6),CPCT_COD)+'.'      --CONVERT(varchar(255),'') Obs.(Observa��o do item)
	, CPCT_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, CPCT_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em(Data de cadastro do registro)
	, CPCT_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, CPCT_DTU = Null      --CONVERT(datetime(10),'') Em(Data da �ltima atualiza��o do registro)
	, CPCT_CPID_NOM = Null      --CONVERT(varchar(50),'') Nome For.(Nome do insumo atribu�do pelo fornecedor)
	, CPCT_COD
	--SELECT *
FROM CPCT, MTPR, PUNC
WHERE CPCT_MTPR = MTPR_COD
AND MTPR_MTDV IN ('05', '06')
AND CPCT_STA = 'OK'
AND CPCT_MTPR = PUNC_MTPR_COD
AND CPCT_GLXX = 24AND PUNC_MTPR_MTTP <> 'PA-PRODUCTO ACABADO'INSERT INTO CPCTSELECT CPCT_SIES ,CPCT_SIDO ,CPCT_SISE ,NUM+12524 CPCT_COD ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC ,CPCT_MTPR ,CPCT_MTPC ,CPCT_ESPE ,CPCT_GLTX ,CPCT_GLXX ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ ,CPCT_REV ,CPCT_QTD ,CPCT_QTD_GLFO ,CPCT_CTO ,CPCT_TEL ,CPCT_FAX ,CPCT_EMAIL ,CPCT_GLCP ,CPCT_CPID ,CPCT_CPUN ,CPCT_CPFT ,CPCT_PUN ,CPCT_PUN_GLFO ,CPCT_PUND ,CPCT_PUND_GLFO ,CPCT_VACT ,CPCT_GLMD ,CPCT_IPI_ALI ,CPCT_ISS_ALI ,CPCT_ICM_ALI ,CPCT_VALT ,CPCT_GLPG ,CPCT_PENT ,CPCT_DOCF ,CPCT_OBS ,CPCT_USC ,CPCT_DTC ,CPCT_USU ,CPCT_DTU ,CPCT_CPID_NOMFROM #CPCTWHERE CPCT_MTPR NOT IN (SELECT CPCT_MTPR FROM CPCT)
--CPCT_SIES ,CPCT_SIDO ,CPCT_SISE ,CPCT_COD ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC ,CPCT_MTPR ,CPCT_MTPC ,CPCT_ESPE ,CPCT_GLTX ,CPCT_GLXX ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ ,CPCT_REV ,CPCT_QTD ,CPCT_QTD_GLFO ,CPCT_CTO ,CPCT_TEL ,CPCT_FAX ,CPCT_EMAIL ,CPCT_GLCP ,CPCT_CPID ,CPCT_CPUN ,CPCT_CPFT ,CPCT_PUN ,CPCT_PUN_GLFO ,CPCT_PUND ,CPCT_PUND_GLFO ,CPCT_VACT ,CPCT_GLMD ,CPCT_IPI_ALI ,CPCT_ISS_ALI ,CPCT_ICM_ALI ,CPCT_VALT ,CPCT_GLPG ,CPCT_PENT ,CPCT_DOCF ,CPCT_OBS ,CPCT_USC ,CPCT_DTC ,CPCT_USU ,CPCT_DTU ,CPCT_CPID_NOM ,

SELECT *
--UPDATE CPCT SET CPCT_STA = 'EC'
FROM CPCT a, #CPCT b
WHERE a.CPCT_COD = b.CPCT_COD_OLD
AND a.CPCT_SISE = '001'

--387