/*
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
declare @open varchar(400)
SET @PATH = N'\\192.168.3.3\Disco_W_TI'
--SET @PATH = N'\\192.168.3.85\1_Delphi'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
--set @dir_perfil = 'Atual\Seamonkey\Perfis\'
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

--set @dir='F:\smrasp\_des\puncao\anexos\'
set @dir='N:\Temp\'
--set @pla='MX_punc_v212_header.xlsx'--MX_punc_v212_header.
--set @pla='MX punch menu for S2R with restrictions v2.25-1.xlsx'--MX_punc_v212_header.
set @pla='punc_cod_without_equivalenceV3-1.xlsx'--MX_punc_v212_header.
set @aba='plan1'
--set @aba='Mexico list'
print @open IF OBJECT_ID('TempDB.dbo.##pre') IS NOT NULL DROP TABLE ##preset @sql = 'SELECT *'
set @sql = @sql +'into ##pre'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'

EXEC (@SQL)

select *from ##pre

Exec xp_cmdshell 'net use N: /delete'

*/


IF OBJECT_ID('TempDB.dbo.#pre') IS NOT NULL DROP TABLE #preselect cod MTPC_COD_OLD, MTPC_PRE MTPC_PRE_OLD, F5 MTPC_COD_NEW, 0.00 MTPC_PRE_NEW
into #pre
from ##pre a, MTPC b--, MTPC c 
where cod collate SQL_Latin1_General_CP1_CI_AS = b.mtpc_mtpr
and b.mtpc_pre between 0.01 and 9998
and F5 collate SQL_Latin1_General_CP1_CI_AS is not null
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'Compri%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'CREAT%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'Kit%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'MX V%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'Codigo%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'Medir%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'Need%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'JA FOI%'
and F5 collate SQL_Latin1_General_CP1_CI_AS not like 'EM Es%'

--select * from #pre
--and F5 collate SQL_Latin1_General_CP1_CI_AS = c.mtpc_cod  


--147 TOTAL
select a.*, MTPC_PRE
--update mtpc set mtpc_pre = mtpc_pre_old, mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--update [192.168.3.40].[punc].[dbo].mtpc set mtpc_pre = mtpc_pre_old, mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--from #pre a, mtpc
from #pre a, [192.168.3.40].[punc].[dbo].mtpc
where mtpc_cod = mtpc_cod_new collate SQL_Latin1_General_CP1_CI_AS

--63 EXISTE
select MTPC_COD_NEW, round(convert(decimal(12,2),substring(MTPC_COD_NEW,9,(charindex('-',MTPC_COD_NEW,9)-9)))/ 100,2,charindex('-',MTPC_COD_NEW,9)-9,charindex('-',MTPC_COD_NEW,9)-9
from #pre
where mtpc_cod_new collate SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT MTPC_COD FROM MTPC)
--76

select *
--update mtpc set mtpc_pre = mtpc_pre_old, mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--update [192.168.3.40].[punc].[dbo].mtpc set mtpc_pre = mtpc_pre_old, mtpc_pre_usu = 'KINKEL', MTPC_PRE_DTU = GETDATE()
--from #pre a, mtpc
from #pre a
where mtpc_cod_new collate SQL_Latin1_General_CP1_CI_AS not in (select mtpc_cod from [192.168.3.40].[punc].[dbo].mtpc)
