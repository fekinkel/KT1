--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 07/02/2017--ASSUNTO      : DIVIS�O ERRADA--DEPARTAMENTO : CORRIGIR AS DIVIS�O EM DUPLICIDADE------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#PRE') IS NOT NULL DROP TABLE #PRE
select substring(mtpr_cod,1, charindex('-',mtpr_cod,4)-1)PRE
INTO #PRE
from mtpr
where charindex('-',mtpr_cod)>1
and len(mtpr_cod)>7 
group by substring(mtpr_cod,1, charindex('-',mtpr_cod,4)-1)
--75
--SELECT * FROM #PRE

IF OBJECT_ID('TempDB.dbo.#CLA') IS NOT NULL DROP TABLE #CLA
select PRE, a.mtpr_mtdv, a.mtpr_mtln, a.mtpr_mtfm
INTO #CLA
from mtpr a, #PRE b
where substring(a.mtpr_cod,1,7) = PRE
and len(a.mtpr_cod)>7 
--and len(a.mtpr_mtln)=2
group by PRE, a.mtpr_mtdv, a.mtpr_mtln, a.mtpr_mtfm
order by PRE, a.mtpr_mtdv, a.mtpr_mtln, a.mtpr_mtfm

--SELECT * FROM #CLA
IF OBJECT_ID('TempDB.dbo.#DEFEITO') IS NOT NULL DROP TABLE #DEFEITO
select count(pre)QDE, pre
INTO #DEFEITO
from #cla
group by pre
having count(pre) >1

select PRE, QDE, MTPR_COD, a.mtpr_mtdv, a.mtpr_mtln, a.mtpr_mtfm, *
from mtpr a, #DEFEITO
where substring(a.mtpr_cod,1,7) = PRE
and len(a.mtpr_cod)>=6
AND QDE = 2 
and len(a.mtpr_mtln)=2
--group by substring(a.mtpr_cod,1, charindex('-',a.mtpr_cod,4)-1), a.mtpr_mtdv, a.mtpr_mtln, a.mtpr_mtfm
order by PRE, a.mtpr_mtdv, a.mtpr_mtln, a.mtpr_mtfm




