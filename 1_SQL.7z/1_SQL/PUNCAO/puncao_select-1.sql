declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
SET @PATH = N'\\192.168.3.85\1_Delphi'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
--set @dir_perfil = 'Atual\Seamonkey\Perfis\'
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

--set @dir='F:\smrasp\_des\puncao\anexos\'
set @dir='N:\Temp\'
set @pla='MX_punc_v212_header.xlsx'--MX_punc_v212_header.
set @aba='plan1'
/*
set @sql=      'select '
set @sql=@sql +' cod1,nom1,nom,dia1,len1'
set @sql=@sql +',codB,preB,mdlB,dayB       ,moeB,nomB,diaB,lenB, L2Std,L2Op1,L2Op2,MinP,MaxP,MinW,MaxPoG'
set @sql=@sql +',codS     ,mdlS,dayS       ,moeS,nomS,diaS,LenS'
set @sql=@sql +',codL	  ,mdlL,dayL       ,moeL,nomL,diaL,LenL'
set @sql=@sql +',codV	  ,mdlV,dayV1,dayV2,moeV,nomV,diaV,LenV'
set @sql=@sql +',codR	  ,mdlR,dayR1,dayR2,moeR,nomR,diaR,LenR'
set @sql=@sql +',codF	  ,mdlF,dayF       ,moeF,nomF,diaF,lenF'
set @sql=@sql +',codH	  ,mdlH,dayH1,dayH2,moeH,nomH,diaH,LenH'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'
set @sql=@sql +' where isnull(cod1,''*'')<>''*'''
*/

set @sql=      'select ''insert PUNC values(''''''+cod1+'''''''
set @sql=@sql +',''''''     +isnull(nom1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nom ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(dia1,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(len1,0) as varchar)+'''

set @sql=@sql +',''''''     +isnull(codB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(preB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomB,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaB,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenB,0) as varchar)+'''

set @sql=@sql +',''    +cast(isnull(L2Std,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(L2Op1,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(L2Op2,0) as varchar)+'''

set @sql=@sql +',''    +cast(isnull(MinP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(MaxP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(MinW,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(MaxPoG,0) as varchar)+'''+char(10)


set @sql=@sql +',''''''     +isnull(codS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomS,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaS,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenS,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomL,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaL,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenL,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayV1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayV2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomV,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaV,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenV,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayR1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayR2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomR,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaR,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenR,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomF,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaF,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenF,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayH1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayH2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomH,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaH,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenH,0) as varchar)+'''+char(10)

set @sql=@sql +',''''SqlQaSMR'''''
set @sql=@sql +', getdate()'
set @sql=@sql +', null'
set @sql=@sql +', null'

set @sql=@sql +')'''+char(10)
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'
set @sql=@sql +' where isnull(cod1,''*'')<>''*'''

/*
            insert PUNC ( PUNC_COD1, PUNC_NOM1, PUNC_NOM, PUNC_DIA1, PUNC_LEN1, PUNC_CODB, PUNC_PREB,
                    PUNC_MDLB, PUNC_DAYB, PUNC_MOEB, PUNC_NOMB, PUNC_DIAB, PUNC_LENB, PUNC_L2STD,
                    PUNC_L2OP1, PUNC_L2OP2, PUNC_MINP, PUNC_MAXP, PUNC_MINW, PUNC_MAXPOG
                    , PUNC_CODS, PUNC_MDLS, PUNC_DAYS             , PUNC_MOES, PUNC_NOMS, PUNC_DIAS, PUNC_LENS
                    , PUNC_CODL, PUNC_MDLL, PUNC_DAYL             , PUNC_MOEL, PUNC_NOML, PUNC_DIAL, PUNC_LENL
                    , PUNC_CODV, PUNC_MDLV, PUNC_DAYV1, PUNC_DAYV2, PUNC_MOEV, PUNC_NOMV, PUNC_DIAV, PUNC_LENV
                    , PUNC_CODR, PUNC_MDLR, PUNC_DAYR1, PUNC_DAYR2, PUNC_MOER, PUNC_NOMR, PUNC_DIAR, PUNC_LENR
                    , PUNC_CODF, PUNC_MDLF, PUNC_DAYF             , PUNC_MOEF, PUNC_NOMF, PUNC_DIAF, PUNC_LENF
                    , PUNC_CODH, PUNC_MDLH, PUNC_DAYH1, PUNC_DAYH2, PUNC_MOEH, PUNC_NOMH, PUNC_DIAH, PUNC_LENH
                    , PUNC_USC, PUNC_DTC, PUNC_USU, PUNC_DTU)
*/

/*
select 'insert PUNC values('''+cod1+''','''     +isnull(nom1,'')+''','''     +isnull(nom ,'')+''','    +cast(isnull(dia1,0) as varchar)+','    +cast(isnull(len1,0) as varchar)+','''     +isnull(codB,'')+''','''     +isnull(preB,'')+''','''     +isnull(mdlB,'')+''','''     +isnull(dayB,'')+''','''     +isnull(moeB,'')+''','''     +isnull(nomB,'')+''','    +cast(isnull(diaB,0) as varchar)+','    +cast(isnull(lenB,0) as varchar)+','    +cast(isnull(L2Std,0) as varchar)+','    +cast(isnull(L2Op1,0) as varchar)+','    +cast(isnull(L2Op2,0) as varchar)+','    +cast(isnull(MinP,0) as varchar)+','    +cast(isnull(MaxP,0) as varchar)+','    +cast(isnull(MinW,0) as varchar)+','    +cast(isnull(MaxPoG,0) as varchar)+'
,'''     +isnull(codS,'')+''','''     +isnull(mdlS,'')+''','''     +isnull(dayS,'')+''','''     +isnull(moeS,'')+''','''     +isnull(nomS,'')+''','    +cast(isnull(diaS,0) as varchar)+','    +cast(isnull(lenS,0) as varchar)+'
,'''     +isnull(codL,'')+''','''     +isnull(mdlL,'')+''','''     +isnull(dayL,'')+''','''     +isnull(moeL,'')+''','''     +isnull(nomL,'')+''','    +cast(isnull(diaL,0) as varchar)+','    +cast(isnull(lenL,0) as varchar)+'
,'''     +isnull(codV,'')+''','''     +isnull(mdlV,'')+''','''     +isnull(dayV1,'')+''','''     +isnull(dayV2,'')+''','''     +isnull(moeV,'')+''','''     +isnull(nomV,'')+''','    +cast(isnull(diaV,0) as varchar)+','    +cast(isnull(lenV,0) as varchar)+'
,'''     +isnull(codR,'')+''','''     +isnull(mdlR,'')+''','''     +isnull(dayR1,'')+''','''     +isnull(dayR2,'')+''','''     +isnull(moeR,'')+''','''     +isnull(nomR,'')+''','    +cast(isnull(diaR,0) as varchar)+','    +cast(isnull(lenR,0) as varchar)+'
,'''     +isnull(codF,'')+''','''     +isnull(mdlF,'')+''','''     +isnull(dayF,'')+''','''     +isnull(moeF,'')+''','''     +isnull(nomF,'')+''','    +cast(isnull(diaF,0) as varchar)+','    +cast(isnull(lenF,0) as varchar)+'
,'''     +isnull(codH,'')+''','''     +isnull(mdlH,'')+''','''     +isnull(dayH1,'')+''','''     +isnull(dayH2,'')+''','''     +isnull(moeH,'')+''','''     +isnull(nomH,'')+''','    +cast(isnull(diaH,0) as varchar)+','    +cast(isnull(lenH,0) as varchar)+'
,''SqlQaSMR'', getdate(), null, null)'
 FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=F:\smrasp\_des\puncao\anexos\MX_punc_v22_header.xlsx', 'SELECT * FROM [plan1$]') where isnull(cod1,'*')<>'*'



select 'insert PUNC values('''+cod1+''','''     +isnull(nom1,'')+''','''     +isnull(nom ,'')+''','    +cast(isnull(dia1,0) as varchar)+','    +cast(isnull(len1,0) as varchar)+','''     +isnull(codB,'')+''','''     +isnull(preB,'')+''','''     +isnull(mdlB,'')+''','''     +isnull(dayB,'')+''','''     +isnull(moeB,'')+''','''     +isnull(nomB,'')+''','    +cast(isnull(diaB,0) as varchar)+','    +cast(isnull(lenB,0) as varchar)+','    +cast(isnull(L2Std,0) as varchar)+','    +cast(isnull(L2Op1,0) as varchar)+','    +cast(isnull(L2Op2,0) as varchar)+','    +cast(isnull(MinP,0) as varchar)+','    +cast(isnull(MaxP,0) as varchar)+','    +cast(isnull(MinW,0) as varchar)+','    +cast(isnull(MaxPoG,0) as varchar)+'
,'''     +isnull(codS,'')+''','''     +isnull(mdlS,'')+''','''     +isnull(dayS,'')+''','''     +isnull(moeS,'')+''','''     +isnull(nomS,'')+''','    +cast(isnull(diaS,0) as varchar)+','    +cast(isnull(lenS,0) as varchar)+'
,'''     +isnull(codL,'')+''','''     +isnull(mdlL,'')+''','''     +isnull(dayL,'')+''','''     +isnull(moeL,'')+''','''     +isnull(nomL,'')+''','    +cast(isnull(diaL,0) as varchar)+','    +cast(isnull(lenL,0) as varchar)+'
,'''     +isnull(codV,'')+''','''     +isnull(mdlV,'')+''','''     +isnull(dayV1,'')+''','''     +isnull(dayV2,'')+''','''     +isnull(moeV,'')+''','''     +isnull(nomV,'')+''','    +cast(isnull(diaV,0) as varchar)+','    +cast(isnull(lenV,0) as varchar)+'
,'''     +isnull(codR,'')+''','''     +isnull(mdlR,'')+''','''     +isnull(dayR1,'')+''','''     +isnull(dayR2,'')+''','''     +isnull(moeR,'')+''','''     +isnull(nomR,'')+''','    +cast(isnull(diaR,0) as varchar)+','    +cast(isnull(lenR,0) as varchar)+'
,'''     +isnull(codF,'')+''','''     +isnull(mdlF,'')+''','''     +isnull(dayF,'')+''','''     +isnull(moeF,'')+''','''     +isnull(nomF,'')+''','    +cast(isnull(diaF,0) as varchar)+','    +cast(isnull(lenF,0) as varchar)+'
,'''     +isnull(codH,'')+''','''     +isnull(mdlH,'')+''','''     +isnull(dayH1,'')+''','''     +isnull(dayH2,'')+''','''     +isnull(moeH,'')+''','''     +isnull(nomH,'')+''','    +cast(isnull(diaH,0) as varchar)+','    +cast(isnull(lenH,0) as varchar)+'
,''SqlQaSMR'', getdate(), null, null)'
 FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=F:\smrasp\_des\puncao\anexos\MX_punc_v22_header.xlsx', 'SELECT * FROM [plan1$]') where isnull(cod1,'*')<>'*'
 
*/

print @sql
exec(@sql)
go


---------------------------------------------
---------------------------------------------
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
set @dir='F:\smrasp\_des\puncao\anexos\'
set @pla='MX_punc_v212_header.xlsx'
set @aba='plan1'
/*
set @sql=      'select '
set @sql=@sql +' cod1,nom1,nom,dia1,len1'
set @sql=@sql +',codB,preB,mdlB,dayB       ,moeB,nomB,diaB,lenB, L2Std,L2Op1,L2Op2,MinP,MaxP,MinW,MaxPoG'
set @sql=@sql +',codS     ,mdlS,dayS       ,moeS,nomS,diaS,LenS'
set @sql=@sql +',codL	  ,mdlL,dayL       ,moeL,nomL,diaL,LenL'
set @sql=@sql +',codV	  ,mdlV,dayV1,dayV2,moeV,nomV,diaV,LenV'
set @sql=@sql +',codR	  ,mdlR,dayR1,dayR2,moeR,nomR,diaR,LenR'
set @sql=@sql +',codF	  ,mdlF,dayF       ,moeF,nomF,diaF,lenF'
set @sql=@sql +',codH	  ,mdlH,dayH1,dayH2,moeH,nomH,diaH,LenH'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'
set @sql=@sql +' where isnull(cod1,''*'')<>''*'''
*/

set @sql=      'select ''insert PUNC values(''''''+codB+'''''''
set @sql=@sql +',''''''     +isnull(preB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomB,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaB,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenB,0) as varchar)+'''

set @sql=@sql +',''''''     +isnull(cod1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nom1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nom ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(dia1,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(len1,0) as varchar)+'''

-- Novos campos para as Matrizes
set @sql=@sql +',''    +cast(isnull(dayDHstd,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(dayDH1  ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(dayDH2  ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(mdlDHStd,0) as varchar)+'''

set @sql=@sql +',''    +cast(isnull(L2Std,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(L2Op1,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(L2Op2,0) as varchar)+'''

set @sql=@sql +',''    +cast(isnull(MinP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(MaxP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(MinW,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(MaxPoG,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomS,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaS,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenS,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomL,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaL,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenL,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayV1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayV2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomV,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaV,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenV,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayR1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayR2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomR,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaR,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenR,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomF,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaF,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenF,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayH1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayH2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomH,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaH,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenH,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomZ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaZ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenZ,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomY,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaY,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenY,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomP,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenP,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(codQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(mdlQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(dayQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(moeQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(nomQ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(diaQ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(lenQ,0) as varchar)+'''+char(10)

set @sql=@sql +',''''SqlQaSMR'''''
set @sql=@sql +', getdate()'
set @sql=@sql +', null'
set @sql=@sql +', null'

set @sql=@sql +')'''+char(10)
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'
set @sql=@sql +' where isnull(cod1,''*'')<>''*'''

/*
            insert PUNC ( PUNC_COD1, PUNC_NOM1, PUNC_NOM, PUNC_DIA1, PUNC_LEN1, PUNC_CODB, PUNC_PREB,
                    PUNC_MDLB, PUNC_DAYB, PUNC_MOEB, PUNC_NOMB, PUNC_DIAB, PUNC_LENB, PUNC_L2STD,
                    PUNC_L2OP1, PUNC_L2OP2, PUNC_MINP, PUNC_MAXP, PUNC_MINW, PUNC_MAXPOG
                    , PUNC_CODS, PUNC_MDLS, PUNC_DAYS             , PUNC_MOES, PUNC_NOMS, PUNC_DIAS, PUNC_LENS
                    , PUNC_CODL, PUNC_MDLL, PUNC_DAYL             , PUNC_MOEL, PUNC_NOML, PUNC_DIAL, PUNC_LENL
                    , PUNC_CODV, PUNC_MDLV, PUNC_DAYV1, PUNC_DAYV2, PUNC_MOEV, PUNC_NOMV, PUNC_DIAV, PUNC_LENV
                    , PUNC_CODR, PUNC_MDLR, PUNC_DAYR1, PUNC_DAYR2, PUNC_MOER, PUNC_NOMR, PUNC_DIAR, PUNC_LENR
                    , PUNC_CODF, PUNC_MDLF, PUNC_DAYF             , PUNC_MOEF, PUNC_NOMF, PUNC_DIAF, PUNC_LENF
                    , PUNC_CODH, PUNC_MDLH, PUNC_DAYH1, PUNC_DAYH2, PUNC_MOEH, PUNC_NOMH, PUNC_DIAH, PUNC_LENH
                    , PUNC_CODZ, PUNC_MDLZ, PUNC_DAYZ             , PUNC_MOEZ, PUNC_NOMZ, PUNC_DIAZ, PUNC_LENZ
                    , PUNC_CODY, PUNC_MDLY, PUNC_DAYY             , PUNC_MOEY, PUNC_NOMY, PUNC_DIAY, PUNC_LENY
                    , PUNC_CODP, PUNC_MDLP, PUNC_DAYP             , PUNC_MOEP, PUNC_NOMP, PUNC_DIAP, PUNC_LENP
                    , PUNC_CODQ, PUNC_MDLQ, PUNC_DAYQ             , PUNC_MOEQ, PUNC_NOMQ, PUNC_DIAQ, PUNC_LENQ
                    , PUNC_USC, PUNC_DTC, PUNC_USU, PUNC_DTU)
*/

/*
select 'insert PUNC values('''+cod1+''','''     +isnull(nom1,'')+''','''     +isnull(nom ,'')+''','    +cast(isnull(dia1,0) as varchar)+','    +cast(isnull(len1,0) as varchar)+','''     +isnull(codB,'')+''','''     +isnull(preB,'')+''','''     +isnull(mdlB,'')+''','''     +isnull(dayB,'')+''','''     +isnull(moeB,'')+''','''     +isnull(nomB,'')+''','    +cast(isnull(diaB,0) as varchar)+','    +cast(isnull(lenB,0) as varchar)+','    +cast(isnull(L2Std,0) as varchar)+','    +cast(isnull(L2Op1,0) as varchar)+','    +cast(isnull(L2Op2,0) as varchar)+','    +cast(isnull(MinP,0) as varchar)+','    +cast(isnull(MaxP,0) as varchar)+','    +cast(isnull(MinW,0) as varchar)+','    +cast(isnull(MaxPoG,0) as varchar)+'
,'''     +isnull(codS,'')+''','''     +isnull(mdlS,'')+''','''     +isnull(dayS,'')+''','''     +isnull(moeS,'')+''','''     +isnull(nomS,'')+''','    +cast(isnull(diaS,0) as varchar)+','    +cast(isnull(lenS,0) as varchar)+'
,'''     +isnull(codL,'')+''','''     +isnull(mdlL,'')+''','''     +isnull(dayL,'')+''','''     +isnull(moeL,'')+''','''     +isnull(nomL,'')+''','    +cast(isnull(diaL,0) as varchar)+','    +cast(isnull(lenL,0) as varchar)+'
,'''     +isnull(codV,'')+''','''     +isnull(mdlV,'')+''','''     +isnull(dayV1,'')+''','''     +isnull(dayV2,'')+''','''     +isnull(moeV,'')+''','''     +isnull(nomV,'')+''','    +cast(isnull(diaV,0) as varchar)+','    +cast(isnull(lenV,0) as varchar)+'
,'''     +isnull(codR,'')+''','''     +isnull(mdlR,'')+''','''     +isnull(dayR1,'')+''','''     +isnull(dayR2,'')+''','''     +isnull(moeR,'')+''','''     +isnull(nomR,'')+''','    +cast(isnull(diaR,0) as varchar)+','    +cast(isnull(lenR,0) as varchar)+'
,'''     +isnull(codF,'')+''','''     +isnull(mdlF,'')+''','''     +isnull(dayF,'')+''','''     +isnull(moeF,'')+''','''     +isnull(nomF,'')+''','    +cast(isnull(diaF,0) as varchar)+','    +cast(isnull(lenF,0) as varchar)+'
,'''     +isnull(codH,'')+''','''     +isnull(mdlH,'')+''','''     +isnull(dayH1,'')+''','''     +isnull(dayH2,'')+''','''     +isnull(moeH,'')+''','''     +isnull(nomH,'')+''','    +cast(isnull(diaH,0) as varchar)+','    +cast(isnull(lenH,0) as varchar)+'
,'''     +isnull(codZ,'')+''','''     +isnull(mdlZ,'')+''','''     +isnull(dayZ,'')+''','''     +isnull(moeZ,'')+''','''     +isnull(nomZ,'')+''','    +cast(isnull(diaZ,0) as varchar)+','    +cast(isnull(lenZ,0) as varchar)+'
,'''     +isnull(codY,'')+''','''     +isnull(mdlY,'')+''','''     +isnull(dayY,'')+''','''     +isnull(moeY,'')+''','''     +isnull(nomY,'')+''','    +cast(isnull(diaY,0) as varchar)+','    +cast(isnull(lenY,0) as varchar)+'
,'''     +isnull(codP,'')+''','''     +isnull(mdlP,'')+''','''     +isnull(dayP,'')+''','''     +isnull(moeP,'')+''','''     +isnull(nomP,'')+''','    +cast(isnull(diaP,0) as varchar)+','    +cast(isnull(lenP,0) as varchar)+'
,'''     +isnull(codQ,'')+''','''     +isnull(mdlQ,'')+''','''     +isnull(dayQ,'')+''','''     +isnull(moeQ,'')+''','''     +isnull(nomQ,'')+''','    +cast(isnull(diaQ,0) as varchar)+','    +cast(isnull(lenQ,0) as varchar)+'
,''SqlQaSMR'', getdate(), null, null)'
 FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=F:\smrasp\_des\puncao\anexos\MX_punc_v212_header.xlsx', 'SELECT * FROM [plan1$]') where isnull(cod1,'*')<>'*'
*/

print @sql
exec(@sql)
go

/*
-- resultados em 24/11/2016 16:43
select 'insert PUNC values('''+codB+''','''     +isnull(preB,'')+''','''     +isnull(mdlB,'')+''','''     +isnull(dayB,'')+''','''     +isnull(moeB,'')+''','''     +isnull(nomB,'')+''','    +cast(isnull(diaB,0) as varchar)+','    +cast(isnull(lenB,0) as varchar)+','''     +isnull(cod1,'')+''','''     +isnull(nom1,'')+''','''     +isnull(nom ,'')+''','    +cast(isnull(dia1,0) as varchar)+','    +cast(isnull(len1,0) as varchar)+','    +cast(isnull(dayDHstd,0) as varchar)+','    +cast(isnull(dayDH1  ,0) as varchar)+','    +cast(isnull(dayDH2  ,0) as varchar)+','    +cast(isnull(mdlDHStd,0) as varchar)+','    +cast(isnull(L2Std,0) as varchar)+','    +cast(isnull(L2Op1,0) as varchar)+','    +cast(isnull(L2Op2,0) as varchar)+','    +cast(isnull(MinP,0) as varchar)+','    +cast(isnull(MaxP,0) as varchar)+','    +cast(isnull(MinW,0) as varchar)+','    +cast(isnull(MaxPoG,0) as varchar)+'
,'''     +isnull(codS,'')+''','''     +isnull(mdlS,'')+''','''     +isnull(dayS,'')+''','''     +isnull(moeS,'')+''','''     +isnull(nomS,'')+''','    +cast(isnull(diaS,0) as varchar)+','    +cast(isnull(lenS,0) as varchar)+'
,'''     +isnull(codL,'')+''','''     +isnull(mdlL,'')+''','''     +isnull(dayL,'')+''','''     +isnull(moeL,'')+''','''     +isnull(nomL,'')+''','    +cast(isnull(diaL,0) as varchar)+','    +cast(isnull(lenL,0) as varchar)+'
,'''     +isnull(codV,'')+''','''     +isnull(mdlV,'')+''','''     +isnull(dayV1,'')+''','''     +isnull(dayV2,'')+''','''     +isnull(moeV,'')+''','''     +isnull(nomV,'')+''','    +cast(isnull(diaV,0) as varchar)+','    +cast(isnull(lenV,0) as varchar)+'
,'''     +isnull(codR,'')+''','''     +isnull(mdlR,'')+''','''     +isnull(dayR1,'')+''','''     +isnull(dayR2,'')+''','''     +isnull(moeR,'')+''','''     +isnull(nomR,'')+''','    +cast(isnull(diaR,0) as varchar)+','    +cast(isnull(lenR,0) as varchar)+'
,'''     +isnull(codF,'')+''','''     +isnull(mdlF,'')+''','''     +isnull(dayF,'')+''','''     +isnull(moeF,'')+''','''     +isnull(nomF,'')+''','    +cast(isnull(diaF,0) as varchar)+','    +cast(isnull(lenF,0) as varchar)+'
,'''     +isnull(codH,'')+''','''     +isnull(mdlH,'')+''','''     +isnull(dayH1,'')+''','''     +isnull(dayH2,'')+''','''     +isnull(moeH,'')+''','''     +isnull(nomH,'')+''','    +cast(isnull(diaH,0) as varchar)+','    +cast(isnull(lenH,0) as varchar)+'
,'''     +isnull(codZ,'')+''','''     +isnull(mdlZ,'')+''','''     +isnull(dayZ,'')+''','''     +isnull(moeZ,'')+''','''     +isnull(nomZ,'')+''','    +cast(isnull(diaZ,0) as varchar)+','    +cast(isnull(lenZ,0) as varchar)+'
,'''     +isnull(codY,'')+''','''     +isnull(mdlY,'')+''','''     +isnull(dayY,'')+''','''     +isnull(moeY,'')+''','''     +isnull(nomY,'')+''','    +cast(isnull(diaY,0) as varchar)+','    +cast(isnull(lenY,0) as varchar)+'
,'''     +isnull(codP,'')+''','''     +isnull(mdlP,'')+''','''     +isnull(dayP,'')+''','''     +isnull(moeP,'')+''','''     +isnull(nomP,'')+''','    +cast(isnull(diaP,0) as varchar)+','    +cast(isnull(lenP,0) as varchar)+'
,'''     +isnull(codQ,'')+''','''     +isnull(mdlQ,'')+''','''     +isnull(dayQ,'')+''','''     +isnull(moeQ,'')+''','''     +isnull(nomQ,'')+''','    +cast(isnull(diaQ,0) as varchar)+','    +cast(isnull(lenQ,0) as varchar)+'
,''SqlQaSMR'', getdate(), null, null)'
 FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=F:\smrasp\_des\puncao\anexos\MX_punc_v212_header.xlsx', 'SELECT * FROM [plan1$]') where isnull(cod1,'*')<>'*'

*/


/*
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-4-40).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-4-45).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-115).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-120).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-125).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-130).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-135).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-140).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPNB-32-150).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPE1-5-40).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPE1-5-45).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPE1-5-50).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPE1-5-55).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (PB-PPE1-32-150).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (DB-SMDB-22-20).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (DB-SMCB-22-20-12).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (DB-SMCB-22-20-6).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (QB-PPNB-12.5-175).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (QB-PPNB-12.5-200).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (QB-PPNB-12.5-225).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (QB-PPE1-18.75-150).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (QB-PPE1-18.75-175).
*/


-- 18/03/2016 18:48 Ap�s a troca da chave de cod1 para codb
/*
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (DB-SMDB-22-20).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (DB-SMCB-22-20-12).
Violation of PRIMARY KEY constraint 'PUNC1'. Cannot insert duplicate key in object 'dbo.PUNC'. The duplicate key value is (DB-SMCB-22-20-6).
*/


update PUNC set PUNC_MDLB='BILEB' where PUNC_PREB='QB-BLEB' and  PUNC_MDLB='BLEB'
update PUNC set PUNC_MDLB='BILB'  where PUNC_PREB='QB-BLNB' and  PUNC_MDLB='BLB'



/*
*/
declare @sql varchar(8000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
set @dir='F:\smrasp\_des\puncao\anexos\'
set @pla='MX_punc_v22_header.xlsx'
set @aba='plan1'
/*

            insert PUNC ( PUNC_CODB, PUNC_PREB, PUNC_MDLB, PUNC_DAYB, PUNC_MOEB, PUNC_NOMB,
                    PUNC_DIAB, PUNC_LENB, PUNC_COD1, PUNC_NOM1, PUNC_NOM, PUNC_DIA1, PUNC_LEN1,
                    PUNC_DHSTD, PUNC_DH1, PUNC_DH2, PUNC_MHSTD, PUNC_L2STD, PUNC_L2OP1, PUNC_L2OP2,
                    PUNC_MINP, PUNC_MAXP, PUNC_MINW, PUNC_MAXPOG, PUNC_CODS, PUNC_MDLS, PUNC_DAYS,
                    PUNC_MOES, PUNC_NOMS, PUNC_DIAS, PUNC_LENS, PUNC_CODL, PUNC_MDLL, PUNC_DAYL,
                    PUNC_MOEL, PUNC_NOML, PUNC_DIAL, PUNC_LENL, PUNC_CODV, PUNC_MDLV, PUNC_DAYV1,
                    PUNC_DAYV2, PUNC_MOEV, PUNC_NOMV, PUNC_DIAV, PUNC_LENV, PUNC_CODR, PUNC_MDLR,
                    PUNC_DAYR1, PUNC_DAYR2, PUNC_MOER, PUNC_NOMR, PUNC_DIAR, PUNC_LENR, PUNC_CODF,
                    PUNC_MDLF, PUNC_DAYF, PUNC_MOEF, PUNC_NOMF, PUNC_DIAF, PUNC_LENF, PUNC_CODH,
                    PUNC_MDLH, PUNC_DAYH1, PUNC_DAYH2, PUNC_MOEH, PUNC_NOMH, PUNC_DIAH, PUNC_LENH,
                    PUNC_CODZ, PUNC_MDLZ, PUNC_DAYZ, PUNC_MOEZ, PUNC_NOMZ, PUNC_DIAZ, PUNC_LENZ,
                    PUNC_CODY, PUNC_MDLY, PUNC_DAYY, PUNC_MOEY, PUNC_NOMY, PUNC_DIAY, PUNC_LENY,
                    PUNC_CODP, PUNC_MDLP, PUNC_DAYP, PUNC_MOEP, PUNC_NOMP, PUNC_DIAP, PUNC_LENP,
                    PUNC_CODQ, PUNC_MDLQ, PUNC_DAYQ, PUNC_MOEQ, PUNC_NOMQ, PUNC_DIAQ, PUNC_LENQ,
                    PUNC_MTPR_COD, PUNC_MTPR_MTTP, PUNC_MTPR_MS, PUNC_MTPR_ATV, PUNC_MTPR_NOM,
                    PUNC_MTPR_MTDV, PUNC_MTPR_MTLN, PUNC_MTPR_MTFM, PUNC_MTPR_MTUN, PUNC_MTPR_MTNC,
                    PUNC_MTPR_ORI, PUNC_MTPR_PES, PUNC_MTPR_DES, PUNC_MTPR_NIV, PUNC_MTPR_ESUN,
                    PUNC_MTPR_ESFT, PUNC_MTPR_CPUN, PUNC_MTPR_CPFT, PUNC_MTPR_ATVV, PUNC_MTPR_CFOV,
                    PUNC_MTPR_ATVC, PUNC_MTPR_CFOC, PUNC_MTPR_TOLE, PUNC_MTES_SIES, PUNC_MTES_MTAL,
                    PUNC_MTES_MTAN, PUNC_MTES_MTAP, PUNC_MTES_LOTE, PUNC_MTES_GLMD, PUNC_MTES_QATU,
                    PUNC_MTES_VATU, PUNC_MTES_VATM, PUNC_MTES_QVIS, PUNC_MTES_QNEC, PUNC_MTES_QPRO,
                    PUNC_MTES_PCME, PUNC_MTES_PCMR, PUNC_MTES_PMIN, PUNC_MTES_POBJ, PUNC_MTES_POEM,
                    PUNC_MTES_PPMI, PUNC_MTES_PLEM, PUNC_MTES_PMUL, PUNC_MTES_PLEC, PUNC_MTES_UCDO,
                    PUNC_MTES_LEAD, PUNC_MTES_LEEM, PUNC_MTES_EXPL, PUNC_MTES_MRP, PUNC_MTES_CREP,
                    PUNC_MTES_CPDR, PUNC_MTES_FGGF, PUNC_MTES_FRAT, PUNC_MTES_CTGT, PUNC_MTES_CPO1,
                    PUNC_MTES_CPO2, PUNC_MTES_CPO3, PUNC_MTES_CPO4, PUNC_MTES_PRAT, PUNC_MTPC_PRE,
                    PUNC_MTPC_GLMD, PUNC_SALDO, PUNC_EXISTS, PUNC_USC, PUNC_DTC, PUNC_USU, PUNC_DTU)
*/


set @sql=      'select ''insert PUNC values(''''''+punc_codB+'''''''
set @sql=@sql +',''''''     +isnull(punc_preB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomB,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayB,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaB,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenB,0) as varchar)+'''

set @sql=@sql +',''''''     +isnull(punc_cod1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nom1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nom ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_dia1,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_len1,0) as varchar)+'''+char(10)

-- Novos campos para as Matrizes
set @sql=@sql +',''    +cast(isnull(punc_DHstd,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_DH1  ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_DH2  ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MHStd,0) as varchar)+'''

set @sql=@sql +',''    +cast(isnull(punc_L2Std,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_L2Op1,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_L2Op2,0) as varchar)+'''

set @sql=@sql +',''    +cast(isnull(punc_MinP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MaxP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MinW,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MaxPoG,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeS,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomS,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaS,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenS,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomL,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaL,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenL,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayV1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayV2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeV,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomV,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaV,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenV,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayR1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayR2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeR,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomR,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaR,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenR,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeF,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomF,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaF,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenF,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayH1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayH2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeH,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomH,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaH,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenH,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeZ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomZ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaZ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenZ,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeY,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomY,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaY,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenY,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomP,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenP,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_codQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_mdlQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_dayQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_moeQ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_nomQ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_diaQ,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_lenQ,0) as varchar)+'''+char(10)


set @sql=@sql +',''''''     +isnull(punc_MTPR_cod ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_mttp,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_ms  ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_atv ,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_mtdv,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_mtln,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_mtfm,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_mtun,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_mtnc,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_ori ,'''')+'''''''+char(10)

set @sql=@sql +',''    +cast(isnull(punc_MTPR_pes ,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTPR_des ,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_MTPR_niv ,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTPR_esun,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_MTPR_esft,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTPR_cpun,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_MTPR_cpft,0) as varchar)+'''+char(10)

set @sql=@sql +',''''''     +isnull(punc_MTPR_atvv,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_cfov,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_atvc,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTPR_cfoc,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_MTPR_tole,0) as varchar)+'''+char(10)


set @sql=@sql +',''    +cast(isnull(punc_MTES_sies,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTES_mtAL,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_mtAN,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_mtAP,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_lote,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_GLMD,'''')+'''''''+char(10)

set @sql=@sql +',''    +cast(isnull(punc_MTES_qatu,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_vatu,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_vatm,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_qvis,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_qnec,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_qpro,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_pcme,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_pcmr,0) as varchar)+'''+char(10)

set @sql=@sql +',''    +cast(isnull(punc_MTES_pmin,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_pobj,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_poem,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_ppmi,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_plem,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_pmul,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_plec,0) as varchar)+'''+char(10)


set @sql=@sql +',''''''     +isnull(punc_MTES_UCDO,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_MTES_lead,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_leem,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTES_expl,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_MRP,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_MTES_CREP,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_CPDR,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_FGGF,0) as varchar)+'''
set @sql=@sql +',''    +cast(isnull(punc_MTES_FRAT,0) as varchar)+'''+char(10)

set @sql=@sql +',''    +cast(isnull(punc_MTES_CTGT,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTES_CPO1,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_CPO2,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_CPO3,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_CPO4,'''')+'''''''
set @sql=@sql +',''''''     +isnull(punc_MTES_PRAT,'''')+'''''''+char(10)

set @sql=@sql +',''    +cast(isnull(punc_MTPC_PRE ,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_MTPC_GLMD,'''')+'''''''
set @sql=@sql +',''    +cast(isnull(punc_SALDO ,0) as varchar)+'''
set @sql=@sql +',''''''     +isnull(punc_EXISTS,'''')+'''''''+char(10)

set @sql=@sql +',''''SqlQaSMR'''''
set @sql=@sql +', getdate()'
set @sql=@sql +', null'
set @sql=@sql +', null'

set @sql=@sql +')'''+char(10)
set @sql=@sql +' FROM PUNC'
set @sql=@sql +' where isnull(punc_codB,''*'')<>''*'''

print @sql

