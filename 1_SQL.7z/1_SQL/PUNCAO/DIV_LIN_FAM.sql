--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 24/01/2017--ASSUNTO      : CRIAR AS LINHAS E FAMILIA COMO NO BRASIL--DEPARTAMENTO : 24/01/2017------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#MTLN') IS NOT NULL DROP TABLE #MTLNSELECT *, MTLN_COD MTLN_COD_OLD INTO #MTLN FROM MTLN WHERE 1 = 0INSERT INTO #MTLNSELECT 		MTLN_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTLN_COD = CASE MTLN_COD
		WHEN '20' THEN '3800'
		WHEN '21' THEN '3900'
		WHEN '22' THEN '3950'
		WHEN '16' THEN '4000'
		WHEN '17' THEN '4100'
		WHEN '18' THEN '4150'
		WHEN '25' THEN '4200'
		ELSE '4200'
	END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTLN_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da linha do produto)
	, MTLN_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTLN_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTLN_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTLN_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTLN_COD
	--SELECT *
FROM MTLNWHERE MTLN_MTDV = '05'INSERT INTO #MTLNSELECT 		MTLN_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTLN_COD = CASE MTLN_COD
		WHEN '20' THEN '4800'
		WHEN '21' THEN '4900'
		WHEN '22' THEN '4950'
		WHEN '16' THEN '5000'
		WHEN '17' THEN '5100'
		WHEN '18' THEN '5150'
		WHEN '25' THEN '5200'
		ELSE '5200'
	END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTLN_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da linha do produto)
	, MTLN_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTLN_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTLN_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTLN_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTLN_COD
	--SELECT *
FROM MTLNWHERE MTLN_MTDV = '06'INSERT INTO MTLNSELECT DISTINCT MTLN_MTDV ,MTLN_COD ,MAX(MTLN_NOM) ,MAX(MTLN_USC) ,MAX(MTLN_DTC) ,MAX(MTLN_USU) ,MAX(MTLN_DTU)FROM #MTLNWHERE MTLN_MTDV+'/'+MTLN_COD NOT IN (SELECT MTLN_MTDV+'/'+MTLN_COD FROM MTLN)
GROUP BY MTLN_MTDV, MTLN_COD--ORDER BY MTLN_MTDV, MTLN_COD--MTLN_MTDV ,MTLN_COD ,MTLN_NOM ,MTLN_USC ,MTLN_DTC ,MTLN_USU ,MTLN_DTU

IF OBJECT_ID('TempDB.dbo.#MTFM') IS NOT NULL DROP TABLE #MTFMSELECT *, MTFM_COD MTFM_COD_OLD INTO #MTFM FROM MTFM WHERE 1 = 0INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '3800' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '330' THEN '4560'
		WHEN '340' THEN '4590'
		WHEN '350' THEN '4620'
		WHEN '355' THEN '4650'
		WHEN '360' THEN '4680'
		WHEN '361' THEN '4690'
		WHEN '362' THEN '4693'
		WHEN '363' THEN '4695'
		ELSE '4550'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '3900' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '365' THEN '4710'
		WHEN '370' THEN '4720'
		ELSE '4700'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '3950' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '390' THEN '4770'
		WHEN '395' THEN '4780'
		ELSE '4700'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4000' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '270' THEN '4800'
		WHEN '275' THEN '4830'
		WHEN '280' THEN '4860'
		WHEN '285' THEN '4890'
		WHEN '290' THEN '5010'
		WHEN '295' THEN '5040'
		ELSE '4800'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4100' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '300' THEN '5070'
		WHEN '305' THEN '5075'
		WHEN '310' THEN '5080'
		ELSE '5085'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4150' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '320' THEN '5090'
		WHEN '325' THEN '5100'
		ELSE '4700'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4200' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '400' THEN '5160'
		WHEN '410' THEN '5170'
		ELSE '5150'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '05'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4800' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '510' THEN '5555'
		WHEN '515' THEN '5560'
		WHEN '520' THEN '5590'
		WHEN '525' THEN '5620'
		WHEN '530' THEN '5650'
		WHEN '532' THEN '5660'
		WHEN '533' THEN '5670'
		ELSE '5555'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4900' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '535' THEN '5710'
		WHEN '540' THEN '5720'
		WHEN '545' THEN '5730'
		WHEN '550' THEN '5740'
		ELSE '5710'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4950' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '555' THEN '5770'
		WHEN '560' THEN '5780'
		ELSE '5770'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '5000' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '455' THEN '5800'
		WHEN '460' THEN '5830'
		WHEN '465' THEN '5860'
		WHEN '470' THEN '5890'
		WHEN '475' THEN '6010'
		ELSE '5800'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '5100' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '480' THEN '6070'
		WHEN '485' THEN '6075'
		WHEN '490' THEN '6080'
		WHEN '495' THEN '6085'
		ELSE '6070'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '5150' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '500' THEN '6090'
		WHEN '505' THEN '6100'
		ELSE '6090'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '5200' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = CASE MTFM_COD
		WHEN '470' THEN '6180'
		WHEN '475' THEN '6190'
		WHEN '480' THEN '6210'
		WHEN '585' THEN '6200'
		ELSE '6180'
		END --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, MTFM_NOM --= CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI --= Null      --CONVERT(int(3),'') Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 --= Null      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD
	--SELECT *
FROM MTFMWHERE MTFM_MTDV = '06'INSERT INTO #MTFMSELECT 		MTFM_MTDV = '05'      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '3800' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = '4697'
	, MTFM_NOM = 'REVISAR'      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI = 180 -- Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE = 'N'      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 = '6020'      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = 'KINKEL'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD = '4697'
	--SELECT *
INSERT INTO #MTFMSELECT 		MTFM_MTDV = '05'      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '3800' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = '4565'
	, MTFM_NOM = 'REVISAR'      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI = 180 -- Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE = 'N'      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 = '6020'      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = 'KINKEL'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD = '4565'
	--SELECT *
INSERT INTO #MTFMSELECT 		MTFM_MTDV = '05'      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '3800' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = '4595'
	, MTFM_NOM = 'REVISAR'      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI = 180 -- Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE = 'N'      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 = '6020'      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = 'KINKEL'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD = '4595'
	--SELECT *
INSERT INTO #MTFMSELECT 		MTFM_MTDV = '05'      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '4200' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = '5195'
	, MTFM_NOM = 'REVISAR'      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI = 180 -- Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE = 'N'      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 = '6020'      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = 'KINKEL'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD = '5195'
	--SELECT *

INSERT INTO #MTFMSELECT 		MTFM_MTDV = '06'      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTFM_MTLN = '5000' --CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTFM_COD = '6020'
	, MTFM_NOM = 'REVISAR'      --CONVERT(varchar(50),'') Nome(Nome da fam�lia do produto)
	, MTFM_MEDI = 180 -- Dias p/ M�dia(N�mero de dias para c�lculo da m�dia de consumo p/ estoque)
	, MTFM_EPRE = 'N'      --CONVERT(char(1),'') Edita pre�o(Indica se permite edi��o de pre�o)
	, MTFM_COD2 = '6020'      --CONVERT(varchar(4),'') Gerencial(Fam�lia gerencial do produto)
	, MTFM_USC = 'KINKEL'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFM_DTC = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFM_COD = '6020'
	--SELECT *
INSERT INTO MTFMSELECT MTFM_MTDV ,MTFM_MTLN ,MTFM_COD ,MAX(MTFM_NOM) ,MAX(MTFM_MEDI) ,MAX(MTFM_EPRE) ,MAX(MTFM_COD2) ,MAX(MTFM_USC) ,MAX(MTFM_DTC) ,MAX(MTFM_USU) ,MAX(MTFM_DTU)FROM #MTFMWHERE MTFM_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD NOT IN (SELECT MTFM_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD FROM MTFM)
GROUP BY MTFM_MTDV ,MTFM_MTLN ,MTFM_COD--MTFM_MTDV ,MTFM_MTLN ,MTFM_COD ,MTFM_NOM ,MTFM_MEDI ,MTFM_EPRE ,MTFM_COD2 ,MTFM_USC ,MTFM_DTC ,MTFM_USU ,MTFM_DTU
