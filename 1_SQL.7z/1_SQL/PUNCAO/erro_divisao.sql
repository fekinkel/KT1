
IF OBJECT_ID('TempDB.dbo.#COD') IS NOT NULL DROP TABLE #COD
select identity(int,1,1) num, mtpr_cod COD, mtdv = 'aa', mtln = 'aaaa', mtfm = 'aaaa'
into #COD
from mtpr
where mtpr_cod like 'PB-%'
and MTPR_MTDV = '11'
and len(mtpr_cod) = 7
--111
--3345

declare
@i int = 1,
@dv varchar(4),
@ln varchar(4),
@fm varchar(4)

while @i <= (select max(num) from #cod) begin

	set @dv = 'zz'
	set @ln = 'zzzz'
	set @fm = 'zzzz'
	select top 1 @dv = isnull(mtpr_mtdv,'zz'), @ln = isnull(mtpr_mtln,'zzzz'), @fm = isnull(mtpr_mtfm,'zzzz')
	from mtpr, #COD
	where mtpr_cod like COD+'%'
	and len(mtpr_cod) > 7	
	and num = @i

	update #cod set mtdv = @dv, mtln = @ln, mtfm = @fm
	--select cod, @dv, @ln, @fm
	from #cod
	where num =@i
		
	set @i = @i + 1
end

IF OBJECT_ID('TempDB.dbo.#C') IS NOT NULL DROP TABLE #C
select b.num num_old, b.cod, a.mtdv dv, a.mtln ln, a.mtfm fm
into #c
from #cod a, #cod b
where substring(a.cod,1,6) = substring(b.cod,1,6)
and a.mtdv <> 'zz'
and b.mtdv =  'zz'

update #cod set mtdv = dv, mtln = ln, mtfm = fm
from #cod, #c
where num = num_old

select mtpr_cod, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, *
--update mtpr set mtpr_mtdv = mtdv, mtpr_mtln = mtln, mtpr_mtfm = mtfm
from #cod, mtpr
where mtpr_cod = cod

select *
--update vdpi set VDPI_MTDV = mtdv,	VDPI_MTLN = mtln,	VDPI_MTFM = mtfm
from vdpi, #cod
where vdpi_mtpc = cod

select *
from #cod


