/*
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
declare @open varchar(400)
--SET @PATH = N'\\192.168.3.3\Disco_W_TI'
SET @PATH = N'\\192.168.3.85\1_Delphi'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

set @dir='N:\Temp\'

set @pla='MX punch menu for S2R with restrictions v2.30.xls'--MX_punc_v212_header.
set @aba='Mexico list'
print @open IF OBJECT_ID('TempDB.dbo.##pre') IS NOT NULL DROP TABLE ##preset @sql = 'SELECT *'
set @sql = @sql +'into ##pre'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'

EXEC (@SQL)

select *from ##pre

Exec xp_cmdshell 'net use N: /delete'

*/
--1800
--[192.168.4.2\sqlexpress].[bkp].[dbo].

--147 TOTAL
select [BASE PRODUCT], punc_codb, punc_mtpr_cod, F255
--update [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc set punc_mtpr_cod = F255
--from #pre a, mtpc
--from #pre a, [192.168.3.40].[punc].[dbo].mtpc
from ##pre a, [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc
where punc_codb = [BASE PRODUCT] collate SQL_Latin1_General_CP1_CI_AS
and F255 <> 'NOVO'
and F255 <> '#N/D'
and F255 collate SQL_Latin1_General_CP1_CI_AS <> punc_mtpr_cod



select *
from ##pre
where Producto collate SQL_Latin1_General_CP1_CI_AS like 'bi%'

--where Producto collate SQL_Latin1_General_CP1_CI_AS in (select PUNC_MTPR_COD from [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc)

select punc_codb, PUNC_MTPR_COD from [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc
where PUNC_MTPR_COD like 'BI%'
