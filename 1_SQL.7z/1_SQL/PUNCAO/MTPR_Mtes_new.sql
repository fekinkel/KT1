--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 25/01/2017--ASSUNTO      : CRIAR REGISTROS NA TABELA MTPR A PARTIR DA TABELA PUNC--DEPARTAMENTO : MEXICO------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT * INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD =  PUNC_CODB--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = PUNC_MTPR_MTTP--CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
--	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_NOM = (PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM PUNCWHERE PUNC_MTPR_COD IN (SELECT MTPR_COD FROM MTPR)--AND PUNC_MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)--(1047) J� EXISTE UM CORRESPONDENTE NA TABELA MTPR--SELECT * FROM #MTPR WHERE MTPR_COD LIKE 'PB-PVE%'
INSERT INTO #MTPRSELECT 		MTPR_COD =  STUFF(PUNC_CODB, 7, 1, '1')--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = 'PA-PRODUCTO ACABADO'--PUNC_MTPR_MTTP--CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
--	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_NOM = (PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM PUNCWHERE PUNC_MTPR_COD IN (SELECT MTPR_COD FROM MTPR)--AND PUNC_MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)AND PUNC_MTPR_MTTP = 'PI-PRODUCTO INTERMEDIO'--(1047) J� EXISTE UM CORRESPONDENTE NA TABELA MTPR--SELECT * FROM #MTPRINSERT INTO #MTPRSELECT 		MTPR_COD =  PUNC_CODB--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = PUNC_MTPR_MTTP--CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
--	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_NOM = (PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *--PUNC_MTPR_MTLN+'/'+PUNC_MTPR_MTFM, PUNC_MTPR_MTDV,	PUNC_MTPR_MTLN,	PUNC_MTPR_MTFM
FROM PUNCWHERE PUNC_CODB NOT IN (SELECT MTPR_COD FROM MTPR)and PUNC_CODB NOT IN (SELECT MTPR_COD FROM #MTPR)--SELECT * FROM #MTPR WHERE MTPR_COD LIKE 'PB-PVE%'
INSERT INTO #MTPRSELECT 		MTPR_COD =  STUFF(PUNC_CODB, 7, 1, '1')--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = 'PA-PRODUCTO ACABADO'--PUNC_MTPR_MTTP--CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
--	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_NOM = (PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT STUFF(PUNC_CODB, 7, 1, '1'),*--PUNC_MTPR_MTLN+'/'+PUNC_MTPR_MTFM, PUNC_MTPR_MTDV,	PUNC_MTPR_MTLN,	PUNC_MTPR_MTFM
FROM PUNCWHERE STUFF(PUNC_CODB, 7, 1, '1') NOT IN (SELECT MTPR_COD FROM MTPR)and STUFF(PUNC_CODB, 7, 1, '1') NOT IN (SELECT MTPR_COD FROM #MTPR)AND PUNC_MTPR_MTTP = 'PI-PRODUCTO INTERMEDIO'--2970INSERT INTO #MTPRSELECT 		MTPR_COD =  PUNC_COD1--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = 'PA-PRODUCTO ACABADO'--CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
--	, MTPR_NOM = UPPER(MAX(PUNC_MTPR_NOM))--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_NOM = (MAX(PUNC_MTPR_NOM))--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM PUNCWHERE SUBSTRING(PUNC_COD1,7,1) = '1'AND PUNC_COD1 NOT IN (SELECT MTPR_COD FROM MTPR)AND PUNC_MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)GROUP BY PUNC_COD1, PUNC_MTPR_MS, PUNC_MTPR_MTDV, PUNC_MTPR_MTLN, PUNC_MTPR_MTFM
,PUNC_MTPR_MTUN
,PUNC_MTPR_MTNC
,PUNC_MTPR_ORI
,PUNC_MTPR_PES
,PUNC_MTPR_DES
,PUNC_MTPR_NIV
,PUNC_MTPR_ESUN
,PUNC_MTPR_ESFT
,PUNC_MTPR_CPUN
,PUNC_MTPR_CPFT
,PUNC_MTPR_ATVV
,PUNC_MTPR_CFOV
,PUNC_MTPR_ATVC
,PUNC_MTPR_CFOC
,PUNC_MTPR_TOLE
--(4069)INSERT INTO MTPRSELECT *FROM #MTPRWHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)
AND MTPR_COD LIKE 'PB-PVEB%'

--AND MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU
IF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = MTPR_COD--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTES_SIES = PUNC_MTES_SIES--CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTES_MTAL = PUNC_MTES_MTAL--CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, MTES_MTAN = PUNC_MTES_MTAN--Null      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, MTES_MTAP = PUNC_MTES_MTAP--Null      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, MTES_LOTE = PUNC_MTES_LOTE--CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, MTES_GLMD = PUNC_MTES_GLMD--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, MTES_QATU = PUNC_MTES_QATU--Null      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, MTES_VATU = PUNC_MTES_VATU--Null      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, MTES_VATM = PUNC_MTES_VATM--Null      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, MTES_QVIS = PUNC_MTES_QVIS--Null      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, MTES_QNEC = PUNC_MTES_QNEC--Null      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, MTES_QPRO = PUNC_MTES_QPRO--Null      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, MTES_PCME = PUNC_MTES_PCME      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, MTES_PCMR = PUNC_MTES_PCMR      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, MTES_PMIN = PUNC_MTES_PMIN      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, MTES_POBJ = PUNC_MTES_POBJ      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, MTES_POEM = PUNC_MTES_POEM      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, MTES_PPMI = PUNC_MTES_PPMI      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, MTES_PLEM = PUNC_MTES_PLEM      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, MTES_PMUL = PUNC_MTES_PMUL      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, MTES_PLEC = PUNC_MTES_PLEC      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, MTES_UCDO = PUNC_MTES_UCDO      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, MTES_LEAD = PUNC_MTES_LEAD      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, MTES_LEEM = PUNC_MTES_LEEM      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, MTES_EXPL = PUNC_MTES_EXPL--CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, MTES_MRP = PUNC_MTES_MRP--CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, MTES_CREP = PUNC_MTES_CREP      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, MTES_CPDR = PUNC_MTES_CPDR      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, MTES_FGGF = PUNC_MTES_FGGF      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, MTES_FRAT = PUNC_MTES_FRAT--CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, MTES_CTGT = PUNC_MTES_CTGT      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, MTES_CPO1 = PUNC_MTES_CPO1      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, MTES_CPO2 = PUNC_MTES_CPO2      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, MTES_CPO3 = PUNC_MTES_CPO3      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, MTES_CPO4 = PUNC_MTES_CPO4      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, MTES_PRAT = PUNC_MTES_PRAT      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM #MTPR, PUNCWHERE MTPR_COD = PUNC_CODB
INSERT INTO #MTESSELECT 		MTES_MTPR = MTPR_COD--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTES_SIES = PUNC_MTES_SIES--CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTES_MTAL = PUNC_MTES_MTAL--CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, MTES_MTAN = PUNC_MTES_MTAN--Null      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, MTES_MTAP = PUNC_MTES_MTAP--Null      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, MTES_LOTE = PUNC_MTES_LOTE--CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, MTES_GLMD = PUNC_MTES_GLMD--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, MTES_QATU = PUNC_MTES_QATU--Null      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, MTES_VATU = PUNC_MTES_VATU--Null      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, MTES_VATM = PUNC_MTES_VATM--Null      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, MTES_QVIS = PUNC_MTES_QVIS--Null      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, MTES_QNEC = PUNC_MTES_QNEC--Null      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, MTES_QPRO = PUNC_MTES_QPRO--Null      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, MTES_PCME = PUNC_MTES_PCME      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, MTES_PCMR = PUNC_MTES_PCMR      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, MTES_PMIN = PUNC_MTES_PMIN      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, MTES_POBJ = PUNC_MTES_POBJ      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, MTES_POEM = PUNC_MTES_POEM      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, MTES_PPMI = PUNC_MTES_PPMI      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, MTES_PLEM = PUNC_MTES_PLEM      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, MTES_PMUL = PUNC_MTES_PMUL      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, MTES_PLEC = PUNC_MTES_PLEC      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, MTES_UCDO = PUNC_MTES_UCDO      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, MTES_LEAD = PUNC_MTES_LEAD      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, MTES_LEEM = PUNC_MTES_LEEM      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, MTES_EXPL = PUNC_MTES_EXPL--CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, MTES_MRP = PUNC_MTES_MRP--CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, MTES_CREP = PUNC_MTES_CREP      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, MTES_CPDR = PUNC_MTES_CPDR      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, MTES_FGGF = PUNC_MTES_FGGF      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, MTES_FRAT = PUNC_MTES_FRAT--CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, MTES_CTGT = PUNC_MTES_CTGT      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, MTES_CPO1 = PUNC_MTES_CPO1      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, MTES_CPO2 = PUNC_MTES_CPO2      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, MTES_CPO3 = PUNC_MTES_CPO3      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, MTES_CPO4 = PUNC_MTES_CPO4      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, MTES_PRAT = PUNC_MTES_PRAT      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM #MTPR, PUNCWHERE MTPR_COD = STUFF(PUNC_CODB, 7, 1, '1')
SELECT MTPC_GLMD, PUNC_MTPC_GLMD ,	MTPC_PRE, PUNC_MTPC_PRE, mtpc_cod, PUNC_CODB
--UPDATE MTPC SET MTPC_GLMD = PUNC_MTPC_GLMD ,	MTPC_PRE = PUNC_MTPC_PRE
FROM MTPC, #MTPR, PUNC
WHERE MTPR_COD = MTPC_MTPR
AND MTPR_COD = PUNC_CODB
AND PUNC_MTPC_GLMD IS NOT NULL


--SELECT *
--UPDATE MTPC SET MTPC_GLMD = 'USD' ,	MTPC_PRE = 9999.99
FROM MTPC, #MTPR, PUNC
WHERE MTPR_COD = MTPC_MTPR
AND MTPR_COD = PUNC_CODB
AND PUNC_MTPC_GLMD IS NULL


--	, PUNC_SALDO = Null      --CONVERT(decimal(16),'') Saldo(Saldo)-
--	, PUNC_EXISTS = Null      --CONVERT(varchar(1),'') Exists(Exists)
--	, PUNC_USC = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
--	, PUNC_DTC = CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
--	, PUNC_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
--	, PUNC_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
INSERT INTO MTESSELECT *FROM #MTESWHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR FROM MTES)
--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU

--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 03/03/2017--ASSUNTO      : 03/03/2017--DEPARTAMENTO : 03/03/2017------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#MTEP') IS NOT NULL DROP TABLE #MTEPSELECT * INTO #MTEP FROM MTEP WHERE 1 = 0INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)(C�digo do produto ou insumo)
	, MTEP_FIL = CONVERT(varchar(20),STUFF(MTPR_COD, 7, 1, '1'))      --CONVERT(varchar(20),'') C�digo (Filho)(C�digo do produto ou insumo)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia(Sequencia do componente)
	, MTEP_QTD = 1--Null      --CONVERT(decimal(12),'') Quantidade(Quantidade do componente filho para uma unidade do pai)
	, MTEP_PCT = 0--Null      --CONVERT(decimal(10),'') Perda %(Percentual de perda do insumo no processo produtivo)
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.(Define se gera necessidade e exige requisi��o em ordens)
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT STUFF(MTPR_COD, 7, 1, '1'), *
FROM #MTPRWHERE MTPR_MTTP = 'PI-PRODUCTO INTERMEDIO'--SUBSTRING(MTPR_COD,7,1) ='1'WHILE (SELECT COUNT(1)FROM #MTEP WHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP))>0 BEGIN	ALTER TABLE MTEP DISABLE TRIGGER ALL	INSERT INTO MTEP	SELECT *--TOP 1 *	FROM #MTEP	WHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP)
	ALTER TABLE MTEP ENABLE TRIGGER ALLEND--MTEP_PAI ,MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU

--SELECT *
UPDATE MTPR SET MTPR_ATV = 'S', MTPR_MS = 'M'
FROM #MTPR a, MTPR b
WHERE a.MTPR_COD = b.MTPR_COD
