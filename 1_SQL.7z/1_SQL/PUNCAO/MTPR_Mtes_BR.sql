--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 25/01/2017--ASSUNTO      : CRIAR REGISTROS NA TABELA MTPR A PARTIR DA TABELA PUNC--DEPARTAMENTO : MDL BRASIL------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT *, identity(int,1,1)NUM INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT --PUNC_MTPR_MTTP PA-PRODUCTO ACABADO		MTPR_COD =  PUNC_CODB--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = CASE 
		WHEN PUNC_MTPR_MTTP = 'PA-PRODUCTO ACABADO' THEN 'PA-PRODUTO ACABADO' 
		WHEN PUNC_MTPR_MTTP = 'PI-PRODUCTO INTERMEDIO' THEN 'PA-PRODUTO ACAB FABRICADO'
		END --CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = 'PC'--PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = 'PC'--PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = 'PC'--PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = '5.101.B'--PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = '1.101.B'--PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST = Null      --CONVERT(varchar(7),'') CEST(C�digo Especificador da Substitui��o Tribut�ria (CEST) - Confaz Conv�nio ICMS N� 92/2015)	
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT PUNC_MTPR_COD, *
FROM PUNCWHERE PUNC_MTPR_COD IN (SELECT MTPR_COD FROM MTPR)AND PUNC_MTPR_MTDV = '3500'--AND PUNC_MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)INSERT INTO #MTPRSELECT 		MTPR_COD =  PUNC_CODB--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = CASE 
		WHEN PUNC_MTPR_MTTP = 'PA-PRODUCTO ACABADO' THEN 'PA-PRODUTO ACABADO' 
		WHEN PUNC_MTPR_MTTP = 'PI-PRODUCTO INTERMEDIO' THEN 'PA-PRODUTO ACAB FABRICADO'
		END --CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = 'PC'--PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = 'PC'--PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = 'PC'--PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = '5.101.B'--PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = '1.101.B'--PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST = Null      --CONVERT(varchar(7),'') CEST(C�digo Especificador da Substitui��o Tribut�ria (CEST) - Confaz Conv�nio ICMS N� 92/2015)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *--PUNC_MTPR_MTLN+'/'+PUNC_MTPR_MTFM, PUNC_MTPR_MTDV,	PUNC_MTPR_MTLN,	PUNC_MTPR_MTFM
FROM PUNCWHERE PUNC_CODB NOT IN (SELECT MTPR_COD FROM MTPR)AND PUNC_CODB NOT IN (SELECT MTPR_COD FROM #MTPR)AND PUNC_MTPR_MTDV = '3500'
--PB-PPD1-10-71
--AND len(PUNC_MTPR_COD) >= 5
--AND PUNC_MTPR_MTDV+'/'+PUNC_MTPR_MTLN+'/'+PUNC_MTPR_MTFM NOT IN (SELECT MTFM_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD FROM MTFM)--AND PUNC_MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)--GROUP BY PUNC_MTPR_MTDV,	PUNC_MTPR_MTLN,	PUNC_MTPR_MTFM---ORDER BY PUNC_MTPR_MTDV,	PUNC_MTPR_MTLN,	PUNC_MTPR_MTFMINSERT INTO #MTPRSELECT distinct		MTPR_COD =  PUNC_MTPR_COD--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = CASE 
		WHEN PUNC_MTPR_MTTP = 'PA-PRODUCTO ACABADO' THEN 'PA-PRODUTO ACABADO' 
		WHEN PUNC_MTPR_MTTP = 'PI-PRODUCTO INTERMEDIO' THEN 'PA-PRODUTO ACAB FABRICADO'
		END --CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = PUNC_MTPR_MS--CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, MTPR_NOM = UPPER(PUNC_MTPR_NOM)--CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = PUNC_MTPR_MTDV--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = PUNC_MTPR_MTLN--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = PUNC_MTPR_MTFM--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = 'PC'--PUNC_MTPR_MTUN--CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = PUNC_MTPR_MTNC--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = PUNC_MTPR_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = PUNC_MTPR_PES--CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = PUNC_MTPR_DES--Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = PUNC_MTPR_NIV--Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = 'PC'--PUNC_MTPR_ESUN--Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = PUNC_MTPR_ESFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = 'PC'--PUNC_MTPR_CPUN--Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = PUNC_MTPR_CPFT--Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = PUNC_MTPR_ATVV--CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = '5.101.B'--PUNC_MTPR_CFOV--Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = PUNC_MTPR_ATVC--CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = '1.101.B'--PUNC_MTPR_CFOC--Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = PUNC_MTPR_TOLE--CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST = Null      --CONVERT(varchar(7),'') CEST(C�digo Especificador da Substitui��o Tribut�ria (CEST) - Confaz Conv�nio ICMS N� 92/2015)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT PUNC_MTPR_COD,*--PUNC_MTPR_MTLN+'/'+PUNC_MTPR_MTFM, PUNC_MTPR_MTDV,	PUNC_MTPR_MTLN,	PUNC_MTPR_MTFM
FROM PUNCWHERE PUNC_MTPR_COD IS NOT NULLAND PUNC_MTPR_COD <> ''AND LEN(PUNC_MTPR_COD)>3AND PUNC_MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)AND PUNC_MTPR_COD NOT IN (SELECT MTPR_COD FROM #MTPR)AND PUNC_MTPR_MTDV = '3500'--2970--(4069)declare @i int = 1while @i <= (select max(nuM) from #mtpr) begin	INSERT INTO MTPR	SELECT MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE, MTPR_FEST ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU	FROM #MTPR	WHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)
	AND NUM = @I
	--AND MTPR_MTFM NOT IN (SELECT MTFM_COD FROM MTFM)	--DA-BLCB-16-32	--MB.160.20.5B	--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU
	set @i = @i +1endIF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT *, identity(int,1,1) NUM INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = MTPR_COD--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTES_SIES = 5--PUNC_MTES_SIES--CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTES_MTAL = PUNC_MTES_MTAL--CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, MTES_MTAN = PUNC_MTES_MTAN--Null      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, MTES_MTAP = PUNC_MTES_MTAP--Null      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, MTES_LOTE = PUNC_MTES_LOTE--CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, MTES_GLMD = PUNC_MTES_GLMD--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, MTES_QATU = PUNC_MTES_QATU--Null      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, MTES_VATU = PUNC_MTES_VATU--Null      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, MTES_VATM = PUNC_MTES_VATM--Null      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, MTES_QVIS = PUNC_MTES_QVIS--Null      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, MTES_QNEC = PUNC_MTES_QNEC--Null      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, MTES_QPRO = PUNC_MTES_QPRO--Null      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, MTES_PCME = PUNC_MTES_PCME      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, MTES_PCMR = PUNC_MTES_PCMR      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, MTES_PMIN = PUNC_MTES_PMIN      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, MTES_POBJ = PUNC_MTES_POBJ      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, MTES_POEM = PUNC_MTES_POEM      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, MTES_PPMI = PUNC_MTES_PPMI      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, MTES_PLEM = PUNC_MTES_PLEM      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, MTES_PMUL = PUNC_MTES_PMUL      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, MTES_PLEC = PUNC_MTES_PLEC      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, MTES_UCDO = PUNC_MTES_UCDO      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, MTES_LEAD = PUNC_MTES_LEAD      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, MTES_LEEM = PUNC_MTES_LEEM      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, MTES_EXPL = PUNC_MTES_EXPL--CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, MTES_MRP = PUNC_MTES_MRP--CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, MTES_CREP = PUNC_MTES_CREP      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, MTES_CPDR = PUNC_MTES_CPDR      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, MTES_FGGF = PUNC_MTES_FGGF      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, MTES_FRAT = PUNC_MTES_FRAT--CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, MTES_CTGT = PUNC_MTES_CTGT      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, MTES_CPO1 = PUNC_MTES_CPO1      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, MTES_CPO2 = PUNC_MTES_CPO2      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, MTES_CPO3 = PUNC_MTES_CPO3      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, MTES_CPO4 = PUNC_MTES_CPO4      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, MTES_PRAT = PUNC_MTES_PRAT      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM #MTPR, PUNCWHERE MTPR_COD = PUNC_CODB

SELECT MTPC_GLMD, PUNC_MTPC_GLMD ,	MTPC_PRE, PUNC_MTPC_PRE, mtpc_cod, PUNC_CODB
--UPDATE MTPC SET MTPC_GLMD = PUNC_MTPC_GLMD ,	MTPC_PRE = PUNC_MTPC_PRE
FROM MTPC, #MTPR, PUNC
WHERE MTPR_COD = MTPC_MTPR
AND MTPR_COD = PUNC_CODB
AND PUNC_MTPC_GLMD IS NOT NULL


--SELECT *
--UPDATE MTPC SET MTPC_GLMD = 'USD' ,	MTPC_PRE = 9999.99
FROM MTPC, #MTPR, PUNC
WHERE MTPR_COD = MTPC_MTPR
AND MTPR_COD = PUNC_CODB
AND PUNC_MTPC_GLMD IS NULL





--	, PUNC_SALDO = Null      --CONVERT(decimal(16),'') Saldo(Saldo)-
--	, PUNC_EXISTS = Null      --CONVERT(varchar(1),'') Exists(Exists)
--	, PUNC_USC = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
--	, PUNC_DTC = CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
--	, PUNC_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
--	, PUNC_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
select mtes_mtprwhere #mtesdeclare@j int = 1while @j <= (select max(num) from #mtes) begin	INSERT INTO MTES	SELECT MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU	FROM #MTES	WHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR FROM MTES)
	and NUM = @j	set @j = @j + 1enddeclare@k int = 1--while @k <= 10 beginwhile @k <= (select max(num)from #mtpr) begin--SELECT *
	UPDATE MTPR SET MTPR_ATV = 'S', MTPR_MS = 'M'
	FROM #MTPR a, MTPR b
	WHERE a.MTPR_COD = b.MTPR_COD
	and num = @k		set @k = @k + 1end--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU


declare@k int = 1--while @k <= 10 beginwhile @k <= (select max(num)from #mtpr) begin	SELECT B.*
	--UPDATE MTPC SET MTPC_PRE = '9999.99'
	FROM #MTPR a, MTPC b
	WHERE a.MTPR_COD = b.MTPC_COD
	AND MTPR_MTTP = 'PA-PRODUTO ACABADO'
	and num = @k		set @k = @k + 1end