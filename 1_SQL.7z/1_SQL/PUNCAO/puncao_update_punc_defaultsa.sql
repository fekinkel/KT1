-- 16/01/2017 16:47 -- SCIED -- Campos default para atualiza��o de PUNC

-- 17/01/2017 19:14 -- SCIED -- Atualiza��o da fun��o de convers�o
if exists (select 1 from dbo.sysobjects where id = object_id(N'[dbo].[fmt_PuncCodOld2]') and (OBJECTPROPERTY(id, N'IsScalarFunction') = 1 or OBJECTPROPERTY(id, N'IsTableFunction') = 1))
   drop function [dbo].[fmt_PuncCodOld2]
go

----------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------
-- DATA             -- AUTOR -- HIST�RICO
-- 08/12/2015 13:58 -- SCIED -- Retorna o c�digo do blank a partir do prefixo diametro e comprimento em milimetros
----------------------------------------------------------------------------------------------------------------------------------------
CREATE function [dbo].[fmt_PuncCodOld2] (@prefix_new varchar(20), @prefix_atu varchar(20), @dia int, @len int, @vida int, @sufix varchar(20))
returns varchar(20) as
begin
/*
select * from punc where substring(punc_codb,1,1)='D' -- Metric DIE
select * from punc where substring(punc_codb,1,1)='E' -- Inch   DIE
select * from punc where substring(punc_codb,1,1)='P' -- Metric PUNCH
select * from punc where substring(punc_codb,1,1)='Q' -- Inch   PUNCH
select * from punc where substring(punc_codb,1,1)='R' -- Metric RETAINER
select * from punc where substring(punc_codb,1,1)='S' -- Inch   RETAINER

-- lista sem equival�ncia
select distinct 'select top 1 punc_preb, punc_nomb from punc where punc_preb='''+punc_preb+'''' from punc where punc_mdlb ='' order by 'select top 1 punc_preb, punc_nomb from punc where punc_preb='''+punc_preb+''''
select top 1 punc_preb, punc_nomb from punc where punc_preb='PB-BJEB' -- PB-BJEB	Metric punch, M2, ball lock LD knob, ejector 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PB-BKEB' -- PB-BKEB	Metric punch, M2, ball lock HD knob, ejector 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PB-PPDB' -- PB-PPDB	Metric punch, M2, 5mm head, solid center dowel 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PB-PPFB' -- PB-PPFB	Metric punch, M2, 5mm head, ejector center dowel 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PB-PVEB' -- PB-PVEB	Metric punch, M2, 5mm head, V-type ejector 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PB-PVNB' -- PB-PVNB	Metric punch, M2, 5mm head, V-type solid 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PS-PTDB' -- PS-PTDB	Metric punch, M4, 8mm head, solid center dowel 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='PS-PTFB' -- PS-PTFB	Metric punch, M4, 8mm head, ejector center dowel 10mm x 100mm blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='QB-BJEB' -- QB-BJEB	Inch punch, M2, light duty ball lock, knob, ejector 1" x 2.5" blank
select top 1 punc_preb, punc_nomb from punc where punc_preb='QB-BKEB' -- QB-BKEB	Inch punch, M2, heavy duty ball lock, knob, ejector 1" x 2.5" blank


*/
   declare @Result varchar(20)
   set @result=''

   --------------------------- punc_codb	         punc_nomb	                                                         punc_mdlb	mtpr_cod
   if @prefix_atu='BILB'    -- QB-BLNB-75-700
   or @prefix_atu='BILEB'   -- QB-BLEB-25-275
   or @prefix_atu='BILEHB'  -- QB-BHEB-100-300	   Inch punch, M2, heavy duty ball lock, ejector 1" x 3" blank	         BILEHB	BILEHB.100.225.B
   or @prefix_atu='BILHB'   -- QB-BHNB-100-300	   Inch punch, M2, heavy duty ball lock, solid 1" x 3" blank	         BILHB	   BILHB.100.300.B
   begin
      -- N�o multiplica por 10 o di�metro e nem acrescenta Zero no diamentro
      set @Result= @prefix_atu+'.'+cast(@dia as varchar)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         -- Sufixo com o ponto
         set @Result = @Result +'.'+@sufix
      end
   end else
   if @prefix_atu='BILMB'   -- EB-BLCB-100-118.7	Inch die, M2, ball lock, counter bore 1" x 1.187" blank	            BILMB	   BILMB.100.118.250B
   begin
      -- N�o multiplica por 10 o di�metro
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         -- Sufixo com o ponto
         set @Result = @Result +'.'+@sufix
      end
   end else
   if @prefix_atu='BLB'     -- PB-BLNB-10-100	   Metric punch, M2, ball lock LD, solid 10mm x 100mm blank	            BLB	   BLB.060.063B
   or @prefix_atu='BLEB'    -- PB-BLEB-10-100	   Metric punch, M2, ball lock LD, ejector 10mm x 100mm blank	         BLEB	   BLEB.060.056B
   or @prefix_atu='BLEHB'   -- PB-BHEB-10-100	   Metric punch, M2, ball lock HD, ejector 10mm x 100mm blank	         BLEHB	   BLEHB.100.063B
   or @prefix_atu='BLHB'    -- PB-BHNB-10-100	   Metric punch, M2, ball lock HD, solid 10mm x 100mm blank	            BLHB	   BLHB.100.063B
   begin
      -- convers�o padr�o atual
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
-- Aqui temos VIDA 19 e 30 !!!!!!!!!!!   
   if @prefix_atu='BLKB'    -- PB-BJNB-10-100	   Metric punch, M2, ball lock LD knob, solid 10mm x 100mm blank	      BLKB	   BLKB.130.080.19B
   or @prefix_atu='BLKHB'   -- PB-BKNB-10-100	   Metric punch, M2, ball lock HD knob, solid 10mm x 100mm blank	      BLKHB	   BLKHB.130.080.19B
   begin
      -- convers�o padr�o acrescida do L2 (vida)
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)+'.'+dbo.fsi_StrZero(@vida, 2)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
-- Aqui tem os dois A e B o padr�o B � que deve existir (M2)    Devemos acumular os saldos!!!!
   if @prefix_atu='BLMB'    -- DB-BLCB-13-32	      Metric die, M2, ball lock, counter bore 13mm x 32mm blank	         BLMB	   BLMB.130.32.4A
   begin
      -- convers�o padr�o atual  ?? 4A  5A 5B no final ??
      -- n�o faz strzero com o comprimento
--      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+cast(@len as varchar)
/*
DB-BLCB-13-32  4
DB-BLCB-16-32  5
DB-BLCB-20-32  5
DB-BLCB-25-32  6
DB-BLCB-32-32  6
DB-BLCB-38-32  8
*/
      if      @dia<= 13.0 set @vida=4
      else if @dia<= 20.0 set @vida=5
      else if @dia<= 32.0 set @vida=6
      else                set @vida=8
      if @vida<>0 begin
         set @Result= @Result+'.'+cast(@vida as varchar)
      end

      set @sufix='A'
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='BLMBS'   -- DB-BLDB-13-32	      Metric die, M2, ball lock, WEDM 13mm x 32mm blank	                  BLMBS	   BLMBS.130.32A
   begin
      -- convers�o padr�o atual  por�m, somente com o sufixo A no final ??
      -- n�o faz strzero com o comprimento
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+cast(@len as varchar)
      set @sufix='A'
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='MB'      -- DB-SMCB-10-20-5	   Metric die, M2, straight, counter bore 10mm x 20mm blank	            MB	      MB.060.20.3A
   or @prefix_atu='MBS'     -- DB-SMDB-10-20	      Metric die, M2, straight, WEDM 10mm x 20mm blank	                  MBS	   MBS.060.20.3B
   begin
      -- convers�o padr�o acrescida do L2 (vida)
      -- convers�o padr�o comprimento sem strzero
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+cast(@len as varchar)
      if @vida<>0 begin
         set @Result= @Result+'.'+cast(@vida as varchar)
      end
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='MIB'     -- EB-SMCB-100-100	   Inch die, M2, straight, counter bore 1" x 1" blank	                  MIB	   MIB.100.075.250B
   begin
      -- ?? A impress�o que d� � que no caso de polegadas existem alturas H padronizadas...???
      -- convers�o padr�o atual
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      if      @dia<= 50.0 set @vida=15.6
      else if @dia<= 87.5 set @vida=18.8
      else if @dia<=150.0 set @vida=25.0
      else                set @vida=31.2
      if isnull(@vida,0)<>0 begin
         set @Result = @Result +'.' +cast((10*@vida) as varchar)
      end
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='MIBS'    -- EB-SMDB-100-100	   Inch die, M2, straight, WEDM 1" x 1" blank	                        MIBS	   MIBS.100.062.120B
   begin
      -- ?? A impress�o que d� � que no caso de polegadas existem alturas H padronizadas...???
      -- convers�o padr�o atual
      set @Result= @prefix_atu+'.'+cast(@dia as varchar)+'.'+dbo.fsi_StrZero(@len, 3)
/*
      if      @dia<= 50.0 set @vida=15.6
      else if @dia<= 87.5 set @vida=18.8
      else if @dia<=100.0 set @vida=25.0
      else                set @vida=31.2
*/
      set @vida=12  -- est� tudp 120 na base!!!
      if isnull(@vida,0)<>0 begin
         set @Result = @Result +'.' +cast((10*@vida) as varchar)
      end
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='MISB'    -- EB-HMCB-100-100	   Inch die, M2, headed, counter bore 1" x 1" blank	                  MISB	   MISB.100.075.250B
   begin
      -- ?? A impress�o que d� � que no caso de polegadas existem alturas H padronizadas...???
      -- convers�o padr�o atual
      set @Result= @prefix_atu+'.'+cast(@dia as varchar)+'.'+dbo.fsi_StrZero(@len, 3)
      if      @dia<= 50.0 set @vida=15.6
      else if @dia<= 87.5 set @vida=18.8
      else if @dia<=150.0 set @vida=25.0
      else                set @vida=31.2
      if isnull(@vida,0)<>0 begin
         set @Result = @Result +'.' +cast((10*@vida) as varchar)
      end
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='MISBS'   -- EB-HMCB-100-100	   Inch die, M2, headed, counter bore 1" x 1" blank	                  MISB	   MISB.100.075.120B
   begin
      -- ?? A impress�o que d� � que no caso de polegadas existem alturas H padronizadas...???
      -- convers�o padr�o atual
      set @Result= @prefix_atu+'.'+cast(@dia AS VARCHAR)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +'.120'+@sufix
      end
   end else
-- Impress�o que falta a vida???   
   if @prefix_atu='MSB'     -- DB-HMCB-10-20-5	   Metric die, M2, headed, counter bore 10mm x 20mm blank	            MSB	   MSB.060.20.3A
   or @prefix_atu='MSBS'    -- DB-HMDB-10-20	      Metric die, M2, headed, WEDM 10mm x 20mm blank	                     MSBS	   MSBS.010.28B
   begin
      -- convers�o padr�o : sem strzero no @len
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+cast(@len as varchar)  
      if @vida<>0 begin
         set @Result= @Result+'.'+cast(@vida as varchar)
      end
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
      --print '@Result=' +@Result
   end else
   if @prefix_atu='PCI'     -- SR-BTBP-100	      Inch backing plate, triangular, 1"	                                 PCI	   PCI025189
   or @prefix_atu='PCM'     -- RR-BTBP-10	         Metric backing plate, triangular, 10mm	                              PCM	   PCM080048
   begin
      -- convers�o padr�o : sem multiplicar por 10
      -- convers�o padr�o : sem a composi��o do comprimento...
      -- convers�o padr�o : sem sufixo...
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(@dia, 3)
   end else
   if @prefix_atu='PHB'     -- PS-PTNB-10-100	   Metric punch, M4, 8mm head, solid 10mm x 100mm blank	               PHB	   PHB.080.075B
   or @prefix_atu='PHEB'    -- PS-PTEB-10-100	   Metric punch, M4, 8mm head, ejector 10mm x 100mm blank	            PHEB	   PHEB.080.060B
   begin
      -- convers�o padr�o
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='PIAB'    -- QB-PVNB-100-150	   Inch punch, M2, headed, V-type solid 1" x 1.5" blank	               PIAB	   PIAB.100.250.B
   or @prefix_atu='PIAEB'   -- QB-PVEB-100-150	   Inch punch, M2, headed, V-type ejector 1" x 1.5" blank	            PIAEB	   PIAEB.100.150.B
   or @prefix_atu='PIHB'    -- QS-PTNB-100-200	   Inch punch, M2, heavy duty head, solid 1" x 2" blank	               PIHB	   PIHB.037.350.B
   or @prefix_atu='PIHEB'   -- QS-PTEB-100-200	   Inch punch, M2, heavy duty head, ejector 1" x 2" blank	            PIHEB	   PIHEB.100.300.B
   or @prefix_atu='PIPB'    -- QB-PPNB-100-250	   Inch punch, M2, headed, solid 1" x 2.5" blank	                     PIPB	   PIPB.100.250.B
   or @prefix_atu='PIPEB'   -- QB-PPEB-100-250	   Inch punch, M2, headed, ejector 1" x 2.5" blank	                     PIPEB	   PIPEB.100.225.B
   begin
      -- convers�o padr�o : sem multiplicar por 10
      -- convers�o padr�o : sem stringZero
      -- convers�o padr�o : acrescido ponto no Sufixo
      set @Result= @prefix_atu+'.'+cast(@dia as varchar)   +'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +'.' +@sufix
      end
   end else
   if @prefix_atu='PPB'     -- PB-PPNB-10-100	   Metric punch, M2, 5mm head, solid 10mm x 100mm blank	               PPB	   PPB.030.050B (tem)
   or @prefix_atu='PPEB'    -- PB-PPEB-10-100	   Metric punch, M2, 5mm head, ejector 10mm x 100mm blank	            PPEB	   PPEB.050.045B
   begin
      -- convers�o padr�o : Multiplicar por 10
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end else
   if @prefix_atu='TABH'    -- RR-BHTN-10	         Metric retainer, ball lock HD, 10mm	                                 TABH	   TABH.100
   or @prefix_atu='TABL'    -- RR-BLTN-10          Metric retainer, ball lock LD, 10mm	                                 TABL	   TABL.060
   or @prefix_atu='TAIH'    -- SR-BHTN-100	      Inch retainer, ball lock HD, 1"	                                    TAIH	   TAIH.037
   or @prefix_atu='TAIL'    -- SR-BLTN-100         Inch retainer, ball lock LD, 1"	                                    TAIL	   TAIL.025
   or @prefix_atu='TCI'     -- SR-PPRS-100	      Inch retainer, triangular, headed type, for round punches, 1"	      TCI	   TCI.037
   or @prefix_atu='TCM'     -- RR-PPRS-10	         Metric retainer, triangular, headed type, for round punches, 10mm	   TCM	   TCM.080
   or @prefix_atu='TCPI'    -- SR-PPRF-100	      Inch retainer, triangular, headed type, for shaped punches, 1"	      TCPI	   TCPI.037
   or @prefix_atu='TCPM'    -- RR-PPRF-10	         Metric retainer, triangular, headed type, for shaped punches, 10mm	TCPM	   TCPM.080
   begin
      -- convers�o padr�o : sem multiplicar por 10
      -- convers�o padr�o : sem a composi��o do comprimento...
      -- convers�o padr�o : sem sufixo...
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(@dia, 3)
   end else
   begin
      -- Nenhum prefixo anterior cai na convers�o padr�o
      set @Result= @prefix_atu+'.'+dbo.fsi_StrZero(10*@dia, 3)+'.'+dbo.fsi_StrZero(@len, 3)
      if isnull(@sufix,'')<>'' begin
         set @Result = @Result +@sufix
      end
   end
   return @Result
end
go
----------------------------------------------------------------------------------------------------------------------------------------
if exists (select 1 from dbo.sysobjects where id = object_id(N'[dbo].[fmt_PuncPeso]') and (OBJECTPROPERTY(id, N'IsScalarFunction') = 1 or OBJECTPROPERTY(id, N'IsTableFunction') = 1))
   drop function [dbo].[fmt_PuncPeso]
go

----------------------------------------------------------------------------------------------------------------------------------------
-- DATA             -- AUTOR -- HIST�RICO
-- 08/12/2015 13:58 -- SCIED -- Retorna o peso do blank em Kg a partir de suas dimens�es, di�metro e comprimento em milimetros
----------------------------------------------------------------------------------------------------------------------------------------
CREATE function [dbo].[fmt_PuncPeso] (@dia int, @len int)
returns decimal(12,3) as
begin
   declare @Result decimal(12,3)
   set @Result= 7.86 * (3.1416/4) *( power(@dia,2)*(@len-5) +power(@dia+3,2)*5 )/1000000
   return @Result
end
go
----------------------------------------------------------------------------------------------------------------------------------------
---=======================================================================================================






Declare  @modo varchar(1) ,@par_erro varchar(255) ,@PUNC_CODB varchar(20) ,@PUNC_PREB varchar(20) ,@PUNC_MDLB varchar(20) ,@PUNC_DAYB varchar(20) ,@PUNC_MOEB varchar(20) ,@PUNC_NOMB varchar(100) ,@PUNC_DIAB decimal(9,2) ,@PUNC_LENB decimal(9,2) ,@PUNC_COD1 varchar(20)
         ,@PUNC_NOM1 varchar(100) ,@PUNC_NOM varchar(100) ,@PUNC_DIA1 decimal(9,2) ,@PUNC_LEN1 decimal(9,2) ,@PUNC_DHSTD decimal(10,3) ,@PUNC_DH1 decimal(10,3) ,@PUNC_DH2 decimal(10,3) ,@PUNC_MHSTD decimal(10,3) ,@PUNC_L2STD decimal(9,2) ,@PUNC_L2OP1 decimal(9,2)
         ,@PUNC_L2OP2 decimal(9,2) ,@PUNC_MINP decimal(10,3) ,@PUNC_MAXP decimal(10,3) ,@PUNC_MINW decimal(10,3) ,@PUNC_MAXPOG decimal(10,3) ,@PUNC_CODS varchar(20) ,@PUNC_MDLS varchar(20) ,@PUNC_DAYS varchar(20) ,@PUNC_MOES varchar(20) ,@PUNC_NOMS varchar(100)
         ,@PUNC_DIAS decimal(9,2) ,@PUNC_LENS decimal(9,2) ,@PUNC_CODL varchar(20) ,@PUNC_MDLL varchar(20) ,@PUNC_DAYL varchar(20) ,@PUNC_MOEL varchar(20) ,@PUNC_NOML varchar(100) ,@PUNC_DIAL decimal(9,2) ,@PUNC_LENL decimal(9,2) ,@PUNC_CODV varchar(20) ,@PUNC_MDLV varchar(20)
         ,@PUNC_DAYV1 varchar(20) ,@PUNC_DAYV2 varchar(20) ,@PUNC_MOEV varchar(20) ,@PUNC_NOMV varchar(100) ,@PUNC_DIAV decimal(9,2) ,@PUNC_LENV decimal(9,2) ,@PUNC_CODR varchar(20) ,@PUNC_MDLR varchar(20) ,@PUNC_DAYR1 varchar(20) ,@PUNC_DAYR2 varchar(20) ,@PUNC_MOER varchar(20)
         ,@PUNC_NOMR varchar(100) ,@PUNC_DIAR decimal(9,2) ,@PUNC_LENR decimal(9,2) ,@PUNC_CODF varchar(20) ,@PUNC_MDLF varchar(20) ,@PUNC_DAYF varchar(20) ,@PUNC_MOEF varchar(20) ,@PUNC_NOMF varchar(100) ,@PUNC_DIAF decimal(9,2) ,@PUNC_LENF decimal(9,2) ,@PUNC_CODH varchar(20)
         ,@PUNC_MDLH varchar(20) ,@PUNC_DAYH1 varchar(20) ,@PUNC_DAYH2 varchar(20) ,@PUNC_MOEH varchar(20) ,@PUNC_NOMH varchar(100) ,@PUNC_DIAH decimal(9,2) ,@PUNC_LENH decimal(9,2) ,@PUNC_CODZ varchar(20) ,@PUNC_MDLZ varchar(20) ,@PUNC_DAYZ varchar(20) ,@PUNC_MOEZ varchar(20)
         ,@PUNC_NOMZ varchar(100) ,@PUNC_DIAZ decimal(9,2) ,@PUNC_LENZ decimal(9,2) ,@PUNC_CODY varchar(20) ,@PUNC_MDLY varchar(20) ,@PUNC_DAYY varchar(20) ,@PUNC_MOEY varchar(20) ,@PUNC_NOMY varchar(100) ,@PUNC_DIAY decimal(9,2) ,@PUNC_LENY decimal(9,2) ,@PUNC_CODP varchar(20)
         ,@PUNC_MDLP varchar(20) ,@PUNC_DAYP varchar(20) ,@PUNC_MOEP varchar(20) ,@PUNC_NOMP varchar(100) ,@PUNC_DIAP decimal(9,2) ,@PUNC_LENP decimal(9,2) ,@PUNC_CODQ varchar(20) ,@PUNC_MDLQ varchar(20) ,@PUNC_DAYQ varchar(20) ,@PUNC_MOEQ varchar(20) ,@PUNC_NOMQ varchar(100)
         ,@PUNC_DIAQ decimal(9,2) ,@PUNC_LENQ decimal(9,2) ,@PUNC_MTPR_COD varchar(20) ,@PUNC_MTPR_MTTP varchar(25) ,@PUNC_MTPR_MS char(1) ,@PUNC_MTPR_ATV char(1) ,@PUNC_MTPR_NOM varchar(80) ,@PUNC_MTPR_MTDV varchar(4) ,@PUNC_MTPR_MTLN varchar(4) ,@PUNC_MTPR_MTFM varchar(4)
         ,@PUNC_MTPR_MTUN varchar(3) ,@PUNC_MTPR_MTNC varchar(8) ,@PUNC_MTPR_ORI char(1) ,@PUNC_MTPR_PES decimal(13,3) ,@PUNC_MTPR_DES varchar(240) ,@PUNC_MTPR_NIV int ,@PUNC_MTPR_ESUN varchar(3) ,@PUNC_MTPR_ESFT decimal(10,6) ,@PUNC_MTPR_CPUN varchar(3) ,@PUNC_MTPR_CPFT decimal(10,6)
         ,@PUNC_MTPR_ATVV char(1) ,@PUNC_MTPR_CFOV varchar(8) ,@PUNC_MTPR_ATVC char(1) ,@PUNC_MTPR_CFOC varchar(8) ,@PUNC_MTPR_TOLE decimal(12,4) ,@PUNC_MTES_SIES int ,@PUNC_MTES_MTAL varchar(6) ,@PUNC_MTES_MTAN varchar(6) ,@PUNC_MTES_MTAP varchar(6) ,@PUNC_MTES_LOTE char(1)
         ,@PUNC_MTES_GLMD varchar(8) ,@PUNC_MTES_QATU decimal(14,6) ,@PUNC_MTES_VATU decimal(14,6) ,@PUNC_MTES_VATM decimal(14,6) ,@PUNC_MTES_QVIS decimal(14,6) ,@PUNC_MTES_QNEC decimal(14,6) ,@PUNC_MTES_QPRO decimal(14,6) ,@PUNC_MTES_PCME decimal(14,6) ,@PUNC_MTES_PCMR decimal(14,6)
         ,@PUNC_MTES_PMIN int ,@PUNC_MTES_POBJ int ,@PUNC_MTES_POEM int ,@PUNC_MTES_PPMI decimal(14,6) ,@PUNC_MTES_PLEM decimal(14,6) ,@PUNC_MTES_PMUL decimal(14,6) ,@PUNC_MTES_PLEC decimal(14,6) ,@PUNC_MTES_UCDO varchar(25) ,@PUNC_MTES_LEAD int ,@PUNC_MTES_LEEM int
         ,@PUNC_MTES_EXPL char(1) ,@PUNC_MTES_MRP char(1) ,@PUNC_MTES_CREP decimal(18,6) ,@PUNC_MTES_CPDR decimal(18,6) ,@PUNC_MTES_FGGF decimal(18,6) ,@PUNC_MTES_FRAT int ,@PUNC_MTES_CTGT decimal(18,6) ,@PUNC_MTES_CPO1 varchar(50) ,@PUNC_MTES_CPO2 varchar(50)
         ,@PUNC_MTES_CPO3 varchar(50) ,@PUNC_MTES_CPO4 varchar(50) ,@PUNC_MTES_PRAT varchar(20) ,@PUNC_USC varchar(15) ,@PUNC_DTC datetime ,@PUNC_USU varchar(15) ,@PUNC_DTU datetime

-- ============= FASE I -- Campos default's para o M�xico ====================================================================

Select
--  ,@PUNC_MTPR_COD      =''
--  ,@PUNC_MTPR_MTTP     =''
   @PUNC_MTPR_MS       ='M'
  ,@PUNC_MTPR_ATV      ='S'
--  ,@PUNC_MTPR_NOM      =''
--  ,@PUNC_MTPR_MTDV     =''
--  ,@PUNC_MTPR_MTLN     =''
--  ,@PUNC_MTPR_MTFM     =''
  ,@PUNC_MTPR_MTUN     ='PZ'
  ,@PUNC_MTPR_MTNC     ='82073000'
  ,@PUNC_MTPR_ORI      ='1'
--  ,@PUNC_MTPR_PES      =0.000
--  ,@PUNC_MTPR_DES      =''
  ,@PUNC_MTPR_NIV      =0
  ,@PUNC_MTPR_ESUN     ='PZ'
  ,@PUNC_MTPR_ESFT     =1.000000
  ,@PUNC_MTPR_CPUN     ='PZ'
  ,@PUNC_MTPR_CPFT     =1.000000
  ,@PUNC_MTPR_ATVV     ='S'
  ,@PUNC_MTPR_CFOV     ='5.4101'
  ,@PUNC_MTPR_ATVC     ='S'
  ,@PUNC_MTPR_CFOC     ='1.5101'
  ,@PUNC_MTPR_TOLE     =5.0000
  ,@PUNC_MTES_SIES     =1
  ,@PUNC_MTES_MTAL     ='ALMO01'
  ,@PUNC_MTES_MTAN     ='ALMO01'
  ,@PUNC_MTES_MTAP     ='ALMO01'
  ,@PUNC_MTES_LOTE     ='N'
  ,@PUNC_MTES_GLMD     ='USD'
  ,@PUNC_MTES_QATU     =0.000000
  ,@PUNC_MTES_VATU     =0.000000
  ,@PUNC_MTES_VATM     =0.000000
  ,@PUNC_MTES_QVIS     =0.000000
  ,@PUNC_MTES_QNEC     =0.000000
  ,@PUNC_MTES_QPRO     =0.000000
  ,@PUNC_MTES_PCME     =0.000000
  ,@PUNC_MTES_PCMR     =0.000000
  ,@PUNC_MTES_PMIN     =0
  ,@PUNC_MTES_POBJ     =0
  ,@PUNC_MTES_POEM     =0
  ,@PUNC_MTES_PPMI     =0.000000
  ,@PUNC_MTES_PLEM     =0.000000
  ,@PUNC_MTES_PMUL     =0.000000
  ,@PUNC_MTES_PLEC     =0.000000
  ,@PUNC_MTES_UCDO     =''
  ,@PUNC_MTES_LEAD     =0
  ,@PUNC_MTES_LEEM     =0
  ,@PUNC_MTES_EXPL     =''
  ,@PUNC_MTES_MRP      =''
  ,@PUNC_MTES_CREP     =0.000000
  ,@PUNC_MTES_CPDR     =0.000000
  ,@PUNC_MTES_FGGF     =0.000000
  ,@PUNC_MTES_FRAT     =0
  ,@PUNC_MTES_CTGT     =0.000000
  ,@PUNC_MTES_CPO1     =''
  ,@PUNC_MTES_CPO2     =''
  ,@PUNC_MTES_CPO3     =''
  ,@PUNC_MTES_CPO4     =''
  ,@PUNC_MTES_PRAT     =''
--  ,@PUNC_USC           =''
--  ,@PUNC_DTC           =getdate()
--  ,@PUNC_USU           =''
--  ,@PUNC_DTU           =getdate()


update PUNC set 
--,punc_MTPR_COD = @PUNC_MTPR_COD     -- =''
--,punc_MTPR_MTTP= @PUNC_MTPR_MTTP  --   =''
   punc_MTPR_MS  = @PUNC_MTPR_MS      -- ='S'
  ,punc_MTPR_ATV = @PUNC_MTPR_ATV     -- ='S'

-- Exce��o
  ,punc_MTPR_NOM = PUNC_NOMB   --   =''

--,punc_MTPR_MTDV= @PUNC_MTPR_MTDV  --   =''
--,punc_MTPR_MTLN= @PUNC_MTPR_MTLN  --   =''
--,punc_MTPR_MTFM= @PUNC_MTPR_MTFM  --   =''
  ,punc_MTPR_MTUN= @PUNC_MTPR_MTUN    -- ='PZ'
  ,punc_MTPR_MTNC= @PUNC_MTPR_MTNC    -- ='82073000'
  ,punc_MTPR_ORI = @PUNC_MTPR_ORI     -- ='1'
--,punc_MTPR_PES = @PUNC_MTPR_PES   --   =0.000
--,punc_MTPR_DES = @PUNC_MTPR_DES   --   =''
  ,punc_MTPR_NIV = @PUNC_MTPR_NIV     -- =0
  ,punc_MTPR_ESUN= @PUNC_MTPR_ESUN    -- ='PZ'
  ,punc_MTPR_ESFT= @PUNC_MTPR_ESFT    -- =1.000000
  ,punc_MTPR_CPUN= @PUNC_MTPR_CPUN    -- ='PZ'
  ,punc_MTPR_CPFT= @PUNC_MTPR_CPFT    -- =1.000000
  ,punc_MTPR_ATVV= @PUNC_MTPR_ATVV    -- ='S'
  ,punc_MTPR_CFOV= @PUNC_MTPR_CFOV    -- ='S'
  ,punc_MTPR_ATVC= @PUNC_MTPR_ATVC    -- ='S'
  ,punc_MTPR_CFOC= @PUNC_MTPR_CFOC    -- ='S'
  ,punc_MTPR_TOLE= @PUNC_MTPR_TOLE    -- =5.0000
  ,punc_MTES_SIES= @PUNC_MTES_SIES    -- =1
  ,punc_MTES_MTAL= @PUNC_MTES_MTAL    -- ='ALMO01'
  ,punc_MTES_MTAN= @PUNC_MTES_MTAN    -- ='ALMO01'
  ,punc_MTES_MTAP= @PUNC_MTES_MTAP    -- ='ALMO01'
  ,punc_MTES_LOTE= @PUNC_MTES_LOTE    -- ='N'
  ,punc_MTES_GLMD= @PUNC_MTES_GLMD    -- ='USD'
  ,punc_MTES_QATU= @PUNC_MTES_QATU    -- =0.000000
  ,punc_MTES_VATU= @PUNC_MTES_VATU    -- =0.000000
  ,punc_MTES_VATM= @PUNC_MTES_VATM    -- =0.000000
  ,punc_MTES_QVIS= @PUNC_MTES_QVIS    -- =0.000000
  ,punc_MTES_QNEC= @PUNC_MTES_QNEC    -- =0.000000
  ,punc_MTES_QPRO= @PUNC_MTES_QPRO    -- =0.000000
  ,punc_MTES_PCME= @PUNC_MTES_PCME    -- =0.000000
  ,punc_MTES_PCMR= @PUNC_MTES_PCMR    -- =0.000000
  ,punc_MTES_PMIN= @PUNC_MTES_PMIN    -- =0
  ,punc_MTES_POBJ= @PUNC_MTES_POBJ    -- =0
  ,punc_MTES_POEM= @PUNC_MTES_POEM    -- =0
  ,punc_MTES_PPMI= @PUNC_MTES_PPMI    -- =0.000000
  ,punc_MTES_PLEM= @PUNC_MTES_PLEM    -- =0.000000
  ,punc_MTES_PMUL= @PUNC_MTES_PMUL    -- =0.000000
  ,punc_MTES_PLEC= @PUNC_MTES_PLEC    -- =0.000000
  ,punc_MTES_UCDO= @PUNC_MTES_UCDO    -- =''
  ,punc_MTES_LEAD= @PUNC_MTES_LEAD    -- =0
  ,punc_MTES_LEEM= @PUNC_MTES_LEEM    -- =0
  ,punc_MTES_EXPL= @PUNC_MTES_EXPL    -- =''
  ,punc_MTES_MRP = @PUNC_MTES_MRP     -- =''
  ,punc_MTES_CREP= @PUNC_MTES_CREP    -- =0.000000
  ,punc_MTES_CPDR= @PUNC_MTES_CPDR    -- =0.000000
  ,punc_MTES_FGGF= @PUNC_MTES_FGGF    -- =0.000000
  ,punc_MTES_FRAT= @PUNC_MTES_FRAT    -- =0
  ,punc_MTES_CTGT= @PUNC_MTES_CTGT    -- =0.000000
  ,punc_MTES_CPO1= @PUNC_MTES_CPO1    -- =''
  ,punc_MTES_CPO2= @PUNC_MTES_CPO2    -- =''
  ,punc_MTES_CPO3= @PUNC_MTES_CPO3    -- =''
  ,punc_MTES_CPO4= @PUNC_MTES_CPO4    -- =''
  ,punc_MTES_PRAT= @PUNC_MTES_PRAT    -- =''


go


-- ============= FASE II -- Campos calculados para o M�xico ====================================================================


declare @debug char(1)
set @debug='N'
--set @debug='S'
print '@debug='+@debug
   -- Controle das transa��es pelo programador
   set dateformat ymd
   set implicit_transactions off
   set nocount on

declare cPUNC cursor local static for
select
 punc_codB
 ,prenew  =isnull(punc_preB , '')
 ,preatu  =isnull(punc_mdlB , '')
 ,diaB    =isnull(punc_diaB , 0)
 ,lenB    =isnull(punc_lenB , 0)
 ,vida    =isnull(punc_l2std, 0)
from PUNC
-- debug
where isnull(punc_codb,'*')<>'*'-- like 'DB-HMCB%'
order by punc_codB
 


open cPUNC
declare @punc_codb varchar(20), @subs varchar(20), @pos int, @punc_mtpr_pes decimal(15,3)
declare @prefix varchar(20), @preNew varchar(20), @preAtu varchar(20), @equivalente varchar(20), @diaB Int, @lenB Int , @vida Int , @mtpc_pre decimal(12,2), @mtpc_glmd varchar(20)
declare @saldo_dis decimal(16,3), @glmd varchar(8), @price decimal(12,2)

fetch next from cPUNC into  @punc_codB, @preNew, @preAtu, @diaB, @lenB, @vida



while @@fetch_status=0 begin
   -- Ajuste da vida (L2) 
   if (dbo.fsi_Occurs('-',@punc_codB)=4 ) and (@vida=0) begin
      -- Para obter a 3a. dimens�o equivalente a vida (caso das matrizes)
      set @subs=@punc_codB
      set @pos=charindex('-',@subs)
      while @pos>0 begin
         set @subs=substring(@subs,@pos+1,30)
         set @pos=charindex('-',@subs)
      end
      set @vida= cast( @subs as integer)
   end
   -- C�lculo do c�digo equivalente
   set @equivalente=''
   if isnull(@preAtu,'')<>'' begin 
		if substring(@prenew,1,1) in('Q','E','S') begin 
      set @equivalente=dbo.fmt_PuncCodOld2(@preNew, @preAtu, @diaB*100, @lenB+100, @vida, 'B')
		end else begin
      set @equivalente=dbo.fmt_PuncCodOld2(@preNew, @preAtu, @diaB, @lenB, @vida, 'B')
		end
	 end
   if isnull(@equivalente,'*')='*' set @equivalente='*'  
  
   -- C�lculo do Peso
   set @punc_mtpr_pes=0.00
   if substring(@prenew,1,1) in('Q','E','S') begin 
		set @punc_mtpr_pes=dbo.fmt_PuncPeso(@diaB*100, @lenB*100)
	 end else begin
		set @punc_mtpr_pes=dbo.fmt_PuncPeso(@diaB, @lenB)
	 end
   if @debug='N' begin
      update PUNC set 
       punc_mtpr_cod=@equivalente
      ,punc_mtpr_pes=@punc_mtpr_pes
      where punc_codB=@punc_codB
      if @@error<>0 begin
         print 'Erro atualizando PUNC para punc_codB='''+@punc_codb+''''
      end
   end
   print 'Atualizando c�digo '+substring(@punc_codB+space(20), 1, 20) +' equivalente:'+substring(@equivalente+space(20),1,20) +'  peso:'+space(13-len(cast(@punc_mtpr_pes as varchar)))+cast(@punc_mtpr_pes as varchar)
   fetch next from cPUNC into  @punc_codB, @preNew, @preAtu, @diaB, @lenB, @vida
end
close cPUNC
deallocate cPUNC

go
go


-- ============= FASE III -- Pre�o, moneda e Saldo dispon�vel (ALMO01)  ====================================================================
declare @debug char(1)
set @debug='N'
--set @debug='S'
print '@debug='+@debug
   -- Controle das transa��es pelo programador
   set dateformat ymd
   set implicit_transactions off
   set nocount on

declare @ano int, @usu varchar(20), @dtu datetime
select @ano=2017
      ,@usu='SQLqaSMR'
      ,@dtu=getdate()

declare cPUNC cursor local static for
select
 punc_codB
,punc_mtpr_cod
,punc_mtes_sies
,punc_mtes_mtal
from PUNC
-- debug
where isnull(punc_codb    ,'*')<>'*'
and   isnull(punc_mtpr_cod,'*')<>'*'
and   isnull(punc_mtpr_cod,'') <>''
order by punc_codB
 


open cPUNC
declare @punc_codb varchar(20), @punc_mtpr_cod varchar(20), @punc_mtes_sies int, @punc_exists char(1), @punc_mtes_mtal varchar(8)
declare @punc_saldo decimal(16,3), @punc_mtpc_glmd varchar(8), @punc_mtpc_pre decimal(12,2)

fetch next from cPUNC into  @punc_codB, @punc_mtpr_cod, @punc_mtes_sies,  @punc_mtes_mtal
while @@fetch_status=0 begin
   select 
    @punc_mtpc_glmd='USD'
   ,@punc_mtpc_pre =9999.99
   -- Verifica a exist�ncia do c�digo convertido
   if exists (select 1 from MTPR where mtpr_cod=@punc_mtpr_cod) begin
      set @punc_exists='S'
   end else begin
      set @punc_exists='N'
--      print 'Processando c�digo '+@punc_codB +' equivalente:'+@punc_mtpr_cod +' n�o encontrado em MTPR...'
   end
   -- Verifica a exist�ncia de saldo...
   --if @punc_exists='S' begin
      --set @punc_saldo= mdlmex.dbo.fmt_Saldo_mtsy(@punc_mtpr_cod,@punc_mtes_sies, @ano, @punc_mtes_mtal)
      --set @punc_saldo= [192.168.4.2\sqlexpress].[mdlmex].[dbo].fmt_Saldo_mtsy(@punc_mtpr_cod,@punc_mtes_sies, @ano, @punc_mtes_mtal)
   --end else begin
      --set @punc_saldo= 0
   --end
   -- Verifica a exist�ncia do c�digo comercial
   if @punc_exists='S' begin
      if exists (select 1 from MTPC where mtpc_mtpr=@punc_mtpr_cod) begin
         select 
          @punc_mtpc_glmd=mtpc_glmd
         ,@punc_mtpc_pre =mtpc_pre
         from MTPC where mtpc_mtpr=@punc_mtpr_cod
      end else begin
--         set @punc_exists='N'
         print 'Processando c�digo '+@punc_codB +' equivalente:'+@punc_mtpr_cod +' n�o encontrado em MTPC...'
      end
   end
   
   -- Atualiza o registro
   if @debug='N' begin
      update PUNC set 
       punc_mtpc_pre =@punc_mtpc_pre
      ,punc_mtpc_glmd=@punc_mtpc_glmd
      ,punc_saldo    =@punc_saldo
      ,punc_exists   =@punc_exists
      ,punc_usu      =@usu
      ,punc_dtu      =@dtu
      where punc_codB=@punc_codB
      if @@error<>0 begin
         print 'Erro atualizando PUNC para punc_codB='''+@punc_codb+''''
      end
   end      
   print 'Atualizando c�digo '+substring(@punc_codB+space(20), 1, 20) +' equivalente:'+substring(@punc_mtpr_cod+space(20),1,20) +'  pre�o:'+space(13-len(cast(@punc_mtpc_pre as varchar)))+cast(@punc_mtpc_pre as varchar) +'  moeda:'+substring(cast(@punc_mtpc_glmd as varchar)+space(20),1,20)  +'  saldo:'+space(10-len(cast(@punc_saldo as varchar)))+cast(@punc_saldo as varchar)  +'  exists:'+@punc_exists
   fetch next from cPUNC into  @punc_codB, @punc_mtpr_cod, @punc_mtes_sies,  @punc_mtes_mtal
end
close cPUNC
deallocate cPUNC

go
go


-- ============= FASE IV -- Tabela reversa (n�o encontrados )com saldos Saldo dispon�vel  ====================================================================
/*

select mtes_mtpr, mtes_sies, mtes_qatu, mtpr_mtdv, a.punc_mtpr_cod, b.punc_codB
from mtes inner join mtpr on (mtes_mtpr=mtpr_cod)
          left outer join PUNC a on (a.punc_mtpr_cod=mtpr_cod)
          left outer join PUNC b on (b.punc_codB=mtpr_cod)
--and mtes_sies=1
where 
    (mtpr_mtdv='05' or mtpr_mtdv='06')
and mtes_qatu>0
and (isnull(a.PUNC_MTPR_COD,'*')='*' or isnull(a.PUNC_MTPR_COD,'')='')
and (isnull(b.PUNC_CODB,'*')='*'     or isnull(b.PUNC_CODB,'')='')
--and mtes_mtpr like 'MSBS%'
order by mtes_mtpr

--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'BILB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'BILEB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'BILEHB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'BILHB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'BLKHB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'BLMB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'MB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'PIHB%'
--select punc_mtpr_cod, punc_exists, punc_codB from punc where punc_mtpr_cod like 'MSBS%'


*/