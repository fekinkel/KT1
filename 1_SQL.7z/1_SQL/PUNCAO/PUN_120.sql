--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 05/03/2018--DEPARTAMENTO : VENDAS--ASSUNTO      : INCLUIR C�DIGOS COM 120 (PB-PPE1-XXX-120) ------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#PUNC') IS NOT NULL DROP TABLE #PUNCSELECT *, PUNC_CODB PUNC_CODB_OLD INTO #PUNC FROM PUNC WHERE 1 = 0INSERT INTO #PUNCSELECT 		replace(PUNC_CODB,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodB(C�digo do blank)
	, PUNC_PREB --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') PREB(PREB)
	, PUNC_MDLB --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLB(MDLB)
	, PUNC_DAYB --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYB(DAYB)
	, PUNC_MOEB --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEB(MOEB)
	, replace(PUNC_NOMB,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMB(NOMB)
	, PUNC_DIAB --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAB(DIAB)
	, PUNC_LENB = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENB(LENB)
	, replace(PUNC_COD1,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto base)
	, replace(PUNC_NOM1,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') Nome1(Nome do insumo)
	, replace(PUNC_NOM,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') Nome(Nome do insumo)
	, PUNC_DIA1 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') Diametro1(Di�metro base)
	, PUNC_LEN1 = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') Comp1(Comprimento base)
	, PUNC_DHSTD --= Null      --CONVERT(decimal(10),'') DHSTD(Altura padr�o de matrizes Dayton)
	, PUNC_DH1 --= Null      --CONVERT(decimal(10),'') DH1(Altura op��o 1 de matrizes Dayton)
	, PUNC_DH2 --= Null      --CONVERT(decimal(10),'') DH2(Altura op��o 2 de matrizes Dayton)
	, PUNC_MHSTD --= Null      --CONVERT(decimal(10),'') MHSTD(Altura padr�o de matrizes MDL)
	, PUNC_L2STD --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') L2STD(L2STD)
	, PUNC_L2OP1 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') L2OP1(L2OP1)
	, PUNC_L2OP2 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') L2OP2(L2OP2)
	, PUNC_MINP --= Null      --CONVERT(decimal(10),'') MINP(MINP)
	, PUNC_MAXP --= Null      --CONVERT(decimal(10),'') MAXP(MAXP)
	, PUNC_MINW --= Null      --CONVERT(decimal(10),'') MINW(MINW)
	, PUNC_MAXPOG --= Null      --CONVERT(decimal(10),'') MAXPOG(MAXPOG)
	, replace(PUNC_CODS,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodS(C�digo do redondo)
	, PUNC_MDLS --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLS(MDLS)
	, PUNC_DAYS --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYS(DAYS)
	, PUNC_MOES --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOES(MOES)
	, replace(PUNC_NOMS,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMS(NOMS)
	, PUNC_DIAS --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAS(DIAS)
	, PUNC_LENS = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENS(LENS)
	, replace(PUNC_CODL,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodL(C�digo do oblongo)
	, PUNC_MDLL --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLL(MDLL)
	, PUNC_DAYL --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYL(DAYL)
	, PUNC_MOEL --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEL(MOEL)
	, replace(PUNC_NOML,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOML(NOML)
	, PUNC_DIAL --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAL(DIAL)
	, PUNC_LENL = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENL(LENL)
	, replace(PUNC_CODV,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodV(C�digo do quadrado)
	, PUNC_MDLV --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLV(MDLV)
	, PUNC_DAYV1 --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYV1(DAYV1)
	, PUNC_DAYV2 --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYV2(DAYV2)
	, PUNC_MOEV --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEV(MOEV)
	, replace(PUNC_NOMV,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMV(NOMV)
	, PUNC_DIAV --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAV(DIAV)
	, PUNC_LENV = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENV(LENV)
	, replace(PUNC_CODR,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodR(C�digo do retangulo)
	, PUNC_MDLR --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLR(MDLR)
	, PUNC_DAYR1 --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYR1(DAYR1)
	, PUNC_DAYR2 --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYR2(DAYR2)
	, PUNC_MOER --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOER(MOER)
	, replace(PUNC_NOMR,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMR(NOMR)
	, PUNC_DIAR --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAR(DIAR)
	, PUNC_LENR = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENR(LENR)
	, replace(PUNC_CODF,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodF(C�digo do retangulo arredondado)
	, PUNC_MDLF --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLF(MDLF)
	, PUNC_DAYF --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYF(DAYF)
	, PUNC_MOEF --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEF(MOEF)
	, replace(PUNC_NOMF,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMF(NOMF)
	, PUNC_DIAF --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAF(DIAF)
	, PUNC_LENF = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENF(LENF)
	, replace(PUNC_CODH,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodH(C�digo do hex�gono)
	, PUNC_MDLH --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLH(MDLH)
	, PUNC_DAYH1 --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYH1(DAYH1)
	, PUNC_DAYH2 --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYH2(DAYH2)
	, PUNC_MOEH --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEH(MOEH)
	, replace(PUNC_NOMH,'100mm', '120mm') --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMH(NOMH)
	, PUNC_DIAH --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAH(DIAH)
	, PUNC_LENH = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENH(LENH)
	, PUNC_CODZ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodZ(C�digo do piloto padr�o)
	, PUNC_MDLZ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLZ(MDLZ)
	, PUNC_DAYZ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYZ(DAYZ)
	, PUNC_MOEZ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEZ(MOEZ)
	, PUNC_NOMZ --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMZ(NOMZ)
	, PUNC_DIAZ --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAZ(DIAZ)
	, PUNC_LENZ --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENZ(LENZ)
	, PUNC_CODY --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodY(C�digo do piloto angulado)
	, PUNC_MDLY --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLY(MDLY)
	, PUNC_DAYY --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYY(DAYY)
	, PUNC_MOEY --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEY(MOEY)
	, PUNC_NOMY --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMY(NOMY)
	, PUNC_DIAY --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAY(DIAY)
	, PUNC_LENY --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENY(LENY)
	, PUNC_CODP --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodP(C�digo do piloto compacto)
	, PUNC_MDLP --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLP(MDLP)
	, PUNC_DAYP --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYP(DAYP)
	, PUNC_MOEP --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEP(MOEP)
	, PUNC_NOMP --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMP(NOMP)
	, PUNC_DIAP --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAP(DIAP)
	, PUNC_LENP --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENP(LENP)
	, PUNC_CODQ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') CodQ(C�digo do piloto com passo)
	, PUNC_MDLQ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MDLQ(MDLQ)
	, PUNC_DAYQ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') DAYQ(DAYQ)
	, PUNC_MOEQ --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') MOEQ(MOEQ)
	, PUNC_NOMQ --= CONVERT(varchar(100),'')      --CONVERT(varchar(100),'') NOMQ(NOMQ)
	, PUNC_DIAQ --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') DIAQ(DIAQ)
	, PUNC_LENQ = 120 --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') LENQ(LENQ)
	, replace(PUNC_MTPR_COD,'-100','-120') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, PUNC_MTPR_MTTP --= Null      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, PUNC_MTPR_MS --= CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, PUNC_MTPR_ATV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, replace(PUNC_MTPR_NOM,'100mm', '120mm') --= CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, PUNC_MTPR_MTDV --= Null      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, PUNC_MTPR_MTLN --= Null      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, PUNC_MTPR_MTFM --= Null      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, PUNC_MTPR_MTUN --= Null      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, PUNC_MTPR_MTNC --= Null      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, PUNC_MTPR_ORI --= CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, PUNC_MTPR_PES --= CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, PUNC_MTPR_DES --= Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, PUNC_MTPR_NIV --= Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, PUNC_MTPR_ESUN --= Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, PUNC_MTPR_ESFT --= Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, PUNC_MTPR_CPUN --= Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, PUNC_MTPR_CPFT --= Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, PUNC_MTPR_ATVV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, PUNC_MTPR_CFOV --= Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, PUNC_MTPR_ATVC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, PUNC_MTPR_CFOC --= Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, PUNC_MTPR_TOLE --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, PUNC_MTES_SIES --= Null      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, PUNC_MTES_MTAL --= Null      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, PUNC_MTES_MTAN --= Null      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, PUNC_MTES_MTAP --= Null      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, PUNC_MTES_LOTE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, PUNC_MTES_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, PUNC_MTES_QATU --= Null      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, PUNC_MTES_VATU --= Null      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, PUNC_MTES_VATM --= Null      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, PUNC_MTES_QVIS --= Null      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, PUNC_MTES_QNEC --= Null      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, PUNC_MTES_QPRO --= Null      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, PUNC_MTES_PCME --= Null      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, PUNC_MTES_PCMR --= Null      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, PUNC_MTES_PMIN --= Null      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, PUNC_MTES_POBJ --= Null      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, PUNC_MTES_POEM --= Null      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, PUNC_MTES_PPMI --= Null      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, PUNC_MTES_PLEM --= Null      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, PUNC_MTES_PMUL --= Null      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, PUNC_MTES_PLEC --= Null      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, PUNC_MTES_UCDO --= Null      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, PUNC_MTES_LEAD --= Null      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, PUNC_MTES_LEEM --= Null      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, PUNC_MTES_EXPL --= CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, PUNC_MTES_MRP --= CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, PUNC_MTES_CREP --= Null      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, PUNC_MTES_CPDR --= Null      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, PUNC_MTES_FGGF --= Null      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, PUNC_MTES_FRAT --= CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, PUNC_MTES_CTGT --= Null      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, PUNC_MTES_CPO1 --= Null      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, PUNC_MTES_CPO2 --= Null      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, PUNC_MTES_CPO3 --= Null      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, PUNC_MTES_CPO4 --= Null      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, PUNC_MTES_PRAT --= Null      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, PUNC_MTPC_PRE --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, PUNC_MTPC_GLMD --= Null      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, PUNC_SALDO --= Null      --CONVERT(decimal(16),'') Saldo(Saldo)
	, PUNC_EXISTS --= Null      --CONVERT(varchar(1),'') Exists(Exists)
	, PUNC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, PUNC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, PUNC_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, PUNC_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, PUNC_CODB
	--select *
from punc
where substring(punc_cod1,1,7) =  'PB-PPE1'
and punc_cod1 like '%100'
--INSERT INTO PUNCSELECT *FROM #PUNCWHERE PUNC_CODB NOT IN (SELECT PUNC_CODB FROM PUNC)
--PUNC_CODB ,PUNC_PREB ,PUNC_MDLB ,PUNC_DAYB ,PUNC_MOEB ,PUNC_NOMB ,PUNC_DIAB ,PUNC_LENB ,PUNC_COD1 ,PUNC_NOM1 ,PUNC_NOM ,PUNC_DIA1 ,PUNC_LEN1 ,PUNC_DHSTD ,PUNC_DH1 ,PUNC_DH2 ,PUNC_MHSTD ,PUNC_L2STD ,PUNC_L2OP1 ,PUNC_L2OP2 ,PUNC_MINP ,PUNC_MAXP ,PUNC_MINW ,PUNC_MAXPOG ,PUNC_CODS ,PUNC_MDLS ,PUNC_DAYS ,PUNC_MOES ,PUNC_NOMS ,PUNC_DIAS ,PUNC_LENS ,PUNC_CODL ,PUNC_MDLL ,PUNC_DAYL ,PUNC_MOEL ,PUNC_NOML ,PUNC_DIAL ,PUNC_LENL ,PUNC_CODV ,PUNC_MDLV ,PUNC_DAYV1 ,PUNC_DAYV2 ,PUNC_MOEV ,PUNC_NOMV ,PUNC_DIAV ,PUNC_LENV ,PUNC_CODR ,PUNC_MDLR ,PUNC_DAYR1 ,PUNC_DAYR2 ,PUNC_MOER ,PUNC_NOMR ,PUNC_DIAR ,PUNC_LENR ,PUNC_CODF ,PUNC_MDLF ,PUNC_DAYF ,PUNC_MOEF ,PUNC_NOMF ,PUNC_DIAF ,PUNC_LENF ,PUNC_CODH ,PUNC_MDLH ,PUNC_DAYH1 ,PUNC_DAYH2 ,PUNC_MOEH ,PUNC_NOMH ,PUNC_DIAH ,PUNC_LENH ,PUNC_CODZ ,PUNC_MDLZ ,PUNC_DAYZ ,PUNC_MOEZ ,PUNC_NOMZ ,PUNC_DIAZ ,PUNC_LENZ ,PUNC_CODY ,PUNC_MDLY ,PUNC_DAYY ,PUNC_MOEY ,PUNC_NOMY ,PUNC_DIAY ,PUNC_LENY ,PUNC_CODP ,PUNC_MDLP ,PUNC_DAYP ,PUNC_MOEP ,PUNC_NOMP ,PUNC_DIAP ,PUNC_LENP ,PUNC_CODQ ,PUNC_MDLQ ,PUNC_DAYQ ,PUNC_MOEQ ,PUNC_NOMQ ,PUNC_DIAQ ,PUNC_LENQ ,PUNC_MTPR_COD ,PUNC_MTPR_MTTP ,PUNC_MTPR_MS ,PUNC_MTPR_ATV ,PUNC_MTPR_NOM ,PUNC_MTPR_MTDV ,PUNC_MTPR_MTLN ,PUNC_MTPR_MTFM ,PUNC_MTPR_MTUN ,PUNC_MTPR_MTNC ,PUNC_MTPR_ORI ,PUNC_MTPR_PES ,PUNC_MTPR_DES ,PUNC_MTPR_NIV ,PUNC_MTPR_ESUN ,PUNC_MTPR_ESFT ,PUNC_MTPR_CPUN ,PUNC_MTPR_CPFT ,PUNC_MTPR_ATVV ,PUNC_MTPR_CFOV ,PUNC_MTPR_ATVC ,PUNC_MTPR_CFOC ,PUNC_MTPR_TOLE ,PUNC_MTES_SIES ,PUNC_MTES_MTAL ,PUNC_MTES_MTAN ,PUNC_MTES_MTAP ,PUNC_MTES_LOTE ,PUNC_MTES_GLMD ,PUNC_MTES_QATU ,PUNC_MTES_VATU ,PUNC_MTES_VATM ,PUNC_MTES_QVIS ,PUNC_MTES_QNEC ,PUNC_MTES_QPRO ,PUNC_MTES_PCME ,PUNC_MTES_PCMR ,PUNC_MTES_PMIN ,PUNC_MTES_POBJ ,PUNC_MTES_POEM ,PUNC_MTES_PPMI ,PUNC_MTES_PLEM ,PUNC_MTES_PMUL ,PUNC_MTES_PLEC ,PUNC_MTES_UCDO ,PUNC_MTES_LEAD ,PUNC_MTES_LEEM ,PUNC_MTES_EXPL ,PUNC_MTES_MRP ,PUNC_MTES_CREP ,PUNC_MTES_CPDR ,PUNC_MTES_FGGF ,PUNC_MTES_FRAT ,PUNC_MTES_CTGT ,PUNC_MTES_CPO1 ,PUNC_MTES_CPO2 ,PUNC_MTES_CPO3 ,PUNC_MTES_CPO4 ,PUNC_MTES_PRAT ,PUNC_MTPC_PRE ,PUNC_MTPC_GLMD ,PUNC_SALDO ,PUNC_EXISTS ,PUNC_USC ,PUNC_DTC ,PUNC_USU ,PUNC_DTU ,

IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT *, MTPR_COD MTPR_COD_OLD INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		REPLACE(MTPR_COD,'-100','-120')-- = CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP --= CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS --= CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, REPLACE(MTPR_NOM,'x 100', 'x 120')-- = CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI --= CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES --= CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES --= Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV --= Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN --= Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT --= Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN --= Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT --= Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV --= Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC --= Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST --= Null      --CONVERT(varchar(7),'') CEST(C�digo Especificador da Substitui��o Tribut�ria (CEST) - Confaz Conv�nio ICMS N� 92/2015)
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTPR_COD
	--SELECT *	FROM MTPr	WHERE substring(MTPr_COD,1,6) =  'PB-PPE'
	and MTPr_COD like '%100'--INSERT INTO MTPRSELECT *FROM #MTPRWHERE MTPR_cod NOT IN (SELECT MTPR_cod FROM MTPR)
--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_FEST ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU ,

IF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		REPLACE(MTES_MTPR,'-100', '-120')-- = CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTES_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTES_MTAL --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, MTES_MTAN --= Null      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, MTES_MTAP --= Null      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, MTES_LOTE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, MTES_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, MTES_QATU --= Null      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, MTES_VATU --= Null      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, MTES_VATM --= Null      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, MTES_QVIS --= Null      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, MTES_QNEC --= Null      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, MTES_QPRO --= Null      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, MTES_PCME --= Null      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, MTES_PCMR --= Null      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, MTES_PMIN --= Null      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, MTES_POBJ --= Null      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, MTES_POEM --= Null      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, MTES_PPMI --= Null      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, MTES_PLEM --= Null      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, MTES_PMUL --= Null      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, MTES_PLEC --= Null      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, MTES_UCDO --= Null      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, MTES_LEAD --= Null      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, MTES_LEEM --= Null      --CONVERT(int(8),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, MTES_EXPL --= CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, MTES_MRP --= CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, MTES_CREP --= Null      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, MTES_CPDR --= Null      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, MTES_FGGF --= Null      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, MTES_FRAT --= CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, MTES_CTGT --= Null      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, MTES_CPO1 --= Null      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, MTES_CPO2 --= Null      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, MTES_CPO3 --= Null      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, MTES_CPO4 --= Null      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, MTES_PRAT --= Null      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *	FROM MTes	WHERE substring(mtes_MTPr,1,6) =  'PB-PPE'
	and mtes_mtpr like '%100'--INSERT INTO MTESSELECT *FROM #MTESWHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+mtes_mtpr NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+mtes_mtpr FROM MTES)
--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU ,

IF OBJECT_ID('TempDB.dbo.#MTPC') IS NOT NULL DROP TABLE #MTPCSELECT * INTO #MTPC FROM MTPC WHERE 1 = 0INSERT INTO #MTPCSELECT 		REPLACE(MTPC_COD,'-100','-120')-- = CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, REPLACE(MTPC_MTPR,'-100', '-120')-- = CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, REPLACE(MTPC_NOM,'x 100', 'x 120')-- = CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do produto comercial)
	, MTPC_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, MTPC_PRE --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, MTPC_PRE_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_PRE_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do pre�o do produto)
	, MTPC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPC_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *	FROM MTPC	WHERE substring(MTPC_COD,1,6) =  'PB-PPE'
	and MTPC_COD like '%100'--INSERT INTO MTPCSELECT *FROM #MTPCWHERE MTPC_COD NOT IN (SELECT MTPC_COD FROM MTPC)
--MTPC_COD ,MTPC_MTPR ,MTPC_NOM ,MTPC_GLMD ,MTPC_PRE ,MTPC_PRE_USU ,MTPC_PRE_DTU ,MTPC_USC ,MTPC_DTC ,MTPC_USU ,MTPC_DTU ,

IF OBJECT_ID('TempDB.dbo.#MTEP') IS NOT NULL DROP TABLE #MTEPSELECT * INTO #MTEP FROM MTEP WHERE 1 = 0INSERT INTO #MTEPSELECT 		MTEP_PAI = MTPR_COD--CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') C�digo (Pai)(C�digo do produto ou insumo)
	, MTEP_FIL --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') C�digo (Filho)(C�digo do produto ou insumo)
	, MTEP_SEQ --= CONVERT(int(4),'')      --CONVERT(int(4),'') Sequ�ncia(Sequencia do componente)
	, MTEP_QTD --= Null      --CONVERT(decimal(12),'') Quantidade(Quantidade do componente filho para uma unidade do pai)
	, MTEP_PCT --= Null      --CONVERT(decimal(10),'') Perda %(Percentual de perda do insumo no processo produtivo)
	, MTEP_GNEC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Gera Nec.(Define se gera necessidade e exige requisi��o em ordens)
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM MTEP, #MTPRWHERE MTEP_PAI = MTPR_COD_OLDINSERT INTO MTEPSELECT TOP 1 *FROM #MTEPWHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP)
--MTEP_PAI ,MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU ,

SELECT *
--UPDATE MTPR SET MTPR_ATV = 'S'
FROM MTPR a, #MTPR b
WHERE a.MTPR_COD = b.MTPR_COD


