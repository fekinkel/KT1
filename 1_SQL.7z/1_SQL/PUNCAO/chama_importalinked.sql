

--select *  
truncate table punc

--si_exec si_tabe_importalinked

---------------------------------------------------------------------------------------------
-- DATA                -- AUTOR          -- HIST�RICO
-- Jan 31 2017 10:43AM -- si_exec       -- Script p/ prepara��o do exec de uma dada STP
---------------------------------------------------------------------------------------------
Declare  @modo char(1) ,@par_erro varchar(4000) ,@LkOri varchar(50) ,@DbOri varchar(50) ,@TbOri varchar(50) ,@DbDes varchar(50) ,@TbDes varchar(50)
Select
   @modo               =''
  ,@par_erro           =''
  ,@LkOri              ='[192.168.3.188\sqlexpress]'
  ,@DbOri              ='punc'
  ,@TbOri              ='punc'
  ,@DbDes              ='punc'
  ,@TbDes              ='punc'
Exec [dbo].[si_tabe_importalinked]  @modo ,@par_erro ,@LkOri ,@DbOri ,@TbOri ,@DbDes ,@TbDes
