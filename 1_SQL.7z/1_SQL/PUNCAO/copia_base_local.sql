
------------------------------------------------------------------------------------------------------------------
-- Data             -- Autor            -- Hist�rico
-- 31/01/2017 10:45 -- SI_TABE_IMPORTA3 -- Gera script base para a migra��o dos dados da tabela PUNC para PUNC
------------------------------------------------------------------------------------------------------------------
begin
   set implicit_transactions off
   set nocount on
   -- vari�veris auxiliares
   declare @modo char(1), @msg varchar(4000), @cont int, @read int, @time_ini datetime
   declare @chave varchar(400), @par_erro varchar(4000)
   if exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
      drop table #iae
   end
   create table #iae (par_erro varchar(400))
   set @modo   = 'S'
   set @cont   = 0
   set @read   = 0
   set @msg    = ''
   set @time_ini = getdate()
   print 'Importa��o da tabela [192.168.3.188\SQLEXPRESS].PUNC.PUNC para PUNC.PUNC : Inicio :'+convert(char(20), @time_ini, 113)
   -- Pr� requisitos
--   if not exists *select 1 from ???? where ????) begin
--      set @modo     = 'N'
--      set @par_erro = 'Importa��o invi�vel: bla+bla n�o cadastrado.
--      print @par_erro
--   end
   -- cria cursor p/ migra��o
   if @modo='S' begin
      declare cData cursor local static for
      select PUNC_CODB,PUNC_PREB,PUNC_MDLB,PUNC_DAYB,PUNC_MOEB,PUNC_NOMB,PUNC_DIAB,PUNC_LENB,PUNC_COD1,PUNC_NOM1,PUNC_NOM,PUNC_DIA1,PUNC_LEN1,PUNC_DHSTD,
         PUNC_DH1,PUNC_DH2,PUNC_MHSTD,PUNC_L2STD,PUNC_L2OP1,PUNC_L2OP2,PUNC_MINP,PUNC_MAXP,PUNC_MINW,PUNC_MAXPOG,PUNC_CODS,PUNC_MDLS,PUNC_DAYS,PUNC_MOES,
         PUNC_NOMS,PUNC_DIAS,PUNC_LENS,PUNC_CODL,PUNC_MDLL,PUNC_DAYL,PUNC_MOEL,PUNC_NOML,PUNC_DIAL,PUNC_LENL,PUNC_CODV,PUNC_MDLV,PUNC_DAYV1,PUNC_DAYV2,
         PUNC_MOEV,PUNC_NOMV,PUNC_DIAV,PUNC_LENV,PUNC_CODR,PUNC_MDLR,PUNC_DAYR1,PUNC_DAYR2,PUNC_MOER,PUNC_NOMR,PUNC_DIAR,PUNC_LENR,PUNC_CODF,PUNC_MDLF,
         PUNC_DAYF,PUNC_MOEF,PUNC_NOMF,PUNC_DIAF,PUNC_LENF,PUNC_CODH,PUNC_MDLH,PUNC_DAYH1,PUNC_DAYH2,PUNC_MOEH,PUNC_NOMH,PUNC_DIAH,PUNC_LENH,PUNC_CODZ,
         PUNC_MDLZ,PUNC_DAYZ,PUNC_MOEZ,PUNC_NOMZ,PUNC_DIAZ,PUNC_LENZ,PUNC_CODY,PUNC_MDLY,PUNC_DAYY,PUNC_MOEY,PUNC_NOMY,PUNC_DIAY,PUNC_LENY,PUNC_CODP,PUNC_MDLP,
         PUNC_DAYP,PUNC_MOEP,PUNC_NOMP,PUNC_DIAP,PUNC_LENP,PUNC_CODQ,PUNC_MDLQ,PUNC_DAYQ,PUNC_MOEQ,PUNC_NOMQ,PUNC_DIAQ,PUNC_LENQ,PUNC_MTPR_COD,PUNC_MTPR_MTTP,
         PUNC_MTPR_MS,PUNC_MTPR_ATV,PUNC_MTPR_NOM,PUNC_MTPR_MTDV,PUNC_MTPR_MTLN,PUNC_MTPR_MTFM,PUNC_MTPR_MTUN,PUNC_MTPR_MTNC,PUNC_MTPR_ORI,PUNC_MTPR_PES,
         PUNC_MTPR_DES,PUNC_MTPR_NIV,PUNC_MTPR_ESUN,PUNC_MTPR_ESFT,PUNC_MTPR_CPUN,PUNC_MTPR_CPFT,PUNC_MTPR_ATVV,PUNC_MTPR_CFOV,PUNC_MTPR_ATVC,PUNC_MTPR_CFOC,
         PUNC_MTPR_TOLE,PUNC_MTES_SIES,PUNC_MTES_MTAL,PUNC_MTES_MTAN,PUNC_MTES_MTAP,PUNC_MTES_LOTE,PUNC_MTES_GLMD,PUNC_MTES_QATU,PUNC_MTES_VATU,PUNC_MTES_VATM,
         PUNC_MTES_QVIS,PUNC_MTES_QNEC,PUNC_MTES_QPRO,PUNC_MTES_PCME,PUNC_MTES_PCMR,PUNC_MTES_PMIN,PUNC_MTES_POBJ,PUNC_MTES_POEM,PUNC_MTES_PPMI,PUNC_MTES_PLEM,
         PUNC_MTES_PMUL,PUNC_MTES_PLEC,PUNC_MTES_UCDO,PUNC_MTES_LEAD,PUNC_MTES_LEEM,PUNC_MTES_EXPL,PUNC_MTES_MRP,PUNC_MTES_CREP,PUNC_MTES_CPDR,PUNC_MTES_FGGF,
         PUNC_MTES_FRAT,PUNC_MTES_CTGT,PUNC_MTES_CPO1,PUNC_MTES_CPO2,PUNC_MTES_CPO3,PUNC_MTES_CPO4,PUNC_MTES_PRAT,PUNC_MTPC_PRE,PUNC_MTPC_GLMD,PUNC_SALDO,
         PUNC_EXISTS,PUNC_USC,PUNC_DTC,PUNC_USU,PUNC_DTU
      from [192.168.3.188\SQLEXPRESS].PUNC.dbo.PUNC
      open cData
      if Cursor_Status('local','cData')>0 begin
         -- vari�veis da tabela origem
         declare @ori_PUNC_CODB varchar(20  ),@ori_PUNC_PREB varchar(20  ),@ori_PUNC_MDLB varchar(20  ),@ori_PUNC_DAYB varchar(20  ),@ori_PUNC_MOEB varchar(20  ),
            @ori_PUNC_NOMB varchar(100 ),@ori_PUNC_DIAB decimal(9         ,2         ),@ori_PUNC_LENB decimal(9         ,2         ),@ori_PUNC_COD1 varchar(20  ),
            @ori_PUNC_NOM1 varchar(100 ),@ori_PUNC_NOM varchar(100 ),@ori_PUNC_DIA1 decimal(9         ,2         ),@ori_PUNC_LEN1 decimal(9         ,2         ),
            @ori_PUNC_DHSTD decimal(10        ,3         ),@ori_PUNC_DH1 decimal(10        ,3         ),@ori_PUNC_DH2 decimal(10        ,3         ),@ori_PUNC_MHSTD decimal(10        ,3         ),
            @ori_PUNC_L2STD decimal(9         ,2         ),@ori_PUNC_L2OP1 decimal(9         ,2         ),@ori_PUNC_L2OP2 decimal(9         ,2         ),
            @ori_PUNC_MINP decimal(10        ,3         ),@ori_PUNC_MAXP decimal(10        ,3         ),@ori_PUNC_MINW decimal(10        ,3         ),@ori_PUNC_MAXPOG decimal(10        ,3         ),
            @ori_PUNC_CODS varchar(20  ),@ori_PUNC_MDLS varchar(20  ),@ori_PUNC_DAYS varchar(20  ),@ori_PUNC_MOES varchar(20  ),@ori_PUNC_NOMS varchar(100 ),
            @ori_PUNC_DIAS decimal(9         ,2         ),@ori_PUNC_LENS decimal(9         ,2         ),@ori_PUNC_CODL varchar(20  ),@ori_PUNC_MDLL varchar(20  ),
            @ori_PUNC_DAYL varchar(20  ),@ori_PUNC_MOEL varchar(20  ),@ori_PUNC_NOML varchar(100 ),@ori_PUNC_DIAL decimal(9         ,2         ),@ori_PUNC_LENL decimal(9         ,2         ),
            @ori_PUNC_CODV varchar(20  ),@ori_PUNC_MDLV varchar(20  ),@ori_PUNC_DAYV1 varchar(20  ),@ori_PUNC_DAYV2 varchar(20  ),@ori_PUNC_MOEV varchar(20  ),
            @ori_PUNC_NOMV varchar(100 ),@ori_PUNC_DIAV decimal(9         ,2         ),@ori_PUNC_LENV decimal(9         ,2         ),@ori_PUNC_CODR varchar(20  ),
            @ori_PUNC_MDLR varchar(20  ),@ori_PUNC_DAYR1 varchar(20  ),@ori_PUNC_DAYR2 varchar(20  ),@ori_PUNC_MOER varchar(20  ),@ori_PUNC_NOMR varchar(100 ),
            @ori_PUNC_DIAR decimal(9         ,2         ),@ori_PUNC_LENR decimal(9         ,2         ),@ori_PUNC_CODF varchar(20  ),@ori_PUNC_MDLF varchar(20  ),
            @ori_PUNC_DAYF varchar(20  ),@ori_PUNC_MOEF varchar(20  ),@ori_PUNC_NOMF varchar(100 ),@ori_PUNC_DIAF decimal(9         ,2         ),@ori_PUNC_LENF decimal(9         ,2         ),
            @ori_PUNC_CODH varchar(20  ),@ori_PUNC_MDLH varchar(20  ),@ori_PUNC_DAYH1 varchar(20  ),@ori_PUNC_DAYH2 varchar(20  ),@ori_PUNC_MOEH varchar(20  ),
            @ori_PUNC_NOMH varchar(100 ),@ori_PUNC_DIAH decimal(9         ,2         ),@ori_PUNC_LENH decimal(9         ,2         ),@ori_PUNC_CODZ varchar(20  ),
            @ori_PUNC_MDLZ varchar(20  ),@ori_PUNC_DAYZ varchar(20  ),@ori_PUNC_MOEZ varchar(20  ),@ori_PUNC_NOMZ varchar(100 ),@ori_PUNC_DIAZ decimal(9         ,2         ),
            @ori_PUNC_LENZ decimal(9         ,2         ),@ori_PUNC_CODY varchar(20  ),@ori_PUNC_MDLY varchar(20  ),@ori_PUNC_DAYY varchar(20  ),@ori_PUNC_MOEY varchar(20  ),
            @ori_PUNC_NOMY varchar(100 ),@ori_PUNC_DIAY decimal(9         ,2         ),@ori_PUNC_LENY decimal(9         ,2         ),@ori_PUNC_CODP varchar(20  ),
            @ori_PUNC_MDLP varchar(20  ),@ori_PUNC_DAYP varchar(20  ),@ori_PUNC_MOEP varchar(20  ),@ori_PUNC_NOMP varchar(100 ),@ori_PUNC_DIAP decimal(9         ,2         ),
            @ori_PUNC_LENP decimal(9         ,2         ),@ori_PUNC_CODQ varchar(20  ),@ori_PUNC_MDLQ varchar(20  ),@ori_PUNC_DAYQ varchar(20  ),@ori_PUNC_MOEQ varchar(20  ),
            @ori_PUNC_NOMQ varchar(100 ),@ori_PUNC_DIAQ decimal(9         ,2         ),@ori_PUNC_LENQ decimal(9         ,2         ),@ori_PUNC_MTPR_COD varchar(20  ),
            @ori_PUNC_MTPR_MTTP varchar(25  ),@ori_PUNC_MTPR_MS char(1   ),@ori_PUNC_MTPR_ATV char(1   ),@ori_PUNC_MTPR_NOM varchar(80  ),@ori_PUNC_MTPR_MTDV varchar(4   ),
            @ori_PUNC_MTPR_MTLN varchar(4   ),@ori_PUNC_MTPR_MTFM varchar(4   ),@ori_PUNC_MTPR_MTUN varchar(3   ),@ori_PUNC_MTPR_MTNC varchar(8   ),@ori_PUNC_MTPR_ORI char(1   ),
            @ori_PUNC_MTPR_PES decimal(13        ,3         ),@ori_PUNC_MTPR_DES varchar(240 ),@ori_PUNC_MTPR_NIV int,@ori_PUNC_MTPR_ESUN varchar(3   ),
            @ori_PUNC_MTPR_ESFT decimal(10        ,6         ),@ori_PUNC_MTPR_CPUN varchar(3   ),@ori_PUNC_MTPR_CPFT decimal(10        ,6         ),@ori_PUNC_MTPR_ATVV char(1   ),
            @ori_PUNC_MTPR_CFOV varchar(8   ),@ori_PUNC_MTPR_ATVC char(1   ),@ori_PUNC_MTPR_CFOC varchar(8   ),@ori_PUNC_MTPR_TOLE decimal(12        ,4         ),
            @ori_PUNC_MTES_SIES int,@ori_PUNC_MTES_MTAL varchar(6   ),@ori_PUNC_MTES_MTAN varchar(6   ),@ori_PUNC_MTES_MTAP varchar(6   ),@ori_PUNC_MTES_LOTE char(1   ),
            @ori_PUNC_MTES_GLMD varchar(8   ),@ori_PUNC_MTES_QATU decimal(14        ,6         ),@ori_PUNC_MTES_VATU decimal(14        ,6         ),@ori_PUNC_MTES_VATM decimal(14        ,6         ),
            @ori_PUNC_MTES_QVIS decimal(14        ,6         ),@ori_PUNC_MTES_QNEC decimal(14        ,6         ),@ori_PUNC_MTES_QPRO decimal(14        ,6         ),
            @ori_PUNC_MTES_PCME decimal(14        ,6         ),@ori_PUNC_MTES_PCMR decimal(14        ,6         ),@ori_PUNC_MTES_PMIN int,@ori_PUNC_MTES_POBJ int,
            @ori_PUNC_MTES_POEM int,@ori_PUNC_MTES_PPMI decimal(14        ,6         ),@ori_PUNC_MTES_PLEM decimal(14        ,6         ),@ori_PUNC_MTES_PMUL decimal(14        ,6         ),
            @ori_PUNC_MTES_PLEC decimal(14        ,6         ),@ori_PUNC_MTES_UCDO varchar(25  ),@ori_PUNC_MTES_LEAD int,@ori_PUNC_MTES_LEEM int,@ori_PUNC_MTES_EXPL char(1   ),
            @ori_PUNC_MTES_MRP char(1   ),@ori_PUNC_MTES_CREP decimal(18        ,6         ),@ori_PUNC_MTES_CPDR decimal(18        ,6         ),@ori_PUNC_MTES_FGGF decimal(18        ,6         ),
            @ori_PUNC_MTES_FRAT int,@ori_PUNC_MTES_CTGT decimal(18        ,6         ),@ori_PUNC_MTES_CPO1 varchar(50  ),@ori_PUNC_MTES_CPO2 varchar(50  ),
            @ori_PUNC_MTES_CPO3 varchar(50  ),@ori_PUNC_MTES_CPO4 varchar(50  ),@ori_PUNC_MTES_PRAT varchar(20  ),@ori_PUNC_MTPC_PRE decimal(12        ,2         ),
            @ori_PUNC_MTPC_GLMD varchar(8   ),@ori_PUNC_SALDO decimal(16        ,3         ),@ori_PUNC_EXISTS varchar(1   ),@ori_PUNC_USC varchar(15  ),
            @ori_PUNC_DTC datetime,@ori_PUNC_USU varchar(15  ),@ori_PUNC_DTU datetime
         -- vari�veis da tabela destino
         declare @PUNC_CODB varchar(20  ),@PUNC_PREB varchar(20  ),@PUNC_MDLB varchar(20  ),@PUNC_DAYB varchar(20  ),@PUNC_MOEB varchar(20  ),@PUNC_NOMB varchar(100 ),
            @PUNC_DIAB decimal(10        ,4         ),@PUNC_LENB decimal(10        ,4         ),@PUNC_COD1 varchar(20  ),@PUNC_NOM1 varchar(100 ),@PUNC_NOM varchar(100 ),
            @PUNC_DIA1 decimal(10        ,4         ),@PUNC_LEN1 decimal(10        ,4         ),@PUNC_DHSTD decimal(10        ,4         ),@PUNC_DH1 decimal(10        ,4         ),
            @PUNC_DH2 decimal(10        ,4         ),@PUNC_MHSTD decimal(10        ,4         ),@PUNC_L2STD decimal(10        ,4         ),@PUNC_L2OP1 decimal(10        ,4         ),
            @PUNC_L2OP2 decimal(10        ,4         ),@PUNC_MINP decimal(10        ,4         ),@PUNC_MAXP decimal(10        ,4         ),@PUNC_MINW decimal(10        ,4         ),
            @PUNC_MAXPOG decimal(10        ,4         ),@PUNC_CODS varchar(20  ),@PUNC_MDLS varchar(20  ),@PUNC_DAYS varchar(20  ),@PUNC_MOES varchar(20  ),
            @PUNC_NOMS varchar(100 ),@PUNC_DIAS decimal(10        ,4         ),@PUNC_LENS decimal(10        ,4         ),@PUNC_CODL varchar(20  ),@PUNC_MDLL varchar(20  ),
            @PUNC_DAYL varchar(20  ),@PUNC_MOEL varchar(20  ),@PUNC_NOML varchar(100 ),@PUNC_DIAL decimal(10        ,4         ),@PUNC_LENL decimal(10        ,4         ),
            @PUNC_CODV varchar(20  ),@PUNC_MDLV varchar(20  ),@PUNC_DAYV1 varchar(20  ),@PUNC_DAYV2 varchar(20  ),@PUNC_MOEV varchar(20  ),@PUNC_NOMV varchar(100 ),
            @PUNC_DIAV decimal(10        ,4         ),@PUNC_LENV decimal(10        ,4         ),@PUNC_CODR varchar(20  ),@PUNC_MDLR varchar(20  ),@PUNC_DAYR1 varchar(20  ),
            @PUNC_DAYR2 varchar(20  ),@PUNC_MOER varchar(20  ),@PUNC_NOMR varchar(100 ),@PUNC_DIAR decimal(10        ,4         ),@PUNC_LENR decimal(10        ,4         ),
            @PUNC_CODF varchar(20  ),@PUNC_MDLF varchar(20  ),@PUNC_DAYF varchar(20  ),@PUNC_MOEF varchar(20  ),@PUNC_NOMF varchar(100 ),@PUNC_DIAF decimal(10        ,4         ),
            @PUNC_LENF decimal(10        ,4         ),@PUNC_CODH varchar(20  ),@PUNC_MDLH varchar(20  ),@PUNC_DAYH1 varchar(20  ),@PUNC_DAYH2 varchar(20  ),
            @PUNC_MOEH varchar(20  ),@PUNC_NOMH varchar(100 ),@PUNC_DIAH decimal(10        ,4         ),@PUNC_LENH decimal(10        ,4         ),@PUNC_CODZ varchar(20  ),
            @PUNC_MDLZ varchar(20  ),@PUNC_DAYZ varchar(20  ),@PUNC_MOEZ varchar(20  ),@PUNC_NOMZ varchar(100 ),@PUNC_DIAZ decimal(10        ,4         ),
            @PUNC_LENZ decimal(10        ,4         ),@PUNC_CODY varchar(20  ),@PUNC_MDLY varchar(20  ),@PUNC_DAYY varchar(20  ),@PUNC_MOEY varchar(20  ),
            @PUNC_NOMY varchar(100 ),@PUNC_DIAY decimal(10        ,4         ),@PUNC_LENY decimal(10        ,4         ),@PUNC_CODP varchar(20  ),@PUNC_MDLP varchar(20  ),
            @PUNC_DAYP varchar(20  ),@PUNC_MOEP varchar(20  ),@PUNC_NOMP varchar(100 ),@PUNC_DIAP decimal(10        ,4         ),@PUNC_LENP decimal(10        ,4         ),
            @PUNC_CODQ varchar(20  ),@PUNC_MDLQ varchar(20  ),@PUNC_DAYQ varchar(20  ),@PUNC_MOEQ varchar(20  ),@PUNC_NOMQ varchar(100 ),@PUNC_DIAQ decimal(10        ,4         ),
            @PUNC_LENQ decimal(10        ,4         ),@PUNC_MTPR_COD varchar(20  ),@PUNC_MTPR_MTTP varchar(25  ),@PUNC_MTPR_MS char(1   ),@PUNC_MTPR_ATV char(1   ),
            @PUNC_MTPR_NOM varchar(80  ),@PUNC_MTPR_MTDV varchar(4   ),@PUNC_MTPR_MTLN varchar(4   ),@PUNC_MTPR_MTFM varchar(4   ),@PUNC_MTPR_MTUN varchar(3   ),
            @PUNC_MTPR_MTNC varchar(8   ),@PUNC_MTPR_ORI char(1   ),@PUNC_MTPR_PES decimal(13        ,3         ),@PUNC_MTPR_DES varchar(240 ),@PUNC_MTPR_NIV int,
            @PUNC_MTPR_ESUN varchar(3   ),@PUNC_MTPR_ESFT decimal(10        ,6         ),@PUNC_MTPR_CPUN varchar(3   ),@PUNC_MTPR_CPFT decimal(10        ,6         ),
            @PUNC_MTPR_ATVV char(1   ),@PUNC_MTPR_CFOV varchar(8   ),@PUNC_MTPR_ATVC char(1   ),@PUNC_MTPR_CFOC varchar(8   ),@PUNC_MTPR_TOLE decimal(12        ,4         ),
            @PUNC_MTES_SIES int,@PUNC_MTES_MTAL varchar(6   ),@PUNC_MTES_MTAN varchar(6   ),@PUNC_MTES_MTAP varchar(6   ),@PUNC_MTES_LOTE char(1   ),@PUNC_MTES_GLMD varchar(8   ),
            @PUNC_MTES_QATU decimal(14        ,6         ),@PUNC_MTES_VATU decimal(14        ,6         ),@PUNC_MTES_VATM decimal(14        ,6         ),
            @PUNC_MTES_QVIS decimal(14        ,6         ),@PUNC_MTES_QNEC decimal(14        ,6         ),@PUNC_MTES_QPRO decimal(14        ,6         ),
            @PUNC_MTES_PCME decimal(14        ,6         ),@PUNC_MTES_PCMR decimal(14        ,6         ),@PUNC_MTES_PMIN int,@PUNC_MTES_POBJ int,@PUNC_MTES_POEM int,
            @PUNC_MTES_PPMI decimal(14        ,6         ),@PUNC_MTES_PLEM decimal(14        ,6         ),@PUNC_MTES_PMUL decimal(14        ,6         ),
            @PUNC_MTES_PLEC decimal(14        ,6         ),@PUNC_MTES_UCDO varchar(25  ),@PUNC_MTES_LEAD int,@PUNC_MTES_LEEM int,@PUNC_MTES_EXPL char(1   ),
            @PUNC_MTES_MRP char(1   ),@PUNC_MTES_CREP decimal(18        ,6         ),@PUNC_MTES_CPDR decimal(18        ,6         ),@PUNC_MTES_FGGF decimal(18        ,6         ),
            @PUNC_MTES_FRAT int,@PUNC_MTES_CTGT decimal(18        ,6         ),@PUNC_MTES_CPO1 varchar(50  ),@PUNC_MTES_CPO2 varchar(50  ),@PUNC_MTES_CPO3 varchar(50  ),
            @PUNC_MTES_CPO4 varchar(50  ),@PUNC_MTES_PRAT varchar(20  ),@PUNC_MTPC_PRE decimal(12        ,2         ),@PUNC_MTPC_GLMD varchar(8   ),@PUNC_SALDO decimal(16        ,3         ),
            @PUNC_EXISTS varchar(1   ),@PUNC_USC varchar(15  ),@PUNC_DTC datetime,@PUNC_USU varchar(15  ),@PUNC_DTU datetime
         fetch next from cData into
         @ori_PUNC_CODB,@ori_PUNC_PREB,@ori_PUNC_MDLB,@ori_PUNC_DAYB,@ori_PUNC_MOEB,@ori_PUNC_NOMB,@ori_PUNC_DIAB,@ori_PUNC_LENB,@ori_PUNC_COD1,@ori_PUNC_NOM1,
         @ori_PUNC_NOM,@ori_PUNC_DIA1,@ori_PUNC_LEN1,@ori_PUNC_DHSTD,@ori_PUNC_DH1,@ori_PUNC_DH2,@ori_PUNC_MHSTD,@ori_PUNC_L2STD,@ori_PUNC_L2OP1,@ori_PUNC_L2OP2,
         @ori_PUNC_MINP,@ori_PUNC_MAXP,@ori_PUNC_MINW,@ori_PUNC_MAXPOG,@ori_PUNC_CODS,@ori_PUNC_MDLS,@ori_PUNC_DAYS,@ori_PUNC_MOES,@ori_PUNC_NOMS,@ori_PUNC_DIAS,
         @ori_PUNC_LENS,@ori_PUNC_CODL,@ori_PUNC_MDLL,@ori_PUNC_DAYL,@ori_PUNC_MOEL,@ori_PUNC_NOML,@ori_PUNC_DIAL,@ori_PUNC_LENL,@ori_PUNC_CODV,@ori_PUNC_MDLV,
         @ori_PUNC_DAYV1,@ori_PUNC_DAYV2,@ori_PUNC_MOEV,@ori_PUNC_NOMV,@ori_PUNC_DIAV,@ori_PUNC_LENV,@ori_PUNC_CODR,@ori_PUNC_MDLR,@ori_PUNC_DAYR1,@ori_PUNC_DAYR2,
         @ori_PUNC_MOER,@ori_PUNC_NOMR,@ori_PUNC_DIAR,@ori_PUNC_LENR,@ori_PUNC_CODF,@ori_PUNC_MDLF,@ori_PUNC_DAYF,@ori_PUNC_MOEF,@ori_PUNC_NOMF,@ori_PUNC_DIAF,
         @ori_PUNC_LENF,@ori_PUNC_CODH,@ori_PUNC_MDLH,@ori_PUNC_DAYH1,@ori_PUNC_DAYH2,@ori_PUNC_MOEH,@ori_PUNC_NOMH,@ori_PUNC_DIAH,@ori_PUNC_LENH,@ori_PUNC_CODZ,
         @ori_PUNC_MDLZ,@ori_PUNC_DAYZ,@ori_PUNC_MOEZ,@ori_PUNC_NOMZ,@ori_PUNC_DIAZ,@ori_PUNC_LENZ,@ori_PUNC_CODY,@ori_PUNC_MDLY,@ori_PUNC_DAYY,@ori_PUNC_MOEY,
         @ori_PUNC_NOMY,@ori_PUNC_DIAY,@ori_PUNC_LENY,@ori_PUNC_CODP,@ori_PUNC_MDLP,@ori_PUNC_DAYP,@ori_PUNC_MOEP,@ori_PUNC_NOMP,@ori_PUNC_DIAP,@ori_PUNC_LENP,
         @ori_PUNC_CODQ,@ori_PUNC_MDLQ,@ori_PUNC_DAYQ,@ori_PUNC_MOEQ,@ori_PUNC_NOMQ,@ori_PUNC_DIAQ,@ori_PUNC_LENQ,@ori_PUNC_MTPR_COD,@ori_PUNC_MTPR_MTTP,
         @ori_PUNC_MTPR_MS,@ori_PUNC_MTPR_ATV,@ori_PUNC_MTPR_NOM,@ori_PUNC_MTPR_MTDV,@ori_PUNC_MTPR_MTLN,@ori_PUNC_MTPR_MTFM,@ori_PUNC_MTPR_MTUN,@ori_PUNC_MTPR_MTNC,
         @ori_PUNC_MTPR_ORI,@ori_PUNC_MTPR_PES,@ori_PUNC_MTPR_DES,@ori_PUNC_MTPR_NIV,@ori_PUNC_MTPR_ESUN,@ori_PUNC_MTPR_ESFT,@ori_PUNC_MTPR_CPUN,@ori_PUNC_MTPR_CPFT,
         @ori_PUNC_MTPR_ATVV,@ori_PUNC_MTPR_CFOV,@ori_PUNC_MTPR_ATVC,@ori_PUNC_MTPR_CFOC,@ori_PUNC_MTPR_TOLE,@ori_PUNC_MTES_SIES,@ori_PUNC_MTES_MTAL,@ori_PUNC_MTES_MTAN,
         @ori_PUNC_MTES_MTAP,@ori_PUNC_MTES_LOTE,@ori_PUNC_MTES_GLMD,@ori_PUNC_MTES_QATU,@ori_PUNC_MTES_VATU,@ori_PUNC_MTES_VATM,@ori_PUNC_MTES_QVIS,@ori_PUNC_MTES_QNEC,
         @ori_PUNC_MTES_QPRO,@ori_PUNC_MTES_PCME,@ori_PUNC_MTES_PCMR,@ori_PUNC_MTES_PMIN,@ori_PUNC_MTES_POBJ,@ori_PUNC_MTES_POEM,@ori_PUNC_MTES_PPMI,@ori_PUNC_MTES_PLEM,
         @ori_PUNC_MTES_PMUL,@ori_PUNC_MTES_PLEC,@ori_PUNC_MTES_UCDO,@ori_PUNC_MTES_LEAD,@ori_PUNC_MTES_LEEM,@ori_PUNC_MTES_EXPL,@ori_PUNC_MTES_MRP,@ori_PUNC_MTES_CREP,
         @ori_PUNC_MTES_CPDR,@ori_PUNC_MTES_FGGF,@ori_PUNC_MTES_FRAT,@ori_PUNC_MTES_CTGT,@ori_PUNC_MTES_CPO1,@ori_PUNC_MTES_CPO2,@ori_PUNC_MTES_CPO3,@ori_PUNC_MTES_CPO4,
         @ori_PUNC_MTES_PRAT,@ori_PUNC_MTPC_PRE,@ori_PUNC_MTPC_GLMD,@ori_PUNC_SALDO,@ori_PUNC_EXISTS,@ori_PUNC_USC,@ori_PUNC_DTC,@ori_PUNC_USU,@ori_PUNC_DTU
         while @@fetch_status=0 begin
            begin transaction SI_IMPORTA
            set @modo='S'
            -- Defina aqui as regras de convers�o p/ os campos
            set @PUNC_CODB                      = @ori_PUNC_CODB                     
            set @PUNC_PREB                      = @ori_PUNC_PREB                     
            set @PUNC_MDLB                      = @ori_PUNC_MDLB                     
            set @PUNC_DAYB                      = @ori_PUNC_DAYB                     
            set @PUNC_MOEB                      = @ori_PUNC_MOEB                     
            set @PUNC_NOMB                      = @ori_PUNC_NOMB                     
            set @PUNC_DIAB                      = @ori_PUNC_DIAB                     
            set @PUNC_LENB                      = @ori_PUNC_LENB                     
            set @PUNC_COD1                      = @ori_PUNC_COD1                     
            set @PUNC_NOM1                      = @ori_PUNC_NOM1                     
            set @PUNC_NOM                       = @ori_PUNC_NOM                      
            set @PUNC_DIA1                      = @ori_PUNC_DIA1                     
            set @PUNC_LEN1                      = @ori_PUNC_LEN1                     
            set @PUNC_DHSTD                     = @ori_PUNC_DHSTD                    
            set @PUNC_DH1                       = @ori_PUNC_DH1                      
            set @PUNC_DH2                       = @ori_PUNC_DH2                      
            set @PUNC_MHSTD                     = @ori_PUNC_MHSTD                    
            set @PUNC_L2STD                     = @ori_PUNC_L2STD                    
            set @PUNC_L2OP1                     = @ori_PUNC_L2OP1                    
            set @PUNC_L2OP2                     = @ori_PUNC_L2OP2                    
            set @PUNC_MINP                      = @ori_PUNC_MINP                     
            set @PUNC_MAXP                      = @ori_PUNC_MAXP                     
            set @PUNC_MINW                      = @ori_PUNC_MINW                     
            set @PUNC_MAXPOG                    = @ori_PUNC_MAXPOG                   
            set @PUNC_CODS                      = @ori_PUNC_CODS                     
            set @PUNC_MDLS                      = @ori_PUNC_MDLS                     
            set @PUNC_DAYS                      = @ori_PUNC_DAYS                     
            set @PUNC_MOES                      = @ori_PUNC_MOES                     
            set @PUNC_NOMS                      = @ori_PUNC_NOMS                     
            set @PUNC_DIAS                      = @ori_PUNC_DIAS                     
            set @PUNC_LENS                      = @ori_PUNC_LENS                     
            set @PUNC_CODL                      = @ori_PUNC_CODL                     
            set @PUNC_MDLL                      = @ori_PUNC_MDLL                     
            set @PUNC_DAYL                      = @ori_PUNC_DAYL                     
            set @PUNC_MOEL                      = @ori_PUNC_MOEL                     
            set @PUNC_NOML                      = @ori_PUNC_NOML                     
            set @PUNC_DIAL                      = @ori_PUNC_DIAL                     
            set @PUNC_LENL                      = @ori_PUNC_LENL                     
            set @PUNC_CODV                      = @ori_PUNC_CODV                     
            set @PUNC_MDLV                      = @ori_PUNC_MDLV                     
            set @PUNC_DAYV1                     = @ori_PUNC_DAYV1                    
            set @PUNC_DAYV2                     = @ori_PUNC_DAYV2                    
            set @PUNC_MOEV                      = @ori_PUNC_MOEV                     
            set @PUNC_NOMV                      = @ori_PUNC_NOMV                     
            set @PUNC_DIAV                      = @ori_PUNC_DIAV                     
            set @PUNC_LENV                      = @ori_PUNC_LENV                     
            set @PUNC_CODR                      = @ori_PUNC_CODR                     
            set @PUNC_MDLR                      = @ori_PUNC_MDLR                     
            set @PUNC_DAYR1                     = @ori_PUNC_DAYR1                    
            set @PUNC_DAYR2                     = @ori_PUNC_DAYR2                    
            set @PUNC_MOER                      = @ori_PUNC_MOER                     
            set @PUNC_NOMR                      = @ori_PUNC_NOMR                     
            set @PUNC_DIAR                      = @ori_PUNC_DIAR                     
            set @PUNC_LENR                      = @ori_PUNC_LENR                     
            set @PUNC_CODF                      = @ori_PUNC_CODF                     
            set @PUNC_MDLF                      = @ori_PUNC_MDLF                     
            set @PUNC_DAYF                      = @ori_PUNC_DAYF                     
            set @PUNC_MOEF                      = @ori_PUNC_MOEF                     
            set @PUNC_NOMF                      = @ori_PUNC_NOMF                     
            set @PUNC_DIAF                      = @ori_PUNC_DIAF                     
            set @PUNC_LENF                      = @ori_PUNC_LENF                     
            set @PUNC_CODH                      = @ori_PUNC_CODH                     
            set @PUNC_MDLH                      = @ori_PUNC_MDLH                     
            set @PUNC_DAYH1                     = @ori_PUNC_DAYH1                    
            set @PUNC_DAYH2                     = @ori_PUNC_DAYH2                    
            set @PUNC_MOEH                      = @ori_PUNC_MOEH                     
            set @PUNC_NOMH                      = @ori_PUNC_NOMH                     
            set @PUNC_DIAH                      = @ori_PUNC_DIAH                     
            set @PUNC_LENH                      = @ori_PUNC_LENH                     
            set @PUNC_CODZ                      = @ori_PUNC_CODZ                     
            set @PUNC_MDLZ                      = @ori_PUNC_MDLZ                     
            set @PUNC_DAYZ                      = @ori_PUNC_DAYZ                     
            set @PUNC_MOEZ                      = @ori_PUNC_MOEZ                     
            set @PUNC_NOMZ                      = @ori_PUNC_NOMZ                     
            set @PUNC_DIAZ                      = @ori_PUNC_DIAZ                     
            set @PUNC_LENZ                      = @ori_PUNC_LENZ                     
            set @PUNC_CODY                      = @ori_PUNC_CODY                     
            set @PUNC_MDLY                      = @ori_PUNC_MDLY                     
            set @PUNC_DAYY                      = @ori_PUNC_DAYY                     
            set @PUNC_MOEY                      = @ori_PUNC_MOEY                     
            set @PUNC_NOMY                      = @ori_PUNC_NOMY                     
            set @PUNC_DIAY                      = @ori_PUNC_DIAY                     
            set @PUNC_LENY                      = @ori_PUNC_LENY                     
            set @PUNC_CODP                      = @ori_PUNC_CODP                     
            set @PUNC_MDLP                      = @ori_PUNC_MDLP                     
            set @PUNC_DAYP                      = @ori_PUNC_DAYP                     
            set @PUNC_MOEP                      = @ori_PUNC_MOEP                     
            set @PUNC_NOMP                      = @ori_PUNC_NOMP                     
            set @PUNC_DIAP                      = @ori_PUNC_DIAP                     
            set @PUNC_LENP                      = @ori_PUNC_LENP                     
            set @PUNC_CODQ                      = @ori_PUNC_CODQ                     
            set @PUNC_MDLQ                      = @ori_PUNC_MDLQ                     
            set @PUNC_DAYQ                      = @ori_PUNC_DAYQ                     
            set @PUNC_MOEQ                      = @ori_PUNC_MOEQ                     
            set @PUNC_NOMQ                      = @ori_PUNC_NOMQ                     
            set @PUNC_DIAQ                      = @ori_PUNC_DIAQ                     
            set @PUNC_LENQ                      = @ori_PUNC_LENQ                     
            set @PUNC_MTPR_COD                  = @ori_PUNC_MTPR_COD                 
            set @PUNC_MTPR_MTTP                 = @ori_PUNC_MTPR_MTTP                
            set @PUNC_MTPR_MS                   = @ori_PUNC_MTPR_MS                  
            set @PUNC_MTPR_ATV                  = @ori_PUNC_MTPR_ATV                 
            set @PUNC_MTPR_NOM                  = @ori_PUNC_MTPR_NOM                 
            set @PUNC_MTPR_MTDV                 = @ori_PUNC_MTPR_MTDV                
            set @PUNC_MTPR_MTLN                 = @ori_PUNC_MTPR_MTLN                
            set @PUNC_MTPR_MTFM                 = @ori_PUNC_MTPR_MTFM                
            set @PUNC_MTPR_MTUN                 = @ori_PUNC_MTPR_MTUN                
            set @PUNC_MTPR_MTNC                 = @ori_PUNC_MTPR_MTNC                
            set @PUNC_MTPR_ORI                  = @ori_PUNC_MTPR_ORI                 
            set @PUNC_MTPR_PES                  = @ori_PUNC_MTPR_PES                 
            set @PUNC_MTPR_DES                  = @ori_PUNC_MTPR_DES                 
            set @PUNC_MTPR_NIV                  = @ori_PUNC_MTPR_NIV                 
            set @PUNC_MTPR_ESUN                 = @ori_PUNC_MTPR_ESUN                
            set @PUNC_MTPR_ESFT                 = @ori_PUNC_MTPR_ESFT                
            set @PUNC_MTPR_CPUN                 = @ori_PUNC_MTPR_CPUN                
            set @PUNC_MTPR_CPFT                 = @ori_PUNC_MTPR_CPFT                
            set @PUNC_MTPR_ATVV                 = @ori_PUNC_MTPR_ATVV                
            set @PUNC_MTPR_CFOV                 = @ori_PUNC_MTPR_CFOV                
            set @PUNC_MTPR_ATVC                 = @ori_PUNC_MTPR_ATVC                
            set @PUNC_MTPR_CFOC                 = @ori_PUNC_MTPR_CFOC                
            set @PUNC_MTPR_TOLE                 = @ori_PUNC_MTPR_TOLE                
            set @PUNC_MTES_SIES                 = @ori_PUNC_MTES_SIES                
            set @PUNC_MTES_MTAL                 = @ori_PUNC_MTES_MTAL                
            set @PUNC_MTES_MTAN                 = @ori_PUNC_MTES_MTAN                
            set @PUNC_MTES_MTAP                 = @ori_PUNC_MTES_MTAP                
            set @PUNC_MTES_LOTE                 = @ori_PUNC_MTES_LOTE                
            set @PUNC_MTES_GLMD                 = @ori_PUNC_MTES_GLMD                
            set @PUNC_MTES_QATU                 = @ori_PUNC_MTES_QATU                
            set @PUNC_MTES_VATU                 = @ori_PUNC_MTES_VATU                
            set @PUNC_MTES_VATM                 = @ori_PUNC_MTES_VATM                
            set @PUNC_MTES_QVIS                 = @ori_PUNC_MTES_QVIS                
            set @PUNC_MTES_QNEC                 = @ori_PUNC_MTES_QNEC                
            set @PUNC_MTES_QPRO                 = @ori_PUNC_MTES_QPRO                
            set @PUNC_MTES_PCME                 = @ori_PUNC_MTES_PCME                
            set @PUNC_MTES_PCMR                 = @ori_PUNC_MTES_PCMR                
            set @PUNC_MTES_PMIN                 = @ori_PUNC_MTES_PMIN                
            set @PUNC_MTES_POBJ                 = @ori_PUNC_MTES_POBJ                
            set @PUNC_MTES_POEM                 = @ori_PUNC_MTES_POEM                
            set @PUNC_MTES_PPMI                 = @ori_PUNC_MTES_PPMI                
            set @PUNC_MTES_PLEM                 = @ori_PUNC_MTES_PLEM                
            set @PUNC_MTES_PMUL                 = @ori_PUNC_MTES_PMUL                
            set @PUNC_MTES_PLEC                 = @ori_PUNC_MTES_PLEC                
            set @PUNC_MTES_UCDO                 = @ori_PUNC_MTES_UCDO                
            set @PUNC_MTES_LEAD                 = @ori_PUNC_MTES_LEAD                
            set @PUNC_MTES_LEEM                 = @ori_PUNC_MTES_LEEM                
            set @PUNC_MTES_EXPL                 = @ori_PUNC_MTES_EXPL                
            set @PUNC_MTES_MRP                  = @ori_PUNC_MTES_MRP                 
            set @PUNC_MTES_CREP                 = @ori_PUNC_MTES_CREP                
            set @PUNC_MTES_CPDR                 = @ori_PUNC_MTES_CPDR                
            set @PUNC_MTES_FGGF                 = @ori_PUNC_MTES_FGGF                
            set @PUNC_MTES_FRAT                 = @ori_PUNC_MTES_FRAT                
            set @PUNC_MTES_CTGT                 = @ori_PUNC_MTES_CTGT                
            set @PUNC_MTES_CPO1                 = @ori_PUNC_MTES_CPO1                
            set @PUNC_MTES_CPO2                 = @ori_PUNC_MTES_CPO2                
            set @PUNC_MTES_CPO3                 = @ori_PUNC_MTES_CPO3                
            set @PUNC_MTES_CPO4                 = @ori_PUNC_MTES_CPO4                
            set @PUNC_MTES_PRAT                 = @ori_PUNC_MTES_PRAT                
            set @PUNC_MTPC_PRE                  = @ori_PUNC_MTPC_PRE                 
            set @PUNC_MTPC_GLMD                 = @ori_PUNC_MTPC_GLMD                
            set @PUNC_SALDO                     = @ori_PUNC_SALDO                    
            set @PUNC_EXISTS                    = @ori_PUNC_EXISTS                   
            set @PUNC_USC                       = @ori_PUNC_USC                      
            set @PUNC_DTC                       = @ori_PUNC_DTC                      
            set @PUNC_USU                       = @ori_PUNC_USU                      
            set @PUNC_DTU                       = @ori_PUNC_DTU                      
            if @modo='S' begin
               -- Verifica a exist�ncia do registro na tabela destino
               set @chave='PUNC_CODB '+' : '+cast(@PUNC_CODB as varchar)
               if not exists (
                  select 1 from PUNC..PUNC
                  where PUNC_CODB=@PUNC_CODB
               ) begin --"express�o chave"
                  insert PUNC..PUNC ( PUNC_CODB, PUNC_PREB, PUNC_MDLB, PUNC_DAYB, PUNC_MOEB, PUNC_NOMB, PUNC_DIAB, PUNC_LENB, PUNC_COD1, PUNC_NOM1, PUNC_NOM,
                   PUNC_DIA1, PUNC_LEN1, PUNC_DHSTD, PUNC_DH1, PUNC_DH2, PUNC_MHSTD, PUNC_L2STD, PUNC_L2OP1, PUNC_L2OP2, PUNC_MINP, PUNC_MAXP, PUNC_MINW,
                   PUNC_MAXPOG, PUNC_CODS, PUNC_MDLS, PUNC_DAYS, PUNC_MOES, PUNC_NOMS, PUNC_DIAS, PUNC_LENS, PUNC_CODL, PUNC_MDLL, PUNC_DAYL, PUNC_MOEL,
                   PUNC_NOML, PUNC_DIAL, PUNC_LENL, PUNC_CODV, PUNC_MDLV, PUNC_DAYV1, PUNC_DAYV2, PUNC_MOEV, PUNC_NOMV, PUNC_DIAV, PUNC_LENV, PUNC_CODR,
                   PUNC_MDLR, PUNC_DAYR1, PUNC_DAYR2, PUNC_MOER, PUNC_NOMR, PUNC_DIAR, PUNC_LENR, PUNC_CODF, PUNC_MDLF, PUNC_DAYF, PUNC_MOEF, PUNC_NOMF,
                   PUNC_DIAF, PUNC_LENF, PUNC_CODH, PUNC_MDLH, PUNC_DAYH1, PUNC_DAYH2, PUNC_MOEH, PUNC_NOMH, PUNC_DIAH, PUNC_LENH, PUNC_CODZ, PUNC_MDLZ,
                   PUNC_DAYZ, PUNC_MOEZ, PUNC_NOMZ, PUNC_DIAZ, PUNC_LENZ, PUNC_CODY, PUNC_MDLY, PUNC_DAYY, PUNC_MOEY, PUNC_NOMY, PUNC_DIAY, PUNC_LENY, PUNC_CODP,
                   PUNC_MDLP, PUNC_DAYP, PUNC_MOEP, PUNC_NOMP, PUNC_DIAP, PUNC_LENP, PUNC_CODQ, PUNC_MDLQ, PUNC_DAYQ, PUNC_MOEQ, PUNC_NOMQ, PUNC_DIAQ, PUNC_LENQ,
                   PUNC_MTPR_COD, PUNC_MTPR_MTTP, PUNC_MTPR_MS, PUNC_MTPR_ATV, PUNC_MTPR_NOM, PUNC_MTPR_MTDV, PUNC_MTPR_MTLN, PUNC_MTPR_MTFM, PUNC_MTPR_MTUN,
                   PUNC_MTPR_MTNC, PUNC_MTPR_ORI, PUNC_MTPR_PES, PUNC_MTPR_DES, PUNC_MTPR_NIV, PUNC_MTPR_ESUN, PUNC_MTPR_ESFT, PUNC_MTPR_CPUN, PUNC_MTPR_CPFT,
                   PUNC_MTPR_ATVV, PUNC_MTPR_CFOV, PUNC_MTPR_ATVC, PUNC_MTPR_CFOC, PUNC_MTPR_TOLE, PUNC_MTES_SIES, PUNC_MTES_MTAL, PUNC_MTES_MTAN, PUNC_MTES_MTAP,
                   PUNC_MTES_LOTE, PUNC_MTES_GLMD, PUNC_MTES_QATU, PUNC_MTES_VATU, PUNC_MTES_VATM, PUNC_MTES_QVIS, PUNC_MTES_QNEC, PUNC_MTES_QPRO, PUNC_MTES_PCME,
                   PUNC_MTES_PCMR, PUNC_MTES_PMIN, PUNC_MTES_POBJ, PUNC_MTES_POEM, PUNC_MTES_PPMI, PUNC_MTES_PLEM, PUNC_MTES_PMUL, PUNC_MTES_PLEC, PUNC_MTES_UCDO,
                   PUNC_MTES_LEAD, PUNC_MTES_LEEM, PUNC_MTES_EXPL, PUNC_MTES_MRP, PUNC_MTES_CREP, PUNC_MTES_CPDR, PUNC_MTES_FGGF, PUNC_MTES_FRAT, PUNC_MTES_CTGT,
                   PUNC_MTES_CPO1, PUNC_MTES_CPO2, PUNC_MTES_CPO3, PUNC_MTES_CPO4, PUNC_MTES_PRAT, PUNC_MTPC_PRE, PUNC_MTPC_GLMD, PUNC_SALDO, PUNC_EXISTS,
                   PUNC_USC, PUNC_DTC, PUNC_USU, PUNC_DTU)
                  values      (@PUNC_CODB,@PUNC_PREB,@PUNC_MDLB,@PUNC_DAYB,@PUNC_MOEB,@PUNC_NOMB,@PUNC_DIAB,@PUNC_LENB,@PUNC_COD1,@PUNC_NOM1,@PUNC_NOM,
                  @PUNC_DIA1,@PUNC_LEN1,@PUNC_DHSTD,@PUNC_DH1,@PUNC_DH2,@PUNC_MHSTD,@PUNC_L2STD,@PUNC_L2OP1,@PUNC_L2OP2,@PUNC_MINP,@PUNC_MAXP,@PUNC_MINW,
                  @PUNC_MAXPOG,@PUNC_CODS,@PUNC_MDLS,@PUNC_DAYS,@PUNC_MOES,@PUNC_NOMS,@PUNC_DIAS,@PUNC_LENS,@PUNC_CODL,@PUNC_MDLL,@PUNC_DAYL,@PUNC_MOEL,
                  @PUNC_NOML,@PUNC_DIAL,@PUNC_LENL,@PUNC_CODV,@PUNC_MDLV,@PUNC_DAYV1,@PUNC_DAYV2,@PUNC_MOEV,@PUNC_NOMV,@PUNC_DIAV,@PUNC_LENV,@PUNC_CODR,
                  @PUNC_MDLR,@PUNC_DAYR1,@PUNC_DAYR2,@PUNC_MOER,@PUNC_NOMR,@PUNC_DIAR,@PUNC_LENR,@PUNC_CODF,@PUNC_MDLF,@PUNC_DAYF,@PUNC_MOEF,@PUNC_NOMF,
                  @PUNC_DIAF,@PUNC_LENF,@PUNC_CODH,@PUNC_MDLH,@PUNC_DAYH1,@PUNC_DAYH2,@PUNC_MOEH,@PUNC_NOMH,@PUNC_DIAH,@PUNC_LENH,@PUNC_CODZ,@PUNC_MDLZ,
                  @PUNC_DAYZ,@PUNC_MOEZ,@PUNC_NOMZ,@PUNC_DIAZ,@PUNC_LENZ,@PUNC_CODY,@PUNC_MDLY,@PUNC_DAYY,@PUNC_MOEY,@PUNC_NOMY,@PUNC_DIAY,@PUNC_LENY,@PUNC_CODP,
                  @PUNC_MDLP,@PUNC_DAYP,@PUNC_MOEP,@PUNC_NOMP,@PUNC_DIAP,@PUNC_LENP,@PUNC_CODQ,@PUNC_MDLQ,@PUNC_DAYQ,@PUNC_MOEQ,@PUNC_NOMQ,@PUNC_DIAQ,@PUNC_LENQ,
                  @PUNC_MTPR_COD,@PUNC_MTPR_MTTP,@PUNC_MTPR_MS,@PUNC_MTPR_ATV,@PUNC_MTPR_NOM,@PUNC_MTPR_MTDV,@PUNC_MTPR_MTLN,@PUNC_MTPR_MTFM,@PUNC_MTPR_MTUN,
                  @PUNC_MTPR_MTNC,@PUNC_MTPR_ORI,@PUNC_MTPR_PES,@PUNC_MTPR_DES,@PUNC_MTPR_NIV,@PUNC_MTPR_ESUN,@PUNC_MTPR_ESFT,@PUNC_MTPR_CPUN,@PUNC_MTPR_CPFT,
                  @PUNC_MTPR_ATVV,@PUNC_MTPR_CFOV,@PUNC_MTPR_ATVC,@PUNC_MTPR_CFOC,@PUNC_MTPR_TOLE,@PUNC_MTES_SIES,@PUNC_MTES_MTAL,@PUNC_MTES_MTAN,@PUNC_MTES_MTAP,
                  @PUNC_MTES_LOTE,@PUNC_MTES_GLMD,@PUNC_MTES_QATU,@PUNC_MTES_VATU,@PUNC_MTES_VATM,@PUNC_MTES_QVIS,@PUNC_MTES_QNEC,@PUNC_MTES_QPRO,@PUNC_MTES_PCME,
                  @PUNC_MTES_PCMR,@PUNC_MTES_PMIN,@PUNC_MTES_POBJ,@PUNC_MTES_POEM,@PUNC_MTES_PPMI,@PUNC_MTES_PLEM,@PUNC_MTES_PMUL,@PUNC_MTES_PLEC,@PUNC_MTES_UCDO,
                  @PUNC_MTES_LEAD,@PUNC_MTES_LEEM,@PUNC_MTES_EXPL,@PUNC_MTES_MRP,@PUNC_MTES_CREP,@PUNC_MTES_CPDR,@PUNC_MTES_FGGF,@PUNC_MTES_FRAT,@PUNC_MTES_CTGT,
                  @PUNC_MTES_CPO1,@PUNC_MTES_CPO2,@PUNC_MTES_CPO3,@PUNC_MTES_CPO4,@PUNC_MTES_PRAT,@PUNC_MTPC_PRE,@PUNC_MTPC_GLMD,@PUNC_SALDO,@PUNC_EXISTS,
                  @PUNC_USC,@PUNC_DTC,@PUNC_USU,@PUNC_DTU)
                  -- verifica se a operac�o gerou erro (segundo foreign key)
                  if @@error<>0 begin
                     set @modo     = 'N'
                     set @par_erro = isnull(@chave,'Chave nula') +' Erro interno. Prov�vel viola��o de FOREIGN KEY'
                  -- verifica se a operac�o gerou erro (segundo triggers antigas)
                  end else if exists (select 1 from #IAE) begin
                     set @modo     = 'N'
                     select top 1 @par_erro=par_erro from #iae
                  end
               end else begin
                  set @modo     = 'N'
                  set @par_erro = 'Registro j� existente na tabela destino: '+isnull(@chave,'Chave nula')
               end
            end
            set @read =@read +1
            if @modo='S' begin
               set @cont =@cont +1
               commit transaction SI_IMPORTA
--fetch last from cDATA into bla bla (p/ inclus�o de um �nico registro para testes...
            end else begin
               if isnull(@par_erro,'')<>'' begin
                  print @par_erro
               end
               rollback transaction SI_IMPORTA
            end
            fetch next from cData into
               @ori_PUNC_CODB,@ori_PUNC_PREB,@ori_PUNC_MDLB,@ori_PUNC_DAYB,@ori_PUNC_MOEB,@ori_PUNC_NOMB,@ori_PUNC_DIAB,@ori_PUNC_LENB,@ori_PUNC_COD1,@ori_PUNC_NOM1,
               @ori_PUNC_NOM,@ori_PUNC_DIA1,@ori_PUNC_LEN1,@ori_PUNC_DHSTD,@ori_PUNC_DH1,@ori_PUNC_DH2,@ori_PUNC_MHSTD,@ori_PUNC_L2STD,@ori_PUNC_L2OP1,
               @ori_PUNC_L2OP2,@ori_PUNC_MINP,@ori_PUNC_MAXP,@ori_PUNC_MINW,@ori_PUNC_MAXPOG,@ori_PUNC_CODS,@ori_PUNC_MDLS,@ori_PUNC_DAYS,@ori_PUNC_MOES,
               @ori_PUNC_NOMS,@ori_PUNC_DIAS,@ori_PUNC_LENS,@ori_PUNC_CODL,@ori_PUNC_MDLL,@ori_PUNC_DAYL,@ori_PUNC_MOEL,@ori_PUNC_NOML,@ori_PUNC_DIAL,@ori_PUNC_LENL,
               @ori_PUNC_CODV,@ori_PUNC_MDLV,@ori_PUNC_DAYV1,@ori_PUNC_DAYV2,@ori_PUNC_MOEV,@ori_PUNC_NOMV,@ori_PUNC_DIAV,@ori_PUNC_LENV,@ori_PUNC_CODR,
               @ori_PUNC_MDLR,@ori_PUNC_DAYR1,@ori_PUNC_DAYR2,@ori_PUNC_MOER,@ori_PUNC_NOMR,@ori_PUNC_DIAR,@ori_PUNC_LENR,@ori_PUNC_CODF,@ori_PUNC_MDLF,
               @ori_PUNC_DAYF,@ori_PUNC_MOEF,@ori_PUNC_NOMF,@ori_PUNC_DIAF,@ori_PUNC_LENF,@ori_PUNC_CODH,@ori_PUNC_MDLH,@ori_PUNC_DAYH1,@ori_PUNC_DAYH2,
               @ori_PUNC_MOEH,@ori_PUNC_NOMH,@ori_PUNC_DIAH,@ori_PUNC_LENH,@ori_PUNC_CODZ,@ori_PUNC_MDLZ,@ori_PUNC_DAYZ,@ori_PUNC_MOEZ,@ori_PUNC_NOMZ,@ori_PUNC_DIAZ,
               @ori_PUNC_LENZ,@ori_PUNC_CODY,@ori_PUNC_MDLY,@ori_PUNC_DAYY,@ori_PUNC_MOEY,@ori_PUNC_NOMY,@ori_PUNC_DIAY,@ori_PUNC_LENY,@ori_PUNC_CODP,@ori_PUNC_MDLP,
               @ori_PUNC_DAYP,@ori_PUNC_MOEP,@ori_PUNC_NOMP,@ori_PUNC_DIAP,@ori_PUNC_LENP,@ori_PUNC_CODQ,@ori_PUNC_MDLQ,@ori_PUNC_DAYQ,@ori_PUNC_MOEQ,@ori_PUNC_NOMQ,
               @ori_PUNC_DIAQ,@ori_PUNC_LENQ,@ori_PUNC_MTPR_COD,@ori_PUNC_MTPR_MTTP,@ori_PUNC_MTPR_MS,@ori_PUNC_MTPR_ATV,@ori_PUNC_MTPR_NOM,@ori_PUNC_MTPR_MTDV,
               @ori_PUNC_MTPR_MTLN,@ori_PUNC_MTPR_MTFM,@ori_PUNC_MTPR_MTUN,@ori_PUNC_MTPR_MTNC,@ori_PUNC_MTPR_ORI,@ori_PUNC_MTPR_PES,@ori_PUNC_MTPR_DES,
               @ori_PUNC_MTPR_NIV,@ori_PUNC_MTPR_ESUN,@ori_PUNC_MTPR_ESFT,@ori_PUNC_MTPR_CPUN,@ori_PUNC_MTPR_CPFT,@ori_PUNC_MTPR_ATVV,@ori_PUNC_MTPR_CFOV,
               @ori_PUNC_MTPR_ATVC,@ori_PUNC_MTPR_CFOC,@ori_PUNC_MTPR_TOLE,@ori_PUNC_MTES_SIES,@ori_PUNC_MTES_MTAL,@ori_PUNC_MTES_MTAN,@ori_PUNC_MTES_MTAP,
               @ori_PUNC_MTES_LOTE,@ori_PUNC_MTES_GLMD,@ori_PUNC_MTES_QATU,@ori_PUNC_MTES_VATU,@ori_PUNC_MTES_VATM,@ori_PUNC_MTES_QVIS,@ori_PUNC_MTES_QNEC,
               @ori_PUNC_MTES_QPRO,@ori_PUNC_MTES_PCME,@ori_PUNC_MTES_PCMR,@ori_PUNC_MTES_PMIN,@ori_PUNC_MTES_POBJ,@ori_PUNC_MTES_POEM,@ori_PUNC_MTES_PPMI,
               @ori_PUNC_MTES_PLEM,@ori_PUNC_MTES_PMUL,@ori_PUNC_MTES_PLEC,@ori_PUNC_MTES_UCDO,@ori_PUNC_MTES_LEAD,@ori_PUNC_MTES_LEEM,@ori_PUNC_MTES_EXPL,
               @ori_PUNC_MTES_MRP,@ori_PUNC_MTES_CREP,@ori_PUNC_MTES_CPDR,@ori_PUNC_MTES_FGGF,@ori_PUNC_MTES_FRAT,@ori_PUNC_MTES_CTGT,@ori_PUNC_MTES_CPO1,
               @ori_PUNC_MTES_CPO2,@ori_PUNC_MTES_CPO3,@ori_PUNC_MTES_CPO4,@ori_PUNC_MTES_PRAT,@ori_PUNC_MTPC_PRE,@ori_PUNC_MTPC_GLMD,@ori_PUNC_SALDO,@ori_PUNC_EXISTS,
               @ori_PUNC_USC,@ori_PUNC_DTC,@ori_PUNC_USU,@ori_PUNC_DTU
         end
      end else begin
         print 'PUNC: N�o existem registros a serem migrados...'
      end
      close cData
      deallocate cData
   end
   drop table #iae
   print ' --> N�mero de registros lidos   : '+Cast(@read as varchar)
   print ' --> N�mero de registros gravados: '+Cast(@cont as varchar)
   print 'Importa��o da tabela PUNC para PUNC : Termino:'+convert(char(20), getdate(), 113) + ' (tempo: '+ cast(datediff(minute,@time_ini,getdate()) as varchar)+' min.).'
end