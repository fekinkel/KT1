/*
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
declare @open varchar(400)
SET @PATH = N'\\192.168.3.3\Disco_W_TI'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
--set @dir_perfil = 'Atual\Seamonkey\Perfis\'
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

--set @dir='F:\smrasp\_des\puncao\anexos\'
set @dir='N:\Temp\'
--set @pla='MX_punc_v212_header.xlsx'--MX_punc_v212_header.
set @pla='MX punch menu for S2R with restrictions v2.25-1.xlsx'--MX_punc_v212_header.
--set @aba='plan1'
set @aba='Mexico list'
print @open IF OBJECT_ID('TempDB.dbo.##new') IS NOT NULL DROP TABLE ##newset @sql = 'SELECT *'
set @sql = @sql +'into ##new'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'
set @sql=@sql +' where isnull(cod1,''*'')<>''*'''

print @sql

EXEC (@SQL)

--select *from ##new
update ##new set MTPR_MTTP = 'PA' where MTPR_MTTP is null
update ##new set MTPR_NOM = '' where MTPR_NOM is null

SELECT * FROM ##new where MTPR_MTDV IS null

*/

IF OBJECT_ID('TempDB.dbo.#PUNC') IS NOT NULL DROP TABLE #PUNC--SELECT * INTO #PUNC FROM [192.168.3.40].[PUNC].[dbo].PUNC WHERE 1 = 0SELECT * INTO #PUNC FROM PUNC WHERE 1 = 0INSERT INTO #PUNCSELECT 		PUNC_CODB = CONVERT(varchar(20),isnull(codB,''))      --CONVERT(varchar(20),'') CodB(C�digo do blank)
	, PUNC_PREB = CONVERT(varchar(20),isnull(preB,''))      --CONVERT(varchar(20),'') PREB(PREB)
	, PUNC_MDLB = CONVERT(varchar(20),isnull(mdlB,''))      --CONVERT(varchar(20),'') MDLB(MDLB)
	, PUNC_DAYB = CONVERT(varchar(20),isnull(dayB,''))      --CONVERT(varchar(20),'') DAYB(DAYB)
	, PUNC_MOEB = CONVERT(varchar(20),isnull(moeB,''))      --CONVERT(varchar(20),'') MOEB(MOEB)
	, PUNC_NOMB = CONVERT(varchar(100),isnull(nomB,''))      --CONVERT(varchar(100),'') NOMB(NOMB)
	, PUNC_DIAB = CONVERT(decimal(9,2),isnull(diaB,0))      --CONVERT(decimal(9),'') DIAB(DIAB)
	, PUNC_LENB = CONVERT(decimal(9,2),isnull(lenB,0))      --CONVERT(decimal(9),'') LENB(LENB)
	, PUNC_COD1 = CONVERT(varchar(20),cod1)      --CONVERT(varchar(20),'') Insumo(C�digo do produto base)
	, PUNC_NOM1 = CONVERT(varchar(100),isnull(nom1,''))      --CONVERT(varchar(100),'') Nome1(Nome do insumo)
	, PUNC_NOM = CONVERT(varchar(100),isnull(nom,''))      --CONVERT(varchar(100),'') Nome(Nome do insumo)
	, PUNC_DIA1 = CONVERT(decimal(9,2),isnull(dia1,0))      --CONVERT(decimal(9),'') Diametro1(Di�metro base)
	, PUNC_LEN1 = CONVERT(decimal(9,2),isnull(len1,0))      --CONVERT(decimal(9),'') Comp1(Comprimento base)
	, PUNC_DHSTD = CONVERT(decimal(10,3),isnull(replace(dayDHstd,',','.'),0.0))--Null      --CONVERT(decimal(10),'') DHSTD(Altura padr�o de matrizes Dayton)
	, PUNC_DH1 = CONVERT(decimal(10,3),isnull(dayDH1,0))--Null      --CONVERT(decimal(10),'') DH1(Altura op��o 1 de matrizes Dayton)
	, PUNC_DH2 = CONVERT(decimal(10,3),isnull(dayDH2,0))--Null      --CONVERT(decimal(10),'') DH2(Altura op��o 2 de matrizes Dayton)
	, PUNC_MHSTD = CONVERT(decimal(10,3),isnull(replace(mdlDHstd,',','.'),0))--Null      --CONVERT(decimal(10),'') MHSTD(Altura padr�o de matrizes MDL)
	, PUNC_L2STD = CONVERT(decimal(9,2),isnull(L2std,0))      --CONVERT(decimal(9),'') L2STD(L2STD)
	, PUNC_L2OP1 = CONVERT(decimal(9,2),isnull(L2op1,0))      --CONVERT(decimal(9),'') L2OP1(L2OP1)
	, PUNC_L2OP2 = CONVERT(decimal(9,2),isnull(L2op2,0))      --CONVERT(decimal(9),'') L2OP2(L2OP2)
	, PUNC_MINP = CONVERT(decimal(10,3),isnull(minP,0))--Null      --CONVERT(decimal(10),'') MINP(MINP)
	, PUNC_MAXP = CONVERT(decimal(10,3),isnull(maxP,0))--Null      --CONVERT(decimal(10),'') MAXP(MAXP)
	, PUNC_MINW = CONVERT(decimal(10,3),isnull(minW,0))--Null      --CONVERT(decimal(10),'') MINW(MINW)
	, PUNC_MAXPOG = CONVERT(decimal(10,3),isnull(maxPOG,0))--Null      --CONVERT(decimal(10),'') MAXPOG(MAXPOG)
	, PUNC_CODS = CONVERT(varchar(20),isnull(codS,''))      --CONVERT(varchar(20),'') CodS(C�digo do redondo)
	, PUNC_MDLS = CONVERT(varchar(20),isnull(mdlS,''))      --CONVERT(varchar(20),'') MDLS(MDLS)
	, PUNC_DAYS = CONVERT(varchar(20),isnull(dayS,''))      --CONVERT(varchar(20),'') DAYS(DAYS)
	, PUNC_MOES = CONVERT(varchar(20),isnull(moeS,''))      --CONVERT(varchar(20),'') MOES(MOES)
	, PUNC_NOMS = CONVERT(varchar(100),isnull(nomS,''))      --CONVERT(varchar(100),'') NOMS(NOMS)
	, PUNC_DIAS = CONVERT(decimal(9,2),isnull(diaS,0))      --CONVERT(decimal(9),'') DIAS(DIAS)
	, PUNC_LENS = CONVERT(decimal(9,2),isnull(lenS,0))      --CONVERT(decimal(9),'') LENS(LENS)
	, PUNC_CODL = CONVERT(varchar(20),isnull(codL,''))      --CONVERT(varchar(20),'') CodL(C�digo do oblongo)
	, PUNC_MDLL = CONVERT(varchar(20),isnull(mdlL,''))      --CONVERT(varchar(20),'') MDLL(MDLL)
	, PUNC_DAYL = CONVERT(varchar(20),isnull(dayL,''))      --CONVERT(varchar(20),'') DAYL(DAYL)
	, PUNC_MOEL = CONVERT(varchar(20),isnull(moeL,''))      --CONVERT(varchar(20),'') MOEL(MOEL)
	, PUNC_NOML = CONVERT(varchar(100),isnull(nomL,''))      --CONVERT(varchar(100),'') NOML(NOML)
	, PUNC_DIAL = CONVERT(decimal(9,2),isnull(diaL,0))      --CONVERT(decimal(9),'') DIAL(DIAL)
	, PUNC_LENL = CONVERT(decimal(9,2),isnull(lenL,0))      --CONVERT(decimal(9),'') LENL(LENL)
	, PUNC_CODV = CONVERT(varchar(20),isnull(codV,''))      --CONVERT(varchar(20),'') CodV(C�digo do quadrado)
	, PUNC_MDLV = CONVERT(varchar(20),isnull(mdlV,''))      --CONVERT(varchar(20),'') MDLV(MDLV)
	, PUNC_DAYV1 = CONVERT(varchar(20),isnull(dayV1,''))      --CONVERT(varchar(20),'') DAYV1(DAYV1)
	, PUNC_DAYV2 = CONVERT(varchar(20),isnull(dayV2,''))      --CONVERT(varchar(20),'') DAYV2(DAYV2)
	, PUNC_MOEV = CONVERT(varchar(20),isnull(moeV,''))      --CONVERT(varchar(20),'') MOEV(MOEV)
	, PUNC_NOMV = CONVERT(varchar(100),isnull(nomV,''))      --CONVERT(varchar(100),'') NOMV(NOMV)
	, PUNC_DIAV = CONVERT(decimal(9,2),isnull(diaV,0))      --CONVERT(decimal(9),'') DIAV(DIAV)
	, PUNC_LENV = CONVERT(decimal(9,2),isnull(lenV,0))      --CONVERT(decimal(9),'') LENV(LENV)
	, PUNC_CODR = CONVERT(varchar(20),isnull(codR,''))      --CONVERT(varchar(20),'') CodR(C�digo do retangulo)
	, PUNC_MDLR = CONVERT(varchar(20),isnull(mdlR,''))      --CONVERT(varchar(20),'') MDLR(MDLR)
	, PUNC_DAYR1 = CONVERT(varchar(20),isnull(dayR1,''))      --CONVERT(varchar(20),'') DAYR1(DAYR1)
	, PUNC_DAYR2 = CONVERT(varchar(20),isnull(dayR2,''))      --CONVERT(varchar(20),'') DAYR2(DAYR2)
	, PUNC_MOER = CONVERT(varchar(20),isnull(moeR,''))      --CONVERT(varchar(20),'') MOER(MOER)
	, PUNC_NOMR = CONVERT(varchar(100),isnull(nomR,''))      --CONVERT(varchar(100),'') NOMR(NOMR)
	, PUNC_DIAR = CONVERT(decimal(9,2),isnull(diaR,0))      --CONVERT(decimal(9),'') DIAR(DIAR)
	, PUNC_LENR = CONVERT(decimal(9,2),isnull(lenR,0))      --CONVERT(decimal(9),'') LENR(LENR)
	, PUNC_CODF = CONVERT(varchar(20),isnull(codF,''))      --CONVERT(varchar(20),'') CodF(C�digo do retangulo arredondado)
	, PUNC_MDLF = CONVERT(varchar(20),isnull(mdlF,''))      --CONVERT(varchar(20),'') MDLF(MDLF)
	, PUNC_DAYF = CONVERT(varchar(20),isnull(dayF,''))      --CONVERT(varchar(20),'') DAYF(DAYF)
	, PUNC_MOEF = CONVERT(varchar(20),isnull(moeF,''))      --CONVERT(varchar(20),'') MOEF(MOEF)
	, PUNC_NOMF = CONVERT(varchar(100),isnull(nomF,''))      --CONVERT(varchar(100),'') NOMF(NOMF)
	, PUNC_DIAF = CONVERT(decimal(9,2),isnull(diaF,0))      --CONVERT(decimal(9),'') DIAF(DIAF)
	, PUNC_LENF = CONVERT(decimal(9,2),isnull(lenF,0))      --CONVERT(decimal(9),'') LENF(LENF)
	, PUNC_CODH = CONVERT(varchar(20),isnull(codH,''))      --CONVERT(varchar(20),'') CodH(C�digo do hex�gono)
	, PUNC_MDLH = CONVERT(varchar(20),isnull(mdlH,''))      --CONVERT(varchar(20),'') MDLH(MDLH)
	, PUNC_DAYH1 = CONVERT(varchar(20),isnull(dayH1,''))      --CONVERT(varchar(20),'') DAYH1(DAYH1)
	, PUNC_DAYH2 = CONVERT(varchar(20),isnull(dayH2,''))      --CONVERT(varchar(20),'') DAYH2(DAYH2)
	, PUNC_MOEH = CONVERT(varchar(20),isnull(moeH,''))      --CONVERT(varchar(20),'') MOEH(MOEH)
	, PUNC_NOMH = CONVERT(varchar(100),isnull(nomH,''))      --CONVERT(varchar(100),'') NOMH(NOMH)
	, PUNC_DIAH = CONVERT(decimal(9,2),isnull(diaH,0))      --CONVERT(decimal(9),'') DIAH(DIAH)
	, PUNC_LENH = CONVERT(decimal(9,2),isnull(lenH,0))      --CONVERT(decimal(9),'') LENH(LENH)
	, PUNC_CODZ = CONVERT(varchar(20),isnull(codZ,''))      --CONVERT(varchar(20),'') CodZ(C�digo do piloto padr�o)
	, PUNC_MDLZ = CONVERT(varchar(20),isnull(mdlZ,''))      --CONVERT(varchar(20),'') MDLZ(MDLZ)
	, PUNC_DAYZ = CONVERT(varchar(20),isnull(dayZ,''))      --CONVERT(varchar(20),'') DAYZ(DAYZ)
	, PUNC_MOEZ = CONVERT(varchar(20),isnull(moeZ,''))      --CONVERT(varchar(20),'') MOEZ(MOEZ)
	, PUNC_NOMZ = CONVERT(varchar(100),isnull(nomZ,''))      --CONVERT(varchar(100),'') NOMZ(NOMZ)
	, PUNC_DIAZ = CONVERT(decimal(9,2),isnull(diaZ,0))      --CONVERT(decimal(9),'') DIAZ(DIAZ)
	, PUNC_LENZ = CONVERT(decimal(9,2),isnull(lenZ,0))      --CONVERT(decimal(9),'') LENZ(LENZ)
	, PUNC_CODY = CONVERT(varchar(20),isnull(codY,''))      --CONVERT(varchar(20),'') CodY(C�digo do piloto angulado)
	, PUNC_MDLY = CONVERT(varchar(20),isnull(mdlY,''))      --CONVERT(varchar(20),'') MDLY(MDLY)
	, PUNC_DAYY = CONVERT(varchar(20),isnull(dayY,''))      --CONVERT(varchar(20),'') DAYY(DAYY)
	, PUNC_MOEY = CONVERT(varchar(20),isnull(moeY,''))      --CONVERT(varchar(20),'') MOEY(MOEY)
	, PUNC_NOMY = CONVERT(varchar(100),isnull(nomY,''))      --CONVERT(varchar(100),'') NOMY(NOMY)
	, PUNC_DIAY = CONVERT(decimal(9,2),isnull(diaY,0))      --CONVERT(decimal(9),'') DIAY(DIAY)
	, PUNC_LENY = CONVERT(decimal(9,2),isnull(lenY,0))      --CONVERT(decimal(9),'') LENY(LENY)
	, PUNC_CODP = CONVERT(varchar(20),isnull(codP,''))      --CONVERT(varchar(20),'') CodP(C�digo do piloto compacto)
	, PUNC_MDLP = CONVERT(varchar(20),isnull(mdlP,''))      --CONVERT(varchar(20),'') MDLP(MDLP)
	, PUNC_DAYP = CONVERT(varchar(20),isnull(dayP,''))      --CONVERT(varchar(20),'') DAYP(DAYP)
	, PUNC_MOEP = CONVERT(varchar(20),isnull(moeP,''))      --CONVERT(varchar(20),'') MOEP(MOEP)
	, PUNC_NOMP = CONVERT(varchar(100),isnull(nomP,''))      --CONVERT(varchar(100),'') NOMP(NOMP)
	, PUNC_DIAP = CONVERT(decimal(9,2),isnull(diaP,0))      --CONVERT(decimal(9),'') DIAP(DIAP)
	, PUNC_LENP = CONVERT(decimal(9,2),isnull(lenP,0))      --CONVERT(decimal(9),'') LENP(LENP)
	, PUNC_CODQ = CONVERT(varchar(20),isnull(codQ,''))      --CONVERT(varchar(20),'') CodQ(C�digo do piloto com passo)
	, PUNC_MDLQ = CONVERT(varchar(20),isnull(mdlQ,''))      --CONVERT(varchar(20),'') MDLQ(MDLQ)
	, PUNC_DAYQ = CONVERT(varchar(20),isnull(dayQ,''))      --CONVERT(varchar(20),'') DAYQ(DAYQ)
	, PUNC_MOEQ = CONVERT(varchar(20),isnull(moeQ,''))      --CONVERT(varchar(20),'') MOEQ(MOEQ)
	, PUNC_NOMQ = CONVERT(varchar(100),isnull(nomQ,''))      --CONVERT(varchar(100),'') NOMQ(NOMQ)
	, PUNC_DIAQ = CONVERT(decimal(9,2),isnull(diaQ,0))      --CONVERT(decimal(9),'') DIAQ(DIAQ)
	, PUNC_LENQ = CONVERT(decimal(9,2),isnull(lenQ,0))      --CONVERT(decimal(9),'') LENQ(LENQ)
	, PUNC_MTPR_COD = CONVERT(varchar(20),isnull(MTPR_COD,''))      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, PUNC_MTPR_MTTP = replace(replace(CONVERT(VARCHAR(25),isnull(MTPR_MTTP,'')),'PA','PA-PRODUCTO ACABADO'),'PI','PI-PRODUCTO INTERMEDIO')--Null      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, PUNC_MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, PUNC_MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, PUNC_MTPR_NOM = UPPER(CONVERT(varchar(80),MTPR_NOM))      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, PUNC_MTPR_MTDV = CASE SUBSTRING(NOM,1,3)
		WHEN 'Met' THEN '05'
		WHEN 'Inc' THEN '06'
		ELSE CONVERT(varchar(4),MTPR_MTDV)      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
		END
	, PUNC_MTPR_MTLN = CASE 
		WHEN ((SUBSTRING(NOM,1,3) = 'Met')AND(MTPR_MTLN IS NULL)) THEN '4150'
		WHEN (( SUBSTRING(NOM,1,3) = 'Inc')AND(MTPR_MTLN IS NULL)) THEN '5150'
		ELSE CONVERT(varchar(4),MTPR_MTLN)      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
		END
	, PUNC_MTPR_MTFM = CASE 
		WHEN ((SUBSTRING(NOM,1,3) = 'Met')AND(MTPR_MTFM IS NULL)AND(MTPR_MTLN IS NULL)) THEN '4700'
		WHEN (( SUBSTRING(NOM,1,3) = 'Inc')AND(MTPR_MTFM IS NULL)AND(MTPR_MTLN IS NULL)) THEN '6090'
		WHEN ((SUBSTRING(NOM,1,3) = 'Met')AND(MTPR_MTFM IS NULL)AND(MTPR_MTLN IS NOT NULL)) THEN '4697'
		WHEN (( SUBSTRING(NOM,1,3) = 'Inc')AND(MTPR_MTFM IS NULL)AND(MTPR_MTLN IS NOT NULL)) THEN '5555'
		ELSE CONVERT(varchar(4),MTPR_MTFM)      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
		END --CONVERT(varchar(4),MTPR_MTFM)      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, PUNC_MTPR_MTUN = MTPR_MTUN --Null      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, PUNC_MTPR_MTNC = CONVERT(varchar(8),'82073000')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, PUNC_MTPR_ORI = CONVERT(char(1),'1')      --CONVERT(char(1),'') Origem(Origem do produto)
	, PUNC_MTPR_PES = CONVERT(decimal(13,3),'0')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, PUNC_MTPR_DES = Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, PUNC_MTPR_NIV = CONVERT(int,0)      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, PUNC_MTPR_ESUN = 'PZ'      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, PUNC_MTPR_ESFT = 1.0      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, PUNC_MTPR_CPUN = 'PZ'      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, PUNC_MTPR_CPFT = 1.0      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, PUNC_MTPR_ATVV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, PUNC_MTPR_CFOV = '5.4101'      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, PUNC_MTPR_ATVC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, PUNC_MTPR_CFOC = '1.5101'      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, PUNC_MTPR_TOLE = CONVERT(decimal(12,2),'5')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, PUNC_MTES_SIES = 1      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, PUNC_MTES_MTAL = 'ALMO01'      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, PUNC_MTES_MTAN = 'ALMO01'      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, PUNC_MTES_MTAP = 'PROCES'      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, PUNC_MTES_LOTE = CONVERT(char(1),'N')      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, PUNC_MTES_GLMD = CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, PUNC_MTES_QATU = 0.00      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, PUNC_MTES_VATU = 0.00      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, PUNC_MTES_VATM = 0.00      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, PUNC_MTES_QVIS = 0.00      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, PUNC_MTES_QNEC = 0.00      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, PUNC_MTES_QPRO = 0.00      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, PUNC_MTES_PCME = 0.00      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, PUNC_MTES_PCMR = 0.00      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, PUNC_MTES_PMIN = 0      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, PUNC_MTES_POBJ = 0      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, PUNC_MTES_POEM = 0      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, PUNC_MTES_PPMI = 0.00      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, PUNC_MTES_PLEM = 0.00      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, PUNC_MTES_PMUL = 0.00      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, PUNC_MTES_PLEC = 0.00      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, PUNC_MTES_UCDO = ''      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, PUNC_MTES_LEAD = 0      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, PUNC_MTES_LEEM = 0      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, PUNC_MTES_EXPL = CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, PUNC_MTES_MRP = CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, PUNC_MTES_CREP = 0.00      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, PUNC_MTES_CPDR = 0.00      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, PUNC_MTES_FGGF = 0.00      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, PUNC_MTES_FRAT = CONVERT(int,'0')      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, PUNC_MTES_CTGT = 0.00      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, PUNC_MTES_CPO1 = ''      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, PUNC_MTES_CPO2 = ''      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, PUNC_MTES_CPO3 = ''      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, PUNC_MTES_CPO4 = ''      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, PUNC_MTES_PRAT = ''      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, PUNC_MTPC_PRE = CONVERT(decimal(12,2),'0')      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, PUNC_MTPC_GLMD = Null      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, PUNC_SALDO = Null      --CONVERT(decimal(16),'') Saldo(Saldo)
	, PUNC_EXISTS = Null      --CONVERT(varchar(1),'') Exists(Exists)
	, PUNC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, PUNC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, PUNC_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, PUNC_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM ##NEWSELECT *FROM #PUNCWHERE PUNC_MTPR_COD =''--497SELECT *FROM #PUNCWHERE PUNC_CODB =''--497--INSERT INTO [192.168.3.40].[PUNC].[dbo].PUNCINSERT INTO PUNCSELECT *FROM #PUNC--WHERE PUNC_CODB NOT IN (SELECT PUNC_CODB FROM [192.168.3.40].[PUNC].[dbo].PUNC)
WHERE PUNC_CODB NOT IN (SELECT PUNC_CODB FROM PUNC)

--AND PUNC_MTPR_MTDV+'/'+PUNC_MTPR_MTLN+'/'+PUNC_MTPR_MTFM NOT IN (SELECT MTFM_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD FROM MTFM)
--AND PUNC_MTPR_MTDV = '05'

--AND PUNC_CODB NOT IN ('YU-SRNN-61')--PUNC_CODB ,PUNC_PREB ,PUNC_MDLB ,PUNC_DAYB ,PUNC_MOEB ,PUNC_NOMB ,PUNC_DIAB ,PUNC_LENB ,PUNC_COD1 ,PUNC_NOM1 ,PUNC_NOM ,PUNC_DIA1 ,PUNC_LEN1 ,PUNC_DHSTD ,PUNC_DH1 ,PUNC_DH2 ,PUNC_MHSTD ,PUNC_L2STD ,PUNC_L2OP1 ,PUNC_L2OP2 ,PUNC_MINP ,PUNC_MAXP ,PUNC_MINW ,PUNC_MAXPOG ,PUNC_CODS ,PUNC_MDLS ,PUNC_DAYS ,PUNC_MOES ,PUNC_NOMS ,PUNC_DIAS ,PUNC_LENS ,PUNC_CODL ,PUNC_MDLL ,PUNC_DAYL ,PUNC_MOEL ,PUNC_NOML ,PUNC_DIAL ,PUNC_LENL ,PUNC_CODV ,PUNC_MDLV ,PUNC_DAYV1 ,PUNC_DAYV2 ,PUNC_MOEV ,PUNC_NOMV ,PUNC_DIAV ,PUNC_LENV ,PUNC_CODR ,PUNC_MDLR ,PUNC_DAYR1 ,PUNC_DAYR2 ,PUNC_MOER ,PUNC_NOMR ,PUNC_DIAR ,PUNC_LENR ,PUNC_CODF ,PUNC_MDLF ,PUNC_DAYF ,PUNC_MOEF ,PUNC_NOMF ,PUNC_DIAF ,PUNC_LENF ,PUNC_CODH ,PUNC_MDLH ,PUNC_DAYH1 ,PUNC_DAYH2 ,PUNC_MOEH ,PUNC_NOMH ,PUNC_DIAH ,PUNC_LENH ,PUNC_CODZ ,PUNC_MDLZ ,PUNC_DAYZ ,PUNC_MOEZ ,PUNC_NOMZ ,PUNC_DIAZ ,PUNC_LENZ ,PUNC_CODY ,PUNC_MDLY ,PUNC_DAYY ,PUNC_MOEY ,PUNC_NOMY ,PUNC_DIAY ,PUNC_LENY ,PUNC_CODP ,PUNC_MDLP ,PUNC_DAYP ,PUNC_MOEP ,PUNC_NOMP ,PUNC_DIAP ,PUNC_LENP ,PUNC_CODQ ,PUNC_MDLQ ,PUNC_DAYQ ,PUNC_MOEQ ,PUNC_NOMQ ,PUNC_DIAQ ,PUNC_LENQ ,PUNC_MTPR_COD ,PUNC_MTPR_MTTP ,PUNC_MTPR_MS ,PUNC_MTPR_ATV ,PUNC_MTPR_NOM ,PUNC_MTPR_MTDV ,PUNC_MTPR_MTLN ,PUNC_MTPR_MTFM ,PUNC_MTPR_MTUN ,PUNC_MTPR_MTNC ,PUNC_MTPR_ORI ,PUNC_MTPR_PES ,PUNC_MTPR_DES ,PUNC_MTPR_NIV ,PUNC_MTPR_ESUN ,PUNC_MTPR_ESFT ,PUNC_MTPR_CPUN ,PUNC_MTPR_CPFT ,PUNC_MTPR_ATVV ,PUNC_MTPR_CFOV ,PUNC_MTPR_ATVC ,PUNC_MTPR_CFOC ,PUNC_MTPR_TOLE ,PUNC_MTES_SIES ,PUNC_MTES_MTAL ,PUNC_MTES_MTAN ,PUNC_MTES_MTAP ,PUNC_MTES_LOTE ,PUNC_MTES_GLMD ,PUNC_MTES_QATU ,PUNC_MTES_VATU ,PUNC_MTES_VATM ,PUNC_MTES_QVIS ,PUNC_MTES_QNEC ,PUNC_MTES_QPRO ,PUNC_MTES_PCME ,PUNC_MTES_PCMR ,PUNC_MTES_PMIN ,PUNC_MTES_POBJ ,PUNC_MTES_POEM ,PUNC_MTES_PPMI ,PUNC_MTES_PLEM ,PUNC_MTES_PMUL ,PUNC_MTES_PLEC ,PUNC_MTES_UCDO ,PUNC_MTES_LEAD ,PUNC_MTES_LEEM ,PUNC_MTES_EXPL ,PUNC_MTES_MRP ,PUNC_MTES_CREP ,PUNC_MTES_CPDR ,PUNC_MTES_FGGF ,PUNC_MTES_FRAT ,PUNC_MTES_CTGT ,PUNC_MTES_CPO1 ,PUNC_MTES_CPO2 ,PUNC_MTES_CPO3 ,PUNC_MTES_CPO4 ,PUNC_MTES_PRAT ,PUNC_MTPC_PRE ,PUNC_MTPC_GLMD ,PUNC_SALDO ,PUNC_EXISTS ,PUNC_USC ,PUNC_DTC ,PUNC_USU ,PUNC_DTU ,

--YU-SRNN-61
SELECT PUNC_MTPR_MTDV, PUNC_MTPR_MTLN, PUNC_MTPR_MTFMFROM #PUNCWHERE PUNC_CODB NOT IN (SELECT PUNC_CODB FROM PUNC)
group by PUNC_MTPR_MTDV, PUNC_MTPR_MTLN, PUNC_MTPR_MTFM
ORDER by PUNC_MTPR_MTDV, PUNC_MTPR_MTLN, PUNC_MTPR_MTFM
