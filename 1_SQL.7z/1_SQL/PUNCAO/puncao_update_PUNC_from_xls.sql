-- 16/01/2017 16:45 -- SCIED
-- SELE��O DAS NOVAS COLUNAS mttp, ms, atv...   

---------------------------------------------
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
set @dir='F:\smrasp\_des\puncao\anexos\'
set @pla='MX punch menu for S2R with restrictions v2.19.xlsx'
set @aba='Mexico list'

/*
set @sql=      'select top 10 * '+char(10)
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'
set @sql=@sql +' where isnull(cod1,''*'')<>''*'''

print @sql

select top 10 punc_codB=BLANK
, punc_mttp=F186 -- "PA"; "PI"
, punc_ms  =F187 -- "M"
, punc_atv =F188 -- "S"
, punc_nom =F189 -- ""
, punc_mtdv=F190 -- "05"; "06"
, punc_mtln=F191 -- "3800"; "4000"; "4200"; "4800" ; "5000"; "5800"; ""; ""; ""; ""; ""
, punc_mtfm=F192 -- "4550"; "4560"; "4565"; "4595"; "4620"......; "6190"; "6200"
, punc_mtun=F193 -- "PZ" 
, * 
 FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=F:\smrasp\_des\puncao\anexos\MX punch menu for S2R with restrictions v2.19.xlsx', 'SELECT * FROM [Mexico list$]')
 where isnull(BLANK,'*')<>'*'
*/
declare @debug char(1)
set @debug='N'
set @debug='S'

declare cPUNC cursor local static for 
select 
 punc_codB=BLANK
,punc_mtpr_mttp=F186 -- "PA"; "PI"
,punc_mtpr_ms  =F187 -- "M"
,punc_mtpr_atv =F188 -- "S"
,punc_mtpr_nom =F189 -- ""
,punc_mtpr_mtdv=F190 -- "05"; "06"
,punc_mtpr_mtln=F191 -- "3800"; "4000"; "4200"; "4800" ; "5000"; "5800"; ""; ""; ""; ""; ""
,punc_mtpr_mtfm=F192 -- "4550"; "4560"; "4565"; "4595"; "4620"......; "6190"; "6200"
,punc_mtpr_mtun=F193 -- "PZ" 
 FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=F:\smrasp\_des\puncao\anexos\MX punch menu for S2R with restrictions v2.19.xlsx', 'SELECT * FROM [Mexico list$]')
 where isnull(BLANK,'*')<>'*'

open cPUNC

Declare  @modo varchar(1) ,@par_erro varchar(255) ,@PUNC_CODB varchar(20) ,@PUNC_PREB varchar(20) ,@PUNC_MDLB varchar(20) ,@PUNC_DAYB varchar(20) ,@PUNC_MOEB varchar(20) ,@PUNC_NOMB varchar(100) ,@PUNC_DIAB decimal(9,2) ,@PUNC_LENB decimal(9,2) ,@PUNC_COD1 varchar(20)
         ,@PUNC_NOM1 varchar(100) ,@PUNC_NOM varchar(100) ,@PUNC_DIA1 decimal(9,2) ,@PUNC_LEN1 decimal(9,2) ,@PUNC_DHSTD decimal(10,3) ,@PUNC_DH1 decimal(10,3) ,@PUNC_DH2 decimal(10,3) ,@PUNC_MHSTD decimal(10,3) ,@PUNC_L2STD decimal(9,2) ,@PUNC_L2OP1 decimal(9,2)
         ,@PUNC_L2OP2 decimal(9,2) ,@PUNC_MINP decimal(10,3) ,@PUNC_MAXP decimal(10,3) ,@PUNC_MINW decimal(10,3) ,@PUNC_MAXPOG decimal(10,3) ,@PUNC_CODS varchar(20) ,@PUNC_MDLS varchar(20) ,@PUNC_DAYS varchar(20) ,@PUNC_MOES varchar(20) ,@PUNC_NOMS varchar(100)
         ,@PUNC_DIAS decimal(9,2) ,@PUNC_LENS decimal(9,2) ,@PUNC_CODL varchar(20) ,@PUNC_MDLL varchar(20) ,@PUNC_DAYL varchar(20) ,@PUNC_MOEL varchar(20) ,@PUNC_NOML varchar(100) ,@PUNC_DIAL decimal(9,2) ,@PUNC_LENL decimal(9,2) ,@PUNC_CODV varchar(20) ,@PUNC_MDLV varchar(20)
         ,@PUNC_DAYV1 varchar(20) ,@PUNC_DAYV2 varchar(20) ,@PUNC_MOEV varchar(20) ,@PUNC_NOMV varchar(100) ,@PUNC_DIAV decimal(9,2) ,@PUNC_LENV decimal(9,2) ,@PUNC_CODR varchar(20) ,@PUNC_MDLR varchar(20) ,@PUNC_DAYR1 varchar(20) ,@PUNC_DAYR2 varchar(20) ,@PUNC_MOER varchar(20)
         ,@PUNC_NOMR varchar(100) ,@PUNC_DIAR decimal(9,2) ,@PUNC_LENR decimal(9,2) ,@PUNC_CODF varchar(20) ,@PUNC_MDLF varchar(20) ,@PUNC_DAYF varchar(20) ,@PUNC_MOEF varchar(20) ,@PUNC_NOMF varchar(100) ,@PUNC_DIAF decimal(9,2) ,@PUNC_LENF decimal(9,2) ,@PUNC_CODH varchar(20)
         ,@PUNC_MDLH varchar(20) ,@PUNC_DAYH1 varchar(20) ,@PUNC_DAYH2 varchar(20) ,@PUNC_MOEH varchar(20) ,@PUNC_NOMH varchar(100) ,@PUNC_DIAH decimal(9,2) ,@PUNC_LENH decimal(9,2) ,@PUNC_CODZ varchar(20) ,@PUNC_MDLZ varchar(20) ,@PUNC_DAYZ varchar(20) ,@PUNC_MOEZ varchar(20)
         ,@PUNC_NOMZ varchar(100) ,@PUNC_DIAZ decimal(9,2) ,@PUNC_LENZ decimal(9,2) ,@PUNC_CODY varchar(20) ,@PUNC_MDLY varchar(20) ,@PUNC_DAYY varchar(20) ,@PUNC_MOEY varchar(20) ,@PUNC_NOMY varchar(100) ,@PUNC_DIAY decimal(9,2) ,@PUNC_LENY decimal(9,2) ,@PUNC_CODP varchar(20)
         ,@PUNC_MDLP varchar(20) ,@PUNC_DAYP varchar(20) ,@PUNC_MOEP varchar(20) ,@PUNC_NOMP varchar(100) ,@PUNC_DIAP decimal(9,2) ,@PUNC_LENP decimal(9,2) ,@PUNC_CODQ varchar(20) ,@PUNC_MDLQ varchar(20) ,@PUNC_DAYQ varchar(20) ,@PUNC_MOEQ varchar(20) ,@PUNC_NOMQ varchar(100)
         ,@PUNC_DIAQ decimal(9,2) ,@PUNC_LENQ decimal(9,2) ,@PUNC_MTPR_COD varchar(20) ,@PUNC_MTPR_MTTP varchar(25) ,@PUNC_MTPR_MS char(1) ,@PUNC_MTPR_ATV char(1) ,@PUNC_MTPR_NOM varchar(80) ,@PUNC_MTPR_MTDV varchar(4) ,@PUNC_MTPR_MTLN varchar(4) ,@PUNC_MTPR_MTFM varchar(4)
         ,@PUNC_MTPR_MTUN varchar(3) ,@PUNC_MTPR_MTNC varchar(8) ,@PUNC_MTPR_ORI char(1) ,@PUNC_MTPR_PES decimal(13,3) ,@PUNC_MTPR_DES varchar(240) ,@PUNC_MTPR_NIV int ,@PUNC_MTPR_ESUN varchar(3) ,@PUNC_MTPR_ESFT decimal(10,6) ,@PUNC_MTPR_CPUN varchar(3) ,@PUNC_MTPR_CPFT decimal(10,6)
         ,@PUNC_MTPR_ATVV char(1) ,@PUNC_MTPR_CFOV varchar(8) ,@PUNC_MTPR_ATVC char(1) ,@PUNC_MTPR_CFOC varchar(8) ,@PUNC_MTPR_TOLE decimal(12,4) ,@PUNC_MTES_SIES int ,@PUNC_MTES_MTAL varchar(6) ,@PUNC_MTES_MTAN varchar(6) ,@PUNC_MTES_MTAP varchar(6) ,@PUNC_MTES_LOTE char(1)
         ,@PUNC_MTES_GLMD varchar(8) ,@PUNC_MTES_QATU decimal(14,6) ,@PUNC_MTES_VATU decimal(14,6) ,@PUNC_MTES_VATM decimal(14,6) ,@PUNC_MTES_QVIS decimal(14,6) ,@PUNC_MTES_QNEC decimal(14,6) ,@PUNC_MTES_QPRO decimal(14,6) ,@PUNC_MTES_PCME decimal(14,6) ,@PUNC_MTES_PCMR decimal(14,6)
         ,@PUNC_MTES_PMIN int ,@PUNC_MTES_POBJ int ,@PUNC_MTES_POEM int ,@PUNC_MTES_PPMI decimal(14,6) ,@PUNC_MTES_PLEM decimal(14,6) ,@PUNC_MTES_PMUL decimal(14,6) ,@PUNC_MTES_PLEC decimal(14,6) ,@PUNC_MTES_UCDO varchar(25) ,@PUNC_MTES_LEAD int ,@PUNC_MTES_LEEM int
         ,@PUNC_MTES_EXPL char(1) ,@PUNC_MTES_MRP char(1) ,@PUNC_MTES_CREP decimal(18,6) ,@PUNC_MTES_CPDR decimal(18,6) ,@PUNC_MTES_FGGF decimal(18,6) ,@PUNC_MTES_FRAT int ,@PUNC_MTES_CTGT decimal(18,6) ,@PUNC_MTES_CPO1 varchar(50) ,@PUNC_MTES_CPO2 varchar(50)
         ,@PUNC_MTES_CPO3 varchar(50) ,@PUNC_MTES_CPO4 varchar(50) ,@PUNC_MTES_PRAT varchar(20) ,@PUNC_USC varchar(15) ,@PUNC_DTC datetime ,@PUNC_USU varchar(15) ,@PUNC_DTU datetime

fetch next from cPUNC into 
 @punc_codB
,@punc_mtpr_mttp--=F186 -- "PA"; "PI"
,@punc_mtpr_ms  --=F187 -- "M"
,@punc_mtpr_atv --=F188 -- "S"
,@punc_mtpr_nom --=F189 -- ""
,@punc_mtpr_mtdv--=F190 -- "05"; "06"
,@punc_mtpr_mtln--=F191 -- "3800"; "4000"; "4200"; "4800" ; "5000"; "5800"; ""; ""; ""; ""; ""
,@punc_mtpr_mtfm--=F192 -- "4550"; "4560"; "4565"; "4595"; "4620"......; "6190"; "6200"
,@punc_mtpr_mtun--=F193 -- "PZ" 
while @@fetch_status=0 begin
   if isnull(@punc_codB,'')<>'' begin
      if exists (select 1 from PUNC where punc_codb=@punc_codB) begin
         if @punc_mtpr_MTTP='PA' set @punc_mtpr_MTTP='PA-PRODUCTO ACABADO'
         if @punc_mtpr_MTTP='PI' set @punc_mtpr_MTTP='PI-PRODUCTO INTERMEDIO'
         if @debug='N' begin
            update PUNC set 
             PUNC_MTPR_MTTP =@punc_mtpr_MTTP
            ,PUNC_MTPR_MTDV =@punc_mtpr_MTDV
            ,PUNC_MTPR_MTLN =@punc_mtpr_MTLN
            ,PUNC_MTPR_MTFM =@punc_mtpr_MTFM
            where punc_codb =@punc_codB
         end
         -- verifica se a operac�o gerou erro (segundo foreign key)
         if @@error<>0 begin
            print 'Erro na atualiza��o de PUNC para @PUNC_COD='+@punc_codB+' ...'
         end else begin
            print 'Atualiza��o de PUNC para @PUNC_COD='+@punc_codB+' realizada com sucesso.'
         end
      end else begin
         print '@punc_codB: ' +@punc_codB +' n�o encontrado em PUNC...'
      end
   end else begin
      print '@punc_codB � nulo...'
   end
   fetch next from cPUNC into 
    @punc_codB
   ,@punc_mtpr_mttp--=F186 -- "PA"; "PI"
   ,@punc_mtpr_ms  --=F187 -- "M"
   ,@punc_mtpr_atv --=F188 -- "S"
   ,@punc_mtpr_nom --=F189 -- ""
   ,@punc_mtpr_mtdv--=F190 -- "05"; "06"
   ,@punc_mtpr_mtln--=F191 -- "3800"; "4000"; "4200"; "4800" ; "5000"; "5800"; ""; ""; ""; ""; ""
   ,@punc_mtpr_mtfm--=F192 -- "4550"; "4560"; "4565"; "4595"; "4620"......; "6190"; "6200"
   ,@punc_mtpr_mtun--=F193 -- "PZ" 
end 
close cPUNC
deallocate cPUNC



/*

-- cargaas sucessivas com criticas de foreign keys 
-- at� que desativeis as foreign keys....

-- criticas
select div_lin_fam=punc_mtpr_mtdv+'/'+punc_mtpr_mtln+'/'+punc_mtpr_mtfm, 
punc_codB, punc_preb, punc_mdlb, punc_nomb
from punc left outer join mtfm on (punc_mtpr_mtdv=mtfm_mtdv and punc_mtpr_mtln=mtfm_mtln and punc_mtpr_mtfm=mtfm_cod)
where isnull(mtfm_cod,'nulo')='nulo'
*/
