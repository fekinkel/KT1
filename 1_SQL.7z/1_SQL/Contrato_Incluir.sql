select *
from vdcv
where vdcv_cod = 36

--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 21/02/2017--ASSUNTO      : 21/02/2017--DEPARTAMENTO : 21/02/2017------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#VDCX') IS NOT NULL DROP TABLE #VDCXSELECT *, VDCX_PUN_VAL VDCX_PUN_VAL_OLD INTO #VDCX FROM VDCX WHERE 1 = 0INSERT INTO #VDCXSELECT 		VDCX_VDCV = CONVERT(int,'36')      --CONVERT(int(3),'') Contrato(C�digo do contrato de venda)
	, VDCX_MTPC = CONVERT(varchar(20),mtpc_cod)      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, VDCX_ATV = CONVERT(char(1),'')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, VDCX_MTPR_NOM = mtpc_nom--Null      --CONVERT(varchar(254),'') Nome(Nome do produto comercial)
	, VDCX_PUN_MOD = CONVERT(char(1),'N')      --CONVERT(char(1),'') Pre�o espec�fico(Define a modalidade de pre�o (S=Espec�fico; N=Percentual sobre padr�o))
	, VDCX_PUN_VAL = CONVERT(decimal(12,2),mtpc_pre*.75)      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, VDCX_PUN_GLMD = CONVERT(varchar(8),'MXN')      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda que expressa o pre�o)
	, VDCX_PUN_PCT = CONVERT(decimal(6,2),75.00)      --CONVERT(decimal(6),'') % Sobre Padr�o(Percentual sobre a tabela de pre�os padr�o)
	, VDCX_COM_TIPO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Comiss�o Negociada(Define o padr�o de comissao (N: Padr�o; S: Negociada))
	, VDCX_COM_PCT = Null      --CONVERT(decimal(6),'') Comiss�o %(Percentual de comiss�o negociada)
	, VDCX_QTD = 0--Null      --CONVERT(decimal(14),'') Expectativa/Ano(Quantidade esperada de vendas num ano)
	, VDCX_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, VDCX_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, VDCX_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, VDCX_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, mtpc_pre
	--SELECT *
FROM MTPC, MTPRWHERE MTPC_MTPR = MTPR_CODAND MTPR_MTDV = 4INSERT INTO VDCXSELECT VDCX_VDCV ,VDCX_MTPC ,VDCX_ATV ,VDCX_MTPC_NOM ,VDCX_PUN_MOD ,VDCX_PUN_VAL ,VDCX_PUN_GLMD ,VDCX_PUN_PCT ,VDCX_COM_TIPO ,VDCX_COM_PCT ,VDCX_QTD ,VDCX_USC ,VDCX_DTC ,VDCX_USU ,VDCX_DTUFROM #VDCXWHERE CONVERT(VARCHAR(6),VDCX_VDCV)+'/'+VDCX_MTPC NOT IN (SELECT CONVERT(VARCHAR(6),VDCX_VDCV)+'/'+VDCX_MTPC FROM VDCX)
--VDCX_VDCV ,VDCX_MTPC ,VDCX_ATV ,VDCX_MTPC_NOM ,VDCX_PUN_MOD ,VDCX_PUN_VAL ,VDCX_PUN_GLMD ,VDCX_PUN_PCT ,VDCX_COM_TIPO ,VDCX_COM_PCT ,VDCX_QTD ,VDCX_USC ,VDCX_DTC ,VDCX_USU ,VDCX_DTU

