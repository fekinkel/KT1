drop table #newselect Comercial cod, new pre--*--, identity(int,1,1) NUMinto #newFROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\0_Arq\tabmolas.XLS',tabmolas$) where new is not null--[192.168.2.39].[MDL].[dbo].select MTPC_PRE, MTPC_PRE*1.05, b.*, *
--update [192.168.2.39].[MDL].[dbo].mtpc set MTPC_PRE = pre, MTPC_USU = 'KINKEL',	MTPC_DTU = getdate()
from [192.168.2.39].[MDL].[dbo].mtpc a, #new b
where mtpc_cod = cod collate SQL_Latin1_General_CP1_CI_AS

			--mtpc_cod like '9-%'
