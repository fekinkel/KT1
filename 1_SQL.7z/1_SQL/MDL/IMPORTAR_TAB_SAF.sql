--[].[].[].--[192.168.2.39].[MDL].[dbo].--IMPORTA��O DO SAF(ATIVO FIXO) DOS(dbf) SQL(MSSQL)--GRUPOS DROP TABLE #AFGRSELECT * INTO #AFGR FROM [192.168.2.39].[MDL].[dbo].AFGR WHERE 1 = 0INSERT INTO #AFGRSELECT 		AFGR_COD = LTRIM(CONVERT(varchar(10),COD_GRU))      --CONVERT(varchar(10),'') Grupo
	, AFGR_NOM = CONVERT(varchar(50),NOM_GRU)      --CONVERT(varchar(50),'') Nome
	, AFGR_DEP = CONVERT(char(1),DEP_GRU)      --CONVERT(char(1),'') Deprecia
	, AFGR_COR = CONVERT(char(1),COR_GRU)      --CONVERT(char(1),'') Corrige
	, AFGR_PRZ = CONVERT(int,PRZ_GRU)      --CONVERT(int(3),'') Prazo
	, AFGR_TXA = CONVERT(decimal(6,2),TXA_GRU)      --CONVERT(decimal(6),'') Taxa Anual
	, AFGR_GLMD = CONVERT(varchar(8),NOM_IND)      --CONVERT(varchar(8),'') �ndice
	, AFGR_AQD_PCC = AQD_PCC   --CONVERT(varchar(15),'') Conta Principal
	, AFGR_AQC_PCC = AQC_PCC   --CONVERT(varchar(15),'') Conta Auxiliar
	, AFGR_DPD_PCC = DPD_PCC   --CONVERT(varchar(15),'') Conta Principal (DP)
	, AFGR_DPC_PCC = DPC_PCC   --CONVERT(varchar(15),'') Conta Auxiliar (DP)
	, AFGR_CMD_PCC = CMD_PCC   --CONVERT(varchar(15),'') Conta Principal (CM)
	, AFGR_CMC_PCC = CMC_PCC   --CONVERT(varchar(15),'') Conta Auxiliar (CM)
	, AFGR_DMD_PCC = DMD_PCC   --CONVERT(varchar(15),'') Conta Principal (DM)
	, AFGR_DMC_PCC = DMC_PCC   --CONVERT(varchar(15),'') Conta Auxiliar (DM)
	, AFGR_USC = CONVERT(varchar(15),USU_SIS)      --CONVERT(varchar(15),'') Cadastrado por
	, AFGR_DTC = CONVERT(datetime,DTC_SIS)      --CONVERT(datetime(10),'') em
	, AFGR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, AFGR_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT * 
FROM OPENROWSET('MSDASQL',' Driver={Microsoft dBASE Driver (*.dbf)}; DefaultDir=C:\SCG1012\EMP01; SourceType=DBF','SELECT * FROM 01agru.dbf')
INSERT INTO [192.168.2.39].[MDL].[dbo].AFGRSELECT *FROM #AFGR--WHERE CONVERT(VARCHAR(6),AFGR_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),AFGR_SIES)FROM AFGR)
--AFGR_COD ,AFGR_NOM ,AFGR_DEP ,AFGR_COR ,AFGR_PRZ ,AFGR_TXA ,AFGR_GLMD ,AFGR_AQD_PCC ,AFGR_AQC_PCC ,AFGR_DPD_PCC ,AFGR_DPC_PCC ,AFGR_CMD_PCC ,AFGR_CMC_PCC ,AFGR_DMD_PCC ,AFGR_DMC_PCC ,AFGR_USC ,AFGR_DTC ,AFGR_USU ,AFGR_DTU ,

--LOCALIZA��O
DROP TABLE #AFLCSELECT * INTO #AFLC FROM [192.168.2.39].[MDL].[dbo].AFLC WHERE 1 = 0INSERT INTO #AFLCSELECT 		AFLC_COD = CONVERT(varchar(6),COD_LOC)      --CONVERT(varchar(6),'') Local
	, AFLC_NOM = CONVERT(varchar(50),NOM_LOC)      --CONVERT(varchar(50),'') Nome
	, AFLC_RES = CONVERT(varchar(15),RES_LOC)      --CONVERT(varchar(15),'') Respons�vel
	, AFLC_AQD_CTC = AQD_CTC      --CONVERT(varchar(15),'') C.Custo D�bito
	, AFLC_AQC_CTC = AQC_CTC		   --CONVERT(varchar(15),'') C.Custo Cr�dito
	, AFLC_DPD_CTC = DPD_CTC      --CONVERT(varchar(15),'') C.Custo D�bito (DP)
	, AFLC_DPC_CTC = DPC_CTC      --CONVERT(varchar(15),'') C.Custo Cr�dito (DP)
	, AFLC_CMD_CTC = CMD_CTC      --CONVERT(varchar(15),'') C.Custo D�bito (CM)
	, AFLC_CMC_CTC = CMC_CTC      --CONVERT(varchar(15),'') C.Custo Cr�dito (CM)
	, AFLC_DMD_CTC = DMD_CTC      --CONVERT(varchar(15),'') C.Custo D�bito (DM)
	, AFLC_DMC_CTC = DMC_CTC      --CONVERT(varchar(15),'') C.Custo Cr�dito (DM)
	, AFLC_USC = CONVERT(varchar(15),USU_SIS)      --CONVERT(varchar(15),'') Cadastrado por
	, AFLC_DTC = CONVERT(datetime,DTC_SIS)      --CONVERT(datetime(10),'') em
	, AFLC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, AFLC_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT * 
FROM OPENROWSET('MSDASQL',' Driver={Microsoft dBASE Driver (*.dbf)}; DefaultDir=C:\SCG1012\EMP01; SourceType=DBF','SELECT * FROM 01aloc.dbf')
INSERT INTO [192.168.2.39].[MDL].[dbo].AFLCSELECT *FROM #AFLC--WHERE CONVERT(VARCHAR(6),AFLC_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),AFLC_SIES)FROM AFLC)
--AFLC_COD ,AFLC_NOM ,AFLC_RES ,AFLC_AQD_CTC ,AFLC_AQC_CTC ,AFLC_DPD_CTC ,AFLC_DPC_CTC ,AFLC_CMD_CTC ,AFLC_CMC_CTC ,AFLC_DMD_CTC ,AFLC_DMC_CTC ,AFLC_USC ,AFLC_DTC ,AFLC_USU ,AFLC_DTU ,

--SEGURO
DROP TABLE #AFSGSELECT * INTO #AFSG FROM [192.168.2.39].[MDL].[dbo].AFSG WHERE 1 = 0INSERT INTO #AFSGSELECT 		AFSG_COD = CONVERT(varchar(6),COD_SEG)      --CONVERT(varchar(6),'') Seguro
	, AFSG_NOM = CONVERT(varchar(50),NOM_SEG)      --CONVERT(varchar(50),'') Nome
	, AFSG_APO = CONVERT(varchar(10),APO_SEG)      --CONVERT(varchar(10),'') Ap�lice
	, AFSG_DTV = CONVERT(datetime,DTV_SEG)      --CONVERT(datetime(10),'') Vencimento
	, AFSG_USC = CONVERT(varchar(15),USU_SIS)      --CONVERT(varchar(15),'') Cadastrado por
	, AFSG_DTC = CONVERT(datetime,DTC_SIS)      --CONVERT(datetime(10),'') em
	, AFSG_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, AFSG_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT * 
FROM OPENROWSET('MSDASQL',' Driver={Microsoft dBASE Driver (*.dbf)}; DefaultDir=C:\SCG1012\EMP01; SourceType=DBF','SELECT * FROM 01aSEG.dbf')
INSERT INTO [192.168.2.39].[MDL].[dbo].AFSGSELECT *FROM #AFSG--WHERE CONVERT(VARCHAR(6),AFSG_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),AFSG_SIES)FROM AFSG)
--AFSG_COD ,AFSG_NOM ,AFSG_APO ,AFSG_DTV ,AFSG_USC ,AFSG_DTC ,AFSG_USU ,AFSG_DTU ,

--MOVIMENTO PADR�O
DROP TABLE #AFMPSELECT * INTO #AFMP FROM [192.168.2.39].[MDL].[dbo].AFMP WHERE 1 = 0INSERT INTO #AFMPSELECT 		AFMP_COD = CONVERT(varchar(10),COD_MPR)      --CONVERT(varchar(10),'') C�digo
	, AFMP_NOM = CONVERT(varchar(50),NOM_MPR)      --CONVERT(varchar(50),'') Nome
	, AFMP_SIT_ATU = CONVERT(varchar(2),SIT_ATU)      --CONVERT(varchar(2),'') Situa��o Atual
	, AFMP_AFGR_ATU = LTRIM(CONVERT(varchar(10),GRU_ATU))      --CONVERT(varchar(10),'') Grupo Atual
	, AFMP_SIT_FIM = CONVERT(varchar(2),SIT_FIM)      --CONVERT(varchar(2),'') Situa��o Final
	, AFMP_AFGR_FIM = LTRIM(CONVERT(varchar(10),GRU_FIM))      --CONVERT(varchar(10),'') Grupo Final
	, AFMP_AQD_PCC = AQD_PCC      --CONVERT(varchar(15),'') Conta Principal
	, AFMP_AQC_PCC = AQC_PCC      --CONVERT(varchar(15),'') Conta Auxiliar
	, AFMP_DPD_PCC = DPD_PCC      --CONVERT(varchar(15),'') Conta Principal (DP)
	, AFMP_DPC_PCC = DPC_PCC      --CONVERT(varchar(15),'') Conta Auxiliar (DP)
	, AFMP_CMD_PCC = CMD_PCC      --CONVERT(varchar(15),'') Conta Principal (CM)
	, AFMP_CMC_PCC = CMC_PCC      --CONVERT(varchar(15),'') Conta Auxiliar (CM)
	, AFMP_DMD_PCC = DMD_PCC      --CONVERT(varchar(15),'') Conta Principal (DM)
	, AFMP_DMC_PCC = DMC_PCC      --CONVERT(varchar(15),'') Conta Auxiliar (DM)
	, AFMP_USC = CONVERT(varchar(15),USU_SIS)      --CONVERT(varchar(15),'') Cadastrado por
	, AFMP_DTC = CONVERT(datetime,DTC_SIS)      --CONVERT(datetime(10),'') em
	, AFMP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, AFMP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT * 
FROM OPENROWSET('MSDASQL',' Driver={Microsoft dBASE Driver (*.dbf)}; DefaultDir=C:\SCG1012\EMP01; SourceType=DBF','SELECT * FROM 01AMPR.dbf')
UPDATE #AFMP SET AFMP_DPD_PCC = null FROM #AFMPWHERE AFMP_DPD_PCC = '1302020009'INSERT INTO [192.168.2.39].[MDL].[dbo].AFMPSELECT *FROM #AFMPWHERE AFMP_AFGR_FIM  IN (SELECT AFGR_COD FROM [192.168.2.39].[MDL].[dbo].AFGR)			AND AFMP_DPD_PCC  NOT IN (SELECT CTPC_COD FROM [192.168.2.39].[MDL].[dbo].CTPC)--WHERE CONVERT(VARCHAR(6),AFMP_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),AFMP_SIES)FROM AFMP)
--AFMP_COD ,AFMP_NOM ,AFMP_SIT_ATU ,AFMP_AFGR_ATU ,AFMP_SIT_FIM ,AFMP_AFGR_FIM ,AFMP_AQD_PCC ,AFMP_AQC_PCC ,AFMP_DPD_PCC ,AFMP_DPC_PCC ,AFMP_CMD_PCC ,AFMP_CMC_PCC ,AFMP_DMD_PCC ,AFMP_DMC_PCC ,AFMP_USC ,AFMP_DTC ,AFMP_USU ,AFMP_DTU ,
