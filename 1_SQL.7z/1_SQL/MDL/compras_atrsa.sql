
select 'pedido/item '  +cast(cpip_sies as varchar)+'/' +cpip_sido+'/' +cpip_sise+'/' +cast(cpip_cppc as varchar)+'/' +cast(cpip_cod as varchar)
      +' de '+cpip_mtpr
      +' com atraso de ' +cast(cast(getdate() as integer)-cast(cpip_dent as integer) as varchar) +' dias'
 from cpip, cppc
where cppc_sies=cpip_sies and cppc_sido=cpip_sido and cppc_sise=cpip_sise and cppc_cod =cpip_cppc
and cpip_qtd-cpip_qor-cpip_qnf>0 and cpip_sta='OK'
and cpip_dent<getdate()

select *
from pror
where PROR_STA = 'LB'
			and PROR_ORDE = 'S'
			and 

select b.*
from cppc a, cpip b, mtes c
where cppc_sies = cpip_sies
			and cppc_sido = cpip_sido
			and cppc_sise = cpip_sise
			and cppc_cod  = cpip_cppc
			and cppc_sies = 5
			and CPIP_STA = 'OK'
			and CPIP_QTD <> CPIP_QNF
			and cpip_mtpr = mtes_mtpr
			and mtes_sies = cpip_sies
			and mtes_mrp  <> 'N'
			and convert(varchar(10),CPIP_DENT,102) >= '2015.01.01'
			and convert(varchar(10),CPIP_DENT,102) < convert(varchar(10),getdate(),102) 
			and CPIP_CPSC_SIDO <> 'CPSC'



