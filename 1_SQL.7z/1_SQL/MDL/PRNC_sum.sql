


--26/08/2015 - ALTERA��O NA ULTIMA COLUNA, FOI COLOCADOA AQUANTIDADE
--31/08/2016 - ALTERA��O ORDENAR POR DATA(ULTIMA LINHA)
IF OBJECT_ID('TempDB.dbo.#PRNC') IS NOT NULL DROP TABLE #PRNC

select max(convert(varchar(6),a.PRNC_SIES)+'/'+a.PRNC_SIDO+'/'+a.PRNC_SISE+'/'+convert(varchar(6),a.PRNC_NPAI)+'/'+convert(varchar(6),a.PRNC_COD)) VDPD,
c.PRNC_SIES, c.PRNC_SIDO, c.PRNC_SISE, c.PRNC_NPAI, 
max(convert(varchar(6),b.pror_sies)+'/'+b.pror_sido+'/'+b.pror_sise+'/'+convert(varchar(6),b.pror_cod)) PROR, 
c.PRNC_MTPR, sum(c.PRNC_VALA) VAL,
max(convert(varchar(10),b.pror_RDTR,103)) DATA,
sum(c.prnc_qtd) Qde --26/08/2015
into #PRNC
from prnc a, pror b, prnc c
where a.prnc_sies = 5
and a.prnc_sido = 'vdpd'
and convert(varchar(10),b.pror_RDTR,102) between '2016.08.01' and '2016.12.31'
--and convert(varchar(10),b.pror_RDTR,102) between '2016.01.01' and '2016.07.31'
--and convert(varchar(10),b.pror_RDTR,102) between '2015.12.01' and '2015.12.31'
--and convert(varchar(10),b.pror_RDTR,102) between '2015.09.01' and '2015.11.30'
--and convert(varchar(10),a.PRNC_DTC,102) between '2015.01.01' and '2015.01.31'
and a.PRNC_ORDE = 'N'
and a.PRNC_SIEX = b.pror_sies	
and a.PRNC_SIDX	= b.pror_sido
and a.PRNC_SISX	= b.pror_sise
and a.PRNC_NUMX	= b.pror_cod
--and a.PRNC_SEQX
and c.PRNC_SIEs = b.pror_sies	
and c.PRNC_SIDo	= b.pror_sido
and c.PRNC_SISe	= b.pror_sise
and c.PRNC_Npai	= b.pror_cod
--and b.pror_cod  = 70086

and convert(varchar(10),c.PRNC_DTC,102)<> convert(varchar(10),b.PROR_DTC,102)
and substring(c.PRNC_MTPR,1,3) <> 'BFT'


group by c.PRNC_SIES, c.PRNC_SIDO, c.PRNC_SISE, c.PRNC_NPAI, c.PRNC_MTPR
order by c.PRNC_SIES, c.PRNC_SIDO, c.PRNC_SISE, c.PRNC_NPAI, c.PRNC_MTPR

/*
select *
from pror
where pror_cod = 69875
*/

select convert(varchar(4),year(DATA))+'/'+convert(varchar(4),month(DATA)) DATA_RECEBIMENTO, sum(VAL) TOTAL
from #prnc
group by convert(varchar(4),year(DATA))+'/'+convert(varchar(4),month(DATA))
order by convert(varchar(4),year(DATA))+'/'+convert(varchar(4),month(DATA))

select VDPD, PROR, sum(VAL) TOTAL, DATA DATA_RECEBIMENTO
from #prnc
group by VDPD, PROR, DATA
order by DATA

select *
from #prnc
order by substring(DATA,7,4),substring(DATA,4,2), substring(DATA,1,2)
--01/01/2016
