
select  'True', substring(substring(ADsPath,CHARINDEX(',OU',ADsPath)+4,100),1,charindex(',OU',substring(ADsPath,CHARINDEX(',OU',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login], Mail email, title Titulo, department Dep
from  openquery(adsi, '
				select ADsPath,
				sAMAccountName, displayName, userPassword, userPrincipalName, lastLogon, pwdLastSet, Mail, title, department
				from    ''LDAP://dc=mdl,dc=com,dc=br''
where   objectCategory = ''Person''
and objectClass = ''*'' and sAMAccountName = ''kinkel'''  )
ADsPath  

declare  
	@name varchar(255),
	@pwd varchar(255)

set @name = 'rodrigod'
BEGIN

DECLARE
--CRIA UMA VARI�VEL DE UMA TIPO TABELA
@exec nvarchar(4000)

	begin try
		--COLOCA O USU�RIO E SENHA NO ADSI
		set @exec = 'master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'+char(39)+'ADSI'+char(39)+',@useself=N'+char(39)+'False'+char(39)+',@locallogin=NULL,@rmtuser=N'+char(39)+'mdl\'+@name+CHAR(39)+',@rmtpassword='+CHAR(39)+@pwd+CHAR(39)
		exec (@exec)

		--EXECUTA O ADSI, SE DER CERTO PQ A SENHA EST� CORRETA
		set @exec = '
		select  '+char(39)+'True'+CHAR(39)+', substring(substring(ADsPath,CHARINDEX('+CHAR(39)+',OU'+CHAR(39)+',ADsPath)+4,100),1,charindex('+CHAR(39)+',OU'+CHAR(39)+',substring(ADsPath,CHARINDEX('+CHAR(39)+',OU'+CHAR(39)+',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login], Mail, title, department
		from  openquery(adsi, '+CHAR(39)+'
		select ADsPath,
		sAMAccountName, displayName, userPassword, userPrincipalName, lastLogon, pwdLastSet, Mail, title, department
		from    '+char(39)+char(39)+'LDAP://dc=mdl,dc=com,dc=br'+char(39)+char(39)+CHAR(10)+
		'where   objectCategory = '+char(39)+char(39)+'Person'+char(39)+char(39)+CHAR(10)+
		'and objectClass = '+char(39)+char(39)+'*'+char(39)+char(39)+' and sAMAccountName = '+char(39)+char(39)+@name+char(39)+Char(39) +char(39)+'  )'

		exec (@exec)
	end try begin catch
		select 'False', 'Erro', 'Usu�rio/Senha inv�lido','Inv�lido'
	end catch

END
