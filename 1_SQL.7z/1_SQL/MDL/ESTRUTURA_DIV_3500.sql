--6714
--6318
--6305
--5672 - 37 = 5635 
select MTEP_PAI,	MTEP_FIL
from mtpr a, mtep b
where mtpr_mtdv = '3500'
and (MTPR_MTTP <> 'PA-PRODUTO ACABADO'
and MTPR_MTTP <> 'MP-MAT�RIA PRIMA')
and substring(mtpr_cod,1,1) <>'O' 
and substring(mtpr_cod,1,1) <> 'R' 
and MTPR_ATV = 'S'
and mtep_pai = mtpr_cod
--and substring(MTEP_PAI,1,1) = substring(MTEP_FIL,1,1)
and MTEP_SEQ = 10

select MTPR_COD, *
from mtpr
where mtpr_mtdv = '3500'
and (MTPR_MTTP <> 'PA-PRODUTO ACABADO'
and MTPR_MTTP <> 'MP-MAT�RIA PRIMA')
and substring(mtpr_cod,1,1) <> 'O' 
and substring(mtpr_cod,1,1) <> 'R' 
and MTPR_ATV = 'S'
and mtpr_cod not in (select mtep_pai from mtep)
