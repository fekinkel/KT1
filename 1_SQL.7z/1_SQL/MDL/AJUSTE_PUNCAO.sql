--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 31/10/2016--ASSUNTO      : 31/10/2016--DEPARTAMENTO : 31/10/2016------------------------------------------------------------------------------------------------------------------------


--833
IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPR
select *, IDENTITY(INT,1,1) NUM
INTO #MTPR
from mtpr, [CFG_MDL].[dbo].[Plan1$]
where mtpr_mtdv = '3500'
AND MTPR_ATV = 'S'
and Insumo = mtpr_cod
--group by substring(MTPR_MTLN,1,2)
order by MTPR_MTLN, MTPR_COD

IF OBJECT_ID('TempDB.dbo.#LN') IS NOT NULL DROP TABLE #LN
select substring(MTPR_MTLN,1,2) MTPR_MTLN, count(1) TOTAL
INTO #LN
from #mtpr
group by substring(MTPR_MTLN,1,2)
order by MTPR_MTLN


SELECT * FROM #LN


IF OBJECT_ID('TempDB.dbo.#MTMV') IS NOT NULL DROP TABLE #MTMVSELECT * INTO #MTMV FROM MTMV WHERE 1 = 0
DECLARE
@I INT,
@J INT,
@K INT,
@MTMV INT,
@LN CHAR(2),
@MTPR VARCHAR(20),
@SALDO DECIMAL(12,2),
@VAL DECIMAL(12,2),
@modo     varchar(1),
@par_erro varchar(255),
@ANO INT,
@MES INT,
@CTPC VARCHAR(20)

SELECT @J=1, @I = MAX(NUM) FROM #MTPR
SELECT @K=1, @MTMV = 1106788, @LN = substring(MTPR_MTLN,1,2) FROM #MTPR WHERE NUM = @J
SELECT @ANO = YEAR(GETDATE()), @MES = MONTH(GETDATE())

WHILE @J <= @I BEGIN
--WHILE @J <= 10 BEGIN
	IF (SELECT substring(MTPR_MTLN,1,2) FROM #MTPR WHERE NUM = @J)<> @LN BEGIN
		SELECT @K=1, @LN = substring(MTPR_MTLN,1,2) FROM #MTPR WHERE NUM = @J
		SET @MTMV = @MTMV + 2
	END
	SELECT @MODO = 'S', @MTPR = MTPR_COD, @VAL = [Custo Unt#]--, NUM, @LN, @K, @MTMV
	FROM #MTPR 
	WHERE NUM = @J
	
	exec MT_MTSW_SALDO @MTPR, 5, @ANO, @MES, 'ALMO01', '', '', @SALDO output, 0, 0, 0
	--exec MT_Saldo_Estru @MODO OUTPUT, @ERRO output, @MTPR ,5, 'N'


	INSERT INTO #MTMV	SELECT 		MTMV_SIES = CONVERT(int,5)      --CONVERT(int(6),'') Estab.
		, MTMV_SIDO = CONVERT(varchar(4),'MTMV')      --CONVERT(varchar(4),'') Tip.Doc.
		, MTMV_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
		, MTMV_COD = CONVERT(int,@MTMV)      --CONVERT(int(6),'') N�mero
		, MTMV_SEQ = CONVERT(int,@K)      --CONVERT(int(3),'') Seq.
		, MTMV_DAT = CONVERT(datetime,'31/10/2016')      --CONVERT(datetime(10),'') Data
		, MTMV_MTES = CONVERT(varchar(20),@MTPR)      --CONVERT(varchar(20),'') Insumo
		, MTMV_MTTR = CONVERT(varchar,MTTR_COD)      --CONVERT(varchar(6),'') Transa��o
		, MTMV_AUTO = MTTR_AUTO --CONVERT(char(1),'')      --CONVERT(char(1),'') Nec.Auto
		, MTMV_TRAN = MTTR_TRAN --CONVERT(char(1),'')      --CONVERT(char(1),'') Transforma��o
		, MTMV_ACAO = MTTR_ACAO --CONVERT(char(1),'')      --CONVERT(char(1),'') C�lculo
		, MTMV_DIRE = MTTR_DIRE --CONVERT(char(1),'')      --CONVERT(char(1),'') Opera��o
		, MTMV_VLIN = MTTR_VLIN --CONVERT(char(1),'')      --CONVERT(char(1),'') Inf. Valor
		, MTMV_UCIN = MTTR_UCIN --CONVERT(char(1),'')      --CONVERT(char(1),'') Ult. compra
		, MTMV_ATUM = MTTR_ATUM --CONVERT(char(1),'')      --CONVERT(char(1),'') Atualiza Consumo
		, MTMV_SUCA = MTTR_SUCA --CONVERT(char(1),'')      --CONVERT(char(1),'') Sucata
		, MTMV_SIDX = Null      --CONVERT(varchar(4),'') Doc.Externo
		, MTMV_SISX = Null      --CONVERT(varchar(3),'') S�r.Ext.
		, MTMV_CODX = Null      --CONVERT(int(6),'') N�m.Ext.
		, MTMV_SEQX = Null      --CONVERT(int(8),'') Seq.Ext.
		, MTMV_MTAL_ORI = MTTR_MTAL_ORI --CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Origem
		, MTMV_SUBL_ORI = MTTR_SUBL_ORI --CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local O
		, MTMV_TABE_ORI = Null      --CONVERT(varchar(8),'') Tabela Origem
		, MTMV_SIDO_ORI = Null      --CONVERT(varchar(4),'') Doc.Ori.
		, MTMV_SISE_ORI = Null      --CONVERT(varchar(3),'') S�r.Ori
		, MTMV_COD_ORI = Null      --CONVERT(int(6),'') N�mero Ori
		, MTMV_SEQ_ORI = Null      --CONVERT(int(3),'') Seq.Ori
		, MTMV_LOTE_ORI = Null      --CONVERT(varchar(20),'') Lote Origem
		, MTMV_CTPC_ORI = '1110070006' --Null      --CONVERT(varchar(15),'') Conta origem
		, MTMV_CTCC_ORI = Null      --CONVERT(varchar(15),'') C.Custo origem
		, MTMV_MTAL_DES = MTTR_MTAL_DES --CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Destino
		, MTMV_SUBL_DES = MTTR_SUBL_DES --CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local D
		, MTMV_TABE_DES = Null      --CONVERT(varchar(8),'') Tabela Destino
		, MTMV_SIDO_DES = Null      --CONVERT(varchar(4),'') Doc Des
		, MTMV_SISE_DES = Null      --CONVERT(varchar(3),'') S�r.Des
		, MTMV_COD_DES = Null      --CONVERT(int(6),'') N�mero Des
		, MTMV_SEQ_DES = Null      --CONVERT(int(3),'') Seq.Des
		, MTMV_LOTE_DES = Null      --CONVERT(varchar(20),'') Lote Destino
		, MTMV_CTPC_DES = MTAL_CTPC --Null      --CONVERT(varchar(15),'') Conta destino
		, MTMV_CTCC_DES = MTAL_CTCC --Null      --CONVERT(varchar(15),'') C.Custo destino
		, MTMV_MTAL_AUT = Null      --CONVERT(varchar(6),'') Almox.Auto
		, MTMV_QTD = @SALDO --Null      --CONVERT(decimal(14),'') Quantidade
		, MTMV_VAL = 0 --Null      --CONVERT(decimal(14),'') Valor Total
		, MTMV_VALM = 0 --Null      --CONVERT(decimal(14),'') Valor Total M
		, MTMV_VALP = 0 --Null      --CONVERT(decimal(14),'') Valor Padr�o
		, MTMV_VALA = 0 --Null      --CONVERT(decimal(14),'') Valor Arbitrado
		, MTMV_GLHP = Null      --CONVERT(varchar(5),'') Hist�rico
		, MTMV_MEN = upper(CONVERT(varchar(256),'atualiza��o do custo m�dio de estoque da divis�o 3500'))     --CONVERT(varchar(256),'') Texto
		, MTMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
		, MTMV_DTC = CONVERT(datetime,getdate())      --CONVERT(datetime(10),'') em
		, MTMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
		, MTMV_DTU = Null      --CONVERT(datetime(10),'') em
		--SELECT *	FROM MTTR, MTAL	WHERE MTTR_SIES = 5				and MTTR_COD = 'SAICME'				AND MTTR_SIES = MTAL_SIES 
				AND MTTR_MTAL_DES = MTAL_COD

	INSERT INTO #MTMV	SELECT 		MTMV_SIES = CONVERT(int,5)      --CONVERT(int(6),'') Estab.
		, MTMV_SIDO = CONVERT(varchar(4),'MTMV')      --CONVERT(varchar(4),'') Tip.Doc.
		, MTMV_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
		, MTMV_COD = CONVERT(int,@MTMV + 1)      --CONVERT(int(6),'') N�mero
		, MTMV_SEQ = CONVERT(int,@K)      --CONVERT(int(3),'') Seq.
		, MTMV_DAT = CONVERT(datetime,'31/10/2016')      --CONVERT(datetime(10),'') Data
		, MTMV_MTES = CONVERT(varchar(20),@MTPR)      --CONVERT(varchar(20),'') Insumo
		, MTMV_MTTR = CONVERT(varchar,MTTR_COD)      --CONVERT(varchar(6),'') Transa��o
		, MTMV_AUTO = MTTR_AUTO --CONVERT(char(1),'')      --CONVERT(char(1),'') Nec.Auto
		, MTMV_TRAN = MTTR_TRAN --CONVERT(char(1),'')      --CONVERT(char(1),'') Transforma��o
		, MTMV_ACAO = MTTR_ACAO --CONVERT(char(1),'')      --CONVERT(char(1),'') C�lculo
		, MTMV_DIRE = MTTR_DIRE --CONVERT(char(1),'')      --CONVERT(char(1),'') Opera��o
		, MTMV_VLIN = MTTR_VLIN --CONVERT(char(1),'')      --CONVERT(char(1),'') Inf. Valor
		, MTMV_UCIN = MTTR_UCIN --CONVERT(char(1),'')      --CONVERT(char(1),'') Ult. compra
		, MTMV_ATUM = MTTR_ATUM --CONVERT(char(1),'')      --CONVERT(char(1),'') Atualiza Consumo
		, MTMV_SUCA = MTTR_SUCA --CONVERT(char(1),'')      --CONVERT(char(1),'') Sucata
		, MTMV_SIDX = Null      --CONVERT(varchar(4),'') Doc.Externo
		, MTMV_SISX = Null      --CONVERT(varchar(3),'') S�r.Ext.
		, MTMV_CODX = Null      --CONVERT(int(6),'') N�m.Ext.
		, MTMV_SEQX = Null      --CONVERT(int(8),'') Seq.Ext.
		, MTMV_MTAL_ORI = MTTR_MTAL_ORI --CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Origem
		, MTMV_SUBL_ORI = MTTR_SUBL_ORI --CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local O
		, MTMV_TABE_ORI = Null      --CONVERT(varchar(8),'') Tabela Origem
		, MTMV_SIDO_ORI = Null      --CONVERT(varchar(4),'') Doc.Ori.
		, MTMV_SISE_ORI = Null      --CONVERT(varchar(3),'') S�r.Ori
		, MTMV_COD_ORI = Null      --CONVERT(int(6),'') N�mero Ori
		, MTMV_SEQ_ORI = Null      --CONVERT(int(3),'') Seq.Ori
		, MTMV_LOTE_ORI = Null      --CONVERT(varchar(20),'') Lote Origem
		, MTMV_CTPC_ORI = MTAL_CTPC --Null      --CONVERT(varchar(15),'') Conta origem
		, MTMV_CTCC_ORI = MTAL_CTCC --Null      --CONVERT(varchar(15),'') C.Custo origem
		, MTMV_MTAL_DES = MTTR_MTAL_DES --CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Destino
		, MTMV_SUBL_DES = MTTR_SUBL_DES --CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local D
		, MTMV_TABE_DES = Null      --CONVERT(varchar(8),'') Tabela Destino
		, MTMV_SIDO_DES = Null      --CONVERT(varchar(4),'') Doc Des
		, MTMV_SISE_DES = Null      --CONVERT(varchar(3),'') S�r.Des
		, MTMV_COD_DES = Null      --CONVERT(int(6),'') N�mero Des
		, MTMV_SEQ_DES = Null      --CONVERT(int(3),'') Seq.Des
		, MTMV_LOTE_DES = Null      --CONVERT(varchar(20),'') Lote Destino
		, MTMV_CTPC_DES = '1110070006' --Null      --CONVERT(varchar(15),'') Conta destino
		, MTMV_CTCC_DES = Null      --CONVERT(varchar(15),'') C.Custo destino
		, MTMV_MTAL_AUT = Null      --CONVERT(varchar(6),'') Almox.Auto
		, MTMV_QTD = @SALDO --Null      --CONVERT(decimal(14),'') Quantidade
		, MTMV_VAL = @SALDO*@VAL --Null      --CONVERT(decimal(14),'') Valor Total
		, MTMV_VALM = @SALDO*@VAL --Null      --CONVERT(decimal(14),'') Valor Total M
		, MTMV_VALP = 0--@SALDO*@VAL --Null      --CONVERT(decimal(14),'') Valor Padr�o
		, MTMV_VALA = 0--@SALDO*@VAL --Null      --CONVERT(decimal(14),'') Valor Arbitrado
		, MTMV_GLHP = Null      --CONVERT(varchar(5),'') Hist�rico
		, MTMV_MEN = upper(CONVERT(varchar(256),'atualiza��o do custo m�dio de estoque da divis�o 3500'))     --CONVERT(varchar(256),'') Texto
		, MTMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
		, MTMV_DTC = CONVERT(datetime,getdate())      --CONVERT(datetime(10),'') em
		, MTMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
		, MTMV_DTU = Null      --CONVERT(datetime(10),'') em
		--SELECT *	FROM MTTR, MTAL 	WHERE MTTR_SIES = 5				and MTTR_COD = 'ENTCME'				AND MTTR_SIES = MTAL_SIES 
				AND MTTR_MTAL_ORI = MTAL_COD
	
	SELECT @MTPR, @SALDO
	SET @K = @K + 1
	SET @J = @J + 1
	
END

/*
SAIDA EXTCPV
ENTRADA ALMO01

TRANSACAO SAICME E ENTCME
*/

INSERT INTO MTMVSELECT *FROM #MTMVWHERE CONVERT(VARCHAR(7),MTMV_COD) NOT IN (SELECT CONVERT(VARCHAR(7),MTMV_COD)FROM MTMV)
and MTMV_MTTR = 'saiCME'and MTMV_QTD <> 0.000000INSERT INTO MTMVSELECT *FROM #MTMVWHERE CONVERT(VARCHAR(7),MTMV_COD) NOT IN (SELECT CONVERT(VARCHAR(7),MTMV_COD)FROM MTMV)
and MTMV_MTTR = 'ENTCME'and MTMV_QTD <> 0.000000--MTMV_SIES ,MTMV_SIDO ,MTMV_SISE ,MTMV_COD ,MTMV_SEQ ,MTMV_DAT ,MTMV_MTES ,MTMV_MTTR ,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX ,MTMV_SEQX ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI ,MTMV_SEQ_ORI ,MTMV_LOTE_ORI ,MTMV_CTPC_ORI ,MTMV_CTCC_ORI ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES ,MTMV_SEQ_DES ,MTMV_LOTE_DES ,MTMV_CTPC_DES ,MTMV_CTCC_DES ,MTMV_MTAL_AUT ,MTMV_QTD ,MTMV_VAL ,MTMV_VALM ,MTMV_VALP ,MTMV_VALA ,MTMV_GLHP ,MTMV_MEN ,MTMV_USC ,MTMV_DTC ,MTMV_USU ,MTMV_DTU ,


--select top 1 * from mtmv WHERE MTMV_COD = 1103356 SELECT TOP 1 * FROM MTTR WHERE MTTR_COD = 'SAICME'

--SELECT * FROM MTPR

select *
--delete mtmv
FROM #MTMV a, mtmv bWHERE --CONVERT(VARCHAR(7),MTMV_COD) NOT IN (SELECT CONVERT(VARCHAR(7),MTMV_COD)FROM MTMV)
 b.MTMV_MTTR = 'saiCME'--and a.MTMV_QTD <> 0.000000and a.MTMV_SIES = b.MTMV_SIES
and	a.MTMV_SIDO = b.MTMV_SIDO
and	a.MTMV_SISE = b.MTMV_SISE
and	a.MTMV_COD = b.MTMV_COD
and	a.MTMV_SEQ = b.MTMV_SEQ


declare
@w int,
@cod varchar(20)
set @w = 1
while @w <= 833 begin
	select @cod = mtpr_cod from #mtpr where num = @w
	exec MT_MOV_REC_LOG6 'KINKEL',@cod,5,2016,10
	set @w = @w +1
end
