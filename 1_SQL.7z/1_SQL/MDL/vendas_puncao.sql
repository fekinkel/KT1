--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 16/01/2018--DEPARTAMENTO : SISTEMA--ASSUNTO      : QUANTIDADE VENDIDA DOS PUN��ES COM C�DIGO ANTIGO.------------------------------------------------------------------------------------------------------------------------
/*IF OBJECT_ID('TempDB.dbo.#VDC1') IS NOT NULL DROP TABLE #VDC1select vdc1_mtpr, VDC1_QTDEinto #vdc1from vdc1where convert(varchar(10),vdc1_dtc, 102)>= '2017.01.01'
IF OBJECT_ID('TempDB.dbo.#VDPI') IS NOT NULL DROP TABLE #VDPIselect vdPI_mtpr, VDPI_QTDinto #vdPIfrom vdPIwhere convert(varchar(10),vdPI_dtc, 102)>= '2017.01.01'

*/IF OBJECT_ID('TempDB.dbo.#PRE') IS NOT NULL DROP TABLE #PRESELECT SUBSTRING(MTPR_COD,1,3) PRE, IDENTITY(INT,1,1) N, 0 N_PREINTO #PREFROM MTPRWHERE SUBSTRING(MTPR_COD,1,2) = 'PP' AND SUBSTRING(REVERSE(MTPR_COD),1,1) = 'B'AND MTPR_ATVV = 'S'GROUP BY SUBSTRING(MTPR_COD,1,3)UPDATE #PRE SET N_PRE = 1 WHERE N = 1UPDATE #PRE SET N_PRE = 2 WHERE N = 6UPDATE #PRE SET N_PRE = 3 WHERE N = 4UPDATE #PRE SET N_PRE = 4 WHERE N = 3UPDATE #PRE SET N_PRE = 5 WHERE N = 5UPDATE #PRE SET N_PRE = 6 WHERE N = 7UPDATE #PRE SET N_PRE = 7 WHERE N = 2/* 1 = B
6 = S
4 = L
3 = F
5 = R
7 = V
*/--SELECT * FROM #PRE--PPB
--PPE
--PPF
--PPL
--PPR
--PPS
--PPVDECLARE@J INT = 1WHILE @j <= (SELECT MAX(N_PRE) FROM #PRE) BEGIN	IF OBJECT_ID('TempDB.dbo.#mtpr') IS NOT NULL DROP TABLE #mtpr	select MTPR_COD cod, identity(int,1,1) num, Qde_orc = 99999999, Qde_ven = 99999999, Preco_ant = CONVERT(DECIMAL(12,2),MTPC_PRE), Preco_nov = 99999999.99
	into #mtpr
	from mtpr, #PRE, mtpc
	where mtpr_cod like PRE+'%'
	AND N_PRE = @j
	AND SUBSTRING(REVERSE(MTPR_COD),1,1) = 'B'
	AND MTPR_ATVV = 'S'
	AND MTPC_MTPR = MTPR_COD
	--SELECT * FROM #PRE WHERE N_PRE = @J
	--SELECT * FROM #MTPR
	
	declare
	@i int = 1
	,@v int
	--IF OBJECT_ID('TempDB.dbo.#mtpr') IS NOT NULL DROP TABLE #mtpt
	while @i <= (select max(num) from #mtpr) begin
		set @v = 0
		select  @v = sum(VDC1_QTDE)
		from #vdc1, #mtpr
		where VDC1_MTPR = cod
		and num = @i
		group by cod

		If @v  is null set @v = 0

		update #mtpr set qde_orc = @v where num = @i

		select  @v = sum(VDPI_QTD)
		from #vdPI, #mtpr
		where VDPI_MTPR = cod
		and num = @i
		group by cod

		If @v  is null set @v = 0

		update #mtpr set qde_VEN = @v where num = @i

		--and convert(varchar(10),vdc1_dtc, 102)>= '2017.01.01'

		set @i = @i + 1

	end
	select Qde_orc,	Qde_ven, Preco_ant,	Preco_nov, COD, NUM --*--, Qde_ven * 100/Qde_ORC
	from #mtpr
	
	SET @j = @J + 1

END

select *--, Qde_ven * 100/Qde_ORC
from #mtpr
--WHERE Qde_ven > 0
--AND COD = 'PPB.380.152B'

/*
SELECT *
FROM VDC1
WHERE VDC1_MTPR = 'PPB.380.152B'
AND convert(varchar(10),vdc1_dtc, 102)>= '2017.01.01'

SELECT *
FROM VDPI
WHERE VDC1_MTPR = 'PPB.380.152B'
AND convert(varchar(10),vdc1_dtc, 102)>= '2017.01.01'
*/

