--SOMENTE E10
drop table #new
--[VND].[dbo].
select MTES_MTPR, MTES_PCMR, MTES_PPMI, MTES_PMIN, MTES_POBJ, MTES_PLEM,	MTES_PMUL
into #new
from [VND].[dbo].mtpr a, [VND].[dbo].mtes b
where mtpr_mtln = 4200
			and mtpr_atv = 's'
			and mtes_mtpr = mtpr_cod
			and mtes_sies = 5
			and MTES_PCMR <> 0
			--and mtpr_cod = 'BLB.100.080b'
--73			
--MTES_PCME = MTES_PCMR

--73
select *--MTES_MTPR, MTES_PCMR, MTES_PPMI, MTES_PMIN, MTES_POBJ, MTES_PLEM,	MTES_PMUL
--UPDATE MTES set MTES_PCME = a.MTES_PCMR, MTES_PCMR = a.MTES_PCMR, MTES_PPMI = a.MTES_PPMI, MTES_PMIN = a.MTES_PMIN, MTES_POBJ = a.MTES_POBJ, MTES_PLEM = a.MTES_PLEM,	MTES_PMUL = a.MTES_PMUL
from #new a, mtes b
where a.mtes_mtpr = b.mtes_mtpr
			and b.mtes_sies = 5
			--and MTES_PCMR <> 0

drop table #new

select MTES_MTPR, MTES_PCMR, MTES_PPMI, MTES_PMIN, MTES_POBJ, MTES_PLEM,	MTES_PMUL
into #new
from mtpr a, mtes b
where mtpr_mtdv = 3500
			and mtpr_atv = 's'
			and mtes_mtpr = mtpr_cod
			and mtes_sies = 7
			and MTES_PCMR <> 0
			--and mtpr_cod = 'BLB.100.080b'
--640			
--MTES_PCME = MTES_PCMR

--931
select a.mtes_mtpr, MTES_PCME = a.MTES_PCMR, MTES_PCMR = a.MTES_PCMR, MTES_PPMI = a.MTES_PPMI, MTES_PMIN = a.MTES_PMIN, MTES_POBJ = a.MTES_POBJ, MTES_PLEM = a.MTES_PLEM,	MTES_PMUL = a.MTES_PMUL--*--MTES_MTPR, MTES_PCMR, MTES_PPMI, MTES_PMIN, MTES_POBJ, MTES_PLEM,	MTES_PMUL
--UPDATE MTES set MTES_PCME = a.MTES_PCMR, MTES_PCMR = a.MTES_PCMR, MTES_PPMI = a.MTES_PPMI, MTES_PMIN = a.MTES_PMIN, MTES_POBJ = a.MTES_POBJ, MTES_PLEM = a.MTES_PLEM,	MTES_PMUL = a.MTES_PMUL
from #new a, mtes b
where a.mtes_mtpr = b.mtes_mtpr
			and b.mtes_sies = 5
			--and MTES_PCMR <> 0
