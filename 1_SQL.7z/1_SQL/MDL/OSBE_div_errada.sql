/*
select mtpr_cod, ftit_mtpr, *
--update ftit set ftit_mtln = mtpr_mtln, ftit_mtfm = mtpr_mtfm
from ftit, ftnf, mtpr
where ftit_ftnf = ftnf_cod
			and ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and convert(varchar(10),ftnf_dat,102) between '2015.01.01' and '2017.01.01'
			and ftit_mtpr = mtpr_cod
			and ftit_mtln <> mtpr_mtln


select distinct GLCR_GLCL--mtpr_cod, ftit_mtpr, d.*
*/

SELECT *
--update ftit set ftit_mtfm = mtpr_mtfm
from ftit, ftnf b, mtpr, glcr d
where ftit_ftnf = ftnf_cod
			and ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and convert(varchar(10),ftnf_dat,102) between '2015.01.01' and '2017.01.01'
			and ftit_mtpr = mtpr_cod
			and ftit_mtfm <> mtpr_mtfm

			and glcr_glcl = ftnf_glxx
			and GLCR_STA = 'OK'
			and ftnf_gltx = 'GLCL'

/*

*/