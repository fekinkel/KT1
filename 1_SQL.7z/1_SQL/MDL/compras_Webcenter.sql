SET LANGUAGE 'Brazilian'--select UPPER(datename(month, GETDATE()-30))+'/'+CONVERT(VARCHAR(20),YEAR(GETDATE()-30))DECLARE@I INT, @J INT,@K INT,@G INT,@H INT,@M int,@ped int,@item intSELECT @I = SISE_NUM FROM SISE WHERE SISE_SIDO = 'CPSC' and sise_sies = 5
--insert into CPSC
IF OBJECT_ID('TempDB.dbo.#cpsc') IS NOT NULL DROP TABLE #cpsc
select identity(int,1,1) num,999999 new,CPSC_SIES ,CPSC_SIDO ,CPSC_SISE , @I+(row_number() over (order by CPSC_NPAI)) CPSC_NPAI ,CPSC_COD ,CPSC_STA ,CPSC_MTAP ,CPSC_MOTIVO ,CPSC_GLFU ,CPSC_MTPR ,CPSC_MTPC ,CPSC_NFOP ,CPSC_REV ,CPSC_QTD ,CPSC_DTES ,CPSC_CTPC ,CPSC_RDPC ,CPSC_CTCC ,CPSC_RDCC ,replace(CPSC_NOM,'JULHO/2014',UPPER(datename(month, GETDATE()-30))+'/'+CONVERT(VARCHAR(20),YEAR(GETDATE()-30))) CPSC_NOM, replace(CPSC_ESPE,'JULHO/2014',UPPER(datename(month, GETDATE()-30))+'/'+CONVERT(VARCHAR(20),YEAR(GETDATE()-30))) CPSC_ESPE ,CPSC_PROJ ,CPSC_CPCT_SIES ,CPSC_CPCT_SIDO ,CPSC_CPCT_SISE ,CPSC_CPCT ,0 CPSC_CPIP_SIES ,'' CPSC_CPIP_SIDO ,'' CPSC_CPIP_SISE ,0 CPSC_CPIP_CPPC ,0 CPSC_CPIP ,CPSC_OBS ,CPPC_GLXX CPSC_GLXX ,'KINKEL' CPSC_USC ,getdate() CPSC_DTC ,NULL CPSC_USU ,NULL CPSC_DTU, 0 PED
--select identity(int,1,1) num,999999 new,CPSC_SIES ,CPSC_SIDO ,CPSC_SISE , @I+(row_number() over (order by CPSC_NPAI)) CPSC_NPAI ,CPSC_COD ,CPSC_STA ,CPSC_MTAP ,CPSC_MOTIVO ,CPSC_GLFU ,CPSC_MTPR ,CPSC_MTPC ,CPSC_NFOP ,CPSC_REV ,CPSC_QTD ,CPSC_DTES ,CPSC_CTPC ,CPSC_RDPC ,CPSC_CTCC ,CPSC_RDCC , CPSC_NOM,STUFF(CPSC_ESPE, charindex('REF.',CPSC_ESPE), 14, 'REF.'+convert(char(2),month(getdate()))+'/'+convert(char(4),year(getdate()))) CPSC_ESPE ,CPSC_PROJ ,CPSC_CPCT_SIES ,CPSC_CPCT_SIDO ,CPSC_CPCT_SISE ,CPSC_CPCT ,0 CPSC_CPIP_SIES ,'' CPSC_CPIP_SIDO ,'' CPSC_CPIP_SISE ,0 CPSC_CPIP_CPPC ,0 CPSC_CPIP ,CPSC_OBS ,CPSC_GLXX ,'KINKEL' CPSC_USC ,getdate() CPSC_DTC ,NULL CPSC_USU ,NULL CPSC_DTU
--select identity(int,1,1) num,999999 new,CPSC_SIES ,CPSC_SIDO ,CPSC_SISE , 0 CPSC_NPAI ,CPSC_COD ,CPSC_STA ,CPSC_MTAP ,CPSC_MOTIVO ,CPSC_GLFU ,CPSC_MTPR ,CPSC_MTPC ,CPSC_NFOP ,CPSC_REV ,CPSC_QTD ,CPSC_DTES ,CPSC_CTPC ,CPSC_RDPC ,CPSC_CTCC ,CPSC_RDCC ,CPSC_NOM ,STUFF(CPSC_ESPE, charindex('REF.',CPSC_ESPE), 14, 'REF.'+convert(char(2),month(getdate()))+'/'+convert(char(4),year(getdate()))) CPSC_ESPE ,CPSC_PROJ ,CPSC_CPCT_SIES ,CPSC_CPCT_SIDO ,CPSC_CPCT_SISE ,CPSC_CPCT ,0 CPSC_CPIP_SIES ,'' CPSC_CPIP_SIDO ,'' CPSC_CPIP_SISE ,0 CPSC_CPIP_CPPC ,0 CPSC_CPIP ,CPSC_OBS ,CPSC_GLXX ,CPSC_USC ,getdate() CPSC_DTC ,CPSC_USU ,CPSC_DTU
into #cpsc
from CPIP, CPSC, CPPC
where CPIP_CPPC in (39832)
--where CPIP_CPPC in (39432, 39431, 35007)
--where CPIP_CPPC in (35140, 35063, 35007) ANTIGO MAIS 10,7633%
			and CPIP_CPSC_SIES = CPSC_SIES
			and	CPIP_CPSC_SIDO = CPSC_SIDO
			and	CPIP_CPSC_SISE = CPSC_SISE
			and	CPIP_CPSC_NPAI = CPSC_NPAI
			and	CPIP_CPSC = CPSC_COD
			and CPIP_SIES = CPPC_SIES
			AND CPIP_SIDO = CPPC_SIDO
			AND CPIP_SISE = CPPC_SISE
			AND CPIP_CPPC = CPPC_COD
			--AND 0 --VERIFICAR PARA CRIAR PEDIDO DE COMPRAS
--39431 35063 webcenter
--35007 SMR
--39432 35140 Philips
--select 'REF.'+convert(char(2),month(getdate()))+'/'+convert(char(4),year(getdate()))

--SELECT STUFF('a123def', 2, 3, 'ijklmn');

insert into cpsc
select CPSC_SIES ,CPSC_SIDO ,CPSC_SISE ,CPSC_NPAI ,CPSC_COD ,CPSC_STA ,CPSC_MTAP ,CPSC_MOTIVO ,CPSC_GLFU ,CPSC_MTPR ,CPSC_MTPC ,CPSC_NFOP ,CPSC_REV ,CPSC_QTD ,CPSC_DTES ,CPSC_CTPC ,CPSC_RDPC ,CPSC_CTCC ,CPSC_RDCC ,CPSC_NOM ,CPSC_ESPE ,CPSC_PROJ ,CPSC_CPCT_SIES ,CPSC_CPCT_SIDO ,CPSC_CPCT_SISE ,CPSC_CPCT ,CPSC_CPIP_SIES ,CPSC_CPIP_SIDO ,CPSC_CPIP_SISE ,CPSC_CPIP_CPPC ,CPSC_CPIP ,CPSC_OBS ,CPSC_GLXX ,CPSC_USC ,CPSC_DTC ,CPSC_USU ,CPSC_DTU
from #cpsc

--SELECT * FROM #CPSC

SELECT @J = MAX(CPsc_NPAI) FROM #CPscselect @I+1, @J 
UPDATE SISE SET SISE_NUM = @J--select * from siseWHERE SISE_SIDO = 'CPSC'			and sise_sies = 5
			

-----------------------------------------------------------------------------

SELECT @m = 0, @H = 1, @G = MAX(NUM) FROM #CPSC 

print @h

WHILE @H <= @G BEGIN

	if (select CPSC_GLXX from #cpsc where num = @h) <> @m begin 

		select @ped = 0, @m = CPSC_GLXX, @k = CPSC_NPAI from #cpsc where num = @h
		
		declare @M1 varchar(800)
		set @M1=''
		--'Gera��o do Pedido de Compra realizada com sucesso! => 5/CPPC/001/37862'
		declare @M2 varchar(800)
		set @M2='I'
		
		exec [MDL].[DBO].CP_SOL_PED @M1 output,@M2 output,5,'CPSC','001',@k,1,'KINKEL'
		
		select @ped=convert(int,rtrim(ltrim(substring(@M1,charindex('=>',@M1)+14,10))))				
		
		print @ped
		
	end else begin

		select @m = CPSC_GLXX, @k = CPSC_NPAI from #cpsc where num = @h
		
		declare @p1 varchar(80)
		declare @p2 varchar(80)
		declare @p3 int
		declare @p4 varchar(80)
		declare @p5 varchar(80)
		declare @p6 int
		declare @p7 int
		DECLARE @DATA DATETIME

		--WHILE (SELECT @k) <= @j BEGIN
		set @p1='I'
		set @p2=''
		set @p3=5
		set @p4='CPPC'
		set @p5='001'
		set @p7=0

		select @p6=@ped, @DATA = GETDATE()
		select @item = max(cpip_cod)+1 from [MDL].[DBO].cpip where cpip_sies = @p3 and cpip_sido = @p4 and cpip_sise = @p5 and cpip_cppc = @ped

		exec [MDL].[DBO].CPPC_i_CPIP_smr @p1 output,@p2 output,@p3 output,@p4 output,@p5 output,@p6 output,@p7 output,5,'CPSC','001',@k,1,'KINKEL',@DATA,@m,'REAL','BRA','SP','BRA','SP'
	end	

	SELECT @k = @k + 1
	SELECT @h = @h + 1
	
END

