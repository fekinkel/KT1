--select vdc1_rev, VDCO_REV, *
--update vdc1 set vdc1_rev = VDCO_REV
from vdco, vdc1
where convert(varchar(10),vdco_dtc,102) >= '2016.12.01'
and vdco_sies = vdc1_sies
and vdco_sido = vdc1_sido
and vdco_sise = vdc1_sise
and vdco_cod  = vdc1_vdco
and VDCO_REV <> vdc1_rev
and VDCO_STA = 'OK'



--select vdpi_rev, VDPD_REV, *
--update vdpi set vdpi_rev = VDPD_REV
from vdpd, vdpi
where convert(varchar(10),vdpd_dtc,102) >= '2016.12.01'
and vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and VDpd_REV <> vdpi_rev
and VDPD_QTD <> (VDPD_QOR+VDPD_QNF)
--and VDpd_STA = 'EA'

--select vdpi_rev, VDPD_REV, *
--update vdpd set vdpd_rev = 'N'
from vdpd, vdpi
where convert(varchar(10),vdpd_dtc,102) >= '2016.12.01'
and vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and vdpd_cod = 251246
--and VDpd_REV <> vdpi_rev
--and VDPD_QTD <> (VDPD_QOR+VDPD_QNF)
--and VDpd_STA = 'EA'

