--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Autor                : Fernando Kinkel
--Data                : 11/03/2015
--Solicitante    : Sr. Patrick (MDL-MEX)
--Objetivo        : Script que cria tabela com primeiro e ultimo dia do mes assim como os dias uteis de cada mes
--                        :    PARA EXECUTAR A PROCEDURE DO RELATORIO (RL_VDA_MovimentoDiarioDiv - RELATORIO DE VENDA DIARIA POR DIVISAO)
--                        :    MENU RELATORIOS -> VENDAS -> MOVIMENTO DI�RIO POR DIVISAO
--Campos            :
--Restries        :
--Observaes        : ALTERAR ONDE INDICA DATA INICIAL / FINAL POIS E O INTERVALO DE DATA.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
declare
                  @di date     --data inicio
                , @df date     --data fim
                , @dii varchar(10)     --data fim
                , @dff varchar(10)     --data fim
                , @data date
								, @datafim date
                , @i int
                , @j int
                , @k int
                , @d int
								, @s varchar(4000)
								, @field varchar(5000)
								, @div varchar(4)
								, @lin varchar(4)
								, @fam varchar(4)
								, @ds varchar(10)
--set @div = '0500'
set @div = '1500'
--set @div = '1000'
set @lin = ''
set @fam = ''
set @data = convert(date,'2014.01.01',102)     -- DATA DE INICIO
select @datafim = convert(date,'2018.01.01',102)--dateadd(MONTH,12, @data)

--------VALIDA��O DIVIS�O LINHA FAMILIA
IF @DIV = '' SET @diV = ' ' 
IF @LIN = '' SET @lin = ' ' 
IF @FAM = '' SET @fam = ' ' 
-------
--select @div,@lin,@fam

IF OBJECT_ID('TempDB.dbo.##new') IS NOT NULL DROP TABLE ##new
select MTPR_MTDV[divisao], mtdv_nom[nom_div],	MTPR_MTLN[linha],mtln_nom[nom_lin],	MTPR_MTFM[familia], mtfm_nom[nom_fam], MTPC_COD [mtpc], MTPR_COD [insumo] 
into ##new
from mtpr, mtdv, mtln, mtfm, mtpc
where mtpr_mtdv LIKE REPLACE(@div,' ','%%')
and mtpr_mtln LIKE REPLACE(@lin,' ','%%')
and mtpr_mtfm LIKE REPLACE(@fam,' ','%%')
and mtdv_cod = mtpr_mtdv
and mtpr_mtln = mtln_cod
and mtln_mtdv = mtdv_cod
and mtpr_mtln = mtln_cod
and mtpr_mtfm = mtfm_cod
and mtfm_mtln = mtln_cod
and mtfm_mtdv = mtdv_cod
and mtpr_cod  = mtpc_mtpr
--select * from ##new
select @field = ''
while (select @data) <= @datafim begin            -- DATA DE FIM

print 'DE ='+convert(varchar(10),@data,102)+' ---/--- At� = '+convert(varchar(10), @datafim,102)
 select @di					= @data
 select @df					= dateadd(day, 32, @di)
 select @k					= DAY(@df)-1
 select @data				= dateadd(day, - @k, @df)
 select @df					= DATEADD(day,-1,@data)
 select @j					= DAY(@df)

 --select @di, @df, @data


 set        @i        = 1
 set        @d        = 0


IF OBJECT_ID('TempDB.dbo.##tmpRlmb') IS NOT NULL DROP TABLE ##tmpRlmb
 CREATE TABLE ##tmpRlmb
   ( Rlmb_mtdv char(4)
   , Rlmb_mtdv_nom varchar(50)
   , Rlmb_mtln char(4)
   , Rlmb_mtln_nom varchar(50)
   , Rlmb_mtfm char(4)
   , Rlmb_mtfm_nom varchar(50)
   , Rlmb_mtpc varchar(20)
   , Rlmb_mtpc_nom varchar(50)
   , Rlmb_ftit varchar(25) -- 1/FTNF/001/123456/123
   , Rlmb_data datetime
   , Rlmb_glcl int
   , Rlmb_glcl_dig int
   , Rlmb_glcl_nom varchar(60)
   , Rlmb_qtdf decimal(12,3)
   , Rlmb_mtun char(2)
   , Rlmb_vdpi varchar(25) -- 1/VDPD/001/123456/123
   , Rlmb_vcus decimal(12,2)
   , Rlmb_vliq decimal(12,2)
   , Rlmb_marg decimal(6,2)
-- 30/01/2013 13:42 -- SCIED - Novos campos acrescidos para LAAX
   , Rlmb_glfo int
   , Rlmb_glfo_dig int
   , Rlmb_glfo_nom varchar(60)
   , Rlmb_mtfo varchar(20)
   , Rlmb_mtfo_nom varchar(50)
   )

 WHILE @i <= @j  BEGIN
  IF (SELECT (DATEPART(DW,DATEADD(day,+(@i),@di) ))-1) IN (1,2,3,4,5) BEGIN
   SET @d = @d + 1
  END
  SET @i = @i + 1
 END

	IF @DIV = ' ' SET @diV = '0' 
	IF @LIN = ' ' SET @lin = '0' 
	IF @FAM = ' ' SET @fam = '0' 
	select @dii = convert(varchar(2),day(@di))+'/'+convert(varchar(2),month(@di))+'/'+convert(varchar(4),year(@di)), @dff = convert(varchar(2),day(@df))+'/'+convert(varchar(2),month(@df))+'/'+convert(varchar(4),year(@df))
    --select @j, @k, @di [Data Inicio], @df [Data Fim], @data [Proxima data], @d [Dias Uteis]            -- EXIBE A DATA DOS DADOS
		truncate table ##tmpRlmb
    insert into ##tmpRlmb
		--exec RL_VDA_MovimentoDiarioDiv 0,'S',0,'0','0',@df,@d,'0','S','S'                         -- PROCEDURE DO RELATORIO (MENU RELATORIOS -> VENDAS -> MOVIMENTO DI�RIO POR DIVISAO)
		exec RL_FAT_MARGEMBRUTA 5,'S',@div,@lin,@fam,@dii,@dff,'REAL',100,'N',0,0,2

		--select 5,'S',@div,@lin,@fam,@dii,@dff,'REAL',100,'N',0,0,2
		--select * from ##tmpRlmb

		IF OBJECT_ID('TempDB.dbo.##tmpRlmb1') IS NOT NULL DROP TABLE ##tmpRlmb1
		select Rlmb_mtpc, sum(Rlmb_qtdf) Rlmb_qtdf, sum(Rlmb_vcus)Rlmb_vcus,	sum(Rlmb_vliq)Rlmb_vliq,	sum(Rlmb_marg)Rlmb_marg 
		into ##tmpRlmb1
		from ##tmpRlmb
		group by Rlmb_mtpc
	--goto fim
		--select * from ##tmpRlmb1
		IF OBJECT_ID('TempDB.dbo.##new') IS NULL begin
			set @s = 'select Rlmb_mtdv [divisao], Rlmb_mtln[linha], Rlmb_mtfm [familia],	Rlmb_mtfm_nom[nome_fam], Rlmb_mtpc [insumo], Rlmb_qtdf [qde_'+char(39)+convert(varchar(10),month(@di))+'/'+convert(varchar(10),year(@di))+char(39)+']'+
			'into ##new '+ 
			'from ##tmpRlmb1'
			exec(@s)
		end else begin
			IF OBJECT_ID('TempDB.dbo.##aux') IS NOT NULL DROP TABLE ##aux
			select @ds = convert(varchar(10),@di,102)
			set @field = @field +', '+'sum([qde_'+substring(@ds,1,4)+'_'+substring(@ds,6,2)+'])'+' [qde_'+substring(@ds,1,4)+'_'+substring(@ds,6,2)+']'
			--select * from ##new
			--select * from ##tmpRlmb
			--set @field = @field + 
			set @s = 'select b.*'+
			', isnull(Rlmb_qtdf,0) [qde_'+substring(@ds,1,4)+'_'+substring(@ds,6,2)+'] '+
			--', isnull(Rlmb_vcus,0) [vcus_'+substring(@ds,1,4)+'_'+substring(@ds,6,2)+'] '+
			--', isnull(Rlmb_vliq,0) [vliq_'+substring(@ds,1,4)+'_'+substring(@ds,6,2)+'] '+
			--', isnull(Rlmb_marg,0) [marg_'+substring(@ds,1,4)+'_'+substring(@ds,6,2)+'] '+
			'into ##aux '+
			'from ##new b left join ##tmpRlmb1 a on mtpc = Rlmb_mtpc '
--			'from ##tmpRlmb a, ##new b '+ 
--			'where insumo = Rlmb_mtpc'
			--print @s
			exec(@s)
			--select * from ##new b left join ##tmpRlmb1 a on insumo = Rlmb_mtpc
			IF OBJECT_ID('TempDB.dbo.##new') IS NOT NULL DROP TABLE ##new
			set @s = 'select * '+
			'into ##new '+
			'from ##aux'
			exec(@s)
		end
fim:
end

select @field

IF OBJECT_ID('TempDB.dbo.#molas') IS NOT NULL DROP TABLE #molas
select *
into #molas
from ##new
where mtpc like '9-%'
order by insumo

/*
select substring(mtpc,3,2) , sum([qde_2017_11]) [qde_2017_11], sum([qde_2017_12]) [qde_2017_12]
from #molas
group by substring(mtpc,3,2)
*/
select *--sum([qde_2017_01]) [qde_2017_01], sum([qde_2017_02]) [qde_2017_02], sum([qde_2017_03]) [qde_2017_03], sum([qde_2017_04]) [qde_2017_04], sum([qde_2017_05]) [qde_2017_05], sum([qde_2017_06]) [qde_2017_06], sum([qde_2017_07]) [qde_2017_07], sum([qde_2017_08]) [qde_2017_08], sum([qde_2017_09]) [qde_2017_09], sum([qde_2017_10]) [qde_2017_10], sum([qde_2017_11]) [qde_2017_11], sum([qde_2017_12]) [qde_2017_12], sum([qde_2018_01]) [qde_2018_01]
from ##new
--, , sum([qde_2007_01]) [qde_2007_01], sum([qde_2007_02]) [qde_2007_02], sum([qde_2007_03]) [qde_2007_03], sum([qde_2007_04]) [qde_2007_04], sum([qde_2007_05]) [qde_2007_05], sum([qde_2007_06]) [qde_2007_06], sum([qde_2007_07]) [qde_2007_07], sum([qde_2007_08]) [qde_2007_08], sum([qde_2007_09]) [qde_2007_09], sum([qde_2007_10]) [qde_2007_10], sum([qde_2007_11]) [qde_2007_11], sum([qde_2007_12]) [qde_2007_12], sum([qde_2008_01]) [qde_2008_01], sum([qde_2008_02]) [qde_2008_02], sum([qde_2008_03]) [qde_2008_03], sum([qde_2008_04]) [qde_2008_04], sum([qde_2008_05]) [qde_2008_05], sum([qde_2008_06]) [qde_2008_06], sum([qde_2008_07]) [qde_2008_07], sum([qde_2008_08]) [qde_2008_08], sum([qde_2008_09]) [qde_2008_09], sum([qde_2008_10]) [qde_2008_10], sum([qde_2008_11]) [qde_2008_11], sum([qde_2008_12]) [qde_2008_12], sum([qde_2009_01]) [qde_2009_01], sum([qde_2009_02]) [qde_2009_02], sum([qde_2009_03]) [qde_2009_03], sum([qde_2009_04]) [qde_2009_04], sum([qde_2009_05]) [qde_2009_05], sum([qde_2009_06]) [qde_2009_06], sum([qde_2009_07]) [qde_2009_07], sum([qde_2009_08]) [qde_2009_08], sum([qde_2009_09]) [qde_2009_09], sum([qde_2009_10]) [qde_2009_10], sum([qde_2009_11]) [qde_2009_11], sum([qde_2009_12]) [qde_2009_12], sum([qde_2010_01]) [qde_2010_01], sum([qde_2010_02]) [qde_2010_02], sum([qde_2010_03]) [qde_2010_03], sum([qde_2010_04]) [qde_2010_04], sum([qde_2010_05]) [qde_2010_05], sum([qde_2010_06]) [qde_2010_06], sum([qde_2010_07]) [qde_2010_07], sum([qde_2010_08]) [qde_2010_08], sum([qde_2010_09]) [qde_2010_09], sum([qde_2010_10]) [qde_2010_10], sum([qde_2010_11]) [qde_2010_11], sum([qde_2010_12]) [qde_2010_12], sum([qde_2011_01]) [qde_2011_01], sum([qde_2011_02]) [qde_2011_02], sum([qde_2011_03]) [qde_2011_03], sum([qde_2011_04]) [qde_2011_04], sum([qde_2011_05]) [qde_2011_05], sum([qde_2011_06]) [qde_2011_06], sum([qde_2011_07]) [qde_2011_07], sum([qde_2011_08]) [qde_2011_08], sum([qde_2011_09]) [qde_2011_09], sum([qde_2011_10]) [qde_2011_10], sum([qde_2011_11]) [qde_2011_11], sum([qde_2011_12]) [qde_2011_12], sum([qde_2012_01]) [qde_2012_01], sum([qde_2012_02]) [qde_2012_02], sum([qde_2012_03]) [qde_2012_03], sum([qde_2012_04]) [qde_2012_04], sum([qde_2012_05]) [qde_2012_05], sum([qde_2012_06]) [qde_2012_06], sum([qde_2012_07]) [qde_2012_07], sum([qde_2012_08]) [qde_2012_08], sum([qde_2012_09]) [qde_2012_09], sum([qde_2012_10]) [qde_2012_10], sum([qde_2012_11]) [qde_2012_11], sum([qde_2012_12]) [qde_2012_12], sum([qde_2013_01]) [qde_2013_01], sum([qde_2013_02]) [qde_2013_02], sum([qde_2013_03]) [qde_2013_03], sum([qde_2013_04]) [qde_2013_04], sum([qde_2013_05]) [qde_2013_05], sum([qde_2013_06]) [qde_2013_06], sum([qde_2013_07]) [qde_2013_07], sum([qde_2013_08]) [qde_2013_08], sum([qde_2013_09]) [qde_2013_09], sum([qde_2013_10]) [qde_2013_10], sum([qde_2013_11]) [qde_2013_11], sum([qde_2013_12]) [qde_2013_12], sum([qde_2014_01]) [qde_2014_01], sum([qde_2014_02]) [qde_2014_02], sum([qde_2014_03]) [qde_2014_03], sum([qde_2014_04]) [qde_2014_04], sum([qde_2014_05]) [qde_2014_05], sum([qde_2014_06]) [qde_2014_06], sum([qde_2014_07]) [qde_2014_07], sum([qde_2014_08]) [qde_2014_08], sum([qde_2014_09]) [qde_2014_09], sum([qde_2014_10]) [qde_2014_10], sum([qde_2014_11]) [qde_2014_11], sum([qde_2014_12]) [qde_2014_12], sum([qde_2015_01]) [qde_2015_01], sum([qde_2015_02]) [qde_2015_02], sum([qde_2015_03]) [qde_2015_03], sum([qde_2015_04]) [qde_2015_04], sum([qde_2015_05]) [qde_2015_05], sum([qde_2015_06]) [qde_2015_06], sum([qde_2015_07]) [qde_2015_07], sum([qde_2015_08]) [qde_2015_08], sum([qde_2015_09]) [qde_2015_09], sum([qde_2015_10]) [qde_2015_10], sum([qde_2015_11]) [qde_2015_11], sum([qde_2015_12]) [qde_2015_12], sum([qde_2016_01]) [qde_2016_01], sum([qde_2016_02]) [qde_2016_02], sum([qde_2016_03]) [qde_2016_03], sum([qde_2016_04]) [qde_2016_04], sum([qde_2016_05]) [qde_2016_05], sum([qde_2016_06]) [qde_2016_06], sum([qde_2016_07]) [qde_2016_07], sum([qde_2016_08]) [qde_2016_08], sum([qde_2016_09]) [qde_2016_09], sum([qde_2016_10]) [qde_2016_10], sum([qde_2016_11]) [qde_2016_11], sum([qde_2016_12]) [qde_2016_12], sum([qde_2017_01]) [qde_2017_01], sum([qde_2017_02]) [qde_2017_02], sum([qde_2017_03]) [qde_2017_03], sum([qde_2017_04]) [qde_2017_04], sum([qde_2017_05]) [qde_2017_05], sum([qde_2017_06]) [qde_2017_06], sum([qde_2017_07]) [qde_2017_07], sum([qde_2017_08]) [qde_2017_08], sum([qde_2017_09]) [qde_2017_09], sum([qde_2017_10]) [qde_2017_10], sum([qde_2017_11]) [qde_2017_11]

