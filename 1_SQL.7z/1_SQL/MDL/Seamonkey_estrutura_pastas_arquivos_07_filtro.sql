--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Autor				: Rodrigo Dias
--Data				: 25/07/2014
--Solicitante	: Sr(a). Fernando
--Objetivo 01	: Script para Criar Estrutura de Pastas no Software de email Seamonkey
--Campos			: 
--Restries		: 
--Observaes		: Criar estrutura de Pastas e Filtros
--						: Nao criamos os arquivos .MSF para as pastas ENVIADOS e RECEBIDOS pois eles s�o ponteiros que o proprio Seamonkey cria
--						: Somaente criamos arquivos .MSF para subpastas que ficam dentro das Pastas ENVIADOS e RECEBIDOS
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------
-- ALTERAR LINGUAGEM DO BANCO DE DADOS
--------------------------------------
USE tempdb

SET LANGUAGE 'Brazilian'



----------------------------------------
-- Script para criar pastar no Seamonkey
----------------------------------------

--------------------------
-- Declaracao de Variaveis
--------------------------

declare 

-- Criar Pasta e Arquivos
	  @str_Caminho_Local			varchar(1000)		-- Variavel contendo o caminho da pasta
	, @str_Caminho_Principal		varchar(1000)		-- Variavel contendo o caminho da pasta
	, @str_NomeArquivo				varchar(100)		-- Variavel contendo o nome do arquivo e pasta _2014	, @str_Comando					varchar(8000)		-- Variaveis dos comandos executados na criacao dos arquivos e pastas-- Variaveis com os dados para autenticacao na rede windows para o comando NET USE
	, @str_user					varchar(100)		-- Variavel contendo  o Usuario utilizado para autentica��o no dom�nio
	, @str_pass					varchar(100)		-- Variavel contendo  a Senha de acesso do usu�rio
	, @str_dom					varchar(100)		-- Variavel contendo Dom�nio Windows onde o usu�rio pertence
	, @str_netusedel		varchar(100)		-- Variavel com todo o comando deexclusao do mapeamento
	, @str_netuse				varchar(100)		-- Variavel com todo o comando de mapeamento a ser executado
--	, @str_dir					varchar(100)	-- Variavel contendo Comando com a listagem de Diret�rios da unidade mapeda para teste
	, @str_uni					varchar(100)		-- Variavel com o nome da unidade a ser mapeada (Ex.: Z:)
	, @str_cam					varchar(100)		-- Variavel contendo o caminho da unidade a ser mapeado  , @email varchar(100)
-- Variaveis da Criacao da tabela temporaria #DATA com os meses do ANO	
	, @str_mes					int							-- Variavel contendo o numero de meses que possuimos no ano (
	, @str_comand				varchar(100)
	, @str_data					varchar(10)
	, @str_tam					varchar(100)/*-- Variaveis da Criacao dos Filtros--	, @str_Filtro_1				varchar(1000)
	, @str_Filtro				varchar(1000)
	, @str_Filtro_Name			varchar(1000)
	, @str_Filtro_Action		varchar(1000)
	, @str_Filtro_Caminho		varchar(1000)
	, @str_Filtro_Pasta			varchar(1000)
	, @str_Filtro_Data_ini		varchar(1000)
	, @str_Filtro_Data_fim		varchar(1000)
	, @str_Filtro_TAG			varchar(1000)
	, @str_Filtro_TAG_COND		varchar(1000)
	, @str_Filtro_TAG_TAG		varchar(1000)*/		--------------------------------------------------------------------------------------- Net Use - Dados para Autenticacao Dominio-- Utilizado para efetuar mapeamento da unidade de rede onde estao as pastas do email--------------------------------------------------------------------------------------- remover mapeamentoExec xp_cmdshell 'net use s: /delete'
set @str_user = 'administrator'						-- Usuario Administrador do Dominio
set @str_pass = 'mdl168@@'								-- Senha para autentica��o do usu�rioset @str_dom  = 'mdl'											-- Dominio Windowsset @str_uni  = 's:'											-- Nome da Unidade a ser mapeadoset @str_cam  = '\\192.168.2.3\email'		-- Caminho da unidade a ser mapeadoset @email = 'vendamq@mdl-danly.com.br'--set @str_cam  = '\\192.168.3.3\email'			-- Caminho da unidade a ser mapeado--set @str_netusedel = 'net use' + ' ' + @str_uni + ' ' + '/DELETE' + ' '+ @str_pass + ' ' + '/USER:' + @str_dom + '\' + @str_userset @str_netuse = 'net use' + ' ' + @str_uni + ' ' + @str_cam + ' '+ @str_pass + ' ' + '/USER:' + @str_dom + '\' + @str_userPRINT 'COMANDO NET USE PARA MAPEAMENTO'print @str_netuse--EXEC xp_cmdshell @str_netusedelExec xp_cmdshell @str_netuse-- COMANDO DIR-- Exec xp_cmdshell 'DIR s:'-- Exec xp_cmdshell 'net use'------------------------------------- CRIAR PASTAS PAIS-- Nomes das pastas a serem criadas -----------------------------------
-- Excluindo Tabela Temporaria
drop table #PASTA_PAI

-- Criando Tabela Temporaria
create table #PASTA_PAI (	ITEM INT IDENTITY(1,1)	--CONTADOR 
						  ,	PASTA_PAI VARCHAR(20)							--NOME PASTA PRINCIPAL
						  , TAG		  INT												--SE TEM TA
						  , TEG_NOM	  VARCHAR(20)							--NOME DO TAG '$label1' = IMPORTANTE
						  , PARA	  INT												--
						  , DE		  INT
						  , ANTERIOR  INT
						  , PASTA_mes INT											--SE 1 O MES � UMA PASTA
						  , PASTA_AUX VARCHAR(20)
						  , NOME VARCHAR(30)
						)
-- INSERINDO DADOS NA TABELAINSERT INTO #PASTA_PAIVALUES		( 'MDL_ENVIADOS'		, 2, NULL				, 0, 1, 1, 0, NULL, NULL)						, ( 'MDL_RECEBIDOS'		, 1, '$label1'	, 1, 0, 1, 0, NULL, NULL)		-- TEG_NOM = '$label1' = IMPORTANTE				, ( 'MDL_VENDEDORES'	, 0, NULL				, 0, 0, 0, 1, NULL, NULL)				, ( 'ANAC'						, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)				, ( 'MILENAS'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)				, ( 'DEBORAC'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)				, ( 'GISLAINEM'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)				, ( 'GRACIELEC'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)				, ( 'LUCIANEM'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)				, ( 'KATIAJ'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)--			, ( N'VENDAMQ'			, 0, NULL				, 0, 0, 0)--			, ( N'VENDASLIDER'	, 0, NULL	   , 0, 0, 0)			--			, ( N'VENDASLIDER'	, 0, NULL	   , 0, 0, 0)			--			, ( N'VENDAS.SAC'	, 0, NULL	   , 0, 0, 0)			--			, ( N'EMAIL'		, 0, NULL	   , 0, 0, 0)				--		    , ( N'msgFilterRules' )-- VISUALIZAR TABELA TEMPORARIA #PASTA_PAI-- SELECT * FROM #PASTA_PAI--SELECT * UPDATE #PASTA_PAI SET NOME = GLFU_NRDZFROM #PASTA_PAI, [mdl].[dbo].[glfu]WHERE TAG = 3			AND PASTA_PAI = GLFU_SIUS---------------------------------------------------------------------------------
-- Criar tabela temporaria #MESES com os Meses do ANO para utilizar nas subpastas
---------------------------------------------------------------------------------

-- Excluindo Tabela Temporaria
drop table #meses

-- Criando Tabela Temporaria
create table #meses (num_1 int identity(1,1), mes varchar(20), mes_1 varchar(20), ano_1 int, usado int)

-------------------------------------
-- Dados da Tabela Temporaria (#data)
-------------------------------------

-- Setando Valores das Variaveis
set @str_mes = 1
-- set @str_comand = (select datename(month, @str_mes)) 
-- While com a condi��o de parada quando a variavel chegar a 12 pois temos 12 meses no ano
While @str_mes <= 24 Begin
		-- Print para verificacao
--		print @str_mes
--		print @str_comand
		
	-- Incremento na variavel
		
		-- Data criada para efetuar a conversao reultando no datename
		if @str_mes <= 12 begin
			set @str_data = convert(varchar(4), datepart(year, getdate())) + '.' + convert(varchar(2), @str_mes) + '.' + '01'	
			print 'data 0 ' + @str_data + '  '+CONVERT(varchar(2),@str_mes)
 			-- Parte utilizada para inserir numero 0 na frente de um numero (01, 02, 03 ...)
	 		set @str_tam = replicate('0', 2 - datalength(convert(varchar(2), @str_mes))) + convert(varchar(2), @str_mes)
		end else begin
			set @str_data = convert(varchar(4), datepart(year, getdate())) + '.' + convert(varchar(2), @str_mes-12) + '.' + '01'
			print 'data 1 ' + @str_data	+ '  '+CONVERT(varchar(2),@str_mes)
	 		-- Parte utilizada para inserir numero 0 na frente de um numero (01, 02, 03 ...)
 			set @str_tam = replicate('0', 2 - datalength(convert(varchar(2), @str_mes-12))) + convert(varchar(2), @str_mes-12)
		end

-- 		print @str_tam

		-- Forma que ser� criada o mes na tabela temporaria
 		set @str_comand =@str_tam + '_' + (select datename(month,@str_data))

		-- Print para verificacao
--		print @str_data
--		print @str_comand

		INSERT INTO #meses
		select UPPER(@str_comand), upper(datename(month,@str_data)), YEAR(GETDATE())+(-1+(@str_mes/13)),0

		set @str_mes = @str_mes + 1		-- neste caso inclemento no final 

	-- Inserindo dados da Variavel na tabela temporaria (#data)
End

UPDATE #meses set usado = 1
from #meses
--where num_1 between  month(getdate())+0 and month(getdate())+12
where num_1 between  month(getdate())+9 and month(getdate())+12
--where num_1 between  month(1)+1 and month(1)+12
--where num_1 between  month(12)+1 and month(12)+12

-- Select para vizualizar a tabela temporaria #DATA
-- SELECT * FROM #meses----------------------------------------------------
-- CRIANDO TABELA TEMPORARIA PARA CRIACAO DAS PASTAS
----------------------------------------------------

-- Excluindo Tabela Temporaria
drop table #COMANDO
--go
-- Criando Tabela Temporaria
create table #COMANDO (
												  NUM INT IDENTITY(1,1)
												, COMANDO varchar(200)
												, CRIAR varchar(1)
												, PASTA_Mes INT
												, CRIAR_1 INT
											)
					  
-- INSERINDO DADOR NA TABELA TEMPORARIA #COMANDO
/* 
DECLARE 
		  @str_Caminho		VARCHAR(100)
		, @str_COMANDO		VARCHAR(100)
*/
		
-- SET @str_Caminho = 'S:\ti\local'							-- Caminho onde se localiza os email

--SET @str_Caminho_Local = @str_uni + '\Vendas\VendaMQ\Locais'							-- Caminho onde se localiza os email
--SET @str_Caminho_Principal = @str_uni + '\Vendas\VendaMQ\Principal\VendasMQ'							-- Caminho onde se localiza os email

SET @str_Caminho_Local = @str_uni + '\ti\local'							-- Caminho onde se localiza os email
SET @str_Caminho_Principal = @str_uni + '\ti\principal'							-- Caminho onde se localiza os email

--M:\Email\Vendas\VendaMQ\Locais // M:\Email\Vendas\VendaMQ\Principal\VendasMQ
PRINT 'CAMINHO DE LOCALIZACAO DA PASTA DE EMAIL'
PRINT @str_Caminho_Local


---------------------------------------------------------------------------- 
-- Inserindo o caminho de criacao dos arquivos na tabela temporaria #COMANDO
----------------------------------------------------------------------------

-- COMANDOS PARA CRIACAO DAS PASTAS PAI
INSERT INTO #COMANDO
SELECT @str_Caminho_Local + '\' + max(PASTA_PAI) + '_' + convert(varchar(4), datepart(year, getdate())-1) + '.sbd'															-- ANO CORRENTE
	   , 'S'
	   , (PASTA_Mes)
	   , max(usado) 
	   --select *
FROM #PASTA_PAI, #meses
WHERE	 PASTA_AUX IS NULL			and (datepart(year, getdate())-1) = ano_1GROUP BY PASTA_PAI, ano_1, pasta_mes
/*
SELECT '@str_Caminho_Local' + '\' + max(PASTA_PAI) + '_' + convert(varchar(4), datepart(year, getdate())-1) + '.sbd'															-- ANO CORRENTE
	   , 'S'
	   , (PASTA_Mes)
	   , max(usado) 
	   --select *
FROM #PASTA_PAI, #meses
WHERE	 PASTA_AUX IS NULL			and (datepart(year, getdate())-1) = ano_1GROUP BY PASTA_PAI, ano_1, pasta_mes
*/

INSERT INTO #COMANDO
SELECT @str_Caminho_Local + '\' + max(PASTA_PAI) + '_' + convert(varchar(4), datepart(year, getdate())) + '.sbd'															-- ANO CORRENTE
	   , 'S'
	   , (PASTA_Mes)
	   , max(usado)
	   --select *
FROM #PASTA_PAI, #meses
WHERE	 PASTA_AUX IS NULL 			and (datepart(year, getdate())) = ano_1GROUP BY PASTA_PAI, ano_1, PASTA_MES--select * from #PASTA_PAI--PASTA_PAI = N'MDL_ENVIADOS'--	  OR PASTA_PAI = N'MDL_RECEBIDOS'
-- 2 REGISTROS


-- COMANDOS PARA CRIACAO DOS ARQUIVOS RESPONSAVEIS PELAS SUBPASTAS
INSERT INTO #COMANDO
SELECT COMANDO + '\' + MES+REPLACE(REPLACE(PASTA_Mes,0,''),1,'.sbd')
	   , REPLACE(REPLACE(PASTA_Mes,0,'N'),1,'S')
	   , 0
	   , usado
		--SELECT *
FROM #COMANDO, #MESES
WHERE COMANDO LIKE '%'+convert(varchar(6),ANO_1)+'%'



INSERT INTO #COMANDO
SELECT COMANDO + '\' + PASTA_PAI
	   , 'N'
	   , 0
	   , CASE CRIAR_1
				WHEN 0 THEN 2
				ELSE CRIAR_1
			END
	   --SELECT *
FROM #COMANDO, #PASTA_PAI
WHERE COMANDO LIKE '%'+PASTA_AUX+'%'
			AND COMANDO LIKE '%.sbd\%'

---- SELECT * FROM #meses SELECT * FROM #COMANDO where comando like '%vende%'
-- 24 REGISTROS

-- COMANDOS PARA CRIACAO DO ARQUIVO DE FILTRO -- comantado pois esta sendo criado abaixo
--INSERT INTO #COMANDO
--SELECT top 1 @str_Caminho_Principal + N'\' + N'msgFilterRules' + N'.dat'
--	   , N'N'
--FROM #COMANDO

-- 24 REGISTROS

-- VERIFICAR TABELA #COMANDO
-- SELECT * FROM #COMANDO
-- 52 REGISTROS TOTAL

-----------------------------
-- WHILE PARA CRIAR O COMANDO
-----------------------------

 -- variaveis
declare  
				  @str_cont	int																																					-- Variavel contendo o numero de meses que possuimos no ano
				, @STR_EXEC VARCHAR(400)																																		-- Variavel criada que contem o comando a ser executado para criacao de pastas e arquivos

set @str_cont = 1																																										-- Setando Valore inicial da da Variavel responsavel pela contagem
-- set @str_comand = (select datename(month, @str_mes)) 
--SELECT * FROM #COMANDO
While @str_cont <= (SELECT MAX(NUM) FROM #COMANDO) 
--While @str_cont <= 28
	Begin													
	--PRINT @str_cont
	-- SELECT * FROM #COMANDO
	IF ( SELECT CRIAR_1 FROM #COMANDO WHERE NUM = @str_cont ) = 1 BEGIN
		PRINT 'CONTADOR � '+CONVERT(VARCHAR(3),@str_cont)+' ENTROU'
		IF ( SELECT CRIAR FROM #COMANDO WHERE NUM = @str_cont ) = N'S' 																		-- Condicao para entrar no laco e executar a criacao das pastar dentro do IF
			BEGIN
			--PRINT	'ENTROU NO IF'																																						-- PRINT com mensagem informando que entramos no IF
			SELECT  @STR_EXEC = 'MD' + ' ' +  COMANDO  FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC
			--PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
			Exec xp_cmdshell @STR_EXEC																																			-- executa a variavel @STR_EXEC com o comando de criacao de pastas
			
			SELECT  @STR_EXEC = 'COPY NUL' + ' ' +  COMANDO FROM #COMANDO WHERE NUM = @str_cont							-- Inseri o comando para criacao de arquivos auxiliares das Pastas na variavel @STR_EXEC
			--SET @STR_EXEC = REPLACE(@STR_EXEC,'.SBD','')
			IF CHARINDEX('.sbd',SUBSTRING(@str_exec,LEN(@str_exec)-5,10)) > 0 BEGIN
				SELECT @str_exec = SUBSTRING(@str_exec,1,LEN(@str_exec)-4)
			END  																										-- Retira a extencao .SBD do arquivo que sera criado
			--PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
			Exec xp_cmdshell @STR_EXEC																																			-- Executa a variavel @STR_EXEC com o comando para criacao de arquivos auxiliares das Pastas

			--SELECT  @STR_EXEC = 'COPY NUL' + ' ' + COMANDO + '.MSF' FROM #COMANDO WHERE NUM = @str_cont							
			--SET @STR_EXEC = REPLACE(@STR_EXEC,'.SBD','')																														
			--PRINT @STR_EXEC
			--Exec xp_cmdshell @STR_EXEC
		
		END ELSE	 																																											-- Caso nao esteja na condicao do IF acima, ele executara o ELSE (SENAO)
			BEGIN																																														
			SELECT  @STR_EXEC = 'COPY NUL' + ' ' +  COMANDO FROM #COMANDO WHERE NUM = @str_cont							-- Inserindo o comando para criacao dos arquivos das subpastas com os MESES
			--PRINT @STR_EXEC																																									
			Exec xp_cmdshell @STR_EXEC
		
			--SELECT  @STR_EXEC = 'COPY NUL' + ' ' + COMANDO + '.MSF' FROM #COMANDO WHERE NUM = @str_cont
			--PRINT @STR_EXEC
			--Exec xp_cmdshell @STR_EXEC
		
		END
	END ELSE BEGIN
		--IF ( SELECT CRIAR FROM #COMANDO WHERE NUM = @str_cont ) = 'S' BEGIN
		
			IF (SELECT SUBSTRING(COMANDO, LEN(COMANDO)-3, 4) FROM #COMANDO WHERE NUM = @str_cont) = '.sbd' BEGIN
				SELECT  @STR_EXEC = 'RD' + ' ' +  COMANDO + ' /S /Q' FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC
				PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
				Exec xp_cmdshell @STR_EXEC
				SELECT  @STR_EXEC = 'DEL' + ' ' +  SUBSTRING(COMANDO, 1, LEN(COMANDO)-4) + ' /S /Q' FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC
				PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
				Exec xp_cmdshell @STR_EXEC
			END ELSE BEGIN
				SELECT  @STR_EXEC = 'DEL' + ' ' +  COMANDO + ' /S /Q'  FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC			
				PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
				Exec xp_cmdshell @STR_EXEC
			END
		--END																																			-- executa a variavel @STR_EXEC com o comando de criacao de pastas
	END
	set @str_cont = @str_cont + 1																																			--	Incremento para contunuar executando o comando
END


/* -- TABELAS TEMPORARIAS CRIADOAS
SELECT * FROM #MESES
SELECT * FROM #PASTA_PAI
SELECT * FROM #COMANDO
*/



------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- CRIANDO FILTROS
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------
-- CRIANDO TABELA TEMPORARIA COM AS DATAS PARA O FILTRO
-------------------------------------------------------
-- Excluindo Tabela Temporaria

SET LANGUAGE 'English'

drop table #MES_SEAMONKEY

-- Criando Tabela Temporaria
create table #MES_SEAMONKEY (  ITEM INT IDENTITY(1,1)
							 , MES		varchar(5)
							 , MES_ANT	varchar(5)	
							 , MES_POS	varchar(5)
							 , DIA_ANT	varchar(5)
							 , DIA_POS  varchar(5)
							 , ANO_ANT	varchar(5)
							 , ANO_POS	varchar(5)
							 , mes_char char(2)
							 , ano_char char(4)
							 , mes_ext varchar(20)
							)

-- TESTE TABELA TEMPORARIA #MES_SEAMONKEY								
-- SELECT * FROM #MES_SEAMONKEY	



DECLARE
				  @STR_F_CONT INT
				, @STR_F_MES VARCHAR(3)
				, @STR_F_DATA1 DATETIME
				, @STR_F_MES_ANT VARCHAR(3)
				, @STR_F_MES_POS VARCHAR(3)
				, @STR_F_DIA_ANT VARCHAR(3)
				, @STR_F_DIA_POS VARCHAR(3)
				, @STR_F_ANO_ANT VARCHAR(4)
				, @STR_F_ANO_POS VARCHAR(4)
SET @str_F_cont = 1

WHILE
				@str_f_cont <= 12
		BEGIN				
			-- PRINT VARIAVEIS
			--PRINT 'LACO PARA CRIACAO DA TABELA TEMP #MES_SEAMONKEY'
			--PRINT @STR_F_CONT
			
			-- SETANDO VARIAVEIS

			SET @STR_F_DATA1   = CONVERT(DATETIME, (CONVERT(VARCHAR(4),(DATEPART(YEAR, GETDATE()))) + N'.' 
							     + REPLICATE(N'0',2 - LEN(CONVERT(VARCHAR(2),@str_F_cont))) + CONVERT(VARCHAR(2),@str_F_cont) 
							     + N'.01'), 102)
			SET @STR_F_MES	   = DATENAME(MONTH,@STR_F_DATA1)										
			SET @STR_F_MES_ANT = DATENAME(MONTH, DATEADD(MONTH, -1, @STR_F_DATA1))
			SET @STR_F_MES_POS = DATENAME(MONTH, DATEADD(MONTH, 1, @STR_F_DATA1))
			SET @STR_F_DIA_ANT = DATEPART(day, DATEADD(DAY, -1, @STR_F_DATA1))
			SET @STR_F_DIA_POS = DATEPART(DAY,@STR_F_DATA1)
			SET @STR_F_ANO_ANT = DATEPART(YEAR, DATEADD(MONTH, -1,@STR_F_DATA1))
			SET @STR_F_ANO_POS = DATEPART(YEAR, DATEADD(MONTH, 1,@STR_F_DATA1))
			
			-- VISUALIZAR VARIAVEL
			PRINT @STR_F_DATA1
			PRINT @STR_F_MES 
			PRINT @STR_F_MES_ANT
			PRINT @STR_F_MES_POS
			PRINT @STR_F_DIA_ANT
			PRINT @STR_F_DIA_POS
			PRINT @STR_F_ANO_ANT
			PRINT @STR_F_ANO_POS + CHAR(13)
			
			print @str_F_cont
			-- INSERINDO DADOS NA TABELA TEMPORARIA #MES_SEAMONKEY
			INSERT INTO #MES_SEAMONKEY
			SELECT	  @STR_F_MES		[MES]
					, @STR_F_MES_ANT    [MES_ANT] 
 					, @STR_F_MES_POS	[MES_POS]
					, @STR_F_DIA_ANT	[DIA_ANT]
					, @STR_F_DIA_POS	[DIA_POS]
					, @STR_F_ANO_ANT	[ANO_ANT]
					, @STR_F_ANO_POS	[ANO_POS]
					, REPLICATE(N'0',2 - LEN(CONVERT(VARCHAR(2),@str_F_cont)))+ CONVERT(VARCHAR(2),@str_F_cont)	
					, convert(char(4),DATEPART(YEAR, getdate()))
					, upper(datename(month,@STR_F_DATA1))
						
			SET @str_F_cont = @str_F_cont + 1
		END


-- TESTE TABELA TEMPORARIA #MES_SEAMONKEY	 
-- SELECT * FROM #MES_SEAMONKEY

-----------------------------------------------------------
-- EXECUTAMOS O SCRIPT AT� AQUI ANTES DE ENTRAR NOS FILTROS
-----------------------------------------------------------

select * from #MES_SEAMONKEY


--------------------------------------------
-- CRIA��O TABELA TEMPORARIA PARA OS FILTROS
--------------------------------------------

-- Excluindo Tabela Temporaria
drop table ##FILTRO

-- Criando Tabela Temporaria
create table ##FILTRO (   ITEM INT IDENTITY(1,1)
						, FILTRO varchar(1000))

insert into ##FILTRO
select N'version="9"'

insert into ##FILTRO
select N'logging="no"'
--/*
DECLARE
-- Variaveis da Criacao dos Filtros	  @str_Filtro_CONT1			INT
	, @str_Filtro_CONT2			INT
	, @str_Filtro				varchar(1000)
	, @str_Filtro_Name			varchar(1000)
	, @str_Filtro_Action		varchar(1000)
	, @str_Filtro_Caminho		varchar(1000)
	, @str_Filtro_Pasta			varchar(1000)
	, @str_Filtro_Data_ini		varchar(1000)
	, @str_Filtro_Data_fim		varchar(1000)
	, @str_Filtro_TAG			varchar(1000)
	, @str_Filtro_TAG_COND		varchar(1000)
	, @str_Filtro_TAG_TAG		varchar(1000)
	, @str_Filtro_MES			INT
	, @str_V					INT
	, @mes int
-- SETANDO VARIAVEIS

SET @str_Filtro_CONT1 = 1
SET @str_Filtro_CONT2 = 0

SELECT * FROM #PASTA_PAI select * from #MES_SEAMONKEY
select @mes = month(getdate())

WHILE	(@str_Filtro_CONT1 <= (SELECT MAX(ITEM) FROM #PASTA_PAI)) OR (@str_Filtro_CONT2 = 1)BEGIN

		Print N'na tela'
		print @str_Filtro_CONT1
		print @str_Filtro_CONT2
		Print N'na tela'
		
	-- SETANDO VARIAVEIS
	
	-- FILTRO MDL_MOVER_RECEBER
/*
	select 
		 @str_Filtro_Name		= PASTA_PAI+'_'+mes_char
		,@str_Filtro_Action		= N'Move to folder'
		,@str_Filtro_Caminho		= N'"mailbox://nobody@Local%20Folders'
		,@str_Filtro_Pasta		= PASTA_PAI+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_EXT
		,@str_Filtro_Data_ini	= dia_ant+'-'+mes_ant+'-'+ano_ant
		,@str_Filtro_Data_fim	= dia_pos+'-'+mes_pos+'-'+ano_pos 
		
		,@str_Filtro_TAG			= 'TAG'
		,@str_Filtro_TAG_COND	= 'CONTAINS'	
		,@str_Filtro_TAG_TAG		= N'$label1'
		
	from #MES_SEAMONKEY a, #PASTA_PAI b
	where a.item = @mes-@str_Filtro_CONT2
				AND b.item = @str_Filtro_CONT1 
*/
	set @str_Filtro =   null
	if (select COUNT(1) from #MES_SEAMONKEY a, #PASTA_PAI b where a.item = @mes-@str_Filtro_CONT2 AND b.item = @str_Filtro_CONT1 and TAG > 0) > 0 BEGIN
		SELECT @str_Filtro =   ''
							+'name=' + '"' + PASTA_PAI+'_'+mes_char + '"' + CHAR(10)  
							+ ' ' + 'enabled="yes"'	+ CHAR(10)
							+ ' ' + 'type="17"'		+ CHAR(10)
		from #MES_SEAMONKEY a, #PASTA_PAI b
		where a.item = @mes-@str_Filtro_CONT2
					AND b.item = @str_Filtro_CONT1 
					and TAG > 0

		SELECT @str_Filtro =  @str_Filtro 
						+	case TAG 
							when 1 then	--RECEBIDOS					
	 							+ ' ' + 'action="'		+ 'Move to folder' + '"' + CHAR(13)
								+ ' ' + 'actionValue=' + '"mailbox://nobody@Local%20Folders' + '/' + PASTA_PAI+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_1 +'"' + CHAR(13)
								+ ' ' + 'condition="AND (date,is after,' + dia_ant+'-'+mes_ant+'-'+ano_ant + ')'+ ' ' 											
								+ 'AND (date,is before,' + dia_pos+'-'+mes_pos+'-'+ano_pos + ')' + '' 
								+ 'AND (' + 'tag' + ',' + 'contains' + ',' + TEG_NOM + ')"'
							when 2 then --ENVIADOS
	 							+ ' ' + 'action="'		+ 'Move to folder' + '"' + CHAR(13)
								+ ' ' + 'actionValue=' + '"mailbox://nobody@Local%20Folders' + '/' + PASTA_PAI+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_1 +'"' + CHAR(13)
								+ ' ' + 'condition="AND (date,is after,' + dia_ant+'-'+mes_ant+'-'+ano_ant + ')'+ ' ' 											
								+ 'AND (date,is before,' + dia_pos+'-'+mes_pos+'-'+ano_pos + ')'  
								+ 'AND (from,is,' + @email + ')' + '"'
								--AND (subject,begins with,Proposta Comercial) 
								--AND (from,contains,ti@mdl-danly.com.br)"
							when 3 then --VENDEDORES
	 							+ ' ' + 'action="'		+ 'Move to folder' + '"' + CHAR(13)
								+ ' ' + 'actionValue=' + '"mailbox://nobody@Local%20Folders' + '/' + PASTA_AUX+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_1+'/'+PASTA_PAI +'"' + CHAR(13)
								+ ' ' + 'action="Mark read"'
								+ ' ' + 'condition="AND (date,is after,' + dia_ant+'-'+mes_ant+'-'+ano_ant + ')'+ ' ' 											
								+ 'AND (date,is before,' + dia_pos+'-'+mes_pos+'-'+ano_pos + ')' 
								+ 'AND (from,is,' + @email + ')'  
--								+ 'AND (subject,contains,' + NOME + ')' + '"' 
								+ 'AND (subject,begins with,Proposta Comercial' + ')'
								+ 'AND (from,contains,' + NOME + ')' + '"' 
								--+ 'AND (subject,contains,' + PASTA_PAI + ')' + '"' 
								--AND (subject,contains,ANAC)
							end
		from #MES_SEAMONKEY a, #PASTA_PAI b, #meses--, GLFU c
		where a.item = @mes-@str_Filtro_CONT2
					AND b.item = @str_Filtro_CONT1 
					AND num_1 = @mes-@str_Filtro_CONT2
					--AND (tag = 3 and PASTA_PAI = GLFU_sius) or (TAG<>3)
					and TAG > 0

		--select * from glfu where GLFU_sius = 'ANAC'
		print N'CONTEUDO DO FILTRO'
		print @str_Filtro

		INSERT INTO ##FILTRO
		select @str_Filtro
					
	END
/*
	select *,PASTA_PAI+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_EXT
	from #MES_SEAMONKEY a, #PASTA_PAI b, #meses
	where a.item = 12
				AND b.item = 3
				and a.item = num_1
				and TAG > 0

select *
from #meses

select *
from #pasta_pai

select *
from #mes_seamonkey

*/

/*
	SET @str_Filtro =   N'name=' + N'"' + @str_Filtro_Name + N'"' + CHAR(13)  
						+ N' ' + N'enabled="yes"'	+ CHAR(13)
						+ N' ' + N'type="17"'		+ CHAR(13)
 						+ N' ' + N'action="'		+ @str_Filtro_Action + N'"' + CHAR(13)
						+ N' ' + N'actionValue=' + @str_Filtro_Caminho + N'/' + @str_Filtro_Pasta +N'"' + CHAR(13)
						+ N' ' + N'condition="AND (date,is after,' + @str_Filtro_Data_ini + N')'+ ' ' 
						+ N'AND (date,is before,' + @str_Filtro_Data_fim + N')' + ' ' 
						+ N'AND (' + @str_Filtro_TAG + N',' + @str_Filtro_TAG_COND + N',' + @str_Filtro_TAG_TAG + N')"'
*/


	
	-- VISUALIZAR VARIAVEL
/*			PRINT @str_Filtro_CONT1			
			PRINT @str_Filtro_CONT2			
			PRINT @str_Filtro				
			PRINT @str_Filtro_Name			
			PRINT @str_Filtro_Action		
			PRINT @str_Filtro_Caminho		
			PRINT @str_Filtro_Pasta			
			PRINT @str_Filtro_Data_ini		
			PRINT @str_Filtro_Data_fim		
			PRINT @str_Filtro_TAG			
			PRINT @str_Filtro_TAG_COND		
			PRINT @str_Filtro_TAG_TAG + CHAR(13)
*/

	-- Incremento na variavel
		select @str_V = anterior from #pasta_pai where item = @str_Filtro_CONT1
		
		if ((@str_Filtro_CONT2 = 0) AND (@str_V = 0)) OR ((@str_Filtro_CONT2 = 1) AND (@str_V = 1)) BEGIN 
		
			SET @str_Filtro_CONT2 = 0
				
			set @str_Filtro_CONT1 = @str_Filtro_CONT1 + 1		-- neste caso inclemento no final 
			
		END ELSE BEGIN
		
			set @str_Filtro_CONT2 = @str_V
		
		END
		
		

		

	-- Inserindo dados da Variavel na tabela temporaria (#data)
--		INSERT INTO #data
--		select datename(month, @str_mes)

End

		
		
		
--*/






-- regras dos filtros
-- select * from #pasta_pai
--
-- TESTE TABELA TEMPORARIA #MES_SEAMONKEY	 
-- SELECT * FROM #MES_SEAMONKEY

-- TESTE TABELA TEMPORARIA ##FILTRO
-- SELECT * FROM ##FILTRO


-----------------------------------------------------------------------------------------
-- INSERINDO TABELA TEMPORARIA (##FILTRO) NO ARQUIVO (S:\TI\Principal\msgFilterRules.dat)
-----------------------------------------------------------------------------------------
declare @sql varchar(4000)	
		  set @sql = 'master..xp_cmdshell '+char(39)+'bcp "select filtro from ##FILTRO " queryout "S:\TI\Principal\msgFilterRules.dat " -c -U sa -P mdl1680'+CHAR(39)
		  exec(@sql) 





