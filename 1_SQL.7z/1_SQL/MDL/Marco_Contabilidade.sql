drop table #temp
select PRCC_SIES sies, PRCC_PRCT prct, PRCC_ANO ano, PRCC_MES mes, PRCC_VALP valp
into #temp
from [bkp].[dbo].prcc
where prcc_sies = 5
and prcc_ano = 2017
and prcc_mes = 4


select *
--update prcc set PRCC_VALP = VALP
from #temp, prcc b
where prcc_sies = 5
and prcc_ano = 2017
and prcc_mes = 4
and PRCC_SIES = sies
and PRCC_PRCT = prct
and PRCC_ANO = ano
and PRCC_MES = mes

drop table #temp1
select PRCC_SIES sies, PRCC_PRCT prct, PRCC_ANO ano, 5 mes, PRCC_VALP valp	
--PRCC_SIES,	PRCC_PRCT,	PRCC_ANO,	5 PRCC_MES,	PRCC_VALP,	PRCC_VALS,	PRCC_VALR,	PRCC_OBS,	PRCC_USC,	PRCC_DTC,	PRCC_USU,	PRCC_DTU
into #temp1
from [bkp].[dbo].prcc
where prcc_sies = 5
and prcc_ano = 2017
and prcc_mes = 4


select *
--update prcc set PRCC_VALP = VALP
from #temp1 a, prcc b
where b.prcc_sies = 5
and b.prcc_ano = 2017
and b.prcc_mes = 5
and b.PRCC_SIES = sies
and b.PRCC_PRCT = prct
and b.PRCC_ANO = ano
and b.PRCC_MES = mes
