select *
--update cpct set CPCT_GLPG = '45'
from cpct
where cpct_sta = 'OK'
and cpct_glxx = 1890