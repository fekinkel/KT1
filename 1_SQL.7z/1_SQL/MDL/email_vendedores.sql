declare
@s varchar(400)

set @s = ''

select @s = @s+GLPA_NRDZ+'<'+GLPA_EMAIL+'>; '
from glvd, glpa
where GLVD_GLPA = GLPA_COD
			and GLVD_ATV = 's'
			and GLPA_EMAIL <> ''
			and GLVD_COD <= 38
			
select @s

select getdate()-720

