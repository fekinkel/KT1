----Abaixo:
--1. 1. Itens de nota fiscal de sa�da
--30729
SELECT
convert(varchar(10),FTNF_sies)+'/'+FTNF_SIDO+'/'+FTNF_SISE+'/'+convert(varchar(10),FTNF_COD) [Nota Fiscal]
,FTIT_MTPR [Cod produto]
,FTIT_NOM [Nome do produto]
,FTIT_MTNC [ncm]
,CONVERT(VARCHAR(10),FTNF_DAT,103) [data emiss�o]
,CONVERT(VARCHAR(10),FTNF_DTSAIDA,103) [data sa�da]
,FTNF_GLTX+'/'+CONVERT(VARCHAR(6),FTNF_GLXX)+'/'+CONVERT(VARCHAR(6),FTNF_GLXX_DIG) [cod cliente]-- (de acordo com cadastro)
,FTNF_GLXX_NOM [nome cliente]
,FTIT_QTD [quantidade]
,FTIT_PUN [valor unit]
,FTIT_VAL [valor total]
,FTIT_VAL_FRE+FTIT_VAL_SEG+FTIT_VAL_ACE [outros valores]-- cobrados (frete, seguro...)
,FTIT_DES [desconto concedido]
,FTIT_ICM_BAS [base de calc ICMS]
,FTIT_ICM_ALI [aliq icms]
,FTIT_ICM_VAL [VR ICMS]
,FTIT_CFOP [CFOP]
--* codigo chave que determina se � uma opera��o de venda , ou remessa ... (se houver)
,FTIT_EST [movimenta estoque]
,NFOP_TIT [movimenta financeiro] 
,FTIT_PIS_VAL [valor Pis]
,FTIT_COF_VAL [valor cofins]
,FTIT_IST_VAL [icms ST]
,ftnf_gluf_ori [UF do cliente]
,ftit_IPI_BAS [base IPI]--Base de c�lculo do IPI nas entradas e sa�das.
,ftit_IPI_ALI [aliq IPI]-- Valor do IPI as entradas e sa�das.
,ftit_IPI_VAL [vr IPI]
,convert(varchar(10),FTNF_sies)+'/'+FTNF_SIDX+'/'+FTNF_SISX+'/'+convert(varchar(10),FTNF_CODX) [NF]
FROM FTNF a, FTIT b, NFOP c
WHERE CONVERT(VARCHAR(10),FTNF_DAT,102) BETWEEN '2014.01.01' AND '2014.06.30'
			AND FTIT_SIES = FTNF_SIES
			AND FTIT_SIDO = FTNF_SIDO
			AND FTIT_SISE = FTNF_SISE
			AND FTIT_FTNF = FTNF_COD
			AND FTIT_NFOP = NFOP_COD
			AND FTNF_ES = 'S'
ORDER BY CONVERT(VARCHAR(10),FTNF_DAT,102)




--1. 1. Itens de nota fiscal de entrada

SELECT
convert(varchar(10),RCNF_sies)+'/'+RCNF_SIDO+'/'+RCNF_SISE+'/'+convert(varchar(10),RCNF_COD) [Recebimento]
,RCIT_MTPR [Cod produto]
,RCIT_NOM [Nome do produto]
,RCIT_MTNC [ncm]
,CONVERT(VARCHAR(10),RCNF_DAT,103) [data emiss�o]
,CONVERT(VARCHAR(10),RCNF_DTSAIDA,103) [data sa�da]
,RCNF_GLTX+'/'+CONVERT(VARCHAR(6),RCNF_GLXX)+'/'+CONVERT(VARCHAR(6),RCNF_GLXX_DIG) [cod cliente]-- (de acordo com cadastro)
,RCNF_GLXX_NOM [nome cliente]
,RCIT_QTD [quantidade]
,RCIT_PUN [valor unit]
,RCIT_VAL [valor total]
,RCIT_VAL_FRE+RCIT_VAL_SEG+RCIT_VAL_ACE [outros valores]-- cobrados (frete, seguro...)
,RCIT_DES [desconto concedido]
,RCIT_ICM_BAS [base de calc ICMS]
,RCIT_ICM_ALI [aliq icms]
,RCIT_ICM_VAL [VR ICMS]
,RCIT_CFOP [CFOP]
--* codigo chave que determina se � uma opera��o de venda , ou remessa ... (se houver)
,RCIT_EST [movimenta estoque]
,NFOP_TIT [movimenta financeiro]
,RCIT_PIS_VAL [valor Pis]
,RCIT_COF_VAL [valor cofins]
,RCIT_IST_VAL [icms ST]
,rcnf_gluf_ori [UF do cliente]
,rcit_IPI_BAS [base IPI]--Base de c�lculo do IPI nas entradas e sa�das.
,rcit_IPI_ALI [aliq IPI]-- Valor do IPI as entradas e sa�das.
,rcit_IPI_VAL [vr IPI]
,convert(varchar(10),RCNF_sies)+'/'+RCNF_SIDX+'/'+RCNF_SISX+'/'+convert(varchar(10),RCNF_CODX) [Nota Fiscal]
FROM RCNF a, RCIT b, NFOP c
WHERE CONVERT(VARCHAR(10),RCNF_DAT,102) BETWEEN '2014.01.01' AND '2014.06.30'
			AND RCIT_SIES = RCNF_SIES
			AND RCIT_SIDO = RCNF_SIDO
			AND RCIT_SISE = RCNF_SISE
			AND RCIT_RCNF = RCNF_COD
			AND RCIT_NFOP = NFOP_COD
			AND RCNF_ES = 'E'
ORDER BY CONVERT(VARCHAR(10),RCNF_DAT,102)

/*
*Cod produto
* Nome do produto
* ncm
*cod fornec (de acordo com cadastro)
*nome fornec
* data emiss�o
* data entrada
* quantidade
* valor unit
* valor total
* outros valores cobrados (frete, seguro...)
* desconto concedido
* base de calc ICMS
* aliq icms
* VR ICMS
* CFOP
* codigo chave que determina se � uma opera��o de compra de merc, ou despesa de telefone, energia , etc.... (se houver)
* movimenta estoque ?
* movimenta financeiro ?
* valor Pis
* valor cofins
* icms ST
*/

--1. 2. Cadastro de produtos
--Todos os campos

 SELECT 
 	  'a'+MTPR_COD [Insumo]
	, MTPR_MTTP [Tipo]
	, MTPR_MS [M/S]
	, MTPR_ATV [Ativo]
	, MTPR_NOM [Nome]
	, MTPR_MTDV [Divis�o]
	, MTPR_MTLN [Linha]
	, MTPR_MTFM [Fam�lia]
	, MTPR_MTUN [Unidade]
	, MTPR_MTNC [NCM]
	, MTPR_ORI [Origem]
	, MTPR_PES [Peso em Kg]
	, MTPR_DES [Descri��o]
	, MTPR_NIV [N�vel]
	, MTPR_ESUN [Un.Estrutura]
	, MTPR_ESFT [Fator Un.]
	, MTPR_CPUN [Un.Compra]
	, MTPR_CPFT [Fator Un.]
	, MTPR_ATVV [Vendo]
	, MTPR_CFOV [CFOP Venda]
	, MTPR_ATVC [Compro]
	, MTPR_CFOC [CFOP Compra]
	, MTPR_TOLE [Varia��o%]
FROM MTPR
