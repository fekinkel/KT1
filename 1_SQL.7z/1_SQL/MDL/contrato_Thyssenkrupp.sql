IF OBJECT_ID('TempDB.dbo.#VDCX') IS NOT NULL DROP TABLE #VDCXSELECT * INTO #VDCX FROM VDCX WHERE 1 = 0INSERT INTO #VDCXSELECT 		VDCX_VDCV = CONVERT(int,'107')      --CONVERT(int(3),'') Contrato
	, VDCX_MTPC = CONVERT(varchar(20),substring([DESCRI��O],charindex('9-',[DESCRI��O]),9))      --CONVERT(varchar(20),'') Refer�ncia
	, VDCX_ATV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Ativo
	, VDCX_MTPC_NOM = MTPC_NOM      --CONVERT(varchar(254),'') Nome
	, VDCX_PUN_MOD = CONVERT(char(1),'S')      --CONVERT(char(1),'') Pre�o espec�fico
	, VDCX_PUN_VAL = CONVERT(decimal(12,2),[C/ICMS])      --CONVERT(decimal(12),'') Pre�o
	, VDCX_PUN_GLMD = 'REAL'--Null      --CONVERT(varchar(8),'') Moeda
	, VDCX_PUN_PCT = '15'--Null      --CONVERT(decimal(6),'') % Sobre Padr�o
	, VDCX_COM_TIPO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Comiss�o Negociada
	, VDCX_COM_PCT = 00.00--Null      --CONVERT(decimal(6),'') Comiss�o %
	, VDCX_QTD = QTD--Null      --CONVERT(decimal(14),'') Expectativa/Ano
	, VDCX_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDCX_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDCX_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDCX_DTU = Null      --CONVERT(datetime(10),'') em
	--select substring([DESCRI��O],charindex('9-',[DESCRI��O]),9),*FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\THYSSENKRUPP.xls',Remessas$),[192.168.2.39].[mdl].[dbo].mtpCwhere DESCRI��O is not nulland substring([DESCRI��O],charindex('9-',[DESCRI��O]),9) collate SQL_Latin1_General_CP1_CI_AS = mtpc_cod --in (select mtpc_cod from [192.168.2.39].[mdl].[dbo].mtpc)and [C/ICMS] is not nullINSERT INTO [192.168.2.39].[mdl].[dbo].VDCXSELECT *FROM #VDCXWHERE CONVERT(VARCHAR(6),VDCX_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),VDCX_SIES)FROM VDCX)
--VDCX_VDCV ,VDCX_MTPC ,VDCX_ATV ,VDCX_MTPC_NOM ,VDCX_PUN_MOD ,VDCX_PUN_VAL ,VDCX_PUN_GLMD ,VDCX_PUN_PCT ,VDCX_COM_TIPO ,VDCX_COM_PCT ,VDCX_QTD ,VDCX_USC ,VDCX_DTC ,VDCX_USU ,VDCX_DTU ,
