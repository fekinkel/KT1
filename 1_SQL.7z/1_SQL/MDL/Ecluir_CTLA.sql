/*
select *
--update ctla set CTLA_ATV = 'N'
from ctla
where ctla_cod between 1163866 and 1164273

--delete
from ctla
where ctla_cod between 1163866 and 1164273

select *
--update ctla set CTLA_ATV = 'N'
from ctla
where ctla_cod between 1150748 and 1151125

select *
--delete
from ctla
where ctla_cod between 1150748 and 1151125
*/

select *
--update ctla set CTLA_ATV = 'N'
from ctla
where ctla_cod between 1169310 and 1169730

select *
--delete
from ctla
where ctla_cod between 1169310 and 1169730
