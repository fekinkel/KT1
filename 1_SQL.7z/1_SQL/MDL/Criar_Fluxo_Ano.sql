--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 15/12/2017--DEPARTAMENTO : 15/12/2017--ASSUNTO      : Criar o Fluxo de 15/12/2017 at� 31/12/2018------------------------------------------------------------------------------------------------------------------------
declare
@i int

set @i = 1
IF OBJECT_ID('TempDB.dbo.#CFFX') IS NOT NULL DROP TABLE #CFFXSELECT * INTO #CFFX FROM CFFX WHERE 1 = 0
--CFFX_COD ,CFFX_NOM ,CFFX_OBS ,CFFX_USC ,CFFX_DTC ,CFFX_USU ,CFFX_DTU ,

while convert(date,(getdate()+@i)) <= (convert(date,'2018.12.31',102))  begin

	 print @i
	 select substring(convert(varchar(10),getdate()+@i,102),3,2)+substring(convert(varchar(10),getdate()+@i,102),6,2)+substring(convert(varchar(10),getdate()+@i,102),9,2), convert(varchar(10),getdate()+@i,103)
		INSERT INTO #CFFX		SELECT 			CFFX_COD = CONVERT(varchar(6),substring(convert(varchar(10),getdate()+@i,102),3,2)+substring(convert(varchar(10),getdate()+@i,102),6,2)+substring(convert(varchar(10),getdate()+@i,102),9,2))      --CONVERT(varchar(6),'') Fluxo(C�digo do fluxo de despesa/receita)
			, CFFX_NOM = CONVERT(varchar(50),convert(varchar(10),getdate()+@i,103))      --CONVERT(varchar(50),'') Nome(Nome do fluxo financeiro)
			, CFFX_OBS = Null      --CONVERT(varchar(255),'') Obs.(Observa��o do fluxo)
			, CFFX_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
			, CFFX_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
			, CFFX_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
			, CFFX_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)

	 set @i = @i + 1
end

--INSERT INTO CFFXSELECT *FROM #CFFXWHERE CFFX_COD NOT IN (SELECT CFFX_COD FROM CFFX)

