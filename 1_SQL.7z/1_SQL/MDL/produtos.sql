select *
from mtpc

select top 10 *
from mtes


--Select top 10 mtpc_cod, mtpc_mtpr, mtpc_pre, isnull(mtmv_val,0)/isnull(mtmv_qtd,0), isnull(mtmv_valm,0), mtes_ucdo, mtmv_dat
Select mtpc_cod [Refer�ncia], mtpc_mtpr [Insumo], replace(mtpc_pre,'.',',') [Pre�o], replace(isnull(mtmv_val,0)/isnull(mtmv_qtd,0),'.',',') [Val. unit�rio], mtes_ucdo, mtmv_dat
from MTMV, MTES, mtpc, mtpr
where mtpc_mtpr = mtes_mtpr
--and mtes_mtpr='C�digo do Produto'
and mtpr_cod  = mtpc_mtpr
and mtpr_atv = 'S'
and mtes_sies=5 
and mtmv_sies=mtes_sies
and mtmv_sido=substring(isnull(mtes_ucdo,'9/XXXX/XXX/99999999999999'),3,4)
and mtmv_sise=substring(isnull(mtes_ucdo,'9/XXXX/XXX/99999999999999'),8,3)
and mtmv_cod =substring(isnull(mtes_ucdo,'9/XXXX/XXX/99999999999999'),12,6)
        