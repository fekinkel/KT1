drop table #glfu
select *
into #glfu
from glfu
where GLFU_COD like '18%'

--select * from #glfu where glfu_cod = 180231


drop table #new
select identity(int,1,1) NUM, a.GLFU_SIES,	a.GLFU_COD GLFU_COD_DE,	a.GLFU_NOM GLFU_NOM_DE, b.GLFU_COD GLFU_COD_PARA,	b.GLFU_NOM GLFU_NOM_PARA, a.GLFU_PPAH	GLFU_PPAH_DE , a.GLFU_RDAH GLFU_RDAH_DE, a.GLFU_SIUS GLFU_SIUS_DE
into #new
from glfu a, #glfu b
where a.glfu_sies = 5
and a.GLFU_NOM = b.GLFU_NOM 
AND a.GLFU_COD <> b.GLFU_COD
AND a.GLFU_NOM <> 'VISITANTE'


--SELECT b.*
--UPDATE GLFU SET GLFU_PPAH	= b.GLFU_PPAH_DE , GLFU_RDAH = b.GLFU_RDAH_DE, GLFU_SIUS = b.GLFU_SIUS_DE 
FROM GLFU a, #NEW b
WHERE a.GLFU_SIES = b.GLFU_SIES
	AND a.GLFU_COD = b.GLFU_COD_PARA

--select * from glfu where glfu_cod = '310006'
--select *
--	BEGIN TRY
		ALTER TABLE CPSC DISABLE TRIGGER ALL
		UPDATE CPSC SET CPSC_GLFU = GLFU_COD_PARA
		--SELECT *
		from cpsc, #new
		where CPSC_GLFU = GLFU_COD_DE
			--AND NUM = @i
			--and CPSC_GLFU = '000096'
			AND CPSC_SIES = GLFU_SIES
		ALTER TABLE CPSC ENABLE TRIGGER ALL
--	END TRY
	--BEGIN CATCH
		--SELECT @I
	--END CATCH

ALTER TABLE PRAH DISABLE TRIGGER ALL
UPDATE PRAH SET PRAH_GLFU = GLFU_COD_PARA
--SELECT *
from prah, #new
where PRAH_GLFU = GLFU_COD_DE
and prah_sies = glfu_sies
--and PRAH_GLFU = '000009'
ALTER TABLE PRAH ENABLE TRIGGER ALL


DECLARE
@I INT = 1,
@J INT

SELECT @J = MAX(NUM) FROM #NEW
WHILE @I<=@J BEGIN

	--select *
	BEGIN TRY
		DELETE glfu
		from #new a, GLFU b
		WHERE NUM = @I
		AND a.GLFU_SIES = b.GLFU_SIES
		AND a.GLFU_COD_DE = b.GLFU_COD
	END TRY
	BEGIN CATCH
		SELECT * from #new a, GLFU b
		WHERE NUM = @I
		AND a.GLFU_SIES = b.GLFU_SIES
		AND a.GLFU_COD_DE = b.GLFU_COD
	END CATCH
	SET @I = @I + 1
END

SELECT *
FROM #NEW


select *--distinct prak_tipo, prak_recu
--update [MDL].[dbo].PRAK set prak_recu = GLFU_COD_PARA
from [MDL].[dbo].PRAK, #new
where glfu_cod_de = prak_recu
--and Prak_sies=5 and prak_ano=2016 and prak_mes=04

