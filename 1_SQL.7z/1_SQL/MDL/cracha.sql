--drop table #newINSERT INTO [192.168.2.39].[mdl].[dbo].GLFUselect GLFU_SIES ,'18'+substring(nome,3,4) GLFU_COD ,GLFU_NOM ,GLFU_GLDP ,GLFU_GLFN ,GLFU_OBS ,GLFU_SIUS ,GLFU_NRDZ ,GLFU_FONE ,GLFU_PPAH ,GLFU_RDAH ,'KINKEL' GLFU_USC ,GETDATE() GLFU_DTC ,GLFU_USU ,GLFU_DTU--'18'+substring(nome,3,4) COD,GLFU_COD,substring(nome,9,len(nome)) NOME, b.*--, identity(int,1,1) NUM--into #newFROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\0_arq\cracha.XLS',Dados$) ,[192.168.2.39].[bkp].[dbo].glfu bwhere nome is not null			--and GLFU_NOM like '%'+substring(nome,9,5)+'%' collate SQL_Latin1_General_CP1_CI_AS			and convert(int,substring(nome,3,4)) = convert(int,glfu_cod)			AND '18'+substring(nome,3,4)collate SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT GLFU_COD FROM [192.168.2.39].[bkp].[dbo].GLFU)			and GLFU_SIES = 5			and glfu_cod not like 'SEN%'			AND glfu_cod <> '112'
			--[192.168.2.39].[mdl].[dbo].DROP TABLE #GLFUSELECT * INTO #GLFU FROM [192.168.2.39].[mdl].[dbo].GLFU WHERE 1 = 0INSERT INTO #GLFUSELECT 		GLFU_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, GLFU_COD = CONVERT(varchar(15),'18'+substring(nome,3,4))      --CONVERT(varchar(15),'') Id. Funcional
	, GLFU_NOM = CONVERT(varchar(50),ltrim(substring(nome,11,charindex('/',nome)-14)))      --CONVERT(varchar(50),'') Nome
	, GLFU_GLDP = CONVERT(varchar(15),replace(ltrim(rtrim(substring(nome,charindex('1.',nome+'1.'),9))),'.',''))      --CONVERT(varchar(15),'') C.Custo
	, GLFU_GLFN = CONVERT(varchar(15),ltrim(rtrim(substring(nome,charindex('/',nome)+8,30))))      --CONVERT(varchar(15),'') Fun��o
	, GLFU_OBS = Null      --CONVERT(varchar(255),'') Obs.
	, GLFU_SIUS = Null      --CONVERT(varchar(15),'') Usu�rio
	, GLFU_NRDZ = CONVERT(varchar(15),substring(nome,9,charindex(char(32),nome,11)-9)) -- Apelido
	, GLFU_FONE = Null      --CONVERT(varchar(25),'') Telefone de contato
	, GLFU_PPAH = CONVERT(char(1),'')      --CONVERT(char(1),'') Aponta
	, GLFU_RDAH = CONVERT(char(1),'')      --CONVERT(char(1),'') Reclassifica
	, GLFU_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLFU_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLFU_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLFU_DTU = Null      --CONVERT(datetime(10),'') em
	--select replace(replace(ltrim(rtrim(substring(nome,charindex('1.',nome+'1.'),8))),'.',''),char(32),'11050'), ltrim(rtrim(substring(nome,charindex('/',nome)+8,30))),charindex(char(32),nome),'18'+substring(nome,3,4), *	--select substring(nome,12,charindex('/',nome)-14), *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\0_arq\cracha1.XLS',Dados$)where nome is not null			AND '18'+substring(nome,3,4)collate SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT GLFU_COD FROM [192.168.2.39].[mdl].[dbo].GLFU WHERE GLFU_SIES = 5)			and convert(int,'18'+substring(nome,3,4))>18Update #glfu set GLFU_GLDP = '110503' where GLFU_GLDP = ''Update #glfu set GLFU_GLDP = '110103' where GLFU_GLDP = '110503'Update #glfu set GLFU_GLDP = '110104' where GLFU_GLDP = '110504'Update #glfu set GLFU_GLDP = '120121' where GLFU_GLDP = '120521'Update #glfu set GLFU_GLDP = '120122' where GLFU_GLDP = '120522'Update #glfu set GLFU_GLDP = '120123' where GLFU_GLDP = '120523'Update #glfu set GLFU_GLDP = '120126' where GLFU_GLDP = '120526'Update #glfu set GLFU_GLDP = '120128' where GLFU_GLDP = '120528'DROP TABLE #GLFNSELECT * INTO #GLFN FROM [192.168.2.39].[mdl].[dbo].GLFN WHERE 1 = 0INSERT INTO #GLFNSELECT 		GLFN_COD = CONVERT(varchar(15),GLFU_GLFN)      --CONVERT(varchar(15),'') Fun��o
	, GLFN_NOM = CONVERT(varchar(50),GLFU_GLFN)      --CONVERT(varchar(50),'') Nome
	, GLFN_OBS = Null      --CONVERT(varchar(255),'') Obs.
	, GLFN_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLFN_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLFN_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLFN_DTU = Null      --CONVERT(datetime(10),'') em
	--select *from #glfuwhere substring(glfu_glfn,1,15) not in (select GLFN_CODfrom [192.168.2.39].[mdl].[dbo].GLfn)INSERT INTO [192.168.2.39].[mdl].[dbo].GLFNSELECT *FROM #GLFNWHERE CONVERT(VARCHAR(6),GLFN_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),GLFN_SIES)FROM GLFN)
--GLFN_COD ,GLFN_NOM ,GLFN_OBS ,GLFN_USC ,GLFN_DTC ,GLFN_USU ,GLFN_DTU ,
select *from [192.168.2.39].[mdl].[dbo].GLfn		INSERT INTO [192.168.2.39].[mdl].[dbo].GLFUSELECT top 1 *FROM #GLFUWHERE GLFU_COD NOT IN (SELECT GLFU_COD FROM [192.168.2.39].[mdl].[dbo].GLFU WHERE GLFU_SIES = 5)
--GLFU_COD not in (180268,180271,180266, 180167, 180215, 180252, 180243, 180274)
--GLFU_SIES ,GLFU_COD ,GLFU_NOM ,GLFU_GLDP ,GLFU_GLFN ,GLFU_OBS ,GLFU_SIUS ,GLFU_NRDZ ,GLFU_FONE ,GLFU_PPAH ,GLFU_RDAH ,GLFU_USC ,GLFU_DTC ,GLFU_USU ,GLFU_DTU ,


SELECT CHARINDEX(CHAR(32),'1 FERqqq NAN',3)

SELECT * FROM [192.168.2.39].[mdl].[dbo].GLFU WHERE GLFU_SIES = 5