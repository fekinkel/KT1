
IF OBJECT_ID('TempDB.dbo.#VDPI') IS NOT NULL DROP TABLE #VDPI
select *
into #VDPI
from vdpi

IF OBJECT_ID('TempDB.dbo.#VDPD') IS NOT NULL DROP TABLE #VDPD
select *
into #VDPD
from vdpd

IF OBJECT_ID('TempDB.dbo.#GLPA') IS NOT NULL DROP TABLE #GLPA
select *
into #GLPA
from glpa

IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPR
select *
into #MTPR
from mtpr

IF OBJECT_ID('TempDB.dbo.#GLVD') IS NOT NULL DROP TABLE #GLVD
select *
into #GLVD
from GLVD

select VDPI_SIES,VDPI_SIDO,VDPI_SISE,VDPI_VDPD,VDPI_COD,VDPI_MTPC,VDPI_QTD,VDPI_QNF,VDPI_VAL,VDPI_NFOP,
  VDPD_GLCL,VDPD_GLCL_DIG,VDPD_GLVD,VDPD_GLPG,VDPD_GLMD,VDPD_DTC, VDPI_DENT, VDPD_GLUF_DES, a.GLPA_CID, 
  MTPR_NOM, VDPI_MTDV, VDPI_MTLN, VDPI_MTFM, a.GLPA_NOM,
  VDPD_GLVD, b.glpa_nom
from #VDPI, #VDPD, #GLPA a, #MTPR, #GLPA b, #GLVD
where (vdpd_sta='OK' or vdpd_sta='EC')
 --and convert(char(10),vdpd_dtc,102) between '2014.01.01' and '2014.12.31'
 --and convert(char(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
 --and convert(char(10),vdpd_dtc,102) between '2016.01.01' and '2016.12.31'
 --and convert(char(10),vdpd_dtc,102) between '2017.01.01' and '2017.01.31'
	and convert(char(10),vdpd_dtc,102) between '2017.01.01' and '2017.02.16'
 and vdpi_sta<>'CA'
 and vdpd_sies=vdpi_sies
 and vdpd_sido=vdpi_sido
 and vdpd_sise=vdpi_sise
 and vdpd_cod =vdpi_vdpd
 and vdpd_glpa=a.glpa_cod
 and vdpi_mtpr = mtpr_cod
 
 and vdpd_glvd = glvd_cod
 and glvd_glpa = b.glpa_cod
 --and vdpd_glpa=a.glpa_cod
 order by vdpi_mtpc, vdpi_sies, vdpi_sido, vdpi_sise, vdpi_vdpd, vdpi_cod
 