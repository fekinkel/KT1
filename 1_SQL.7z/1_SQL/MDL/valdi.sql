ALTER TABLE prnc DISABLE TRIGGER ALL
select *
--update prnc set prnc_qtd = 4
from prnc
where prnc_sido = 'VDPD'
			and prnc_npai = 135
			and prnc_cod = 3
ALTER TABLE prnc ENABLE TRIGGER ALL



--PRIMEIRO ITEM -----------------------------------
select VDPS_QTD = VDPS_QTD/6, *
--update vdps set VDPS_QTD = VDPS_QTD/6
from vdps
where vdps_vdpd = 135
			and vdps_vdpi = 1

ALTER TABLE vdpi DISABLE TRIGGER ALL
select *
--update vdpi set VDPI_QTD = 6
from vdpi
where vdpi_vdpd = 135
			and vdpi_cod = 1

ALTER TABLE vdpi ENABLE TRIGGER ALL

--SEGUNDO ITEM -----------------------------------
select VDPS_QTD = VDPS_QTD/9, *
--update vdps set VDPS_QTD = VDPS_QTD/9
from vdps
where vdps_vdpd = 135
			and vdps_vdpi = 2

ALTER TABLE vdpi DISABLE TRIGGER ALL
select *
--update vdpi set VDPI_QTD = 9
from vdpi
where vdpi_vdpd = 135
			and vdpi_cod = 2

ALTER TABLE vdpi ENABLE TRIGGER ALL

--TERCEIRO ITEM -----------------------------------
select VDPS_QTD = VDPS_QTD/4, *
--update vdps set VDPS_QTD = VDPS_QTD/4, VDPS_VAL = VDPS_PUND*(VDPS_QTD/4)
from vdps
where vdps_vdpd = 135
			and vdps_vdpi = 3

ALTER TABLE vdpi DISABLE TRIGGER ALL
select *
--update vdpi set VDPI_QTD = 4
from vdpi
where vdpi_vdpd = 135
			and vdpi_cod = 3

ALTER TABLE vdpi ENABLE TRIGGER ALL


