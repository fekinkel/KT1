

--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 30/08/2017--DEPARTAMENTO : ADMINISTRA��O--ASSUNTO      : TROCAR O REPRESENTANTE DE 38 PARA 92 DESDE 10/07/2017 ------------------------------------------------------------------------------------------------------------------------

IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #new
select VDPD_SIES sies,	VDPD_SIDO sido,	VDPD_SISE sise,	VDPD_COD cod, identity(int,1,1) num
into #new
from vdpd
where vdpd_glvd = 38
and convert(varchar(10), vdpd_dtc, 102) >= '2017.07.10'

declare
@i int,
@j int

select @i = 1, @j = max(num) from #new

while @i <= @j begin
	--select *
	update vdpd set vdpd_glvd = 92
	from #new, vdpd
	where num = @i
	and VDPD_SIES = sies
	and VDPD_SIDO = sido
	and	VDPD_SISE = sise
	and VDPD_COD  = cod
	print @i
	set @i = @i + 1
end
--update vdpd set vdpd_glvd = 92

IF OBJECT_ID('TempDB.dbo.#new1') IS NOT NULL DROP TABLE #new1
select FTNF_SIES SIES,	FTNF_SIDO SIDO,	FTNF_SISE SISE, FTNF_COD COD, identity(int,1,1) num
into #new1
from FTNF
where FTNF_glvd = 38
and convert(varchar(10), FTNF_dtc, 102) >= '2017.07.10'

declare
@k int,
@l int

select @k = 1, @l = max(num) from #new1

while @k <= @l begin
	--select *
	update ftnf set ftnf_glvd = 92
	from #new1, ftnf
	where num = @k
	and FTNF_SIES = sies
	and FTNF_SIDO = sido
	and	FTNF_SISE = sise
	and ftnf_COD  = cod
	print @k
	set @k = @k + 1
end
--update vdpd set vdpd_glvd = 92
