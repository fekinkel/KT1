select a.mtpr_cod, stuff(a.mtpr_cod,4,1,'S'), b.mtpc_pre
, c.mtpc_pre mtpc_pre_L
, d.mtpc_pre mtpc_pre_S
, e.mtpc_pre mtpc_pre_F
, f.mtpc_pre mtpc_pre_R
, g.mtpc_pre mtpc_pre_V
from mtpr a, mtpc b, mtpc c, mtpc d, mtpc e, mtpc f, mtpc g
where substring(a.mtpr_cod,1,4) = 'blhb'
and substring(reverse(a.mtpr_cod),1,1) = 'b'
and b.mtpc_mtpr = a.mtpr_cod
and stuff(a.mtpr_cod,4,1,'L') = c.mtpc_mtpr
and stuff(a.mtpr_cod,4,1,'S') = d.mtpc_mtpr
and stuff(a.mtpr_cod,4,1,'F') = e.mtpc_mtpr
and stuff(a.mtpr_cod,4,1,'R') = f.mtpc_mtpr
and stuff(a.mtpr_cod,4,1,'V') = g.mtpc_mtpr
