select substring(vdpi_nom,1,charindex(')',vdpi_nom))+mtpc_nom,vdpi_mtpc, mtpc_mtpr, vdpi_nom, mtpc_nom, *
--update vdpi set vdpi_nom = substring(vdpi_nom,1,charindex(')',vdpi_nom))+mtpc_nom 
from vdpi, mtpc
where vdpi_vdpd in (196481, 196482, 196483, 196484, 196485, 196706)
			and mtpc_cod  = vdpi_mtpc
			
select vdcx_mtpc, mtpc_mtpr, vdcx_mtpc_nom, mtpc_nom, *
--update vdcx set vdcx_mtpc_nom = mtpc_nom 
from vdcx, mtpc
where mtpc_cod  = vdcx_mtpc
			and substring(vdcx_mtpc_nom,1,20) <> substring(mtpc_nom,1,20)
			and mtpc_cod like '9-%'
