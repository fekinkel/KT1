select MTPR_NOM, replace(MTPR_NOM,'Puncao', 'Matriz')
--update mtpr set MTPR_NOM =  replace(MTPR_NOM,'Puncao', 'Matriz')
from mtpr
where len(mtpr_cod) = 7
and substring(mtpr_cod,3,1) = '-'
and substring(mtpr_cod,1,1) = 'D'
