DROP TABLE #OFITSELECT * INTO #OFIT FROM OFIT WHERE 1 = 0INSERT INTO #OFITSELECT 		OFIT_SIES = CONVERT(int,'7')      --CONVERT(int(6),'') E
	, OFIT_SIDO = CONVERT(varchar(4),'OF55')      --CONVERT(varchar(4),'') Tipo
	, OFIT_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, OFIT_OFNF --= CONVERT(int,'31494')      --CONVERT(int(6),'') N� Doc.
	, OFIT_COD = ROW_NUMBER() OVER(ORDER BY Rlri_mtes)      --CONVERT(int(3),'') Item
	, OFIT_CODF = 0--Null      --CONVERT(int(3),'') Item
	, OFIT_SIDP = 'VDPD'--Null      --CONVERT(varchar(4),'') Tipo
	, OFIT_SISP = '001'--Null      --CONVERT(varchar(3),'') S�rie
	, OFIT_CODP = 0--Null      --CONVERT(int(6),'') Pedido
	, OFIT_CODI = Null      --CONVERT(int(3),'') Item
	, OFIT_MTPC = CONVERT(varchar(20),RLRI_MTES)      --CONVERT(varchar(20),'') Refer�ncia
	, OFIT_NOM = CONVERT(varchar(255),RLRI_NOM)      --CONVERT(varchar(255),'') Descri��o
	, OFIT_MTPR = CONVERT(varchar(20),RLRI_MTES)      --CONVERT(varchar(20),'') Insumo
	, OFIT_MS = CONVERT(varchar(2),'M')      --CONVERT(varchar(2),'') M/S
	, OFIT_MTUN = CONVERT(varchar(3),RLRI_MTUN)      --CONVERT(varchar(3),'') Unidade
	, OFIT_MTNC = CONVERT(varchar(8),RLRI_MTNC)      --CONVERT(varchar(8),'') NCM
	, OFIT_ORI = mtpr_ori--CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, OFIT_MTDV = mtpr_mtdv--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o
	, OFIT_MTLN = mtpr_mtln--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha
	, OFIT_MTFM = mtpr_mtfm--CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia
	, OFIT_PLIQ = mtpr_pes--Null      --CONVERT(decimal(12),'') Peso L�q.
	, OFIT_PLQT = mtpr_pes*Rlri_qtd_alm--Null      --CONVERT(decimal(13),'') Peso Tot.
	, OFIT_PBRT = mtpr_pes*Rlri_qtd_alm--Null      --CONVERT(decimal(13),'') Peso Bruto
	, OFIT_EST --= CONVERT(char(1),'')      --CONVERT(char(1),'') Estoque
	, OFIT_MTTR --= Null      --CONVERT(varchar(6),'') Transa��o
	, OFIT_STA --= CONVERT(int(3),'')      --CONVERT(int(3),'') Reserva
	, OFIT_CTPC --= RLRI_CTPC--Null      --CONVERT(varchar(15),'') Cont�bil
	, OFIT_RDPC --= RLRI_RDPC--Null      --CONVERT(varchar(7),'') Rdz.
	, OFIT_CTCC --= RLRI_CTCC--Null      --CONVERT(varchar(15),'') C.C.
	, OFIT_RDCC --= RLRI_RDCC--Null      --CONVERT(varchar(7),'') Rdz.
	, OFIT_QTD = round(RLRI_QTD_ALM,2)--Null      --CONVERT(decimal(12),'') Quantidade
	, OFIT_PUN = round(RLRI_VUN_ALM,2)--Null      --CONVERT(decimal(12),'') Valor Unit�rio
	, OFIT_VAL = round(round(RLRI_QTD_ALM,2)*round(RLRI_VUN_ALM,2),2)--Null      --CONVERT(decimal(12),'') Valor do Item
	, OFIT_REV = CONVERT(char(1),'I')      --CONVERT(char(1),'') Destina��o
	, OFIT_DES = 0.00--Null      --CONVERT(decimal(12),'') Desconto
	, OFIT_NFOP --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Oper.
	, OFIT_CFOP --= Null      --CONVERT(varchar(6),'') CFOP
	, OFIT_TIT --= CONVERT(char(1),'')      --CONVERT(char(1),'') Gera t�tulos
	, OFIT_TBB --= Null      --CONVERT(varchar(2),'') Tabela B
	, OFIT_MEN --= Null      --CONVERT(varchar(255),'') Mensagem
	, OFIT_IPI_BAS --= Null      --CONVERT(decimal(12),'') Base IPI
	, OFIT_IPI_ALI --= Null      --CONVERT(decimal(5),'') % IPI
	, OFIT_IPI_VAL --= Null      --CONVERT(decimal(12),'') Valor IPI
	, OFIT_IPI_ISE --= Null      --CONVERT(decimal(12),'') IPI Isento
	, OFIT_IPI_OUT = round(round(RLRI_QTD_ALM,2)*round(RLRI_VUN_ALM,2),2)--Null      --CONVERT(decimal(12),'') IPI Outros
	, OFIT_ISS_BAS --= Null      --CONVERT(decimal(12),'') Base de ISS
	, OFIT_ISS_ALI --= Null      --CONVERT(decimal(5),'') % ISS
	, OFIT_ISS_VAL --= Null      --CONVERT(decimal(12),'') Valor do ISS
	, OFIT_ISS_ISE --= Null      --CONVERT(decimal(12),'') ISS Isento
	, OFIT_ISS_OUT --= Null      --CONVERT(decimal(12),'') ISS Isento
	, OFIT_ICM_BAS = round(round(RLRI_QTD_ALM,2)*round(RLRI_VUN_ALM,2),2)--Null      --CONVERT(decimal(12),'') Base ICMS
	, OFIT_ICM_ALI --= Null      --CONVERT(decimal(5),'') % ICMS
	, OFIT_ICM_VAL = round(round(RLRI_QTD_ALM,2)*round(RLRI_VUN_ALM,2),2)*18/100--Null      --CONVERT(decimal(12),'') Valor do ICMS
	, OFIT_ICM_ISE = 0--ROUND(RLRI_MAT_ALM*(100)/100,2)--Null      --CONVERT(decimal(12),'') ICMS Isento
	, OFIT_ICM_OUT --= Null      --CONVERT(decimal(12),'') ICMS Outros
	, OFIT_IST_BAS --= Null      --CONVERT(decimal(12),'') Base ICMS - ST
	, OFIT_IST_ALI --= Null      --CONVERT(decimal(5),'') % ICMS - ST
	, OFIT_IST_VAL --= Null      --CONVERT(decimal(12),'') Valor do ICMS - ST
	, OFIT_IST_ISE --= Null      --CONVERT(decimal(12),'') ICMS Isento - ST
	, OFIT_IST_OUT --= Null      --CONVERT(decimal(12),'') ICMS Outros - ST
	, OFIT_IST_IVA --= Null      --CONVERT(decimal(12),'') ST- IVA %
	, OFIT_ICP_ALI --= Null      --CONVERT(decimal(6),'') %ICMS Complem.
	, OFIT_ICP_VAL --= Null      --CONVERT(decimal(12),'') Valor ICMS Complem.
	, OFIT_PIS_CST --= Null      --CONVERT(varchar(2),'') CST PIS
	, OFIT_PIS_NAT --= Null      --CONVERT(varchar(2),'') Nat BC PIS
	, OFIT_PIS_BAS --= Null      --CONVERT(decimal(12),'') Base PIS
	, OFIT_PIS_ALI --= Null      --CONVERT(decimal(5),'') % PIS
	, OFIT_PIS_VAL --= Null      --CONVERT(decimal(12),'') Valor PIS
	, OFIT_PIS_ISE --= Null      --CONVERT(decimal(12),'') PIS Isento
	, OFIT_PIS_OUT = round(round(RLRI_QTD_ALM,2)*round(RLRI_VUN_ALM,2),2)-- Null      --CONVERT(decimal(12),'') PIS Outros
	, OFIT_COF_CST --= Null      --CONVERT(varchar(2),'') CST COF
	, OFIT_COF_NAT --= Null      --CONVERT(varchar(2),'') Nat BC COF
	, OFIT_COF_BAS --= Null      --CONVERT(decimal(12),'') Base COF
	, OFIT_COF_ALI --= Null      --CONVERT(decimal(5),'') % COF
	, OFIT_COF_VAL --= Null      --CONVERT(decimal(12),'') Valor COF
	, OFIT_COF_ISE --= Null      --CONVERT(decimal(12),'') COF Isento
	, OFIT_COF_OUT = round(round(RLRI_QTD_ALM,2)*round(RLRI_VUN_ALM,2),2)--Null      --CONVERT(decimal(12),'') COF Outros
	, OFIT_VAL_FRE --= Null      --CONVERT(decimal(12),'') Frete
	, OFIT_VAL_SEG --= Null      --CONVERT(decimal(12),'') Seguro
	, OFIT_VAL_ACE --= Null      --CONVERT(decimal(12),'') Desp. Aces.
	, OFIT_IMP_ALI --= Null      --CONVERT(decimal(5),'') % II
	, OFIT_IMP_ADU --= Null      --CONVERT(decimal(12),'') Valor Aduaneiro
	, OFIT_IMP_DAD --= Null      --CONVERT(decimal(12),'') Desp. Aduaneiras
	, OFIT_VAL_PIS --= Null      --CONVERT(decimal(12),'') Valor do PIS
	, OFIT_VAL_COF --= Null      --CONVERT(decimal(12),'') Valor da COFINS
	, OFIT_MTTP_SPED --= Null      --CONVERT(varchar(2),'') Tipo SPED
	, OFIT_FCIT --= Null      --CONVERT(char(1),'') FCI Tipo
	, OFIT_FCIN = Null      --CONVERT(varchar(36),'') FCI #
	, OFIT_FCIP = Null      --CONVERT(decimal(5),'') CI %
	, OFIT_USC --= CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por
	, OFIT_DTC --= CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em
	, OFIT_USU --= Null      --CONVERT(varchar(15),'') Alterado por
	, OFIT_DTU --= Null      --CONVERT(datetime(10),'') em
	--SELECT b.*
FROM [VND].[dbo].OFIT a, tmpRlri1 b, mtprWHERE OFIT_OFNF = 31698--31548			and Rlri_mtes = mtpr_cod			and Rlri_mtnc_new = '00000015'--select top 10 * from mtpr--INSERT INTO FTIT--SELECT OFIT_SIES ,'FT55' OFIT_SIDO ,OFIT_SISE ,31966 OFIT_OFNF ,OFIT_COD ,OFIT_CODF ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC ,OFIT_NOM ,OFIT_MTPR ,OFIT_MS ,OFIT_MTUN ,OFIT_MTNC ,OFIT_ORI ,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT ,OFIT_PBRT ,OFIT_EST ,OFIT_MTTR ,OFIT_STA ,OFIT_CTPC ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD ,OFIT_PUN ,OFIT_VAL ,OFIT_REV ,OFIT_DES ,OFIT_NFOP ,OFIT_CFOP ,OFIT_TIT ,OFIT_TBB ,OFIT_MEN ,OFIT_IPI_BAS ,OFIT_IPI_ALI ,OFIT_IPI_VAL ,OFIT_IPI_ISE ,OFIT_IPI_OUT ,OFIT_ISS_BAS ,OFIT_ISS_ALI ,OFIT_ISS_VAL ,OFIT_ISS_ISE ,OFIT_ISS_OUT ,OFIT_ICM_BAS ,OFIT_ICM_ALI ,OFIT_ICM_VAL ,OFIT_ICM_ISE ,OFIT_ICM_OUT ,OFIT_IST_BAS ,OFIT_IST_ALI ,OFIT_IST_VAL ,OFIT_IST_ISE ,OFIT_IST_OUT ,OFIT_IST_IVA ,OFIT_ICP_ALI ,OFIT_ICP_VAL ,OFIT_PIS_CST ,OFIT_PIS_NAT ,OFIT_PIS_BAS ,OFIT_PIS_ALI ,OFIT_PIS_VAL ,OFIT_PIS_ISE ,OFIT_PIS_OUT ,OFIT_COF_CST ,OFIT_COF_NAT ,OFIT_COF_BAS ,OFIT_COF_ALI ,OFIT_COF_VAL ,OFIT_COF_ISE ,OFIT_COF_OUT ,OFIT_VAL_FRE ,OFIT_VAL_SEG ,OFIT_VAL_ACE ,OFIT_IMP_ALI ,OFIT_IMP_ADU ,OFIT_IMP_DAD ,OFIT_VAL_PIS ,OFIT_VAL_COF ,OFIT_MTTP_SPED ,OFIT_FCIT ,OFIT_FCIN ,OFIT_FCIP ,OFIT_USC ,OFIT_DTC ,OFIT_USU ,OFIT_DTUinsert into ofitselect *FROM #OFITWHERE CONVERT(VARCHAR(6),OFIT_SIES)+'/'+CONVERT(VARCHAR(6),OFIT_SIDO)+'/'+CONVERT(VARCHAR(6),OFIT_SISE)+'/'+CONVERT(VARCHAR(6),OFIT_OFNF)+'/'+CONVERT(VARCHAR(25),OFIT_MTPC) NOT IN (SELECT CONVERT(VARCHAR(6),OFIT_SIES)+'/'+CONVERT(VARCHAR(6),OFIT_SIDO)+'/'+CONVERT(VARCHAR(6),OFIT_SISE)+'/'+CONVERT(VARCHAR(6),OFIT_OFNF)+'/'+CONVERT(VARCHAR(25),OFIT_MTPC) FROM OFIT)
--OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF ,OFIT_COD ,OFIT_CODF ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC ,OFIT_NOM ,OFIT_MTPR ,OFIT_MS ,OFIT_MTUN ,OFIT_MTNC ,OFIT_ORI ,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT ,OFIT_PBRT ,OFIT_EST ,OFIT_MTTR ,OFIT_STA ,OFIT_CTPC ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD ,OFIT_PUN ,OFIT_VAL ,OFIT_REV ,OFIT_DES ,OFIT_NFOP ,OFIT_CFOP ,OFIT_TIT ,OFIT_TBB ,OFIT_MEN ,OFIT_IPI_BAS ,OFIT_IPI_ALI ,OFIT_IPI_VAL ,OFIT_IPI_ISE ,OFIT_IPI_OUT ,OFIT_ISS_BAS ,OFIT_ISS_ALI ,OFIT_ISS_VAL ,OFIT_ISS_ISE ,OFIT_ISS_OUT ,OFIT_ICM_BAS ,OFIT_ICM_ALI ,OFIT_ICM_VAL ,OFIT_ICM_ISE ,OFIT_ICM_OUT ,OFIT_IST_BAS ,OFIT_IST_ALI ,OFIT_IST_VAL ,OFIT_IST_ISE ,OFIT_IST_OUT ,OFIT_IST_IVA ,OFIT_ICP_ALI ,OFIT_ICP_VAL ,OFIT_PIS_CST ,OFIT_PIS_NAT ,OFIT_PIS_BAS ,OFIT_PIS_ALI ,OFIT_PIS_VAL ,OFIT_PIS_ISE ,OFIT_PIS_OUT ,OFIT_COF_CST ,OFIT_COF_NAT ,OFIT_COF_BAS ,OFIT_COF_ALI ,OFIT_COF_VAL ,OFIT_COF_ISE ,OFIT_COF_OUT ,OFIT_VAL_FRE ,OFIT_VAL_SEG ,OFIT_VAL_ACE ,OFIT_IMP_ALI ,OFIT_IMP_ADU ,OFIT_IMP_DAD ,OFIT_VAL_PIS ,OFIT_VAL_COF ,OFIT_MTTP_SPED ,OFIT_FCIT ,OFIT_FCIN ,OFIT_FCIP ,OFIT_USC ,OFIT_DTC ,OFIT_USU ,OFIT_DTU ,
--FTIT_SIES ,FTIT_SIDO ,FTIT_SISE ,FTIT_FTNF ,FTIT_COD ,FTIT_CODF ,FTIT_SIDP ,FTIT_SISP ,FTIT_CODP ,FTIT_CODI ,FTIT_MTPC ,FTIT_NOM ,FTIT_MTPR ,FTIT_MS ,FTIT_MTUN ,FTIT_MTNC ,FTIT_ORI ,FTIT_MTDV ,FTIT_MTLN ,FTIT_MTFM ,FTIT_PLIQ ,FTIT_PLQT ,FTIT_PBRT ,FTIT_EST ,FTIT_MTTR ,FTIT_STA ,FTIT_CTPC ,FTIT_RDPC ,FTIT_CTCC ,FTIT_RDCC ,FTIT_QTD ,FTIT_PUN ,FTIT_VAL ,FTIT_REV ,FTIT_DES ,FTIT_NFOP ,FTIT_CFOP ,FTIT_TIT ,FTIT_TBB ,FTIT_MEN ,FTIT_IPI_BAS ,FTIT_IPI_ALI ,FTIT_IPI_VAL ,FTIT_IPI_ISE ,FTIT_IPI_OUT ,FTIT_ISS_BAS ,FTIT_ISS_ALI ,FTIT_ISS_VAL ,FTIT_ISS_ISE ,FTIT_ISS_OUT ,FTIT_ICM_BAS ,FTIT_ICM_ALI ,FTIT_ICM_VAL ,FTIT_ICM_ISE ,FTIT_ICM_OUT ,FTIT_IST_BAS ,FTIT_IST_ALI ,FTIT_IST_VAL ,FTIT_IST_ISE ,FTIT_IST_OUT ,FTIT_IST_IVA ,FTIT_ICP_ALI ,FTIT_ICP_VAL ,FTIT_PIS_CST ,FTIT_PIS_NAT ,FTIT_PIS_BAS ,FTIT_PIS_ALI ,FTIT_PIS_VAL ,FTIT_PIS_ISE ,FTIT_PIS_OUT ,FTIT_COF_CST ,FTIT_COF_NAT ,FTIT_COF_BAS ,FTIT_COF_ALI ,FTIT_COF_VAL ,FTIT_COF_ISE ,FTIT_COF_OUT ,FTIT_VAL_FRE ,FTIT_VAL_SEG ,FTIT_VAL_ACE ,FTIT_IMP_ALI ,FTIT_IMP_ADU ,FTIT_IMP_DAD ,FTIT_VAL_PIS ,FTIT_VAL_COF ,FTIT_MTTP_SPED ,FTIT_FCIT ,FTIT_FCIN ,FTIT_FCIP ,FTIT_USC ,FTIT_DTC ,FTIT_USU ,FTIT_DTU ,

select *
--delete
from ftit
where ftit_sies = 7
			and ftit_sido = 'FT55'
			and ftit_ftnf = 31969

select *
--delete
from ofit
where ofit_sies = 7
			--and ofit_sido = 'FT55'
			and ofit_ofnf = 31494
