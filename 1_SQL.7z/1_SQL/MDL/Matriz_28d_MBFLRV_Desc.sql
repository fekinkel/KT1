--Ativar
--Verificar com A.C. PI ou PA
--CRIAR cod MB.100.20.5B
--FINAL B

IF OBJECT_ID('TempDB.dbo.#Mx') IS NOT NULL DROP TABLE #MxSELECT 'xxxx' COD,'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' NOM INTO #Mx WHERE 1 = 0 INSERT INTO #Mx SELECT 'MB.',  'MATR. CIL. SC CA_P BLANK ' INSERT INTO #Mx SELECT 'M.' ,  'MATR. CIL. SC CA_P REDONDO'INSERT INTO #Mx SELECT 'MF.',  'MATR. CIL. SC CA_P OBL_R'INSERT INTO #Mx SELECT 'ML.',  'MATR. CIL. SC CA_P OBL'INSERT INTO #Mx SELECT 'MR.',  'MATR. CIL. SC CA_P RETANGULO'INSERT INTO #Mx SELECT 'MV.',  'MATR. CIL. SC CA_P QUADRADO'
--INSERT INTO #Mx SELECT 'MB.', 'MATR C SCCA RB D06 L20 H3' --INSERT INTO #Mx SELECT 'M.',  'MATR C SCCA RA D06 L20 H3'--INSERT INTO #Mx SELECT 'MF.', 'MATR C SC CA F D06 L20 H3'--INSERT INTO #Mx SELECT 'ML.', 'MATR C SC CA L D06 L20 H3'--INSERT INTO #Mx SELECT 'MR.', 'MATR C SC CA R D06 L20 H3'--INSERT INTO #Mx SELECT 'MV.', 'MATR C SC CA V D06 L20 H3'
select NOM+' D'+substring(mtpr_cod,charindex('.',mtpr_cod)+1,2)+
' L'+substring(mtpr_cod,charindex('.',mtpr_cod)+5,2) +
' H'+reverse(substring(reverse(mtpr_cod),2,charindex('.',reverse(mtpr_cod))-2))+
' MAT. '+REPLACE(REPLACE(substring(reverse(mtpr_cod),1,1),'A','D2'),'B','M2'),
mtpr_nom, * 
--UPDATE MTPR SET MTPR_NOM = NOM+' D'+substring(mtpr_cod,charindex('.',mtpr_cod)+1,2)+' L'+substring(mtpr_cod,charindex('.',mtpr_cod)+5,2) +' H'+reverse(substring(reverse(mtpr_cod),2,charindex('.',reverse(mtpr_cod))-2))+' MAT. '+REPLACE(REPLACE(substring(reverse(mtpr_cod),1,1),'A','D2'),'B','M2')
from mtpr, #Mx
where mtpr_cod like COD+'%'
AND MTPR_ATV = 'S'
