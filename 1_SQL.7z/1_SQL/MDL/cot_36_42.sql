select *
--update vdco set vdco_glvd = 42
from vdco
where convert(varchar(10),vdco_dtc,102)>='2015.01.01'
and vdco_glvd = 36 
and vdco_sta = 'EA'

select *
--update vdco set vdco_glvd = 96
from vdco
where convert(varchar(10),vdco_dtc,102)>='2015.01.01'
and vdco_glvd = 236 
and vdco_sta = 'EA'

