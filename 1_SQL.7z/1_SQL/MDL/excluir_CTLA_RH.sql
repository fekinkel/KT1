
select *
--update CTLA set ctla_atv = 'N'
from ctla --ctlc
where ctla_cod between 93730 and 93912
			and ctla_sies = 7

select *
--delete
from ctla --ctlc
where ctla_cod between 93730 and 93912
			and ctla_sies = 7

select *
--update CTLA set ctla_atv = 'N'
from ctla --ctlc
where ctla_cod between 1070092 and 1070368
			and ctla_sies = 5

select *
--delete
from ctla --ctlc
where ctla_cod between 1070092 and 1070368
			and ctla_sies = 5
