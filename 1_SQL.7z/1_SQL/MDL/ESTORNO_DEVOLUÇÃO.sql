--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 29/01/2018--DEPARTAMENTO : FATURAMENTO--ASSUNTO      : DEVOLU��O DE COMPRAS N�O RETORNOU O PEDIDO DE COMPRAS--               MTMV_DIRE = 'N'------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#MTMV') IS NOT NULL DROP TABLE #MTMVSELECT * INTO #MTMV FROM MTMV WHERE 1 = 0INSERT INTO #MTMVSELECT 		MTMV_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento p/ o documento)
	, MTMV_SIDO --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tip.Doc.(Tipo de documento)
	, MTMV_SISE --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�rie(S�rie para o tipo de documento)
	, MTMV_COD = CONVERT(int,1300397)      --CONVERT(int(6),'') N�mero(N�mero interno do documento)
	, MTMV_SEQ = MTMV_SEQX+100--CONVERT(int,'')      --CONVERT(int(3),'') Seq.(Define a sequ�ncia do movimento)
	, MTMV_DAT = CONVERT(datetime,'22/01/2018 17:40')      --CONVERT(datetime(10),'') Data(Data do movimento)
	, MTMV_MTES --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto ou insumo)
	, MTMV_MTTR = CONVERT(varchar(6),'DEVCOM')      --CONVERT(varchar(6),'') Transa��o(C�digo da transa��o)
	, MTMV_AUTO --= CONVERT(char(1),'')      --CONVERT(char(1),'') Nec.Auto(Define se movimento deve atender a Necessidade associada a Ordem automaticamente)
	, MTMV_TRAN --= CONVERT(char(1),'')      --CONVERT(char(1),'') Transforma��o(Indica se movimento � de transforma��o (N-N�o; D-Direta; R-Reversa))
	, MTMV_ACAO --= CONVERT(char(1),'')      --CONVERT(char(1),'') C�lculo(Indica se c�lculo proporcional (S) ou total (N) nas transforma��es)
	, MTMV_DIRE = CONVERT(char(1),'N')      --CONVERT(char(1),'') Opera��o(Indica se acumula (S) ou estorna (N) atendimentos em Necessidades e Ordens)
	, MTMV_VLIN --= CONVERT(char(1),'')      --CONVERT(char(1),'') Inf. Valor(Valor informado?)
	, MTMV_UCIN --= CONVERT(char(1),'')      --CONVERT(char(1),'') Ult. compra(Atualiza �ltima compra?)
	, MTMV_ATUM --= CONVERT(char(1),'')      --CONVERT(char(1),'') Atualiza Consumo(Define se transa��o atualiza a m�dia de consumo (S ou N))
	, MTMV_SUCA --= CONVERT(char(1),'')      --CONVERT(char(1),'') Sucata(Define se transa��o � de sucata (S ou N))
	, MTMV_SIDX = 'FT55'--Null      --CONVERT(varchar(4),'') Doc.Externo(Tipo de documento externo)
	, MTMV_SISX = '001'--Null      --CONVERT(varchar(3),'') S�r.Ext.(S�rie para o tipo de documento externo)
	, MTMV_CODX = 120928--Null      --CONVERT(int(6),'') N�m.Ext.(N�mero do documento externo)
	, MTMV_SEQX --= Null      --CONVERT(int(8),'') Seq.Ext.(Sequ�ncia do documento externo)
	, MTMV_MTAL_ORI = MTMV_MTAL_DES--CONVERT(varchar(6),'FATURA')      --CONVERT(varchar(6),'') Almox.Origem(C�digo de almoxarifado de origem)
	, MTMV_SUBL_ORI = MTMV_SUBL_DES--CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local O(Identifica��o do sub-local origem do movimento)
	, MTMV_TABE_ORI = MTMV_TABE_DES--Null      --CONVERT(varchar(8),'') Tabela Origem(C�digo da tabela origem para validar o documento origem)
	, MTMV_SIDO_ORI = MTMV_SIDO_DES--Null      --CONVERT(varchar(4),'') Doc.Ori.(Identifica��o do tipo do documento origem do movimento)
	, MTMV_SISE_ORI = MTMV_SISE_DES--Null      --CONVERT(varchar(3),'') S�r.Ori(S�rie para o sub-local origem)
	, MTMV_COD_ORI = MTMV_COD_DES--Null      --CONVERT(int(6),'') N�mero Ori(N�mero do documento origem)
	, MTMV_SEQ_ORI = MTMV_SEQ_DES--Null      --CONVERT(int(3),'') Seq.Ori(Sequ�ncia do documento origem)
	, MTMV_LOTE_ORI = MTMV_LOTE_DES--Null      --CONVERT(varchar(20),'') Lote Origem(C�digo de lote origem)
	, MTMV_CTPC_ORI = MTMV_CTPC_DES--Null      --CONVERT(varchar(15),'') Conta origem(Conta cont�bil origem da transa��o, normalmente cr�dito)
	, MTMV_CTCC_ORI = MTMV_CTCC_DES--Null      --CONVERT(varchar(15),'') C.Custo origem(Centro de custo cont�bil origem da transa��o, normalmente cr�dito)
	, MTMV_MTAL_DES = MTMV_MTAL_ORI--CONVERT(varchar(6),'EXTFOR')      --CONVERT(varchar(6),'') Almox.Destino(C�digo de almoxarifado de destino)
	, MTMV_SUBL_DES = MTMV_SUBL_ORI--CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local D(Identifica��o do sub-local destino do movimento)
	, MTMV_TABE_DES = MTMV_TABE_ORI--Null      --CONVERT(varchar(8),'') Tabela Destino(C�digo da tabela para validar o documento destino)
	, MTMV_SIDO_DES = MTMV_SIDO_ORI--Null      --CONVERT(varchar(4),'') Doc Des(Identifica��o do tipo do documento destino do movimento)
	, MTMV_SISE_DES = MTMV_SISE_ORI--Null      --CONVERT(varchar(3),'') S�r.Des(S�rie para o tipo de documento destino)
	, MTMV_COD_DES = MTMV_COD_ORI--Null      --CONVERT(int(6),'') N�mero Des(N�mero do documento destino)
	, MTMV_SEQ_DES = MTMV_SEQ_ORI--Null      --CONVERT(int(3),'') Seq.Des(Sequ�ncia do documento destino)
	, MTMV_LOTE_DES = MTMV_LOTE_ORI--Null      --CONVERT(varchar(20),'') Lote Destino(C�digo de lote destino)
	, MTMV_CTPC_DES = MTMV_CTPC_ORI--Null      --CONVERT(varchar(15),'') Conta destino(Conta cont�bil destino da transa��o, normalmente d�bito)
	, MTMV_CTCC_DES = MTMV_CTCC_ORI--Null      --CONVERT(varchar(15),'') C.Custo destino(Centro de custo cont�bil destino da transa��o, normalmente d�bito)
	, MTMV_MTAL_AUT --= Null      --CONVERT(varchar(6),'') Almox.Auto(C�digo de almoxarifado destino para trans��es autom�ticas)
	, MTMV_QTD --= Null      --CONVERT(decimal(14),'') Quantidade(Quantidade do movimento)
	, MTMV_VAL --= Null      --CONVERT(decimal(14),'') Valor Total(Valor do movimento em moeda corrente)
	, MTMV_VALM --= Null      --CONVERT(decimal(14),'') Valor Total M(Valor do movimento em moeda forte)
	, MTMV_VALP --= Null      --CONVERT(decimal(14),'') Valor Padr�o(Valor do movimento obtido pelo custo padr�o)
	, MTMV_VALA --= Null      --CONVERT(decimal(14),'') Valor Arbitrado(Valor do movimento obtido pelo custo arbitrado)
	, MTMV_GLHP --= Null      --CONVERT(varchar(5),'') Hist�rico(C�digo do hist�rico padr�o)
	, MTMV_MEN = REPLACE(MTMV_MEN,'AUTOM�TICO: ','DEVOLU��O DE COMPRAS: ')--CONVERT(varchar(256),'')      --CONVERT(varchar(256),'') Texto(Texto do hist�rico padr�o)
	, MTMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTMV_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTMV_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--select *
from mtmv
where mtmv_cod in (1300392, 1300393, 1300395, 1300396, 1300397)
order by MTMV_SEQX
INSERT INTO MTMVSELECT *FROM #MTMVWHERE CONVERT(VARCHAR(6),MTMV_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),MTMV_SIES)FROM MTMV)
--MTMV_SIES ,MTMV_SIDO ,MTMV_SISE ,MTMV_COD ,MTMV_SEQ ,MTMV_DAT ,MTMV_MTES ,MTMV_MTTR ,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX ,MTMV_SEQX ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI ,MTMV_SEQ_ORI ,MTMV_LOTE_ORI ,MTMV_CTPC_ORI ,MTMV_CTCC_ORI ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES ,MTMV_SEQ_DES ,MTMV_LOTE_DES ,MTMV_CTPC_DES ,MTMV_CTCC_DES ,MTMV_MTAL_AUT ,MTMV_QTD ,MTMV_VAL ,MTMV_VALM ,MTMV_VALP ,MTMV_VALA ,MTMV_GLHP ,MTMV_MEN ,MTMV_USC ,MTMV_DTC ,MTMV_USU ,MTMV_DTU ,

select *
from mtmv
where mtmv_cod = 1300397
and mtmv_seq > 100

