select *--SIUS_EMAIL, replace(SIUS_EMAIL,'mdl-danly','mdl-brasil')
--update sius set SIUS_EMAIL = replace(SIUS_EMAIL,'mdl-danly','mdl-brasil')
from sius
where SIUS_EMAIL like '%mdl-danly%'
