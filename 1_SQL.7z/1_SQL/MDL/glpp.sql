ALTER TABLE GLPP DISABLE TRIGGER ALL
--select *
update glpp set GLPP_PCT = 33.333068
from glpp
where glpp_glpg = '304560'
and glpp_cod <> 3

ALTER TABLE GLPP ENABLE TRIGGER ALL
