--INCLUIR FORNECEDORES GRUPO DE CONTAIF OBJECT_ID('TempDB.dbo.#CTGC') IS NOT NULL DROP TABLE #CTGCSELECT *, IDENTITY(INT,1,1) NUM INTO #CTGC FROM CTGC WHERE 1 = 0INSERT INTO #CTGCSELECT 		CTGC_CTGR = CONVERT(varchar(6),'EC_LP')      --CONVERT(varchar(6),'') Grupo
	, CTGC_CTGM = CONVERT(varchar(15),'201010301')      --CONVERT(varchar(15),'') N� da Conta
	, CTGC_COD = CONVERT(int,'0')      --CONVERT(int(3),'') Sequ�ncia
	, CTGC_CTPC = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta Cont�bil
	, CTGC_NRD = CTPC_NRD      --CONVERT(varchar(7),'') Reduzido
	, CTGC_OPER = CONVERT(char(1),'+')      --CONVERT(char(1),'') Opera��o
	, CTGC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, CTGC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, CTGC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, CTGC_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from ctpc
where ctpc_cod between '2101010001' and '2101019999'
DECLARE@i INT,@j INT,@k INTSELECT @i = 1, @j = MAX(num) FROM #CTGCWHILE @i <= @j BEGIN	IF (SELECT COUNT(1) FROM #CTGC WHERE NUM = @i and CTGC_CTPC IN (select CTGC_CTPC from CTGC where CTGC_CTGR = 'EC_LP' AND CTGC_CTGM = '201010301') ) = 0 BEGIN 		SELECT @k = 1 + isnull(MAX(CTGC_COD),0) FROM CTGC WHERE CTGC_CTGR = 'EC_LP' AND CTGC_CTGM = '201010301'		INSERT INTO CTGC		SELECT CTGC_CTGR ,CTGC_CTGM ,@k CTGC_COD ,CTGC_CTPC ,CTGC_NRD ,CTGC_OPER ,CTGC_USC ,CTGC_DTC ,CTGC_USU ,CTGC_DTU		FROM #CTGC		WHERE NUM = @i
	END
	SET @i = @i + 1END--CTGC_CTGR ,CTGC_CTGM ,CTGC_COD ,CTGC_CTPC ,CTGC_NRD ,CTGC_OPER ,CTGC_USC ,CTGC_DTC ,CTGC_USU ,CTGC_DTU ,


/*
select *
from ctgc
where ctgc_ctgr = 'EC_LR'
and CTGC_CTGM = '201010301'
*/