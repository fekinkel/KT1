select FTIT_FCIT, FTIT_FCIN, FTIT_FCIP, upper(MTCI_FCI_COD) MTCI_FCI_COD
--update FTit set FTIT_FCIT = 2, FTIT_FCIN = upper(MTCI_FCI_COD)
from ftit, MTCI
where FTIT_ORI in ('3','5','8')
			and MTCI_MTPC = FTIT_MTPC
			and MTCI_SIES = 5
			and FTIT_FCIN <> upper(MTCI_FCI_COD)
			--AND FTIT_FTNF = 24830
			AND FTIT_FTNF = 60830


select *--ORIT_FCIT, ORIT_FCIN, ORIT_FCIP, upper(MTCI_FCI_COD) MTCI_FCI_COD
--update orit set ORIT_FCIP = MTCI_FCI_IND --NULLORIT_FCIT = 2, ORIT_FCIN = upper(MTCI_FCI_COD)
from ORIT, MTCI
where MTCI_MTPC = ORIT_MTPC
			and MTCI_SIES = 5
			and ORIT_ORI in ('3','5','8')
			and orIT_FCIN <> upper(MTCI_FCI_COD)
			--AND rcIT_FTNF = 24830

			select *
			from ORIT
			where ORIT_ORNF = 41372


select ofIT_ORI,ofIT_FCIT, ofIT_FCIN, ofIT_FCIP, upper(MTCI_FCI_COD) MTCI_FCI_COD
--update ofit set ofIT_FCIT = 2, ofIT_FCIN = upper(MTCI_FCI_COD)
from ofit, MTCI
where ofIT_ORI in ('3','5','8')
			and MTCI_MTPC = ofIT_MTPC
			and MTCI_SIES = 7
			and isnull(ofIT_FCIN,'') <> upper(MTCI_FCI_COD)
			--AND FTIT_FTNF = 24830
			AND ofIT_ofNF = 31493
