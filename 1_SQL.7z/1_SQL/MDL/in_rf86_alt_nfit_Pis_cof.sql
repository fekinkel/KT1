select nfit_pis_val, (NFIT_PIS_BAS * NFIT_PIS_ALI)/100, NFIT_COF_VAL, (NFIT_COF_BAS * NFIT_COF_ALI)/100 
--update nfit set nfit_pis_val = (NFIT_PIS_BAS * NFIT_PIS_ALI)/100, NFIT_COF_VAL = (NFIT_COF_BAS * NFIT_COF_ALI)/100
from nfit, NFNF
where NFIT_SIES = NFNF_SIES
			and NFIT_SIDO = NFNF_SIDO
			and NFIT_SISE = NFNF_SISE
			and NFIT_NFNF = NFNF_COD
			and convert(varchar(10),NFNF_DAT,102) between '2008.06.01' and '2008.12.31'
			and NFIT_CFOP = '5.929'
			and nfit_sido = 'FTNF'


select nfit_pis_val, (NFIT_PIS_BAS * NFIT_PIS_ALI)/100, NFIT_COF_VAL, (NFIT_COF_BAS * NFIT_COF_ALI)/100 
--update nfit set nfit_pis_val = (NFIT_PIS_BAS * NFIT_PIS_ALI)/100, NFIT_COF_VAL = (NFIT_COF_BAS * NFIT_COF_ALI)/100
from nfit
where nfit_nfnf in (258803,258875,258947,259020,259100,259164,259246,259310,259358,259407,259477,259561,259648,259732,259810,259866)
			and nfit_sido = 'FTNF'
			
select *
--update nfit set NFIT_PIS_CST = '98', NFIT_COF_CST = '98', NFIT_PIS_NAT = '00', NFIT_COF_NAT = '00'
from nfit, NFNF
where NFIT_SIES = NFNF_SIES
			and NFIT_SIDO = NFNF_SIDO
			and NFIT_SISE = NFNF_SISE
			and NFIT_NFNF = NFNF_COD
			and convert(varchar(10),NFNF_DAT,102) between '2008.06.01' and '2008.12.31'
			and NFIT_NFOP = '3.101.BD'
			and (NFIT_PIS_CST <> '98' or NFIT_COF_CST <> '98')
