--TROCA DE CODIGO PARA ESTRUTURA
--SELECIONAR OS C�DIGOS A SEREM ALTERADOS E SEUS (#MTPR) 
--RECRIAR OS C�DIGOS QUE N�O EXISTEM (MTPR E MTES)
--ALTERAR OS C�DIGOS PAI PARA PARA INTERMEDIARIO
--DESATIVAR OS C�DIGOS PAI
--CRIAR A ESTRUTURA DOS C�DIGOS (MTEP)
--ATIVAR OS C�DIGOS PAI
--TRANSFERIR O SALDO DO ANTIGO(FILHO) PARA O NOVO(PAI) (GIRMAT)
--COPIAR O CONSUMO M�DIO DO PAI PARA CONSUMO ESTIMADO FILHO
--RECRIAR AS COTA��ES DE COMPRAS

--B11 - B10
--B21 - B20IF OBJECT_ID('TempDB.dbo.#MTEP') IS NOT NULL DROP TABLE #MTEPSELECT *, IDENTITY(INT,1,1) NUM  INTO #MTEP FROM MTEP WHERE 1 = 0INSERT INTO #MTEPSELECT 		stuff(stuff(MTEP_PAI,7,0,'.'),4,0,'.') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') C�digo (Pai)
	, stuff(stuff(MTEP_FIL,7,0,'.'),4,0,'.') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ --= CONVERT(int(4),'')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD --= Null      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT --= Null      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--select * --[].[].[].
--from [192.168.3.39].[SIDOR].[dbo].mtep
from [MDLMEX].[dbo].mtep
where SUBSTRING(mtep_pai,1,3) IN ('B11', 'B21')--select * from #MTEP insert into #mtepselect   replace(replace(replace(replace(replace(mtep_pai,'.020.', '.019.'),'.025.','.024.'),'.032.','.030.'),'.040.','.038.'),'.050.','.048.') MTEP_PAI ,replace(replace(replace(replace(replace(mtep_fil,'.020.', '.019.'),'.025.','.024.'),'.032.','.030.'),'.040.','.038.'),'.050.','.048.') MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU from mtpr a, #MTEP bwhere MTPR_ATV = 'S' 			and SUBSTRING(mtpr_cod,1,3) in ('B11') 			and mtpr_cod not in (select mtep_pai from #MTEP)			and replace(replace(replace(replace(replace(mtpr_cod,'.019.','.020.'),'024','025'),'030','032'),'038','040'),'048','050') = mtep_paiinsert into #mtepselect replace(replace(replace(replace(replace(mtep_pai,'.020.', '.019.'),'.025.','.024.'),'.032.','.030.'),'.040.','.038.'),'.050.','.048.') MTEP_PAI ,replace(replace(replace(replace(replace(mtep_fil,'.020.', '.019.'),'.025.','.024.'),'.032.','.030.'),'.040.','.038.'),'.050.','.048.') MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU from mtpr a, #MTEP bwhere MTPR_ATV = 'S' 			and SUBSTRING(mtpr_cod,1,3) in ('B21') 			and mtpr_cod not in (select mtep_pai from #MTEP)			and replace(replace(replace(replace(replace(mtpr_cod,'019','020'),'024','025'),'030','032'),'038','040'),'048','050') = mtep_pai--select * from mtpr where MTPR_ATV = 'S' and SUBSTRING(mtpr_cod,1,3) in ('B11') and mtpr_cod not in (select mtep_pai from #MTEP)--select * from mtpr where MTPR_ATV = 'S' and SUBSTRING(mtpr_cod,1,3) in ('B21') and mtpr_cod not in (select mtep_pai from #MTEP)INSERT INTO #MTEPSELECT 		stuff(stuff(MTEP_PAI,7,0,'.'),4,0,'.') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') C�digo (Pai)
	, stuff(stuff(MTEP_FIL,7,0,'.'),4,0,'.') --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ --= CONVERT(int(4),'')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD --= Null      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT --= Null      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--select * --[].[].[].
--from [192.168.3.39].[SIDOR].[dbo].mtep
from [MDLMEX].[dbo].mtep
where SUBSTRING(mtep_pai,1,3) IN ('B01', 'B02')			and mtep_pai not like ('%I2')			and mtep_pai not like ('%I3')			and mtep_pai not like ('%I4')UPDATE mtpr set MTPR_ATV = 'N'from mtpr, #mtepwhere mtep_pai = mtpr_codand mtep_seq = 1--select *UPDATE mtpr set MTPR_MTTP = 'PI-PRODUTO INTERMEDI�RIO'from mtpr, #mtepwhere mtep_pai = mtpr_cod/*--SABER QUAIS ITENS N�O FORAM CADASTRADOSSELECT *FROM #MTEP WHERE MTEP_PAI NOT IN (SELECT MTPR_COD FROM MTPR)SELECT *FROM #MTEP WHERE MTEP_FIL NOT IN (SELECT MTPR_COD FROM MTPR)*/--select * --delete from mtep where mtep_pai like 'P22%'--KITS QUE N�O EST�O CADASTRADOSIF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT *, MTPR_COD MTPR_COD_OLD, identity(int,1,1) NUM INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPR--select * from #mtprselect MTEP_FIL MTPR_COD ,'PA-PRODUTO ACABADO' MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_FEST ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU, MTEP_PAIfrom mtpr, #mtepwhere mtep_pai = mtpr_codand mtep_seq = 1--select * from #mtprINSERT INTO #MTPRSELECT 		MTPR_COD = CONVERT(varchar(20),MTEP_FIL)      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = CONVERT(varchar(25),'PI-PRODUTO INTERMEDI�RIO')      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = CONVERT(varchar(80),'KIT')      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = CONVERT(varchar(4),'2500')      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = CONVERT(varchar(4),'3100')      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),'3910')      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = CONVERT(varchar(3),'PC')      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = CONVERT(varchar(8),'84669410')      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, MTPR_PES = CONVERT(decimal(13,3),'0')      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = Null      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = Null      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = Null      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = Null      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = Null      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = CONVERT(char(1),'N')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = Null      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = CONVERT(decimal(12),'5')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_FEST = NULL --CONVERT(decimal(12),'5')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	, MTEP_FIL
	--SELECT *FROM #MTEP WHERE MTEP_FIL NOT IN (SELECT replace(MTPR_COD,'.','') FROM MTPR)and mtep_seq = 2GROUP BY MTEP_FIL
--select * from #mtprINSERT INTO MTPRSELECT MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_FEST ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTUFROM #MTPRWHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)
ORDER BY MTPR_COD--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU
IF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = CONVERT(varchar(20),mtpr_cod)      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES --= CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, MTES_MTAL --= CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN --= CONVERT(varchar(6),'ALMO01')	--Null      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP --= CONVERT(varchar(6),'PROCES')	--Null      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE --= CONVERT(char(1),'N')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD --= CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU --= Null      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU --= Null      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM --= Null      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS --= Null      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC --= Null      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO --= Null      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME --= Null      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR --= Null      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN --= Null      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ --= Null      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM --= Null      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI --= Null      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM --= Null      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL --= Null      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC --= Null      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO --= Null      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD --= Null      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM --= Null      --CONVERT(int(8),'') LT Urg�ncia (dias)
	, MTES_EXPL --= CONVERT(char(1),'S')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP --= CONVERT(char(1),'S')      --CONVERT(char(1),'') Pol�tica
	, MTES_CREP --= Null      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR --= Null      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF --= Null      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT --= CONVERT(int,'0')      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT --= Null      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 --= Null      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 --= Null      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 --= Null      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 --= Null      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT --= Null      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *FROM #MTPR, MTESWHERE MTPR_COD_OLD = MTES_MTPRAND MTES_SIES = 5	--SELECT b.*	--update mtes set MTES_EXPL = 'S'FROM #MTPR a, MTES bWHERE MTPR_COD_OLD = MTES_MTPRAND MTES_SIES = 5--WHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)
INSERT INTO MTESSELECT *FROM #MTESWHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR FROM MTES)
--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU
--ATIVAR select *--UPDATE MTPR SET MTPR_ATV = 'N'--update mtpr set MTPR_MTTP = 'PI-PRODUTO INTERMEDI�RIO'SELECT b.*--UPDATE MTPR SET MTPR_ATV = 'S'FROM #MTPR a, MTPR bWHERE a.MTPR_COD = b.MTPR_COD			AND b.MTPR_ATV = 'N'--select * from #mtepDECLARE@I INT SET @I = 1WHILE (SELECT @I)<=355 BEGIN	INSERT INTO MTEP	SELECT MTEP_PAI ,MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU	FROM #MTEP	WHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP)
	and NUM = @i
	--WHERE MTEP_PAI+'/'+MTEP_FIL+'/'+CONVERT(varchar(20),MTEP_SEQ) NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL+'/'+CONVERT(varchar(20),MTEP_SEQ) FROM MTEP)
				--AND MTEP_PAI = 'P22.080.500'--+10	PRINT @I	SET @I=@I+1ENDUPDATE MTPR SET MTPR_ATV = 'S'--select *from mtpr, #mtepwhere mtep_pai = mtpr_codand mtep_seq = 1UPDATE MTPR SET MTPR_ATV = 'S'--select a.*from mtpr a, #mtpr bwhere a.mtpr_cod = b.mtpr_codselect count(1) from #mtpr where MTPR_MTTP ='PA-PRODUTO ACABADO' and num @i and substring(mtpr_cod,1,4) <> 'B01.' and substring(mtpr_cod,1,4) <> 'B02.'--MTEP_PAI ,MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU ,
DECLARE@i INT,@j1 int,@j2 int,@qtd decimal(12,2),@cod varchar(20),@cod_new varchar(20),@erro varchar(4000),@modo char(1),@DATA Datetime,@ano int,@mes int
set @i = 1set @erro = ''set @data = GETDATE()--select * from #mtprWHILE @i <= (SELECT MAX(NUM) FROM #MTPR) BEGIN	IF (select count(1) from #mtpr where MTPR_MTTP ='PA-PRODUTO ACABADO' and num = @i and substring(mtpr_cod,1,4) <> 'B01.' and substring(mtpr_cod,1,4) <> 'B02.') > 0 BEGIN		select @ano = year(getdate()), @mes = month(getdate())		select @cod = MTPR_COD_OLD, @cod_new = MTPR_COD from #mtpr where num = @i and  MTPR_COD_OLD <> ''		exec MT_MTSW_SALDO @cod, 5, @ano, @mes, 'ALMO01', '', '', @qtd output, 0, 0, 0		if (select @qtd)>0 begin 			print 'NUM ='+convert(varchar(10),@i)+'O C�digo � = '+@cod+ ' e seu saldo � '+convert(varchar(20),@qtd)+'  tranferir o saldo para o c�digo = '+@cod_new			set @modo = 'I'			Exec MTTD_iae   @modo output  ,@erro output  ,5  ,'MTTD', '001', 0 , @DATA,'GIRMAT' ,@COD			,'ALMO01', @QTD, @COD_NEW	,'ALMO01', @QTD,'','KINKEL'  ,@DATA  ,NULL  ,NULL
			--print 'Exec MTTD_iae   @modo output  ,@erro output  ,5  ,MTTD, 001, 0 , @DATA,GIRMAT ,'+@COD+'			,ALMO01, @QTD, @COD_NEW	,'--ALMO01', @QTD,'','KINKEL'  ,@DATA  ,NULL  ,NULL
			print @modo + '/'+@erro
		end	END	set @i = @i + 1ENDDROP TABLE #PCMRSELECT MTPR_COD COD, MTES_PCMR VALINTO #PCMRFROM MTES, #MTPRWHERE MTPR_COD_OLD = MTES_MTPRAND MTES_SIES = 5SELECT *--UPDATE MTES SET MTES_PCME = VALFROM MTES, #PCMRWHERE MTES_MTPR = CODAND MTES_SIES = 5DECLARE@j1 int,@j2 intSELECT @j1 = SISE_NUM FROM SISE WHERE SISE_SIDO = 'CPCT' and sise_sies = 5select @j1IF OBJECT_ID('TempDB.dbo.#CPCT') IS NOT NULL DROP TABLE #CPCTSELECT *, CPCT_COD CPCT_COD_OLD, identity(int,1,1) NUM  INTO #CPCT FROM CPCT WHERE 1 = 0INSERT INTO #CPCTSELECT distinct		CPCT_SIES = CONVERT(int,5)      --CONVERT(int(6),'') E
	, CPCT_SIDO --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tipo
	, CPCT_SISE --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�rie
	, CPCT_COD = CONVERT(int,0)      --CONVERT(int(3),'') N�mero
	, CPCT_STA --= CONVERT(char(2),'')      --CONVERT(char(2),'') Status
	, CPCT_CPSC_SIES --= Null      --CONVERT(int(6),'') E.
	, CPCT_CPSC_SIDO --= Null      --CONVERT(varchar(4),'') Tipo
	, CPCT_CPSC_SISE --= Null      --CONVERT(varchar(3),'') S�rie
	, CPCT_CPSC_NPAI --= Null      --CONVERT(int(6),'') Solicita��o
	, CPCT_CPSC --= Null      --CONVERT(int(3),'') Item
	, CPCT_MTPR = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') Insumo
	, CPCT_MTPC = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, CPCT_ESPE --= Null      --CONVERT(varchar(6000),'') Especifica��es
	, CPCT_GLTX --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tipo
	, CPCT_GLXX --= CONVERT(int(6),'')      --CONVERT(int(6),'') Fornecedor
	, CPCT_GLXX_DIG --= CONVERT(int(3),'')      --CONVERT(int(3),'') Digito
	, CPCT_GLXX_GLPA --= CONVERT(int(6),'')      --CONVERT(int(6),'') C�d.Parceiro
	, CPCT_GLXX_NRDZ --= Null      --CONVERT(varchar(15),'') Apelido
	, CPCT_REV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Destina��o
	, CPCT_QTD --= Null      --CONVERT(decimal(12),'') Quantidade
	, CPCT_QTD_GLFO --= Null      --CONVERT(decimal(12),'') Qtd.Forn.
	, CPCT_CTO --= Null      --CONVERT(varchar(25),'') Contato
	, CPCT_TEL --= Null      --CONVERT(varchar(25),'') Fone
	, CPCT_FAX --= Null      --CONVERT(varchar(25),'') Fax
	, CPCT_EMAIL --= Null      --CONVERT(varchar(50),'') Email
	, CPCT_GLCP = CONVERT(int,'4')      --CONVERT(int(6),'') Comprador
	, CPCT_CPID --= Null      --CONVERT(varchar(20),'') Ref. Forn.
	, CPCT_CPUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Un.Forn.
	, CPCT_CPFT --= CONVERT(decimal(10),'')      --CONVERT(decimal(10),'') Fator Un.
	, CPCT_PUN --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o
	, CPCT_PUN_GLFO --= Null      --CONVERT(decimal(12),'') Pre�o Un. Forn.
	, CPCT_PUND --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o c/ Desc.
	, CPCT_PUND_GLFO --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.
	, CPCT_VACT --= CONVERT(int(3),'')      --CONVERT(int(3),'') Validade (dias)
	, CPCT_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda
	, CPCT_IPI_ALI --= Null      --CONVERT(decimal(5),'') % IPI
	, CPCT_ISS_ALI --= Null      --CONVERT(decimal(5),'') % ISS
	, CPCT_ICM_ALI --= Null      --CONVERT(decimal(5),'') % ICMS
	, CPCT_VALT --= Null      --CONVERT(decimal(12),'') Total c/ IPI
	, CPCT_GLPG --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Pagamento
	, CPCT_PENT --= CONVERT(int(3),'')      --CONVERT(int(3),'') Entrega (dias �teis)
	, CPCT_DOCF = CONVERT(varchar(20),'REF.'+CONVERT(CHAR(2),MONTH(GETDATE()))+CONVERT(CHAR(2),YEAR(GETDATE())) ) -- Doc.Fornec.
	, CPCT_OBS = CONVERT(varchar(255),'') -- Obs.
	, CPCT_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, CPCT_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, CPCT_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, CPCT_DTU = Null      --CONVERT(datetime(10),'') em
	, CPCT_CPID_NOM --= Null      --CONVERT(varchar(50),'') Nome For.
	, CPCT_COD
	--select distinct *from #mtpr, cpctwhere MTPR_COD_OLD = cpct_mtprand cpct_sies = 5and cpct_sta = 'OK'and substring(mtpr_cod,1,4) <> 'B01.' and substring(mtpr_cod,1,4) <> 'B02.'and MTPR_MTTP ='PA-PRODUTO ACABADO'--select *UPDATE CPCT SET cpct_sta = 'EC'from cpct a, #cpct bwhere a.cpct_cod = b.cpct_cod_oldand a.cpct_sies = 5and a.cpct_sta = 'OK'INSERT INTO CPCTSELECT CPCT_SIES ,CPCT_SIDO ,CPCT_SISE ,(@j1+ NUM) CPCT_COD ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC ,CPCT_MTPR ,CPCT_MTPC ,CPCT_ESPE ,CPCT_GLTX ,CPCT_GLXX ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ ,CPCT_REV ,CPCT_QTD ,CPCT_QTD_GLFO ,CPCT_CTO ,CPCT_TEL ,CPCT_FAX ,CPCT_EMAIL ,CPCT_GLCP ,CPCT_CPID ,CPCT_CPUN ,CPCT_CPFT ,CPCT_PUN ,CPCT_PUN_GLFO ,CPCT_PUND ,CPCT_PUND_GLFO ,CPCT_VACT ,CPCT_GLMD ,CPCT_IPI_ALI ,CPCT_ISS_ALI ,CPCT_ICM_ALI ,CPCT_VALT ,CPCT_GLPG ,CPCT_PENT ,CPCT_DOCF ,CPCT_OBS ,CPCT_USC ,CPCT_DTC ,CPCT_USU ,CPCT_DTU ,CPCT_CPID_NOMFROM #CPCT--WHERE CONVERT(VARCHAR(6),CPCT_SIES)+'/'+ NOT IN (SELECT CONVERT(VARCHAR(6),CPCT_SIES)FROM CPCT)
order by CPCT_COD--select * from #mtpc where cod not in (select cpct_mtpr from cpct where cpct_sies = 5 and cpct_sta = 'OK')--CPCT_SIES ,CPCT_SIDO ,CPCT_SISE ,CPCT_COD ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC ,CPCT_MTPR ,CPCT_MTPC ,CPCT_ESPE ,CPCT_GLTX ,CPCT_GLXX ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ ,CPCT_REV ,CPCT_QTD ,CPCT_QTD_GLFO ,CPCT_CTO ,CPCT_TEL ,CPCT_FAX ,CPCT_EMAIL ,CPCT_GLCP ,CPCT_CPID ,CPCT_CPUN ,CPCT_CPFT ,CPCT_PUN ,CPCT_PUN_GLFO ,CPCT_PUND ,CPCT_PUND_GLFO ,CPCT_VACT ,CPCT_GLMD ,CPCT_IPI_ALI ,CPCT_ISS_ALI ,CPCT_ICM_ALI ,CPCT_VALT ,CPCT_GLPG ,CPCT_PENT ,CPCT_DOCF ,CPCT_OBS ,CPCT_USC ,CPCT_DTC ,CPCT_USU ,CPCT_DTU ,CPCT_CPID_NOM ,
select @j1 = @j1 + max(NUM)from #CPCTUPDATE SISE
SET SISE_NUM = @J1--select * from siseWHERE SISE_SIDO = 'CPCT'			and sise_sies = 5
