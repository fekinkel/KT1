
IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #new

select PROR_SIES SIES, PROR_SIDO SIDO, PROR_SISE SISE, PROR_COD COD, vdpi_sies, vdpi_sido, vdpi_sise, vdpi_vdpd, vdpi_cod, b.vdpi_sta--, *
into #new
from pror a left join vdpi b on PROR_SIEX = vdpi_sies and PROR_SIDX = vdpi_sido and	PROR_SISX = vdpi_sise	and PROR_NPAX = vdpi_vdpd and PROR_CODX = vdpi_cod and vdpi_sta <> 'OK'
where pror_sta = 'EA'
and pror_sies = 5
and PROR_SIDX = 'VDPD'

order by PROR_cod

select *
--ALTER TABLE PROR DISABLE TRIGGER ALL UPDATE PROR SET PROR_STA = 'EC'
from #new, pror
where vdpi_sies is not null
and vdpi_sta = 'CA'
AND PROR_SIES = SIES
AND	PROR_SIDO = SIDO
AND	PROR_SISE = SISE
AND	PROR_COD  = COD

ALTER TABLE PROR ENABLE TRIGGER ALL

select *
--ALTER TABLE PROR DISABLE TRIGGER ALL UPDATE PROR SET PROR_STA = 'EC'
from #new, prnc
where vdpi_sies is not null
and vdpi_sta = 'CA'
AND PRnc_SIES = vdpi_SIES
AND	PRnc_SIDO = vdpi_SIDO
AND	PRnc_SISE = vdpi_SISE
AND	PRnc_npai = vdpi_vdpd
AND PRNC_COD  = VDPI_COD

select *
--ALTER TABLE PROR DISABLE TRIGGER ALL UPDATE PROR SET PROR_STA = 'EC'
from #new, pror
where vdpi_sies is not null
--and vdpi_sta = 'CA'
AND PROR_SIES = SIES
AND	PROR_SIDO = SIDO
AND	PROR_SISE = SISE
AND	PROR_COD  = COD
