select *
--delete
from CFCP
where CFCP_NEXT like 'PROVI%'
			and CFCP_STA = 'OK'
			and convert(varchar(10),CFCP_DTV,102) = '2014.01.01'
