
--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 15/01/2018--DEPARTAMENTO : 15/01/2018--ASSUNTO      : 15/01/2018------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#SIMO') IS NOT NULL DROP TABLE #SIMOSELECT * INTO #SIMO FROM SIMO WHERE 1 = 0INSERT INTO #SIMOSELECT 		SIMO_SIMD = CONVERT(varchar(20),'Produ��o')      --CONVERT(varchar(20),'') M�dulo(C�digo do m�dulo de aplicativo)
	, SIMO_SIOP = SIOP_COD --CONVERT(varchar(50),'Produ��o')      --CONVERT(varchar(50),'') Op��o(Op��o)
	, SIMO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, SIMO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, SIMO_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, SIMO_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM SIOP
WHERE CONVERT(VARCHAR(10),SIOP_DTC,102) >= '2017.01.01'
AND SIOP_NOM LIKE '%APON%'
INSERT INTO SIMOSELECT *FROM #SIMOWHERE SIMO_SIMD+'/'+SIMO_SIOP NOT IN (SELECT SIMO_SIMD+'/'+SIMO_SIOP FROM SIMO)
--SIMO_SIMD ,SIMO_SIOP ,SIMO_USC ,SIMO_DTC ,SIMO_USU ,SIMO_DTU ,


--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 15/01/2018--DEPARTAMENTO : 15/01/2018--ASSUNTO      : 15/01/2018------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#SIGO') IS NOT NULL DROP TABLE #SIGOSELECT * INTO #SIGO FROM SIGO WHERE 1 = 0INSERT INTO #SIGOSELECT 		SIGO_SIGR = CONVERT(varchar(15),'S2RXE_FABRICA')      --CONVERT(varchar(15),'') Grupo(Grupo de usu�rios)
	, SIGO_SIAP = CONVERT(varchar(6),'S2RXE')      --CONVERT(varchar(6),'') Aplicativo(C�digo do aplicativo)
	, SIGO_SIMD = CONVERT(varchar(20),'Produ��o')      --CONVERT(varchar(20),'') M�dulo(C�digo do m�dulo de aplicativo)
	, SIGO_SIOP = SIOP_COD --CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Op��o(Op��o)
	, SIGO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, SIGO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, SIGO_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, SIGO_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	--SELECT *
FROM SIOP
WHERE CONVERT(VARCHAR(10),SIOP_DTC,102) >= '2017.01.01'
AND SIOP_NOM LIKE '%APON%'
INSERT INTO SIGOSELECT *FROM #SIGOWHERE rtrim(ltrim(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD))+'/'+RTRIM(LTRIM(SIGO_SIOP)) NOT IN (SELECT rtrim(ltrim(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD))+'/'+RTRIM(LTRIM(SIGO_SIOP))
FROM SIGO
WHERE SIGO_SIGR = 'S2RXE_FABRICA'
)
--SIGO_SIGR ,SIGO_SIAP ,SIGO_SIMD ,SIGO_SIOP ,SIGO_USC ,SIGO_DTC ,SIGO_USU ,SIGO_DTU ,


