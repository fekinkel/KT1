select RCIT_SIDP, cpip_sido , RCIT_SISP, cpip_sise, RCIT_CODP, cpip_cppc, RCIT_CODI, cpip_cod
--UPDATE RCIT SET RCIT_SIDP = cpip_sido , RCIT_SISP = cpip_sise, RCIT_CODP = cpip_cppc, RCIT_CODI = cpip_cod
from rcit a, mtmv b, cpip c
where rcit_sies = 5
and rcit_rcnf = 46577
and mtmv_mttr = 'COMPRA'
and MTMV_COD_ORI = rcit_rcnf
and MTMV_SIDX = 'RCNF'
and mtmv_sies = rcit_sies
and RCIT_COD = MTMV_SEQ_ORI
and CPIP_CPSC_SIES = mtmv_sies	
and CPIP_CPSC_SIDO = MTMV_SIDO_DES 	
and CPIP_CPSC_SISE = MTMV_SISE_DES
and CPIP_CPSC_NPAI = MTMV_COD_DES	
and CPIP_CPSC = MTMV_SEQ_DES



