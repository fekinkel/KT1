select ornf_dat, *
--update orcp set ORCP_DAT = ornf_dat
from orcp, ornf
where orcp_sies = ornf_sies
and ORCP_SIDO = ornf_sido
and	ORCP_SISE	= ornf_sise
and ORCP_COD  = ornf_cod
and ORCP_DAT <> ornf_dat
