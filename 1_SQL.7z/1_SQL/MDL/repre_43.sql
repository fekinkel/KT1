--BA - Salvaldor - CEP: 40000-001 at� CEP: 42599-999
--PE - Recife - CEP: 50000-001 at� CEP: 52599-999
--SE - Aracaru - CEP: 49000-001 at� CEP: 49098-999
--AL - Macei� - CEP: 57000-001 at� CEP: 57099-999
--PB - Jo�o Pessoa - CEP: 58000-001 at� CEP: 58099-999
--RN - Natal - CEP: 59000-001 at� CEP: 59139-999
--CE - Fortaleza - CEP: 60000-001 at� CEP: 61599-999

select GLPA_GLRG, glpa_cep, *
from glpa
where glpa_cep between '40000000' and '42599999'
or glpa_cep between '50000000' and '52599999'
or glpa_cep between '49000000' and '49098999'
or glpa_cep between '57000000' and '57099999'
or glpa_cep between '58000000' and '58099999'
or glpa_cep between '59000000' and '59139999'
or glpa_cep between '60000000' and '61599999'
order by GLPA_GLRG, glpa_cod

select glcl_cod, GLPA_NOM ,GLPA_NRDZ ,GLPA_GLPS ,GLPA_PJPF ,GLPA_GLCT ,GLPA_CNPJ ,GLPA_IES ,GLPA_IMU ,GLPA_CPF ,GLPA_RG ,GLPA_GLRG ,GLPA_END ,GLPA_BAI ,GLPA_CID ,GLPA_GLUF ,GLPA_CEP ,GLPA_TEL ,GLPA_FAX ,GLPA_CTO ,GLPA_EMAIL ,GLPA_SITE ,GLPA_USPJ ,GLPA_CNAE ,GLPA_DTPJ, GLPA_REGI ,GLPA_SKIPE ,GLPA_LAT1 ,GLPA_LAT2 ,GLPA_LAT3 ,GLPA_LAT4 ,GLPA_LON1 ,GLPA_LON2 ,GLPA_LON3 ,GLPA_LON4 ,GLPA_GLMN ,GLPA_NUME ,GLPA_COMP
--update glcl set glcl_glvd = 43
--update glpa set GLPA_GLRG = 'NORD'
from glpa a, glcl b
where glpa_cod = glcl_glpa
--and glcl_atv = 'S'
and GLPA_GLUF in ('BA', 'PE', 'SE', 'AL', 'PB', 'RN', 'CE')
--and len(glpa_cep)<8
order by GLPA_GLUF, glpa_cod

