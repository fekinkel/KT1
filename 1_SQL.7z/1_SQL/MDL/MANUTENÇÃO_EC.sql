DROP TABLE #PRMLSELECT * INTO #PRML FROM PRML WHERE 1 = 0INSERT INTO #PRMLSELECT 
		PRML_SIES = CONVERT(int,PRMA_SIES)      --CONVERT(int(6),'') Estab.
	, PRML_SIDO = CONVERT(varchar(4), PRMA_SIDO)      --CONVERT(varchar(4),'') Tipo
	, PRML_SISE = CONVERT(varchar(3),PRMA_SISE)      --CONVERT(varchar(3),'') S�rie
	, PRML_PRMA = CONVERT(int,PRMA_COD)      --CONVERT(int(6),'') N�mero
	, PRML_COD = CONVERT(int,'999')      --CONVERT(int(3),'') Sequ�ncia
	, PRML_LOG = CONVERT(varchar(4000),'ENCERRAMENTO MANUAL')      --CONVERT(varchar(4000),'') Log
	, PRML_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, PRML_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, PRML_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, PRML_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
--update prma set PRMA_STA = 'EC', PRML_LOG = 'ENCERRAMENTO'
from prma
where PRMA_STA <> 'EC'
			and CONVERT(varchar(10),prma_dtc, 102) between '2000.12.31' and '2012.12.31'
INSERT INTO PRMLSELECT *FROM #PRMLWHERE CONVERT(VARCHAR(6),PRML_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),PRML_SIES)FROM PRML)
--PRML_SIES ,PRML_SIDO ,PRML_SISE ,PRML_PRMA ,PRML_COD ,PRML_LOG ,PRML_USC ,PRML_DTC ,PRML_USU ,PRML_DTU ,

select TOP 1 *
--update prma set PRMA_LOG = 'ENCERRAMENTO MANUAL'
from prma
where PRMA_STA <> 'EC'
			and CONVERT(varchar(10),prma_dtc, 102) between '2000.12.31' and '2012.12.31'
			AND PRMA_COD = 429

select TOP 1 *
--update prma set PRMA_STA = 'EC', PRMA_LOG = 'ENCERRAMENTO MANUAL'
from prma
where PRMA_STA <> 'EC'
			and CONVERT(varchar(10),prma_dtc, 102) between '2000.12.31' and '2012.12.31'
