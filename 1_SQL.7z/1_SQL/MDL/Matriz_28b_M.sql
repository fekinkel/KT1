--Ativar
--Verificar com A.C. PI ou PA
--CRIAR cod MB.100.20.5B
--FINAL B
IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT * INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD = CONVERT(varchar(20),substring(a.mtpr_cod,1,1)+substring(a.mtpr_cod,3,len(a.mtpr_cod)))      --CONVERT(varchar(20),'') Insumo
	, b.MTPR_MTTP --= CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo
	, b.MTPR_MS --= CONVERT(char(1),'')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, b.MTPR_NOM --= CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome
	, b.MTPR_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o
	, b.MTPR_MTLN --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha
	, b.MTPR_MTFM --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia
	, b.MTPR_MTUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade
	, b.MTPR_MTNC --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM
	, b.MTPR_ORI --= CONVERT(char(1),'')      --CONVERT(char(1),'') Origem
	, b.MTPR_PES --= CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg
	, b.MTPR_DES --= Null      --CONVERT(varchar(240),'') Descri��o
	, b.MTPR_NIV --= Null      --CONVERT(int(6),'') N�vel
	, b.MTPR_ESUN --= Null      --CONVERT(varchar(3),'') Un.Estrutura
	, b.MTPR_ESFT --= Null      --CONVERT(decimal(10),'') Fator Un.
	, b.MTPR_CPUN --= Null      --CONVERT(varchar(3),'') Un.Compra
	, b.MTPR_CPFT --= Null      --CONVERT(decimal(10),'') Fator Un.
	, b.MTPR_ATVV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo
	, b.MTPR_CFOV --= Null      --CONVERT(varchar(8),'') CFOP Venda
	, b.MTPR_ATVC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Compro
	, b.MTPR_CFOC --= Null      --CONVERT(varchar(8),'') CFOP Compra
	, b.MTPR_TOLE --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from mtpr a, mtpr b
where substring(a.mtpr_cod,1,3) = 'MB.'
and a.mtpr_atv = 's'and b.mtpr_cod = 'M.060.20.3A'--and mtpr_cod = 'MB.100.20.8B'INSERT INTO MTPRSELECT *FROM #MTPRwhere mtpr_cod not in (select mtpr_cod from mtpr)--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU ,

DROP TABLE #NEW
select *
into #new
from mtpr
where substring(mtpr_cod,1,2) = 'M.'
and substring(mtpr_cod,len(mtpr_cod),1) = 'B'


--Desativar A
update mtpr set mtpr_atv = 'N'
--select *
from mtpr a, #NEW b
where substring(a.mtpr_cod,1,2) = 'M.'
and substring(a.mtpr_cod,len(a.mtpr_cod),1) = 'A'
and substring(a.mtpr_cod,1,len(a.mtpr_cod)-1) = substring(b.mtpr_cod,1,len(b.mtpr_cod)-1)

IF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = MTPR_COD      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.
	, MTES_MTAL --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN --= Null      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP --= Null      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU --= Null      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU --= Null      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM --= Null      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS --= Null      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC --= Null      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO --= Null      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME --= Null      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR --= Null      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN --= Null      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ --= Null      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM --= Null      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI --= Null      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM --= Null      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL --= Null      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC --= Null      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO --= Null      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD --= Null      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM --= Null      --CONVERT(int(8),'') LT Urg�ncia (dias)
	, MTES_EXPL --= CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP --= CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica
	, MTES_CREP --= Null      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR --= Null      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF --= Null      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT --= CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT --= Null      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 --= Null      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 --= Null      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 --= Null      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 --= Null      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT --= Null      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from mtes a, #MTPR b
where a.mtes_mtpr = 'M.060.20.3B'
and mtes_sies = 5

INSERT INTO MTESSELECT *FROM #MTESWHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR FROM MTES)


update mtpr set mtpr_atv = 'N'
--select *
from mtpr a, #NEW b
where substring(a.mtpr_cod,1,2) = 'M.'
--and substring(a.mtpr_cod,len(a.mtpr_cod),1) = 'B'
and a.mtpr_cod = b.mtpr_cod

IF OBJECT_ID('TempDB.dbo.#MTEP') IS NOT NULL DROP TABLE #MTEPSELECT * INTO #MTEP FROM MTEP WHERE 1 = 0INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),substring(a.mtpr_cod,1,1)+substring(a.mtpr_cod,3,len(a.mtpr_cod)))      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),mtpr_cod)      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = 1--Null      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = 0--Null      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from mtpr a
where substring(a.mtpr_cod,1,3) = 'MB.'
and a.mtpr_atv = 's'
INSERT INTO MTEPSELECT TOP 1 *FROM #MTEPWHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP)

update mtpr set mtpr_atv = 'S'
--select *
from mtpr a, #MTPR b
where a.mtpr_cod = B.mtpr_cod
--and substring(a.mtpr_cod,len(a.mtpr_cod),1) = 'B'


--ATUALIZAR PRE�O
drop table #mtpc
SELECT mtpr_cod, mtpc_mtpr, mtpc_pre pre
into #mtpc
FROM MTPC a, #NEW b
WHERE a.MTPC_MTPR = reverse(substring(reverse(b.MTPR_COD),2,len(b.mtpr_cod)))+'A'

update mtpc set mtpc_pre = pre
--select *
from mtpc a, #mtpc b
where a.mtpc_mtpr = b.mtpr_cod




