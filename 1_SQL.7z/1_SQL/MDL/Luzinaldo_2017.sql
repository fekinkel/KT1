select convert(varchar(10),vdco_dtc,103) Data
, vdco_sta [Status]
, vdco_cod [N�mero]
, convert(varchar(6),vdco_glcl)+'/'+convert(varchar(6),vdco_glcl_dig) [Cod. Cliente] 
, a.glpa_nom [Nome do Cliente]
, vdco_glvd [Cod. Vendedor]
, b.glpa_nom [Vendedor]
, VDCO_OBS_STA [Motivo]
, vdco_usc [Cadastrado por]
, vdc1_qtde [Quantidade]
, vdc1_mtpc [Refer�ncia]
, vdc1_mtdv [Divis�o]
, vdc1_mtln [Linha]
, vdc1_mtfm [Fam�lia]
, vdc1_puni [Pre�o Uni.]
, vdc1_punid [Pre�o c/ desc Uni.]
, vdc1_desc [Desconto %]
, vdc1_puni*vdc1_qtde [Pre�o]
, vdc1_punid*vdc1_qtde [Pre�o c/ desc]
, GLCL_MTLP [Lista Pre�o]
from vdco, glpa a, glvd, glpa b, vdc1 c, glcl d
--where convert(varchar(10),vdco_dtc,102) between	'2012.01.01' and '2012.12.31'	
--where convert(varchar(10),vdco_dtc,102) between	'2013.01.01' and '2013.12.31'	
--where convert(varchar(10),vdco_dtc,102) between	'2014.01.01' and '2014.12.31'	
--where convert(varchar(10),vdco_dtc,102) between	'2015.01.01' and '2015.12.31'	
--where convert(varchar(10),vdco_dtc,102) between	'2016.01.01' and '2016.12.31'	
where convert(varchar(10),vdco_dtc,102) between	'2017.01.01' and '2017.06.20'	
and vdco_glpa = a.glpa_cod
and vdco_glvd = glvd_cod
and glvd_glpa = b.glpa_cod
and vdco_sies = vdc1_sies
and vdco_sido = vdc1_sido
and vdco_sise = vdc1_sise
and vdco_cod  = vdc1_vdco
and vdc1_sub  = 0
and glcl_cod = VDCO_GLCL
and glcl_dig = vdco_glcl_dig


