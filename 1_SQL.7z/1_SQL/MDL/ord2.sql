drop table #new
-------------------
select a.*,d.*--convert(varchar(6),PROR_SIEX)+'/'+PROR_SIDX+'/'+PROR_SISX+'/'+convert(varchar(6),PROR_NPAX)+'/'+convert(varchar(6),PROR_CODX) NEC_Antiga
				--, Rlri_orde ORD_Antiga
				--,'5/PRNC/001/'+convert(varchar(6),Rlri_nec_cod_new)+'/1' NEC_Nova
				--,convert(varchar(6),c.PRNC_SIEX)+'/'+c.PRNC_SIDX+'/'+c.PRNC_SISX+'/'+convert(varchar(6),c.PRNC_NUMX) ORD_Nova 
				--,'5/VDPD/001/'+convert(varchar(6),Rlri_nec_new) NEC_Nova_VENDAS
				--,convert(varchar(6),d.PRNC_SIEX)+'/'+d.PRNC_SIDX+'/'+d.PRNC_SISX+'/'+convert(varchar(6),d.PRNC_NUMX) ORD_Nova_VENDAS 
				--,a.*,g.*
into #new
from tmpRlri a, pror b, prnc c, prnc d, prnc g-- mtmv e, prnc f
where Rlri_orde = convert(varchar(6),PROR_SIES)+'/'+PROR_SIDO+'/'+PROR_SISE+'/'+convert(varchar(6),PROR_COD)
			and c.prnc_sies = 5
			and c.prnc_sido = 'PRNC'
			and c.prnc_sise = '001'
			and c.prnc_npai = Rlri_nec_cod_new
			and c.prnc_cod  =	1
			and Rlri_nec_new is not null
			and d.prnc_sies = 5
			and d.prnc_sido = 'VDPD'
			and d.prnc_sise = '001'
			and d.prnc_npai = substring(Rlri_nec_new,1,6)
			and d.prnc_cod  =	substring(Rlri_nec_new,8,3)
			and convert(varchar(6),g.PRNC_SIEs)+'/'+g.PRNC_SIDo+'/'+g.PRNC_SISe+'/'+convert(varchar(6),g.PRNC_npai) = convert(varchar(6),d.PRNC_SIEX)+'/'+d.PRNC_SIDX+'/'+d.PRNC_SISX+'/'+convert(varchar(6),d.PRNC_NUMX)
			and g.PRNC_QTDA <> 0
			--and convert(varchar(6),d.PRNC_SIEX)+'/'+d.PRNC_SIDX+'/'+d.PRNC_SISX+'/'+convert(varchar(6),d.PRNC_NUMX) = '5/'+ mtmv_sidx+'/'+mtmv_sisx+'/'+convert(varchar(6),mtmv_codx)
			--and convert(varchar(6),d.PRNC_SIEX)+'/'+d.PRNC_SIDX+'/'+d.PRNC_SISX+'/'+convert(varchar(6),d.PRNC_NUMX) = '5/'+ mtmv_sidx+'/'+mtmv_sisx+'/'+convert(varchar(6),mtmv_codx)
			--and convert(varchar(10),mtmv_dat,102)>='2014.08.01'
order by Rlri_orde

-------------------

select *
--delete prnc 
from prnc b, #new c
where c.prnc_sies = b.prnc_sies
			and c.prnc_sido = b.prnc_sido
			and c.prnc_sise = b.prnc_sise
			and c.prnc_npai = 1031--b.prnc_npai
--			and c.prnc_cod  =	b.prnc_cod

--
select * 
--update mtmv set MTMV_VAL = Rlri_val_alm, MTMV_VALM = Rlri_val_alm, MTMV_MTAL_ORI = 'CTACOR'
from #new, mtmv
where MTMV_CODX = PRNC_Numx
			and mtmv_sies = prnc_siex
			and mtmv_sidx = prnc_sidx
			and mtmv_sisx = prnc_sisx
			and mtmv_mttr = 'SAINEC'

select *
from tmpRlri
where Rlri_nec_new is not null

--66350--66350

select *
from mtmv
where MTMV_CODX = 66366
--mtmv_cod = 761994

select *
--update PRNC set PRNC_QTDA = PRNC_QTD
from tmpRlri, pror, prnc
where Rlri_orde = convert(varchar(6),PROR_SIES)+'/'+PROR_SIDO+'/'+PROR_SISE+'/'+convert(varchar(6),PROR_COD)
			and PROR_QTDR = PROR_QTDO
			and prnc_sies = PROR_SIEX
			and prnc_sido = PROR_SIDX
			and prnc_sise = PROR_SISX
			and prnc_npai = PROR_NPAX
			and prnc_cod  =	1
			and PROR_QTDR = PROR_QTDO
			and PRNC_QTD  <> PRNC_QTDA
