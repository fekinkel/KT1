IF OBJECT_ID('TempDB.dbo.#FRANCA') IS NOT NULL DROP TABLE #FRANCA
select vdc1_MTDV[DIVIS�O], VDC1_MTPC[C�DIGO], 0.00 [CONSUMO], 0.00 [CONSUMO-COTA��O], sum(VDC1_QTDE) [COTA��O]--, b.*
INTO #FRANCA
from VDCO a, VDC1 b
where VDCO_SIES = VDC1_SIES
			and VDCO_SIDO = VDC1_SIDO
			and VDCO_SISE = VDC1_SISE
			and VDCO_COD  = VDC1_VDCO
			and convert(varchar(10),VDCO_DTC,102) between '2014.01.01' and '2014.12.31'
			and ((VDC1_MTDV = 3500 and VDC1_MTLN = 3800) or (VDC1_MTDV = 2500 and vdc1_MTLN = 3200) or (VDC1_MTDV = 6000 and VDC1_MTLN = 5500 and VDC1_MTFM = 6945))
group by VDC1_MTDV, VDC1_MTPC
order by VDC1_MTDV, VDC1_MTPC

SELECT * FROM #FRANCA

--564

IF OBJECT_ID('TempDB.dbo.#FRANCA1') IS NOT NULL DROP TABLE #FRANCA1
select NFIT_MTDV [DIVIS�O], NFIT_MTLN [LINHA], NFIT_MTFM [FAMILIA], nfit_mtpr[C�DIGO], replace(sum(nfit_qtd),'.',',') [CONSUMO]--, b.*
INTO #FRANCA1
from nfnf a, nfit b
where NFNF_SIES = NFIT_SIES
			and NFNF_SIDO = NFIT_SIDO
			and NFNF_SISE = NFIT_SISE
			and NFNF_COD  = NFIT_NFNF
			and convert(varchar(10),NFNF_DAT,102) between '2014.01.01' and '2014.12.31'
			and ((NFIT_MTDV = 3500 and NFIT_MTLN = 3800) or (NFIT_MTDV = 2500 and NFIT_MTLN = 3200) or (NFIT_MTDV = 6000 and NFIT_MTLN = 5500 and NFIT_MTFM = 6945))
			--AND NFIT_MTPR = [C�DIGO]
group by NFIT_MTDV, NFIT_MTLN, NFIT_MTFM, nfit_mtpr
order by NFIT_MTDV, NFIT_MTLN, NFIT_MTFM, nfit_mtpr
--TOTAL DE LINHAS 821

SELECT *
FROM #FRANCA1 a left JOIN #FRANCA b on a.[c�digo] = b.[C�DIGO]
