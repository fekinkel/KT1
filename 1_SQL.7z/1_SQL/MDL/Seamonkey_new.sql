--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Autor				: Rodrigo Dias
--Data				: 25/07/2014
--Solicitante	: Sr(a). Fernando
--Objetivo 01	: Script para Criar Estrutura de Pastas no Software de email Seamonkey
--Campos			: 
--Restries		: 
--Observaes		: Criar estrutura de Pastas e Filtros
--						: Nao criamos os arquivos .MSF para as pastas ENVIADOS e RECEBIDOS pois eles s�o ponteiros que o proprio Seamonkey cria
--						: Somaente criamos arquivos .MSF para subpastas que ficam dentro das Pastas ENVIADOS e RECEBIDOS
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
USE tempdb
SET LANGUAGE 'Brazilian'
----------------------------------------
-- Script para criar pastar no Seamonkey
----------------------------------------
declare 
	  @str_Caminho_Local			varchar(1000)		-- Variavel contendo o caminho da pasta
	, @str_Caminho_Principal		varchar(1000)		-- Variavel contendo o caminho da pasta
	, @str_dir varchar(20)
	, @exec				varchar(100)		-- Variavel com todo o comando de mapeamento a ser executado
  , @email varchar(100)
  , @item int
  , @max_item int
  , @cDir varchar(50)
  , @vCima int
  , @vBaixo int
  , @label varchar(50)
-- Variaveis da Criacao da tabela temporaria #DATA com os meses do ANO	
-------------------------------------------------------------------------------------
-- Net Use - Dados para Autenticacao Dominio
-- Utilizado para efetuar mapeamento da unidade de rede onde estao as pastas do email
-------------------------------------------------------------------------------------
--set @exec = 'net use s: \\192.168.2.3\email mdl168@@ /USER:MDL\administrator'
set @exec = 'net use s: \\192.168.2.3\SeaMonkey mdl168@@ /USER:MDL\administrator'

Exec xp_cmdshell 'net use s: /delete'
Exec xp_cmdshell @exec
-----------------------------------
-- CRIAR PASTAS PAIS
-- Nomes das pastas a serem criadas 
-----------------------------------
set @item = 1 ; select @max_item = max(seae_cod) from [CFG_MDL].[DBO].SEAE
--set @item = 3 ; select @max_item = 3
--set @item = 1 ; select @max_item = 1

WHILE @ITEM <= @max_item BEGIN
	USE tempdb
	SET LANGUAGE 'Brazilian'

	SELECT
		@str_Caminho_Local = SEAE_PATH+'\LOCAL' --@str_uni + '\ti\local'							-- Caminho onde se localiza os email
		,@str_Caminho_Principal = SEAE_PATH+'\PRINCIPAL' --@str_uni + '\ti\principal'							-- Caminho onde se localiza os email
		,@str_dir = SEAE_DIR
		,@email = SEAE_EMAIL --'vendas@mdl-brasil.com.br'
		,@vCima = SEAE_cima
		,@vBaixo = SEAE_BAIXO
		,@label = SEAE_LABEL
	FROM [CFG_MDL].[DBO].SEAE
	WHERE SEAE_COD = @ITEM
	SELECT @cDir = '' 
	SELECT
		@cDir = SEAE_DIR+'_'
	FROM [CFG_MDL].[DBO].SEAE
	WHERE SEAE_COD = @ITEM
		AND SEAE_CDIR = 1

-- Excluindo Tabela Temporaria
	IF OBJECT_ID('TempDB.dbo.#PASTA_PAI') IS NOT NULL DROP TABLE #PASTA_PAI

-- Criando Tabela Temporaria
	create table #PASTA_PAI (	ITEM INT IDENTITY(1,1)	--CONTADOR 
						  ,	PASTA_PAI VARCHAR(20)							--NOME PASTA PRINCIPAL
						  , TAG		  INT												--SE TEM TA
						  , TEG_NOM	  VARCHAR(20)							--NOME DO TAG '$label1' = IMPORTANTE
						  , PARA	  INT												--
						  , DE		  INT
						  , ANTERIOR  INT
						  , PASTA_mes INT											--SE 1 O MES � UMA PASTA
						  , PASTA_AUX VARCHAR(20)
						  , NOME VARCHAR(30)
						)
	INSERT INTO #PASTA_PAI 
	SELECT
		'MDL_'+@cDir+'ENVIADOS'	, 2, NULL			, 0, 1, 0, 0, NULL, NULL

	INSERT INTO #PASTA_PAI 
	SELECT
		'MDL_'+@cDir+'RECEBIDOS', 1, @label, 0, 1, 0, 0, NULL, NULL
	INSERT INTO #PASTA_PAI 
	SELECT
		'MDL_'+@cDir+SEAF_CONDICAO, 0, NULL, 0, 0, 0, 1, NULL, NULL
	FROM [CFG_MDL].[DBO].SEAF
	WHERE SEAF_SEAE = @item
	GROUP BY SEAF_CONDICAO
	
	INSERT INTO #PASTA_PAI 
	SELECT
		SEAF_NOME,  3, NULL, 0, 0, 0, 1, 'MDL_'+@cDir+SEAF_CONDICAO, NULL
	FROM [CFG_MDL].[DBO].SEAF
	WHERE SEAF_SEAE = @item

-- INSERINDO DADOS NA TABELA
/*
INSERT INTO #PASTA_PAI
VALUES		( 'MDL_ENVIADOS'		, 2, NULL				, 0, 1, 1, 0, NULL, NULL)		
				, ( 'MDL_RECEBIDOS'		, 1, '$label1'	, 1, 0, 1, 0, NULL, NULL)		-- TEG_NOM = '$label1' = IMPORTANTE
				, ( 'MDL_VENDEDORES'	, 0, NULL				, 0, 0, 0, 1, NULL, NULL)
				, ( 'ANAC'						, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'MILENAS'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'ERIKAE'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'GISLAINEM'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'GRACIELEC'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'LUCIANEM'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'KATIAJ'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'TALITAC'					, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				--, ( 'GISLEINEL'				, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
				, ( 'CARINAP'						, 3, NULL				, 0, 0, 0, 1, 'MDL_VENDEDORES', NULL)
*/
	UPDATE #PASTA_PAI SET NOME = GLFU_NRDZ
	FROM #PASTA_PAI, [MDL].[DBO].[glfu]
	WHERE TAG = 3
			AND PASTA_PAI = GLFU_SIUS
	---------------------------------------------------------------------------------
	-- Criar tabela temporaria #MESES com os Meses do ANO para utilizar nas subpastas
	---------------------------------------------------------------------------------
	--select * from #meses
	DECLARE
	@i	int,
	@j int,
	@str_data					varchar(10),
	@str_tam					varchar(100)
	IF OBJECT_ID('TempDB.dbo.#meses') IS NOT NULL DROP TABLE #meses
	create table #meses (num_1 int identity(1,1), mes varchar(20), mes_1 varchar(20), ano_1 int, usado int, data_f datetime , mes_f int)
	select  @j = 1 --datepart(year, getdate())
	while @j <= 3 begin
		set @i = 1
		While @i <= 12 Begin
			set @str_data = convert(varchar(4),(datepart(year, getdate()))+(@j-2) )  + '.' + convert(varchar(2), @i) + '.' + '01'	
	 		set @str_tam = replicate('0', 2 - datalength(convert(varchar(2), @i))) + convert(varchar(2), @i)
 			--set @str_comand =@str_tam + '_' + (select datename(month,@str_data))
			INSERT INTO #meses
			select UPPER(@str_tam + '_' + (select datename(month,@str_data)))
			,upper(datename(month,@str_data))
			,YEAR(@str_data)
			,0
			,null
			,@i
			set @i = @i + 1		-- neste caso inclemento no final 
		end
		set @j = @j + 1
	end
	set @i = (month(getdate())+12)-@vBaixo -- Meses para tras (Maximo 12)
	set @j = (month(getdate())+12)+@vCima -- Meses para frente (Maximo 12)
	UPDATE #meses set usado = 1, data_f = convert(varchar(4),ano_1) + '.01'+'.'+REPLICATE('0', 2 -LEN(mes_f))+ convert(varchar(4),mes_f)
	from #meses
	where num_1 between  @i  and @j
	
	----------------------------------------------------
	-- CRIANDO TABELA TEMPORARIA PARA CRIACAO DAS PASTAS
	----------------------------------------------------

	-- Excluindo Tabela Temporaria
	IF OBJECT_ID('TempDB.dbo.#COMANDO') IS NOT NULL DROP TABLE #COMANDO
	--go
	-- Criando Tabela Temporaria
	create table #COMANDO (
														NUM INT IDENTITY(1,1)
													, COMANDO varchar(200)
													, CRIAR varchar(1)
													, PASTA_Mes INT
													, CRIAR_1 INT
												)
	---------------------------------------------------------------------------- 
	-- Inserindo o caminho de criacao dos arquivos na tabela temporaria #COMANDO
	----------------------------------------------------------------------------
	-- COMANDOS PARA CRIACAO DAS PASTAS PAI
	INSERT INTO #COMANDO
	SELECT @str_Caminho_Local + '\' + max(PASTA_PAI) + '_' + convert(varchar(4), datepart(year, getdate())-1) + '.sbd'															-- ANO CORRENTE
			 , 'S'
			 , (PASTA_Mes)Criar_Pastas
			 , max(usado) 
	FROM #PASTA_PAI, #meses
	WHERE	 PASTA_AUX IS NULL
				and (datepart(year, getdate())-1) = ano_1
	GROUP BY PASTA_PAI, ano_1, pasta_mes

	INSERT INTO #COMANDO
	SELECT @str_Caminho_Local + '\' + max(PASTA_PAI) + '_' + convert(varchar(4), datepart(year, getdate())) + '.sbd'															-- ANO CORRENTE
			 , 'S'
			 , (PASTA_Mes)
			 , max(usado)
	FROM #PASTA_PAI, #meses
	WHERE	 PASTA_AUX IS NULL 
				and (datepart(year, getdate())) = ano_1
	GROUP BY PASTA_PAI, ano_1, PASTA_MES

	INSERT INTO #COMANDO
	SELECT @str_Caminho_Local + '\' + max(PASTA_PAI) + '_' + convert(varchar(4), datepart(year, getdate())+1) + '.sbd'															-- ANO CORRENTE
			 , 'S'
			 , (PASTA_Mes)Criar_Pastas
			 , max(usado) 
	FROM #PASTA_PAI, #meses
	WHERE	 PASTA_AUX IS NULL
				and (datepart(year, getdate())+1) = ano_1
	GROUP BY PASTA_PAI, ano_1, pasta_mes


	-- COMANDOS PARA CRIACAO DOS ARQUIVOS RESPONSAVEIS PELAS SUBPASTAS
	INSERT INTO #COMANDO
	SELECT COMANDO + '\' + MES+REPLACE(REPLACE(PASTA_Mes,0,''),1,'.sbd')
			 , REPLACE(REPLACE(PASTA_Mes,0,'N'),1,'S')
			 , 0
			 , usado
	FROM #COMANDO, #MESES
	WHERE COMANDO LIKE '%'+convert(varchar(6),ANO_1)+'%'

	INSERT INTO #COMANDO
	SELECT COMANDO + '\' + PASTA_PAI
			 , 'N'
			 , 0
			 , CASE CRIAR_1
					WHEN 0 THEN 2
					ELSE CRIAR_1
				END
	FROM #COMANDO, #PASTA_PAI
	WHERE COMANDO LIKE '%'+PASTA_AUX+'%'
				AND COMANDO LIKE '%.sbd\%'


----------------------------
-- WHILE PARA CRIAR O COMANDO
-----------------------------
	declare  
						@str_cont	int																																					-- Variavel contendo o numero de meses que possuimos no ano
					, @STR_EXEC VARCHAR(400)																																		-- Variavel criada que contem o comando a ser executado para criacao de pastas e arquivos
	IF OBJECT_ID('TempDB.dbo.##path') IS NOT NULL DROP TABLE ##path
	select identity(int,1,1) NUM, space(4000) val
	into ##path
	where 1 = 0

	set @str_cont = 1																																										-- Setando Valore inicial da da Variavel responsavel pela contagem
	-- set @str_comand = (select datename(month, @str_mes)) 
	While @str_cont <= (SELECT MAX(NUM) FROM #COMANDO) 
	--While @str_cont <= 28
		Begin													
		--PRINT @str_cont
		IF ( SELECT CRIAR_1 FROM #COMANDO WHERE NUM = @str_cont ) = 1 BEGIN
			--PRINT 'CONTADOR � '+CONVERT(VARCHAR(3),@str_cont)+' ENTROU'
			IF ( SELECT CRIAR FROM #COMANDO WHERE NUM = @str_cont ) = 'S' BEGIN
				--PRINT	'ENTROU NO IF'																																						-- PRINT com mensagem informando que entramos no IF
				SELECT  @STR_EXEC = 'MD' + ' ' +  COMANDO  FROM #COMANDO WHERE NUM = @str_cont									-- Criacao de pasta na variavel @STR_EXEC
				--PRINT @STR_EXEC
				insert into ##path select @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
				--Exec xp_cmdshell @STR_EXEC																																			-- executa a variavel @STR_EXEC com o comando de criacao de pastas
				
				SELECT  @STR_EXEC = 'IF NOT EXIST '+COMANDO +' COPY NUL' + ' ' +  COMANDO+ '' FROM #COMANDO WHERE NUM = @str_cont							-- Criacao de arquivos auxiliares das Pastas na variavel @STR_EXEC
				SET @STR_EXEC = REPLACE(@STR_EXEC,'.SBD','')
				IF CHARINDEX('.sbd',SUBSTRING(@str_exec,LEN(@str_exec)-5,10)) > 0 BEGIN
					SELECT @str_exec = SUBSTRING(@str_exec,1,LEN(@str_exec)-4)
				END  																										-- Retira a extencao .SBD do arquivo que sera criado
				--PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
				insert into ##path select @STR_EXEC
				--Exec xp_cmdshell @STR_EXEC																																			-- Executa a variavel @STR_EXEC com o comando para criacao de arquivos auxiliares das Pastas

				--SELECT  @STR_EXEC = 'COPY NUL' + ' ' + COMANDO + '.MSF' FROM #COMANDO WHERE NUM = @str_cont							
				--SET @STR_EXEC = REPLACE(@STR_EXEC,'.SBD','')																														
				--PRINT @STR_EXEC
				--Exec xp_cmdshell @STR_EXEC
			
			END ELSE	 																																											-- Caso nao esteja na condicao do IF acima, ele executara o ELSE (SENAO)
				BEGIN																																														
				SELECT  @STR_EXEC = 'IF NOT EXIST '+COMANDO +' COPY NUL' + ' ' +  COMANDO FROM #COMANDO WHERE NUM = @str_cont							-- Inserindo o comando para criacao dos arquivos das subpastas com os MESES
				--PRINT @STR_EXEC																																									
				insert into ##path select @STR_EXEC
				--Exec xp_cmdshell @STR_EXEC
			
				--SELECT  @STR_EXEC = 'COPY NUL' + ' ' + COMANDO + '.MSF' FROM #COMANDO WHERE NUM = @str_cont
				--PRINT @STR_EXEC
				--Exec xp_cmdshell @STR_EXEC
			
			END
		END ELSE BEGIN
			--IF ( SELECT CRIAR FROM #COMANDO WHERE NUM = @str_cont ) = 'S' BEGIN
			
				IF (SELECT SUBSTRING(COMANDO, LEN(COMANDO)-3, 4) FROM #COMANDO WHERE NUM = @str_cont) = '.sbd' BEGIN
					SELECT  @STR_EXEC = 'RD' + ' ' +  COMANDO + ' /S /Q' FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC
					--PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
					
					insert into ##path select @STR_EXEC
					--Exec xp_cmdshell @STR_EXEC
					SELECT  @STR_EXEC = 'DEL' + ' ' +  SUBSTRING(COMANDO, 1, LEN(COMANDO)-4) + ' /S /Q' FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC
					--PRINT @STR_EXEC
					insert into ##path select @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
					SELECT  @STR_EXEC = 'DEL' + ' ' +  SUBSTRING(COMANDO, 1, LEN(COMANDO)-4) + '.msf /S /Q' FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC
					--PRINT @STR_EXEC
					insert into ##path select @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
					--Exec xp_cmdshell @STR_EXEC
				END ELSE BEGIN
					SELECT  @STR_EXEC = 'DEL' + ' ' +  COMANDO + ' /S /Q'  FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC			
					--PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
					insert into ##path select @STR_EXEC
					SELECT  @STR_EXEC = 'DEL' + ' ' +  COMANDO + '.msf /S /Q'  FROM #COMANDO WHERE NUM = @str_cont									-- Inseri o comando para criacao de pasta na variavel @STR_EXEC			
					--PRINT @STR_EXEC																																									-- Exibe o que esta armazenado na Variavel @STR_EXEC
					insert into ##path select @STR_EXEC
					--Exec xp_cmdshell @STR_EXEC
				END
			--END																																			-- executa a variavel @STR_EXEC com o comando de criacao de pastas
		END
		set @str_cont = @str_cont + 1																																			--	Incremento para contunuar executando o comando
	END

  --select 'Primeiro', * from ##path
  --select * from #comando where CRIAR_1 = 1
 
  insert into ##path
  select ''	
  insert into ##path
  SELECT 'COPY msgFilterRules.dat '+@str_Caminho_Principal+'\msgFilterRules.dat'	
	set @STR_EXEC = 'master..xp_cmdshell '+char(39)+'md S:\'+@str_dir+char(39)
	--print @STR_EXEC
	exec(@STR_EXEC) 

  --select 'Segundo', * from ##path

	set @STR_EXEC = 'master..xp_cmdshell '+char(39)+'bcp "select val from ##path order by num " queryout "'+'S:\'+@str_dir+'\Criar_Pastas.bat'+'" -c -U sa -P mdl1680'+CHAR(39)
	exec(@STR_EXEC) 
	--print @STR_EXEC
--exec master..xp_cmdshell 'bcp "select * from ##path " queryout "C:\0_SQL\teste.bat" -c -U sa -P mdl1680'



	-------------------------------------------------------
	-- CRIANDO TABELA TEMPORARIA COM AS DATAS PARA O FILTRO
	-------------------------------------------------------

	SET LANGUAGE 'English'

	IF OBJECT_ID('TempDB.dbo.#MES_SEAMONKEY') IS NOT NULL DROP TABLE #MES_SEAMONKEY

	-- Criando Tabela Temporaria
	create table #MES_SEAMONKEY (  ITEM INT IDENTITY(1,1)
								 , MES		varchar(25)
								 , MES_ANT	varchar(25)	
								 , MES_POS	varchar(25)
								 , DIA_ANT	varchar(5)
								 , DIA_POS  varchar(5)
								 , ANO_ANT	varchar(5)
								 , ANO_POS	varchar(5)
								 , mes_char char(2)
								 , ano_char char(4)
								 , mes_ext varchar(25)
								 , num_1 int
								)

	DECLARE
						@STR_F_CONT INT
					, @STR_F_DATA1 DATETIME
	SET @str_F_cont = 1

		
				-- INSERINDO DADOS NA TABELA TEMPORARIA #MES_SEAMONKEY
		INSERT INTO #MES_SEAMONKEY
		SELECT	  convert(varchar(25),DATENAME(MONTH,Data_f)	)	[MES]
						, DATENAME(MONTH, DATEADD(MONTH, -1, Data_f))    [MES_ANT] 
 						, DATENAME(MONTH, DATEADD(MONTH, 1, Data_f))	[MES_POS]
						, DATEPART(day, DATEADD(DAY, -1, Data_f))	[DIA_ANT]
						, DATEPART(DAY,Data_f)	[DIA_POS]
						, DATEPART(YEAR, DATEADD(MONTH, -1,Data_f))	[ANO_ANT]
						, DATEPART(YEAR, DATEADD(MONTH, 1,Data_f))	[ANO_POS]
						, REPLICATE('0',2 - LEN(CONVERT(VARCHAR(2),mes_f)))+ CONVERT(VARCHAR(2),mes_f)	
						, convert(char(4),DATEPART(YEAR, data_f))
						, upper(datename(month,Data_f))
						, num_1
		FROM #meses
		where data_f is not null		
--		select * from #MES_SEAMONKEY											
		SET @str_F_cont = @str_F_cont + 1
	--END

	--------------------------------------------
	-- CRIA��O TABELA TEMPORARIA PARA OS FILTROS
	--------------------------------------------
	IF OBJECT_ID('TempDB.dbo.##FILTRO') IS NOT NULL DROP TABLE ##FILTRO
	create table ##FILTRO (   ITEM INT IDENTITY(1,1)
							, FILTRO varchar(1000))

	DECLARE
	-- Variaveis da Criacao dos Filtros
			@str_Filtro_CONT1			INT
		, @str_Filtro_CONT2			INT
		, @str_Filtro				varchar(1000)
		, @str_Filtro_Name			varchar(1000)
		, @str_Filtro_Action		varchar(1000)
		, @str_Filtro_Caminho		varchar(1000)
		, @str_Filtro_Pasta			varchar(1000)
		, @str_Filtro_Data_ini		varchar(1000)
		, @str_Filtro_Data_fim		varchar(1000)
		, @str_Filtro_TAG			varchar(1000)
		, @str_Filtro_TAG_COND		varchar(1000)
		, @str_Filtro_TAG_TAG		varchar(1000)
		, @str_Filtro_MES			INT
		, @str_V					INT
		, @mes int
	-- SETANDO VARIAVEIS

	SET @str_Filtro_CONT1 = 1
	select @mes = month(getdate())
	WHILE	(@str_Filtro_CONT1 <= (SELECT MAX(ITEM) FROM #PASTA_PAI)) BEGIN
		SET @str_Filtro_CONT2 = 1
		WHILE	((@str_Filtro_CONT2 <= (SELECT MAX(ITEM) FROM #MES_SEAMONKEY)) AND ((SELECT TAG FROM #PASTA_PAI WHERE item = @str_Filtro_CONT1)>0) ) BEGIN
			set @str_Filtro =   ''
	--if (select COUNT(1) from #MES_SEAMONKEY a, #PASTA_PAI b where a.item = @mes-@str_Filtro_CONT2 AND b.item = @str_Filtro_CONT1 and TAG > 0) > 0 BEGIN
			SELECT @str_Filtro =   ''
							+'name=' + '"' + PASTA_PAI+'_'+mes_char + '"' + CHAR(10)  
							+ ' ' + 'enabled="yes"'	+ CHAR(10)
							+ ' ' + 'type="17"'		+ CHAR(10)
			from #MES_SEAMONKEY a, #PASTA_PAI b
			where a.item = @str_Filtro_CONT2
					and b.item = @str_Filtro_CONT1 
					and TAG > 0

		SELECT @str_Filtro =  @str_Filtro 
						+	case TAG 
							when 1 then	--RECEBIDOS					
	 							+ ' ' + 'action="'		+ 'Move to folder' + '"' + CHAR(13)
								+ ' ' + 'actionValue=' + '"mailbox://nobody@Local%20Folders' + '/' + PASTA_PAI+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_1 +'"' + CHAR(13)
								+ ' ' + 'condition="AND (date,is after,' + dia_ant+'-'+mes_ant+'-'+ano_ant + ')'+ ' ' 											
								+ 'AND (date,is before,' + dia_pos+'-'+mes_pos+'-'+ano_pos + ')' + '' 
								+ 'AND (' + 'tag' + ',' + 'contains' + ',' + TEG_NOM + ')"'
							when 2 then --ENVIADOS
	 							+ ' ' + 'action="'		+ 'Move to folder' + '"' + CHAR(13)
								+ ' ' + 'actionValue=' + '"mailbox://nobody@Local%20Folders' + '/' + PASTA_PAI+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_1 +'"' + CHAR(13)
								+ ' ' + 'condition="AND (date,is after,' + dia_ant+'-'+mes_ant+'-'+ano_ant + ')'+ ' ' 											
								+ 'AND (date,is before,' + dia_pos+'-'+mes_pos+'-'+ano_pos + ')'  
								+ 'AND (from,is,' + @email + ')' + '"'
								--AND (subject,begins with,Proposta Comercial) 
								--AND (from,contains,ti@mdl-danly.com.br)"
							when 3 then --VENDEDORES
	 							+ ' ' + 'action="'		+ 'Move to folder' + '"' + CHAR(13)
								+ ' ' + 'actionValue=' + '"mailbox://nobody@Local%20Folders' + '/' + PASTA_AUX+'_'+ANO_CHAR+'/'+MES_CHAR+'_'+MES_1+'/'+PASTA_PAI +'"' + CHAR(13)
								+ ' ' + 'action="Mark read"'
								+ ' ' + 'condition="AND (date,is after,' + dia_ant+'-'+mes_ant+'-'+ano_ant + ')'+ ' ' 											
								+ 'AND (date,is before,' + dia_pos+'-'+mes_pos+'-'+ano_pos + ')' 
								+ 'AND (from,is,' + @email + ')'  
--								+ 'AND (subject,contains,' + NOME + ')' + '"' 
								+ 'AND (subject,begins with,Proposta Comercial' + ')'
								+ 'AND (from,contains,' + NOME + ')' + '"' 
								--+ 'AND (subject,contains,' + PASTA_PAI + ')' + '"' 
								--AND (subject,contains,ANAC)
							end
		from #MES_SEAMONKEY a, #PASTA_PAI b, #meses c--, GLFU c
		where a.item = @str_Filtro_CONT2
					and b.item = @str_Filtro_CONT1
					and c.num_1 = a.num_1
					
					--AND num_1 = @mes-@str_Filtro_CONT2
					--AND (tag = 3 and PASTA_PAI = GLFU_sius) or (TAG<>3)
					and TAG > 0
					
--select * from #pasta_pai 
--select * from #meses
--select * from #MES_SEAMONKEY
--select * from ##FILTRO
		--print N'CONTEUDO DO FILTRO'
		--print @str_Filtro

		INSERT INTO ##FILTRO
		select @str_Filtro
			
		SET @str_Filtro_CONT2 = @str_Filtro_CONT2 + 1	
		
		end

	-- Incremento na variavel
		--select @str_V = anterior from #pasta_pai where item = @str_Filtro_CONT1
		
		--if ((@str_Filtro_CONT2 = 0) AND (@str_V = 0)) OR ((@str_Filtro_CONT2 = 1) AND (@str_V = 1)) BEGIN 
		
			SET @str_Filtro_CONT2 = 1
				
			set @str_Filtro_CONT1 = @str_Filtro_CONT1 + 1		-- neste caso inclemento no final 
			
		--END ELSE BEGIN
		
			--set @str_Filtro_CONT2 = @str_V	
		--END
	end

		select * from ##FILTRO
		
	insert into ##FILTRO
	select N'logging="no"'

	insert into ##FILTRO
	select N'version="9"'
		
	-----------------------------------------------------------------------------------------
	-- INSERINDO TABELA TEMPORARIA (##FILTRO) NO ARQUIVO (S:\TI\Principal\msgFilterRules.dat)
	-----------------------------------------------------------------------------------------
	--select * from ##FILTRO
	set @STR_EXEC = 'master..xp_cmdshell '+char(39)+'bcp "select filtro from ##FILTRO ORDER BY item desc " queryout "'+'S:\'+@str_dir+'\msgFilterRules.dat'+'" -c -U sa -P mdl1680'+CHAR(39)
	exec(@STR_EXEC) 
	set @item = @item + 1

END