select a.equi_ip, EQUI_GRUPO, *
from equi a
where substring(a.EQUI_IP,1,10) in ( '192.168.2.', '192.168.1.')-- and LEN(EQUI_IP)<=12
			AND EQUI_GRUPO = 'SERVER'
order by a.EQUI_SO, equi_fabricante

select a.equi_ip, EQUI_GRUPO, *
from equi a
where substring(a.EQUI_IP,1,10) in ( '192.168.2.', '192.168.1.')-- and LEN(EQUI_IP)<=12
			AND EQUI_GRUPO <> 'SERVER'
order by a.EQUI_SO, equi_fabricante

select b.*
from equi a, EQPR b
where substring(a.EQUI_IP,1,13) = '192.168.2.197'
			AND EQUI_MAC = EQPR_MAC


select *
--delete
from EQUI
where EQUI_MAC = 'B8-CA-3A-CC-C0-AE'

select *
--delete
from EQPR
where EQPR_MAC = 'B8-CA-3A-CC-C0-AE'
