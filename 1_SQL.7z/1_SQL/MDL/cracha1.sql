select glfu_nrdz, ctcc_nom, glff_file, GLPR_VALS, glfu_nom, glfu_rg, glfu_cod, replicate('0',7-(len(glfu_cod)))+glfu_cod 
+ right(STR( ((( (convert(int,substring(reverse(glfu_cod),1,1))*(len(glfu_cod)-4))
+ (convert(int,substring(reverse(glfu_cod),2,1))*(len(glfu_cod)-3))
+ (convert(int,substring(reverse(glfu_cod),3,1))*(len(glfu_cod)-2))
+ (convert(int,substring(reverse(glfu_cod),4,1))*(len(glfu_cod)-1))
+ (convert(int,substring(reverse(glfu_cod),5,1))*(len(glfu_cod)))
+ (convert(int,substring(reverse(glfu_cod),6,1))*(len(glfu_cod)+1)) )*10) % 11),10,0),1) glfu_barra
from glfu left join glff on glff_sies = glfu_sies and glff_glfu = glfu_cod left join ctcc on glfu_gldp = ctcc_cod left join glpr on glfu_gldp = glpr_chav and glpr_cod = 'depcor' and glpr_depe = 5
where glfu_sies = 5
and substring(glfu_cod,1,3)='180'
and substring(glfu_nrdz,1,2)<> ' -'
order by ctcc_cod