

insert into VDC1
select *
from [vnd].[dbo].vdc1
where VDC1_VDCO = 297062

insert into VDCR
select *
from [vnd].[dbo].vdcr
where VDCR_VDCO = 297062
