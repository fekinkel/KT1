IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #newselect 'B01.005.0M2' CODINTO #newINSERT #new SELECT 'B01.005.0M3'INSERT #new SELECT 'B01.006.0M3'INSERT #new SELECT 'B01.008.0M3'INSERT #new SELECT 'B01.008.0M4'INSERT #new SELECT 'B02.006.0M3'INSERT #new SELECT 'B02.006.0M4'INSERT #new SELECT 'B02.008.0M3'INSERT #new SELECT 'B02.008.0M4'IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT * INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD = CONVERT(varchar(20),COD)      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = CONVERT(varchar(25),'PI-PRODUTO INTERMEDI�RIO')      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = CONVERT(varchar(80),'KIT PARA BASE')      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = CONVERT(varchar(4),'2500')      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = CONVERT(varchar(4),'3100')      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),'3910')      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = CONVERT(varchar(3),'CJ')      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = CONVERT(varchar(8),'84669410')      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, MTPR_PES = CONVERT(decimal(13,4),'0')      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = Null      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = Null      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = Null      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = Null      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = Null      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = CONVERT(varchar(8),'1.101.A')      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = CONVERT(decimal(12),'5')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #NEWINSERT INTO MTPRSELECT *FROM #MTPRWHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)
--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU
IF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, MTES_MTAL = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP = CONVERT(varchar(6),'PROCES')      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE = CONVERT(char(1),'S')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD = CONVERT(varchar(8),'REAL')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU = Null      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU = Null      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM = Null      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS = Null      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC = Null      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO = Null      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME = Null      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR = Null      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN = Null      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ = Null      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM = Null      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI = Null      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM = Null      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL = Null      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC = Null      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO = Null      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD = Null      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM = Null      --CONVERT(int(8),'') LT Urg�ncia (dias)
	, MTES_EXPL = CONVERT(char(1),'N')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP = CONVERT(char(1),'S')      --CONVERT(char(1),'') Pol�tica
	, MTES_CREP = Null      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR = Null      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF = Null      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT = CONVERT(int,'0')      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT = Null      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 = Null      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 = Null      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 = Null      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 = Null      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT = Null      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRINSERT INTO MTESSELECT *FROM #MTESWHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+MTES_MTPR FROM MTES)
--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU
IF OBJECT_ID('TempDB.dbo.#MTEP') IS NOT NULL DROP TABLE #MTEPSELECT * INTO #MTEP FROM MTEP WHERE 1 = 0INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B01.005.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),2)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.005.0M2'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B01.005.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.005.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B01.006.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.006.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B01.008.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.008.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B01.008.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),4)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.008.0M4'---AINSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.005.012')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),2)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.005.0M2'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.005.012')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.005.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.006.016')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.006.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.008.020')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.008.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.008.020')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),4)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B01.008.0M4'--B02INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B02.006.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),4)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.006.0M4'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B02.006.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.006.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B02.008.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.008.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'B02.008.000')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'10')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),4)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.008.0M4'---AINSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.006.012')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),4)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.006.0M4'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.006.012')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.006.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.008.016')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),3)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.008.0M3'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05.008.016')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),4)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRWHERE MTPR_COD = 'B02.008.0M4'INSERT INTO MTEPSELECT TOP 1 * FROM #MTEPWHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP)
ORDER BY MTEP_PAI, MTEP_SEQ--MTEP_PAI ,MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU

SELECT *
--DELETE
FROM MTEP 
WHERE SUBSTRING(MTEP_PAI,1,3) IN ('P21', 'P22')
AND MTEP_SEQ <> '10'



INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CASE SUBSTRING(MTPR_COD,5,3)      --CONVERT(varchar(20),'') C�digo (Filho)
		when '019' then CONVERT(varchar(20),'B01.005.0M3')
		when '020' then CONVERT(varchar(20),'B01.005.0M3')
		when '024' then CONVERT(varchar(20),'B01.006.0M3')
		when '025' then CONVERT(varchar(20),'B01.006.0M3')
		when '030' then CONVERT(varchar(20),'B01.006.0M3')
		when '032' then CONVERT(varchar(20),'B01.006.0M3')
		when '038' then CONVERT(varchar(20),'B01.008.0M3')
		when '040' then CONVERT(varchar(20),'B01.008.0M3')
		when '048' then CONVERT(varchar(20),'B01.008.0M4')
		when '050' then CONVERT(varchar(20),'B01.008.0M4')
		when '063' then CONVERT(varchar(20),'B01.008.0M4')
		when '080' then CONVERT(varchar(20),'B01.008.0M4')
	END
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),1)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM MTPRWHERE SUBSTRING(MTPR_COD,1,3) = 'P21'INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CASE SUBSTRING(MTPR_COD,5,3)      --CONVERT(varchar(20),'') C�digo (Filho)
		when '019' then CONVERT(varchar(20),'P02.020.000')
		when '020' then CONVERT(varchar(20),'P02.020.000')
		when '024' then CONVERT(varchar(20),'P02.025.000')
		when '025' then CONVERT(varchar(20),'P02.025.000')
		when '030' then CONVERT(varchar(20),'P02.032.000')
		when '032' then CONVERT(varchar(20),'P02.032.000')
		when '038' then CONVERT(varchar(20),'P02.040.000')
		when '040' then CONVERT(varchar(20),'P02.040.000')
		when '048' then CONVERT(varchar(20),'P02.050.000')
		when '050' then CONVERT(varchar(20),'P02.050.000')
		when '063' then CONVERT(varchar(20),'P02.063.000')
		when '080' then CONVERT(varchar(20),'P02.080.000')
	END
	, MTEP_SEQ = CONVERT(int,'20')      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = CONVERT(decimal(12),1)      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = CONVERT(decimal(10),'0')      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM MTPRWHERE SUBSTRING(MTPR_COD,1,3) = 'P22'INSERT INTO MTEPSELECT TOP 1 * FROM #MTEPWHERE MTEP_PAI+'/'+MTEP_FIL NOT IN (SELECT MTEP_PAI+'/'+MTEP_FIL FROM MTEP)
ORDER BY MTEP_PAI, MTEP_SEQ--MTEP_PAI ,MTEP_FIL ,MTEP_SEQ ,MTEP_QTD ,MTEP_PCT ,MTEP_GNEC ,MTEP_USC ,MTEP_DTC ,MTEP_USU ,MTEP_DTU

--select *
update mtpc set MTPC_MTPR = MTPC_COD, MTPC_USU = 'KINKEL',	MTPC_DTU = getdate()
from mtpc
where mtpc_cod like 'P21%'

--select *
update mtpc set MTPC_MTPR = MTPC_COD, MTPC_USU = 'KINKEL',	MTPC_DTU = getdate()
from mtpc
where mtpc_cod like 'P22%'
