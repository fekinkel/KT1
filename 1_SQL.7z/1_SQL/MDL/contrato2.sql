ALTER TABLE VDCX DISABLE TRIGGER ALL
select round(MTPC_PRE*VDCX_PUN_PCT/100,2), b.*
--update VDCX set VDCX_PUN_VAL = round(MTPC_PRE*VDCX_PUN_PCT/100,2), VDCX_PUN_MOD = 'S'
from vdcv a, VDCX b, MTPC c
where VDCV_COD = VDCX_VDCV
			and VDCX_MTPC = MTPC_COD
--			and round(MTPC_PRE*VDCX_PUN_PCT/100,2) <> VDCX_PUN_VAL
			and VDCV_ATV = 'S'
ALTER TABLE VDCX ENABLE TRIGGER ALL

drop table #vdcx
select VDCX_VDCV,	VDCX_MTPC, VDCX_PUN_VAL
into #vdcx
from [bkp].[dbo].vdcv a, [bkp].[dbo].VDCX b
where VDCV_COD = VDCX_VDCV
			and VDCV_ATV = 'S'
			and VDCX_PUN_MOD = 'S'

ALTER TABLE VDCX DISABLE TRIGGER ALL

select b.*
--update VDCX set VDCX_PUN_VAL = b.VDCX_PUN_VAL
from VDCX a, #vdcx b
where a.VDCX_VDCV = b.VDCX_VDCV
			and a.VDCX_MTPC = b.VDCX_MTPC

--			and VDCX_MTPC = MTPC_COD
--			and round(MTPC_PRE*VDCX_PUN_PCT/100,2) <> VDCX_PUN_VAL
			and VDCX_PUN_MOD = 'S'
ALTER TABLE VDCX ENABLE TRIGGER ALL

