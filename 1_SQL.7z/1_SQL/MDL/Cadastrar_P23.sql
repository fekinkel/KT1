IF OBJECT_ID('TempDB.dbo.#MTPR') IS NOT NULL DROP TABLE #MTPRSELECT *, MTPR_COD MTPR_COD_OLD INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD = Stuff(mtpr_cod,3,1,'3')      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP --= CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS --= CONVERT(char(1),'')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = MTPR_NOM + CONVERT(varchar(80),' P/GRAFITADA')      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),'2590')      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI --= CONVERT(char(1),'')      --CONVERT(char(1),'') Origem
	, MTPR_PES --= CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = MTPR_DES + CONVERT(varchar(80),' P/GRAFITADA')      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV --= Null      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN --= Null      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT --= Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN --= Null      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT --= Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV --= CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV --= Null      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC --= CONVERT(char(1),'')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC --= Null      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE --= CONVERT(decimal,'')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	, MTPR_COD = Stuff(mtpr_cod,3,1,'1')
	--select *
from mtpr
where substring(mtpr_cod,1,4) = 'P20.' 
INSERT INTO MTPRSELECT MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTUFROM #MTPRWHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)
--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU

IF OBJECT_ID('TempDB.dbo.#MTES') IS NOT NULL DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = STUFF(MTES_MTPR,3,1,'3')      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.
	, MTES_MTAL --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN --= Null      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP --= Null      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU = 0--Null      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU = 0--Null      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM = 0--Null      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS = 0--Null      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC = 0--Null      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO = 0--Null      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME = 0--Null      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR = 0--Null      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN = 0--Null      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ --= Null      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM --= Null      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI --= Null      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM --= Null      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL --= Null      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC --= Null      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO = Null      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD --= Null      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM --= Null      --CONVERT(int(8),'') LT Urg�ncia (dias)
	, MTES_EXPL --= CONVERT(char(1),'')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP --= CONVERT(char(1),'')      --CONVERT(char(1),'') Pol�tica
	, MTES_CREP = 0--Null      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR = 0--Null      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF = 0--Null      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT --= CONVERT(int(8),'')      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT = 0--Null      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 --= Null      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 --= Null      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 --= Null      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 --= Null      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT --= Null      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from mtES
where substring(mtES_MTPR,1,4) = 'P20.' 
AND MTES_SIES = 5INSERT INTO MTESSELECT *FROM #MTESWHERE MTES_MTPR+'/'+CONVERT(VARCHAR(6),MTES_SIES) NOT IN (SELECT MTES_MTPR+'/'+CONVERT(VARCHAR(6),MTES_SIES)FROM MTES)
--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU


IF OBJECT_ID('TempDB.dbo.#PRE') IS NOT NULL DROP TABLE #PRE
SELECT mtpr_cod COD, ROUND(b.MTPC_PRE*1.1, (4+3)-LEN(b.MTPC_PRE*1.1)) PRE
into #PRE
FROM MTPC b, #MTPR
WHERE b.MTPC_COD = MTPR_COD_OLD 


update mtpc set mtpc_pre = pre
FROM MTPC, #pre
WHERE MTPC_COD = COD 

update mtpr set mtpr_atv = 'S'
FROM MTPr, #pre
WHERE MTPr_COD = COD 
