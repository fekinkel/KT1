select MTPX_SIEX,	MTPX_COD,	MTPX_NOM, MTPV_VAL
from mtpv, mtpx
where MTPV_MTPU = MTPX_MTPU
and 

