--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 26/02/2018--DEPARTAMENTO : VENDAS--ASSUNTO      : ALTERA��O DO PRE�O DE VENDAS------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#VDC1') IS NOT NULL DROP TABLE #VDC1SELECT * INTO #VDC1 FROM VDC1 WHERE 1 = 0INSERT INTO #VDC1SELECT a.*FROM VDC1 a,  vdcoWHERE VDC1_SIES	=VDCO_SIESAND VDC1_SIDO	= VDCO_SIDOAND VDC1_SISE	= VDCO_SISEAND VDC1_VDCO =VDCO_CODand VDC1_VDCO = 373419--373393--373148--373157--373148AND VDC1_SUB = 0AND VDC1_OBS <> ''AND SUBSTRING(VDC1_OBS,1,1) IN ('0','1','2','3','4','5','6','7','8','9')--select * from #vdc1IF (SELECT COUNT(1) FROM #VDC1)>0 BEGIN	IF OBJECT_ID('TempDB.dbo.#VDC2') IS NOT NULL DROP TABLE #VDC2	SELECT VDC1_SIES SIES
	,	VDC1_SIDO SIDO
	,	VDC1_SISE SISE
	,	VDC1_VDCO VDCO
	,	VDC1_COD COD
	,	VDC1_SUB SUB
	--, CONVERT(DECIMAL(12,1),replace(REPLACE(RTRIM(LTRIM(VDC1_OBS)),',','.'),char(13)+char(10),''))	--, vdc1_puni	--, VDC1_PUNID 	--,vdc1_desc	--, vdc1_val	, convert(decimal(12,4),replace(REPLACE(RTRIM(LTRIM(VDC1_OBS)),',','.'),char(13)+char(10),'')) vdc1_PUNI_NEW	, convert(decimal(12,4),replace(REPLACE(VDC1_OBS,',','.'),char(13)+char(10),''))*vdc1_qtde vdc1_val_NEW	, convert(decimal(12,4),100-((convert(decimal(12,4),replace(REPLACE(RTRIM(LTRIM(VDC1_OBS)),',','.'),char(13)+char(10),''))) * 100 / vdc1_puni)) vdc1_desc_new	into #vdc2	FROM #VDC1	--select *	UPDATE VDC1 SET VDC1_PUNID = vdc1_PUNI_NEW, VDC1_VAL = vdc1_val_NEW, VDC1_DESC = vdc1_desc_new, VDC1_OBS = '', VDC1_USU = 'KINKEL', VDC1_DTU = GETDATE()	from #vdc2, vdc1	where VDC1_SIES = SIES
	AND VDC1_SIDO = SIDO
	AND VDC1_SISE = SISE
	AND VDC1_VDCO = VDCO
	AND VDC1_COD = COD
	AND VDC1_SUB = SUB
END ELSE BEGIN
	PRINT 'N�O EXISTE ITENS COM DESCONTO A SER APLICADO'
END
