
select SIGO_SIGR ,SIGO_SIAP ,SIGO_SIMD ,'MNURELORDENSPRODUCAO2' SIGO_SIOP ,'KINKEL' SIGO_USC ,GETDATE() SIGO_DTC ,null SIGO_USU ,null SIGO_DTU
DELETE
from sigo
where sigo_siop = 'mnurelordensproducao2'

insert into sigo
select SIGO_SIGR ,SIGO_SIAP ,SIGO_SIMD ,'MNURELORDENSPRODUCAO2' SIGO_SIOP ,'KINKEL' SIGO_USC ,GETDATE() SIGO_DTC ,null SIGO_USU ,null SIGO_DTU
from sigo
where sigo_siop = 'mnurelordensproducao'