
--BS602 - 15vc
--BS605 - Lancer
--BS603 - R-36
--BS604 - R36-E
--BS614 - 25H
--BS608 - 10H
--BS609 - 20H
--BS613 - BUCK  

select *--YEAR(PROT_DTC) ANO, MONTH(PROT_DTC) MES, PROT_PRCT, sum(PROT_TFIX) PREPARACAO, sum(PROT_TVAR)EXECUSAO, (sum(PROT_TFIX)+sum(PROT_TVAR)) TOTAL
from prot, pror
where PROT_SIES	= pror_sies
and PROT_SIDO = pror_sido
and PROT_SISE	= pror_sise
and PROT_PROR = pror_cod
and convert(varchar(10),PROT_DTC, 102) >= '2016.01.01'
and PROT_PRCT in ('BS602', 'BS605', 'BS603', 'BS604', 'BS614', 'BS608', 'BS609', 'BS613', ' BS607')

--group by YEAR(PROT_DTC), MONTH(PROT_DTC), PROT_PRCT
--order by YEAR(PROT_DTC), MONTH(PROT_DTC), PROT_PRCT



select YEAR(PROT_DTC) ANO, MONTH(PROT_DTC) MES, PROT_PRCT, sum(PROT_TFIX) PREPARACAO, sum(PROT_TVAR)EXECUSAO, (sum(PROT_TFIX)+sum(PROT_TVAR)) TOTAL
from prot, pror
where PROT_SIES	= pror_sies
and PROT_SIDO = pror_sido
and PROT_SISE	= pror_sise
and PROT_PROR = pror_cod
and convert(varchar(10),PROT_DTC, 102) >= '2016.01.01'
and PROT_PRCT in ('BS602', 'BS605', 'BS603', 'BS604', 'BS614', 'BS608', 'BS609', 'BS613', 'BS607')
and PROR_MTPR not in ('ZAFI', 'ZMEV', 'OSSI', 'OR1', 'OR2', 'OSGS', 'ORSA', 'OSGSP', 'OSGMQ', 'OSGST')
group by YEAR(PROT_DTC), MONTH(PROT_DTC), PROT_PRCT
order by YEAR(PROT_DTC), MONTH(PROT_DTC), PROT_PRCT


select YEAR(PROT_DTC) ANO, MONTH(PROT_DTC) MES, PROT_PRCT, sum(PROT_TFIX) PREPARACAO, sum(PROT_TVAR)EXECUSAO, (sum(PROT_TFIX)+sum(PROT_TVAR)) TOTAL
from prot, pror
where PROT_SIES	= pror_sies
and PROT_SIDO = pror_sido
and PROT_SISE	= pror_sise
and PROT_PROR = pror_cod
and convert(varchar(10),PROT_DTC, 102) >= '2016.01.01'
and PROT_PRCT in ('BS602', 'BS605', 'BS603', 'BS604', 'BS614', 'BS608', 'BS609', 'BS613', 'BS607')
and PROR_MTPR in ('ZAFI', 'ZMEV', 'OSSI', 'OR1', 'OR2', 'OSGS', 'ORSA', 'OSGSP', 'OSGMQ', 'OSGST')
group by YEAR(PROT_DTC), MONTH(PROT_DTC), PROT_PRCT
order by YEAR(PROT_DTC), MONTH(PROT_DTC), PROT_PRCT
