select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blmbs.%'
			--and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blmb.%'
			--and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'mpb.%'
			--and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'tpcbs.%'
			--and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'tpcb.%'
			--and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'msbs.%'
			and mtpr_cod like '%a'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'msb.%'
			and mtpr_cod like '%a'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'mbs.%'
			and mtpr_cod like '%A'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'mb.%'
			--and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'pfb.%'
			and mtpr_cod like '%B'
			--and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'


select *
--update mtpr set MTPR_MTTP = 'MP-MAT�RIA PRIMA'
from mtpr
where mtpr_cod like 'tfb.%'
			and mtpr_cod like '%B'
			and substring(mtpr_cod,5,3)> 44 
			and mtpr_atv = 's'

--n�o est� feito
select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'psmb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blkhb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blkb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PI-PRODUTO INTERMEDI�RIO'
from mtpr
where mtpr_cod like 'blehb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blehbN.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PI-PRODUTO INTERMEDI�RIO'
from mtpr
where mtpr_cod like 'bleb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blebN.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blhb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'blb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PI-PRODUTO INTERMEDI�RIO'
from mtpr
where mtpr_cod like 'ppeb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'ppebn.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'

select *
--update mtpr set MTPR_MTTP = 'PA-PRODUTO ACABADO'
from mtpr
where mtpr_cod like 'ppb.%'
			and mtpr_cod like '%B'
			and mtpr_atv = 's'
			
--select top 1 * from mtpr where mtpr_cod like 'tfb.%'