drop table #new

select VDC1_MTDV DIV, VDC1_VDCO NUM, sum(VDC1_PUNID) Valor, sum(VDC1_PUNID)/5000.00 De_5, sum(VDC1_QTDE) QTd, YEAR(vdc1_dtc)ANO, MONTH(vdc1_dtc)MES
into #new
from VDC1, VDCO
where VDC1_VDCO = VDCO_COD
			and VDC1_SIES = VDCO_SIES
			and VDC1_SIDO = VDCO_SIDO
			and VDC1_SISE = VDCO_SISE
			and convert(varchar(10),VDC1_DTC,102) between '2014.01.01' and '2014.12.31'
			and VDC1_MTDV in (2000,3500)
			and VDC1_SUB = 0
			and VDC1_TIPO = 'ESPE'
group by VDC1_MTDV, VDC1_VDCO, YEAR(vdc1_dtc), MONTH(vdc1_dtc)
order by VDC1_MTDV, VDC1_VDCO, YEAR(vdc1_dtc), MONTH(vdc1_dtc)

drop table #cot_5
select DIV, ANO, MES, SUM(Valor) VAL_0_5, count(1) QDE_0_5--, 99999999.00 VAL_5_10, 999999 QDE_5_10, 99999999.00 VAL_10_15, 999999 QDE_10_15, 99999999.00 VAL_15_99, 999999 QDE_15_99 
into #cot_5
from #new
where De_5 >= 0 and De_5 <= 1
group by DIV, ANO, MES
order by DIV, ANO, MES

drop table #cot_10
select DIV, ANO, MES, SUM(Valor) VAL_0_5, count(1) QDE_0_5--, 99999999.00 VAL_5_10, 999999 QDE_5_10, 99999999.00 VAL_10_15, 999999 QDE_10_15, 99999999.00 VAL_15_99, 999999 QDE_15_99 
into #cot_10
from #new
where De_5 > 1 and De_5 <= 2
group by DIV, ANO, MES
order by DIV, ANO, MES

drop table #cot_15
select DIV, ANO, MES, SUM(Valor) VAL_0_5, count(1) QDE_0_5--, 99999999.00 VAL_5_10, 999999 QDE_5_10, 99999999.00 VAL_10_15, 999999 QDE_10_15, 99999999.00 VAL_15_99, 999999 QDE_15_99 
into #cot_15
from #new
where De_5 > 2 and De_5 <= 3
group by DIV, ANO, MES
order by DIV, ANO, MES

drop table #cot_99
select DIV, ANO, MES, SUM(Valor) VAL_0_5, count(1) QDE_0_5--, 99999999.00 VAL_5_10, 999999 QDE_5_10, 99999999.00 VAL_10_15, 999999 QDE_10_15, 99999999.00 VAL_15_99, 999999 QDE_15_99 
into #cot_99
from #new
where De_5 > 3 --and De_5 <= 2
group by DIV, ANO, MES
order by DIV, ANO, MES

--update #cot set VAL_5_10 = 0,	QDE_5_10 = 0,	VAL_10_15 = 0,	QDE_10_15 = 0,	VAL_15_99 = 0,	QDE_15_99 = 0

select a.DIV, a.ANO, a.MES, replace(a.VAL_0_5,'.',',')VAL_0_5, replace(a.QDE_0_5,'.',',') QDE_0_5, replace(isnull(b.VAL_0_5,0),'.',',') VAL_5_10, replace(isnull(b.QDE_0_5,0),'.',',') QDE_5_10, replace(isnull(c.VAL_0_5,0),'.',',') VAL_10_15, replace(isnull(c.QDE_0_5,0),'.',',') QDE_10_15, replace(isnull(d.VAL_0_5,0),'.',',') VAL_15_99, replace(isnull(d.QDE_0_5,0),'.',',') QDE_15_99, replace((isnull(a.VAL_0_5,0) + isnull(b.VAL_0_5,0) +  isnull(c.VAL_0_5,0) + isnull(d.VAL_0_5,0)),'.',',') TOTAL
from #cot_5 a left join #cot_10 b on a.ANO = b.ANO and a.MES = b.MES and a.DIV = b.DIV left join #cot_15 c on a.ANO = c.ANO and a.MES = c.MES and a.DIV = c.DIV left join #cot_99 d on a.ANO = d.ANO and a.MES = d.MES and a.DIV = d.DIV

--select * from #new

--drop table #cot
--select * from #cot

--total
select VDC1_MTDV, sum(VDC1_PUNID), sum(VDC1_QTDE), YEAR(vdc1_dtc), MONTH(vdc1_dtc)
from VDC1, VDCO
where VDC1_VDCO = VDCO_COD
			and VDC1_SIES = VDCO_SIES
			and VDC1_SIDO = VDCO_SIDO
			and VDC1_SISE = VDCO_SISE
			and convert(varchar(10),VDC1_DTC,102) between '2014.01.01' and '2014.12.31'
			and VDC1_MTDV in (2000,3500)
			and VDC1_SUB = 0
			and VDC1_TIPO = 'ESPE'
group by VDC1_MTDV, YEAR(vdc1_dtc), MONTH(vdc1_dtc)
order by VDC1_MTDV, YEAR(vdc1_dtc), MONTH(vdc1_dtc)


select *
from #new
where ANO = 2014 and MES = 9
order by valor, ANO, MES
