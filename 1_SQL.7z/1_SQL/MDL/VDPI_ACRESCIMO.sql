--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 07/03/2018--DEPARTAMENTO : VENDAS--ASSUNTO      : ACRESCIMO DE VALOR INCLUINDO O ITEM 99 COM BASE O VALOR FINAL--OBS.: N�O PRECISA PREENCHER O DESCONTO E COLOCAR O VALOR FINAL------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #newSELECT NUM = 244584, ITEM = 2, VAL = (3200.49), desco = 0 INTO #NEW-- menos 10.51
--SELECT NUM = 244584, ITEM = 1, VAL = 1275.38, desco = 0 INTO #NEW-- menos 10.51
--SELECT *UPDATE #NEW SET VAL = ((VAL-VDPI_PUND)*100/(100-VDPI_DESC)), DESCO = VDPI_DESCFROM VDPI a, #NEWWHERE a.VDPI_SIES = 5
AND	a.VDPI_SIDO = 'VDPD'
and	a.VDPI_SISE = '001'
and	a.VDPI_VDPD = NUM
and a.VDPI_COD = ITEM
IF OBJECT_ID('TempDB.dbo.#VDPS') IS NOT NULL DROP TABLE #VDPSSELECT * INTO #VDPS FROM VDPS WHERE 1 = 0INSERT INTO #VDPSSELECT 		VDPS_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, VDPS_SIDO = CONVERT(varchar(4),'VDPD')      --CONVERT(varchar(4),'') Tipo
	, VDPS_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, VDPS_VDPD = CONVERT(int,NUM)      --CONVERT(int(6),'') Pedido
	, VDPS_VDPI = CONVERT(int,ITEM)      --CONVERT(int(3),'') Item
	, VDPS_COD = CONVERT(int,'99')      --CONVERT(int(3),'') Sub-Item
	, VDPS_MTPC = CONVERT(varchar(20),'++')      --CONVERT(varchar(20),'') Refer�ncia
--	, VDPS_NOM = CONVERT(varchar(255),'ACRESCIMO')      --CONVERT(varchar(255),'') Descri��o
	, VDPS_NOM = CONVERT(varchar(255),'JUROS')      --CONVERT(varchar(255),'') Descri��o
	, VDPS_MTPR = CONVERT(varchar(20),'++')      --CONVERT(varchar(20),'') Insumo
	, VDPS_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, VDPS_MTUN = CONVERT(varchar(3),'UN')      --CONVERT(varchar(3),'') Unidade
	, VDPS_MTNC = CONVERT(varchar(8),'84669410')      --CONVERT(varchar(8),'') NCM
	, VDPS_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, VDPS_MTDV = CONVERT(varchar(4),'9999')      --CONVERT(varchar(4),'') Divis�o
	, VDPS_MTLN = CONVERT(varchar(4),'9999')      --CONVERT(varchar(4),'') Linha
	, VDPS_MTFM = CONVERT(varchar(4),'9999')      --CONVERT(varchar(4),'') Fam�lia
	, VDPS_PLIQ = Null      --CONVERT(decimal(13),'') Peso L�q.
	, VDPS_PLQT = Null      --CONVERT(decimal(13),'') Peso Tot.
	, VDPS_PBRT = Null      --CONVERT(decimal(13),'') Peso Bruto
	, VDPS_COMPO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Composto
	, VDPS_EST = CONVERT(char(1),'N')      --CONVERT(char(1),'') Estoque
	, VDPS_QTD = 1--Null      --CONVERT(decimal(12),'') Quantidade
	, VDPS_QTDC = 1--Null      --CONVERT(decimal(12),'') Quantidade p/ Compra
	, VDPS_PUN = CONVERT(decimal(12,2),VAL)      --CONVERT(decimal(12),'') Pre�o
	, VDPS_PUND = CONVERT(decimal(12,2),VAL)      --CONVERT(decimal(12),'') Pre�o c/ Desc.
	, VDPS_VAL = VAL--Null      --CONVERT(decimal(12),'') Total
	, VDPS_PENT = Null      --CONVERT(int(3),'') Entrega (dias)
	, VDPS_DENT = Null      --CONVERT(datetime(10),'') Entrega
	, VDPS_OBS = Null      --CONVERT(varchar(255),'') Obs.
	, VDPS_CMAT = Null      --CONVERT(decimal(12),'') Material
	, VDPS_FMAT = Null      --CONVERT(decimal(9),'') Fator MAT
	, VDPS_CMDO = Null      --CONVERT(decimal(12),'') Recursos
	, VDPS_FMDO = Null      --CONVERT(decimal(9),'') Fator MDO
	, VDPS_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDPS_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDPS_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDPS_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #NEWINSERT INTO VDPSSELECT *FROM #VDPS--WHERE CONVERT(VARCHAR(6),VDPS_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),VDPS_SIES)FROM VDPS)
--VDPS_SIES ,VDPS_SIDO ,VDPS_SISE ,VDPS_VDPD ,VDPS_VDPI ,VDPS_COD ,VDPS_MTPC ,VDPS_NOM ,VDPS_MTPR ,VDPS_MS ,VDPS_MTUN ,VDPS_MTNC ,VDPS_ORI ,VDPS_MTDV ,VDPS_MTLN ,VDPS_MTFM ,VDPS_PLIQ ,VDPS_PLQT ,VDPS_PBRT ,VDPS_COMPO ,VDPS_EST ,VDPS_QTD ,VDPS_QTDC ,VDPS_PUN ,VDPS_PUND ,VDPS_VAL ,VDPS_PENT ,VDPS_DENT ,VDPS_OBS ,VDPS_CMAT ,VDPS_FMAT ,VDPS_CMDO ,VDPS_FMDO ,VDPS_USC ,VDPS_DTC ,VDPS_USU ,VDPS_DTU ,

SELECT *--delete vdpsFROM VDPS a, #VDPS bwhere a.VDPS_SIES = b.VDPS_SIES
AND	a.VDPS_SIDO = b.VDPS_SIDO
and	a.VDPS_SISE = b.VDPS_SISE
and	a.VDPS_VDPD = b.VDPS_VDPD
and a.VDPS_VDPI = b.VDPS_VDPI
and a.VDPS_COD  = b.VDPS_COD

--select VDPI_PUN, 	VDPI_PUND = VDPI_PUN-(VDPI_PUN*desco/100),	VDPI_DESC = desco, VDPI_VAL
--update vdpi set VDPI_PUND = VDPI_PUN-(VDPI_PUN*desco/100),	VDPI_DESC = desco, VDPI_VAL = VDPI_PUN-(VDPI_PUN*desco/100)
--from VDPI, #new
--where vdpi_vdpd = num

