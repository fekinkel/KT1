select antigo, *--pror_mtpr, novo, *
from pror, TMP_MTPR_PLAN
where pror_cod IN (103211, 102975, 102829) 
--(103258, 103262, 103259, 103261, 103385) 
--(103138, 103024, 103015, 103021, 103138, 103260, 103038, 102690, 103044, 103039, 103043, 103037, 102689 )
--and pror_mtpr = novo
--AND pror_mtpr <> novo
and convert(varchar(10),pror_dtc,102) <='2018.01.12'

select antigo, *
from prnc, TMP_MTPR_PLAN
where prnc_sies = 5
and PRNC_SIDO = 'vdpd'
and convert(varchar(10),PRNC_NPAI)+'/'+convert(varchar(10),PRNC_COD) in ('247699/7', '247699/16', '247727/14', '247727/1', '247727/2', '247727/3', '247727/13', '247799/2', '247280/1', '247280/2', '247699/13')
and PRNC_MTPR = novo

select antigo, *
from prnc, TMP_MTPR_PLAN
where prnc_sies = 5
and PRNC_SIDO = 'PROR'
and PRNC_NPAI in  (103138, 103024, 103015, 103021, 103138, 103260, 103038, 102690, 103044, 103039, 103043, 103037, 102689 )
and PRNC_MTPR = novo
and convert(varchar(10),prNC_dtc,102) <='2018.01.12'
