select *
from sidc
where SIDC_COD like '%_glfu'

ALTER TABLE PRAH DISABLE TRIGGER ALL
select *
--update prah set PRAH_GLFU = '000153'
from PRAH
where PRAH_GLFU = '000196'
			
ALTER TABLE PRAH ENABLE TRIGGER ALL