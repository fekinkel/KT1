--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 19/01/2018--DEPARTAMENTO : SISTEMA--ASSUNTO      : TROCAR O C�DIGO NOVO PARA ANTIGO------------------------------------------------------------------------------------------------------------------------

IF OBJECT_ID('TempDB.dbo.#ANT') IS NOT NULL DROP TABLE #ANT
select antigo, PRNC_PROJ PROJ, PRNC_SIES SIES, PRNC_SIDO SIDO, PRNC_SISE SISE, PRNC_NPAI NPAI, PRNC_COD COD --*
INTO #ANT
from prnc, TMP_MTPR_PLAN
where prnc_sies = 5
and PRNC_SIDO = 'vdpd'
and PRNC_NPAI in (247984)
--(247210, 247211)
--(247115)
--(248210)
--(247672) 
--(247672, 247565)
and PRNC_MTPR = novo
and convert(varchar(10),prNC_dtc,102) <='2018.01.12'

begin tran 
SELECT * FROM prnc (HOLDLOCK)

ALTER TABLE PRNC DISABLE TRIGGER ALL
update prNC set prNC_mtpr = antigo
--select antigo, *
from prnc, #ANT
where prnc_sies = SIES
and PRNC_SIDO = SIDO
and PRNC_NPAI = NPAI
AND PRNC_COD  = COD

ALTER TABLE PRNC enABLE TRIGGER ALL

commit
 
/*
ALTER TABLE PRNC DISABLE TRIGGER ALL
update prNC set prNC_mtpr = antigo
--select antigo, *
from prnc, TMP_MTPR_PLAN
where prnc_sies = 5
and PRNC_SIDO = 'vdpd'
and convert(varchar(10),PRNC_NPAI)+'/'+convert(varchar(10),PRNC_COD) in ('247699/7', '247699/16', '247727/14', '247727/1', '247727/2', '247727/3', '247727/13', '247799/2', '247280/1', '247280/2', '247699/13')
and PRNC_MTPR = novo

ALTER TABLE PRNC enABLE TRIGGER ALL
*/
/*
ALTER TABLE PROR NOCHECK CONSTRAINT FK_PROR_PRRA_PRRA
ALTER TABLE PROR DISABLE TRIGGER ALL
update pror set pror_mtpr = antigo
--select antigo, *--pror_mtpr, novo, *
from pror, TMP_MTPR_PLAN
where pror_cod IN (103138, 103024, 103015, 103021, 103138, 103260, 103038, 102690, 103044, 103039, 103043, 103037, 102689 )
and pror_mtpr = novo
--AND pror_mtpr <> novo
and convert(varchar(10),pror_dtc,102) <='2018.01.12'

ALTER TABLE PRor enABLE TRIGGER ALL
ALTER TABLE PROR CHECK CONSTRAINT FK_PROR_PRRA_PRRA
*/
/*
ALTER TABLE PROR NOCHECK CONSTRAINT FK_PROR_PRRA_PRRA
ALTER TABLE PROR DISABLE TRIGGER ALL
--select pror_mtpr, novo, *
update pror set pror_mtpr = novo
from pror, TMP_MTPR_PLAN
where pror_cod IN (103138, 103024, 103015, 103021, 103138, 103260, 103038, 102690, 103044, 103039, 103043, 103037, 102689 )
and pror_mtpr = antigo
AND pror_mtpr <> novo

ALTER TABLE PRor enABLE TRIGGER ALL
ALTER TABLE PROR CHECK CONSTRAINT FK_PROR_PRRA_PRRA
*/
