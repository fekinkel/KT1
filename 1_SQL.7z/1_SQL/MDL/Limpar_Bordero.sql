drop table #bordero
Select Substring(line,39,4) sido, Substring(line,46,6) numdoc, Substring(line,52,3) item 
into #bordero
From Dbo.uftReadfileAsTable('C:\Temp','CB21121.TXT')
where substring(line,39,2) = 'FT' 

select *
--update cfcr set CFCR_GLCC = '999-02', CFCR_USU = 'KINKEL', CFCR_DTU = GETDATE()
from cfcr, #bordero
where CFCR_COD = numdoc
and cfcr_sido = sido
and CFCR_SEQ = item


select *
--update cfer set CFER_ESTA = 'NP', CFER_EOCO = '01', CFER_RSTA = '',	CFER_ROCO = '', CFER_RNOM = '', CFER_RDAT = null, CFER_RMOT = '', CFER_GLCC = '237-03', CFER_CART = '002', CFER_PMUL = '0.0000', CFER_PJUR = '0.3400', CFER_PDES = '0.0000', CFER_NNU = '',	CFER_NNU_DIG = '', CFER_USU = 'KINKEL',	CFER_DTU = GETDATE()
from cfer, #bordero
where CFER_SIDO = sido
and CFER_CFCR = numdoc
and CFER_SEQ = item


--10000000000000000000000203392001390255FT55001101946003        0000000000000000000800000000001N      
--12345678901234567890123456789012345678901234567890123456