select convert(varchar(6),RCNF_SIES)+'/'+RCNF_SIDO+'/'+RCNF_SISE+'/'+convert(varchar(10),	RCNF_COD) RCNF, convert(varchar(10),RCNF_DAT,103) DATA, RCNF_SIDX+'/'+RCNF_SISX+'/'+convert(varchar(6),	RCNF_CODX) [NOTA FISCAL], rcit_mtpr [C�DIGO], RCIT_QTD QUANTIDADE, RCIT_NOM [DESCRI��O], stuff(stuff(stuff(stuff(glpa_cnpj,13,0,'-'),9,0,'/'),6,0,'.'),3,0,'.') CNPJ, glpa_nom [EMPRESA], char(39)+RCNF_NFE_CHV [CHAVE]
from rcnf, rcit, glpa
where rcnf_sies = rcit_sies
and rcnf_sido = rcit_sido
and rcnf_sise = rcit_sise
and rcnf_cod  = rcit_rcnf
and rcit_mtpr = 'dep.063.002'
and glpa_cod = rcnf_glpa
order by rcnf_dat

select convert(varchar(6),RCNF_SIES)+'/'+RCNF_SIDO+'/'+RCNF_SISE+'/'+convert(varchar(10),	RCNF_COD) RCNF, convert(varchar(10),RCNF_DAT,103) DATA, RCNF_SIDX+'/'+RCNF_SISX+'/'+convert(varchar(6),	RCNF_CODX) [NOTA FISCAL], rcit_mtpr [C�DIGO], RCIT_QTD QUANTIDADE, RCIT_NOM [DESCRI��O], stuff(stuff(stuff(stuff(glpa_cnpj,13,0,'-'),9,0,'/'),6,0,'.'),3,0,'.') CNPJ, glpa_nom [EMPRESA], char(39)+RCNF_NFE_CHV [CHAVE]
from rcnf, rcit, glpa
where rcnf_sies = rcit_sies
and rcnf_sido = rcit_sido
and rcnf_sise = rcit_sise
and rcnf_cod  = rcit_rcnf
and rcit_mtpr LIKE 'dep.040.%'
and glpa_cod = rcnf_glpa
order by rcnf_dat


select convert(varchar(6),RCNF_SIES)+'/'+RCNF_SIDO+'/'+RCNF_SISE+'/'+convert(varchar(10),	RCNF_COD) RCNF, convert(varchar(10),RCNF_DAT,103) DATA, RCNF_SIDX+'/'+RCNF_SISX+'/'+convert(varchar(6),	RCNF_CODX) [NOTA FISCAL], rcit_mtpr [C�DIGO], RCIT_QTD QUANTIDADE, RCIT_NOM [DESCRI��O], stuff(stuff(stuff(stuff(glpa_cnpj,13,0,'-'),9,0,'/'),6,0,'.'),3,0,'.') CNPJ, glpa_nom [EMPRESA], char(39)+RCNF_NFE_CHV [CHAVE]
from rcnf, rcit, glpa
where rcnf_sies = rcit_sies
and rcnf_sido = rcit_sido
and rcnf_sise = rcit_sise
and rcnf_cod  = rcit_rcnf
and rcit_mtpr = 'dep.062.003'
and glpa_cod = rcnf_glpa
order by rcnf_dat

select convert(varchar(6),RCNF_SIES)+'/'+RCNF_SIDO+'/'+RCNF_SISE+'/'+convert(varchar(10),	RCNF_COD) RCNF, convert(varchar(10),RCNF_DAT,103) DATA, RCNF_SIDX+'/'+RCNF_SISX+'/'+convert(varchar(6),	RCNF_CODX) [NOTA FISCAL], rcit_mtpr [C�DIGO], RCIT_QTD QUANTIDADE, RCIT_NOM [DESCRI��O], stuff(stuff(stuff(stuff(glpa_cnpj,13,0,'-'),9,0,'/'),6,0,'.'),3,0,'.') CNPJ, glpa_nom [EMPRESA], char(39)+RCNF_NFE_CHV [CHAVE]
from rcnf, rcit, glpa
where rcnf_sies = rcit_sies
and rcnf_sido = rcit_sido
and rcnf_sise = rcit_sise
and rcnf_cod  = rcit_rcnf
and rcit_mtpr = 'ALM.100.002'
and glpa_cod = rcnf_glpa
order by rcnf_dat

