select *
from vdc1, vdcr
where vdc1_vdco = 322074
and vdc1_sub <> 0
and VDC1_SIES = VDCR_SIES
and	VDC1_SIDO = VDCR_SIDO
and	VDC1_SISE = VDCR_SISE
and	VDC1_VDCO = VDCR_VDCO
and	VDC1_cod = VDCR_VDC1
and	VDC1_SUB = VDCR_SUB

order by VDCR_SIES, VDCR_SIDO, VDCR_SISE, VDCR_VDCO, VDCR_VDC1

select *
from vdc1
where vdc1_vdco = 322074
and vdc1_sub <> 0
