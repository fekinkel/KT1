declare
@STR_EXEC  varchar(4000)

set @STR_EXEC = 'master..xp_cmdshell '+char(39)+' C:\Impressora\Contadores.exe'+char(39)
print @STR_EXEC
Exec(@STR_EXEC)