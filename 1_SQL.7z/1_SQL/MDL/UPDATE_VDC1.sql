select *
--update vdc1 set VDC1_MTPR = 'OM', VDC1_MTPC = 'OM'
from vdc1
where vdc1_vdco = 374951
--374796
and VDC1_SUB = 0