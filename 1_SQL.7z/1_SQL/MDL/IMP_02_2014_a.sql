
delete 
from prro

ALTER TABLE PRRO DISABLE TRIGGER ALL
insert into PRRO
select *
from [newmdl].[dbo].PRRO
where PRRO_PRRA in (select prra_cod from PRRA)
			and convert(varchar(3),PRRO_SIES)+'/'+PRRO_PRCT in (select convert(varchar(3),PRCT_SIES)+'/'+ PRCT_COD from PRCT)
ALTER TABLE PRRO ENABLE TRIGGER ALL
