--N�O ESQUECER DE VERIFICAR BASE DADOS

select a.mtpr_cod, b.mtpr_cod, a.mtpr_pes, b.mtpr_pes
--update [192.168.2.39].[mdl].[dbo].[mtpr] set mtpr_pes =  a.mtpr_pes
from mtpr a, [192.168.2.39].[mdl].[dbo].[mtpr] b 
where a.mtpr_pes >= 0
			--and a.mtpr_cod like 'p35%'
			--and replace(a.mtpr_cod,'P35','P36') = b.mtpr_cod
--			and a.mtpr_cod like 'p15%'
--			and replace(a.mtpr_cod,'P15','P17') = b.mtpr_cod
--			and a.mtpr_cod like 'p25%'
--			and replace(a.mtpr_cod,'P25','P26') = b.mtpr_cod
--			and a.mtpr_cod like 'b45%'
--			and replace(a.mtpr_cod,'B45','B46') = b.mtpr_cod
			and a.mtpr_cod like 'caml%'
--			and replace(a.mtpr_cod,'B45','B46') = b.mtpr_cod

			and a.mtpr_pes <> b.mtpr_pes

select a.mtpr_cod, b.mtpr_cod, a.mtpr_pes, b.mtpr_pes
--update [192.168.2.39].[mdl].[dbo].[mtpr] set mtpr_pes =  a.mtpr_pes
from mtpr a, [192.168.2.39].[mdl].[dbo].[mtpr] b 
where a.mtpr_pes >= 0
--			and a.mtpr_cod like 'b46%'
			and a.mtpr_cod like 'B45%'
			and replace(a.mtpr_cod,'B45','B46') = b.mtpr_cod
			and a.mtpr_cod = b.mtpr_cod
			and b.mtpr_pes <> a.mtpr_pes



select *
from mtpr
where mtpr_nom like '%cal%'
