select *
--update vdco set vdco_glvd = 97
from vdco
where vdco_glvd = 35
			and vdco_sta = 'EA'


select *
--update vdco set vdco_glvd = 41
from vdco
where vdco_glvd = 97
			and vdco_sta = 'EA'

select *
--update glcl set glcl_glvd = 41
from GLCL
where GLCL_GLVD = 41
--			and vdco_sta = 'EA'

