IF OBJECT_ID('TempDB.dbo.#GLPR') IS NOT NULL DROP TABLE #GLPRSELECT * INTO #GLPR FROM GLPR WHERE 1 = 0INSERT INTO #GLPRSELECT 		GLPR_COD-- = CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Par�metro
	, GLPR_CHAV = GLDP_COD--CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Chave
	, GLPR_DEPE = gldp_sies--CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Depend�ncia
	, GLPR_DES --= Null      --CONVERT(varchar(255),'') Descri��o
	, GLPR_VAL --= Null      --CONVERT(decimal(12),'') Valor (Num�rico)
	, GLPR_VALS --= Null      --CONVERT(varchar(50),'') Valor (Caractere)
	, GLPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLPR_DTU = Null      --CONVERT(datetime(10),'') em
--select *
from glpr, gldp
where glpr_cod = 'depcor'
and glpr_chav = '110103'
and gldp_sies = 5
INSERT INTO GLPRSELECT GLPR_COD ,GLPR_CHAV ,GLPR_DEPE ,GLPR_DES ,GLPR_VAL ,GLPR_VALS ,GLPR_USC ,GLPR_DTC ,GLPR_USU ,GLPR_DTUFROM #GLPRWHERE GLPR_COD+'/'+GLPR_CHAV+'/'+GLPR_DEPE NOT IN (SELECT GLPR_COD+'/'+GLPR_CHAV+'/'+GLPR_DEPE FROM GLPR)
--GLPR_COD ,GLPR_CHAV ,GLPR_DEPE ,GLPR_DES ,GLPR_VAL ,GLPR_VALS ,GLPR_USC ,GLPR_DTC ,GLPR_USU ,GLPR_DTU ,


SELECT CTCC_NOM, GLPR_COD ,GLPR_CHAV ,GLPR_DEPE-- ,GLPR_DES ,GLPR_VAL ,GLPR_VALS ,GLPR_USC ,GLPR_DTC ,GLPR_USU ,GLPR_DTUFROM #GLPR, ctccwhere ctcc_cod = glpr_chav