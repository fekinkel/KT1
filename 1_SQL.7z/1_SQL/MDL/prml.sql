select upper(PRMA_UREQ) + char(10)+'	'+PRMA_DES +upper(PRML_USC) + char(10)+'	'+ PRML_LOG+char(10)
from prma, prml
where prma_cod = 3371
and PRMA_SIES	= prml_sies
and PRMA_SIDO	= prml_sido
and PRMA_SISE	= prml_sise
and PRMA_COD  = prml_prma

