select glpa_cep, glpa_cid, b.*
--update GLCL set GLCL_GLVD = 229
from glcl b, glpa a
where glcl_glpa = glpa_cod and(
   glpa_cep between '17580000' and '17589999' --Pompeia
or glpa_cep between  '17500000' and '17539999' --Mar�lia
or glpa_cep between  '16200000' and '16209999' --Birigui
or glpa_cep between  '16300000' and '16309999'--Penapolis
or glpa_cep between  '17400000' and '17409999'--Gar�a
or glpa_cep between  '16400000' and '16429999'--Lins
)
order by glpa_cid