
--ALTERA��O PARA PRE�O ESPECIFICO

select a.*,mtpc_pre, mtpc_pre*VDCX_PUN_PCT/100, *
--update vdcx set VDCX_PUN_VAL = mtpc_pre*VDCX_PUN_PCT/100, VDCX_PUN_MOD = 'S'
from vdcx a, vdcv b, mtpc c, mtpr d, mttp e
where vdcx_vdcv = vdcv_cod
			and mtpc_mtpr = mtpr_cod
			and mtpr_mttp = mttp_cod
			and vdcv_atv = 's'
			and VDCX_MTPC = mtpc_cod
			and MTTP_ESTR <> 'V'
			and VDCX_MTPC = 'PPB.050.071D'
--46754
--46696

select DATEDIFF ( MONTH , VDCV_DTI , VDCV_DTF ),*
--update vdcv set VDCV_REAJ = 'S', VDCV_GLMD = 'REAL', VDCV_NPER =  DATEDIFF ( MONTH , VDCV_DTI , VDCV_DTF ),	VDCV_GLMD_VLR = 1.0, VDCV_GLMD_DTIR = VDCV_DTI
from vdcv
where vdcv_atv = 's'

select DATEDIFF ( MONTH , '02/01/2004' , '25/05/2004' )



--ALTERA��O PARA PRE�O COM PORCENTAGEM

SELECT *
--update vdcv set VDCV_REAJ = 'N', VDCV_GLMD = NULL, VDCV_NPER =  NULL ,	VDCV_GLMD_VLR = NULL, VDCV_GLMD_DTIR = NULL
from vdcv
where vdcv_atv = 's'
			AND VDCV_REAJ <> 'N'


select a.*,mtpc_pre, mtpc_pre*VDCX_PUN_PCT/100, *
--update vdcx set VDCX_PUN_MOD = 'N'
from vdcx a, vdcv b, mtpc c, mtpr d, mttp e
where vdcx_vdcv = vdcv_cod
			and mtpc_mtpr = mtpr_cod
			and mtpr_mttp = mttp_cod
			and vdcv_atv = 's'
			and VDCX_MTPC = mtpc_cod
			and MTTP_ESTR <> 'V'
			AND VDCX_PUN_PCT <> 0
			and vdcx_pun_val <> 0
			and VDCX_VDCV = 4
			and VDCX_VDCV NOT IN (68,73) --=4
			
--			and VDCX_MTPC = 'PPB.050.071D'
