select *
--delete
from mtpc
where mtpc_cod like 'P23%'
and substring(mtpc_cod,5,3) not in ('040','050','063','080')
--and substring(mtpc_cod,5,3) in ('048')
--and mtpc_cod in (select vdc1_mtpc from vdc1)

/*
select *
from vdc1
where vdc1_mtpc like 'P23%'
*/

select *
--delete
from mtpr
where mtpr_cod not in (select mtpc_cod from mtpc)
and mtpr_cod like 'P23%'
