--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 24/08/2017--DEPARTAMENTO : 24/08/2017--ASSUNTO      : 24/08/2017------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#pp') IS NOT NULL DROP TABLE #pp--------------------1------------------------------
select identity(int,1,1) num, MTPR_COD cod, 25 larg, 6 qde, 43.0 dis, 2.5 fonte, 36 tam
into #pp
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tfm.060')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 43.0 dis, 2.5, 36
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.060')
--------------------1------------------------------

--------------------2------------------------------
insert into #pp
select MTPR_COD cod, 25 larg, 6 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tcm.080', 'tcpm.080')

insert into #pp
select MTPR_COD cod, 25 larg, 6 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tcm.100', 'tcpm.100')

insert into #pp
select MTPR_COD cod, 25 larg, 6 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tfm.080')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tfm.100')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.100')

insert into #pp
select MTPR_COD cod, 41 larg, 4 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabh.100')

insert into #pp
select MTPR_COD cod, 25 larg, 6 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tci.037', 'tcpi.037')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tail.025', 'tail.037')

insert into #pp
select MTPR_COD cod, 41 larg, 4 qde, 43.0 dis, 2.5, 40
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('taih.037')

--------------------2------------------------------

--------------------3------------------------------
insert into #pp
select MTPR_COD cod, 25 larg, 6 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tcm.130', 'tcpm.130')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tfm.130')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.130')

insert into #pp
select MTPR_COD cod, 41 larg, 4 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabh.130')

insert into #pp
select MTPR_COD cod, 25 larg, 6 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tci.050', 'tcpi.050')

insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tail.050')

insert into #pp
select MTPR_COD cod, 41 larg, 4 qde, 49.0 dis, 2.5, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('taih.050')

--------------------3------------------------------

--------------------4------------------------------
insert into #pp
select MTPR_COD cod, 25 larg, 3 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tcm.160', 'tcpm.160')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tfm.160')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.160')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabh.160')

insert into #pp
select MTPR_COD cod, 25 larg, 3 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tci.062', 'tcpi.062')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tail.062')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 48
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('taih.062')

--------------------4------------------------------

--------------------5------------------------------
insert into #pp
select MTPR_COD cod, 25 larg, 3 qde, 0.0 dis, 2.5, 53
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tcm.200','tcpm.200')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 53
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tfm.200', 'tabl.200')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 53
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabh.200')

insert into #pp
select MTPR_COD cod, 25 larg, 3 qde, 0.0 dis, 2.5, 53
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tci.075', 'tcpi.075')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 53
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tail.075')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 53
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('taih.075')

--------------------5------------------------------

--------------------6------------------------------
insert into #pp
select MTPR_COD cod, 25 larg, 3 qde, 0.0 dis, 2.5, 61
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tcm.250', 'tcpm.250', 'tcm.320', 'tcpm.320')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 61
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.250', 'tabl.320')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 61
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabh.250', 'tabh.320')

insert into #pp
select MTPR_COD cod, 25 larg, 3 qde, 0.0 dis, 2.5, 61
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tci.100', 'tci.125', 'tcpi.100', 'tcpi.125')

insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 61
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tail.100')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 61
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('taih.100', 'taih.125')
--------------------6------------------------------

--------------------7------------------------------
insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 71
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.380')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 71
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabh.400')
--------------------7------------------------------

--------------------8------------------------------
insert into #pp
select MTPR_COD cod, 32 larg, 2 qde, 0.0 dis, 2.5, 71
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tail.087')

insert into #pp
select MTPR_COD cod, 41 larg, 2 qde, 0.0 dis, 2.5, 71
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('taih.087')
--------------------8------------------------------

--select * from #pp

/*
insert into #pp
select MTPR_COD cod, 32 larg, 4 qde, 49.0 dis, 2.0, 46
from mtpr
where substring(mtpr_cod,1,1) = 'T'
and MTPR_MTDV = '3500'
and MTPR_MTLN = '4200'
and substring(reverse(mtpr_cod),1,1) not in ('*','d','e')
and mtpr_cod in ('tabl.130')
*/
declare
@x int,
@y int,
@f int,
@i int,
@j int,
@k int

set @x =100; set @y =100; set @f = 10

--select * from #pp
IF OBJECT_ID('TempDB.dbo.#ppL') IS NOT NULL DROP TABLE #ppLselect Space(45) Lineinto #ppLwhere 1 = 0set @k = 1

--while @k <= 16 begin
while @k <= (select max(num) from #pp) begin
	if (select dis from #pp where num = @k) > 0 begin
		select @i = 1, @j = qde/2
		from #pp 
		where num = @k
	end else begin
		select @i = 1, @j = qde
		from #pp 
		where num = @k
	end

	while @i <= @j begin
		insert into #ppL
		select convert(char(12),cod)+'40'
		+case when dis = 0 then convert(char(3),@x/2*@f) else convert(char(3),convert(int,(((@x/2)-(dis/2))*@f))) end
		+convert(char(3),((larg*(@i-1))+(larg/2))*@f) --VALOR EM y
		+convert(char(3),'000') --ANGULO
		+convert(char(3), convert(int,fonte*100))
		+'P' --fim de codigo barra
		+replicate('0',3-len(larg*@f))+convert(varchar(3),larg*@f)
		+case when dis = 0 then convert(char(3),@x/2*@f) else convert(char(3),convert(int,(((@x/2)-(dis/2))*@f))) end
		+replicate('0',3-len(convert(varchar(3),(larg*(@i-1))*@f)))+convert(varchar(3),(larg*(@i-1))*@f)
		+replicate('0',3-len(convert(varchar(3),tam*@f)))+convert(varchar(3),tam*@f)
		+'90EE9'+convert(char(1),@i)
		--,convert(char(3),((larg*(@i-1))+(larg/2))*@f) --VALOR EM y
		--,replicate('0',3-len(convert(varchar(3),(larg*(@i-1))*@f)))+convert(varchar(3),(larg*(@i-1))*@f)
		from #pp
		where num = @k
		
		if (select dis from #pp where num = @k) > 0 begin

			insert into #ppL
			select convert(char(12),cod)+'40'
			+case when dis = 0 then convert(char(3),@x/2*@f) else convert(char(3),convert(int,(((@x/2)+(dis/2))*@f))) end
			+convert(char(3),((larg*(@i-1))+(larg/2))*@f) --VALOR EM y
			--+convert(char(3),((larg/2)+larg)*@f) --VALOR EM y
			+convert(char(3),'000') --ANGULO
			+convert(char(3), convert(int,fonte*100))
			+'P' --fim de codigo barra
			+replicate('0',3-len(larg*@f))+convert(varchar(3),larg*@f)
			+case when dis = 0 then convert(char(3),@x/2*@f) else convert(char(3),convert(int,(((@x/2)+(dis/2))*@f))) end
			+replicate('0',3-len(convert(varchar(3),(larg*(@i-1))*@f)))+convert(varchar(3),(larg*(@i-1))*@f)
			+replicate('0',3-len(convert(varchar(3),tam*@f)))+convert(varchar(3),tam*@f)
			+'90EE9'+convert(char(1),(@i+@j))
			--,convert(char(3),convert(int,(((@x/2)+(dis/2))*@f)))
			from #pp
			where num = @k
		end
		set @i = @i + 1 
	end

	set @k = @k + 1 
end

select *
from #ppL
