
drop table #tmpRlfp
   CREATE TABLE #tmpRlfp(
    rlfp_sies int
   ,rlfp_glcl int
   ,rlfp_glcl_dig int
   ,rlfp_glcl_nom varchar(60)
   ,rlfp_mtpc varchar(20)
   ,rlfp_mtpc_nom varchar(50)
   ,rlfp_qtde decimal(12,2)
   ,rlfp_vuni decimal(12,2)
   ,rlfp_valt decimal(12,2)
   ,rlfp_vund decimal(12,2)
   ,rlfp_vald decimal(12,2)
   ,rlfp_pctd decimal(6,2)
--   ,rlfp_ano varchar(4) default '9999'
   )
   --9627 e 10370
insert into #tmpRlfp
exec RL_Fat_CliPro 0,10370,0,'????????????????????','0500','????','????','01/01/2010','31/12/2010'

drop table #new
select *, '2010' ANO into #new from #tmpRlfp

delete from #tmpRlfp

insert into #tmpRlfp
exec RL_Fat_CliPro 0,10370,0,'????????????????????','0500','????','????','01/01/2011','31/12/2011'

insert into #new select *, '2011' ANO from #tmpRlfp

delete from #tmpRlfp

insert into #tmpRlfp
exec RL_Fat_CliPro 0,10370,0,'????????????????????','0500','????','????','01/01/2012','31/12/2012'

insert into #new select *, '2012' ANO from #tmpRlfp

delete from #tmpRlfp

insert into #tmpRlfp
exec RL_Fat_CliPro 0,10370,0,'????????????????????','0500','????','????','01/01/2013','31/12/2013'

insert into #new select *, '2013' ANO from #tmpRlfp

delete from #tmpRlfp

insert into #tmpRlfp
exec RL_Fat_CliPro 0,10370,0,'????????????????????','0500','????','????','01/01/2014','31/12/2014'

insert into #new select *, '2014' ANO from #tmpRlfp

delete from #tmpRlfp

drop table #mtpc

select mtpc_cod
into #mtpc
from MTPC, MTPR
where MTPC_MTPR = MTPR_COD
			and MTPR_MTDV = '0500'
			and MTPC_COD like '9-%'

select mtpc_cod MOLA, replace(isnull(a.rlfp_qtde,0),'.',',') QDE_2010, replace(isnull(b.rlfp_qtde,0),'.',',') QDE_2011, replace(isnull(c.rlfp_qtde,0),'.',',') QDE_2012, replace(isnull(d.rlfp_qtde,0),'.',',') QDE_2013, replace(isnull(e.rlfp_qtde,0),'.',',') QDE_2014
from #mtpc as s left join #new a on s.MTPC_COD = a.rlfp_mtpc and a.ANO = '2010' 
								left join #new b on s.MTPC_COD = b.rlfp_mtpc and b.ANO = '2011'
								left join #new c on s.MTPC_COD = c.rlfp_mtpc and c.ANO = '2012'
								left join #new d on s.MTPC_COD = d.rlfp_mtpc and d.ANO = '2013'
								left join #new e on s.MTPC_COD = e.rlfp_mtpc and e.ANO = '2014'

