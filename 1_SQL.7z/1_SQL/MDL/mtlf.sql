

--TC01 - Fator de venda/fator sugerido de 96,00% incluir divis�o 3500, linha: TODAS e fam�lia: TODAS -> Regi�o Centro Oeste;
--TES1 - Fator de venda/fator sugerido de 96,00% incluir divis�o 3500, linha: TODAS e fam�lia: TODAS -> Estado do Esp�rito Santo;
--TNE1 - Fator de venda/fator sugerido de 96,00% incluir divis�o 3500, linha: TODAS e fam�lia: TODAS -> Regi�o Nordeste;
--TNO1 - Fator de venda/fator sugerido de 96,00% incluir divis�o 3500, linha: TODAS e fam�lia: TODAS -> Regi�o Norte;
 
--TZF1 - Fator de venda/fator sugerido de 81,95% incluir divis�o 3500, linha: TODAS e fam�lia: TODAS -> Zona Franca de Manaus.


IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #new

select 'TTTT' MTLF, 9999999999.99 VAL, '3500' MTDV, identity(int,1,1) NUM
into #new
where 1 = 0

insert into #new select 'TCO1',	96.00, '3500'
insert into #new select 'TES1',	96.00, '3500'
insert into #new select 'TNE1',	96.00, '3500'
insert into #new select 'TNO1',	96.00, '3500'
insert into #new select 'TZF1',	81.95, '3500'


select * from #new

IF OBJECT_ID('TempDB.dbo.#MTLF') IS NOT NULL DROP TABLE #MTLFSELECT * INTO #MTLF FROM MTLF WHERE 1 = 0INSERT INTO #MTLFSELECT 		MTLF_MTLP = CONVERT(varchar(4),MTLF)      --CONVERT(varchar(4),'') C�digo
	, MTLF_MTDV = CONVERT(varchar(4),MTFM_MTDV)      --CONVERT(varchar(4),'') Divis�o
	, MTLF_MTLN = CONVERT(varchar(4),MTFM_MTLN)      --CONVERT(varchar(4),'') Linha
	, MTLF_MTFM = CONVERT(varchar(4),MTFM_COD)      --CONVERT(varchar(4),'') Fam�lia
	, MTLF_NOM = MTFM_NOM--Null      --CONVERT(varchar(50),'') Observa��o
	, MTLF_FATO = CONVERT(decimal(7,2),VAL)      --CONVERT(decimal(7),'') Fator pre�o
	, MTLF_SPFT = CONVERT(decimal(7,2),VAL)  --Null      --CONVERT(decimal(7),'') Fat. P. Sug.
	, MTLF_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTLF_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTLF_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTLF_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM #new, mtfmWHERE mtfm_mtdv = MTDVSELECT *FROM #MTLFWHERE MTLF_MTLP NOT IN (SELECT MTLP_COD FROM MTLP)INSERT INTO MTLFSELECT *FROM #MTLFWHERE MTLF_MTLP+'/'+MTLF_MTDV+'/'+	MTLF_MTLN+'/'+MTLF_MTFM NOT IN (SELECT MTLF_MTLP+'/'+MTLF_MTDV+'/'+	MTLF_MTLN+'/'+MTLF_MTFM FROM MTLF)
--MTLF_MTLP ,MTLF_MTDV ,MTLF_MTLN ,MTLF_MTFM ,MTLF_NOM ,MTLF_FATO ,MTLF_SPFT ,MTLF_USC ,MTLF_DTC ,MTLF_USU ,MTLF_DTU ,

SELECT *--deleteFROM MTLFwhere MTLF_MTLP	= 'TZF1'
and MTLF_MTDV = '3500'
