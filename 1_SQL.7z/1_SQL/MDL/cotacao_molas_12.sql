select replace(VDC1_QTDE,'.',',')VDC1_QTDE, REPLACE(VDC1_PUNI,'.',',')VDC1_PUNI, replace(VDC1_DESC,'.',',')VDC1_DESC, REPLACE(VDC1_PUNID,'.',',')VDC1_PUNID, VDCO_STA, vdc1.* 
from VDc1, vdco, MTPR, MTPC
where vdco_sies = vdc1_sies
			and vdco_sido = vdc1_sido
			and vdco_sise = vdc1_sise
			and VDCO_COD  = VDC1_VDCO
			and vdc1_mtpc = MTPC_COD
			and MTPC_MTPR = MTPR_COD
			and VDCO_COD >= 270636
			and VDCO_STA = 'ea'
			and MTPR_MTDV = '0500'
			and VDCO_GLVD = 12
			--and convert(varchar(6),VDC1_DTC,102) >= '2014.01.01' 
			--Status EA vendedor 12 ano 2014
			--desconto somente nas molas