
--545
select vdc1_mtpc, vdc1_puni, vdcx_pun_val, vdc1_vdcv, a.*
--update vdc1 set vdc1_puni = vdcx_pun_val, vdc1_vdcv = vdcv_cod, VDC1_PUNID = vdcx_pun_val,	VDC1_VAL = vdcx_pun_val
from vdc1 a, vdco b, vdcv, vdcx
--where vdc1_vdco in (318564, 318566, 318567)
where vdc1_vdco in (318565)
 
and vdc1_sies = vdco_sies
and vdc1_sido = vdco_sido
and vdc1_sise = vdco_sise
and vdc1_vdco = vdco_cod
and vdcv_glcl = vdco_glcl
and vdcv_glcl_dig = vdco_glcl_dig
and vdcv_atv = 'S'
and vdcv_cod = vdcx_vdcv
and vdcx_mtpc = vdc1_mtpc

select vdc1_mtpc, vdc1_puni, mtpc_pre, a.*
--update vdc1 set vdc1_puni = mtpc_pre, vdc1_vdcv = 0, VDC1_PUNID = mtpc_pre,	VDC1_VAL = mtpc_pre
from vdc1 a, vdco b, mtpc
where vdc1_vdco in (318564, 318566, 318567)
and vdc1_sies = vdco_sies
and vdc1_sido = vdco_sido
and vdc1_sise = vdco_sise
and vdc1_vdco = vdco_cod
and mtpc_cod = vdc1_mtpc
and mtpc_pre <> 0
