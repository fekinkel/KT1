--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 30/08/2017--DEPARTAMENTO : VENDAS--ASSUNTO      : TROCAR A LINHA PARA AS MOLAS REDONDAS DE 100 PARA 101 DO PERIODO DE 01/01/2015--						 : A TROCA SER� FEITA EM COTA��ES DE VENDAS, PEDIDOS DE VENDAS E FATURAMENTO ------------------------------------------------------------------------------------------------------------------------

drop table #new
select replace(MTPR_COD,'R','S') COD_MDL, MTPR_COD COD_SIDOR
into #new
from [192.168.3.39\sqlexpress].[sidor].[dbo].mtpr
where mtpr_cod like 'r%'
and MTPR_MTTP = 'PA/FABR'
and MTPR_MTDV = '1'

/*
select *
from #new, mtpr
where mtpr_cod = cod_mdl
*/

--ITENS PEDIDO DE VENDAS
ALTER TABLE vdpi DISABLE TRIGGER ALL
--select *
update vdpi set vdpi_MTLN = '0101'
from #new, vdpi
--where convert(varchar(10),vdpi_dtc,102) >= '2017.01.01'
where convert(varchar(10),vdpi_dtc,102) >= '2015.01.01'
and vdpi_mtpr = cod_mdl
ALTER TABLE vdpi ENABLE TRIGGER ALL

--ITENS DA COTA��O DE VENDAS
--select *
update vdc1 set vdc1_MTLN = '0101'
from #new, vdc1
--where convert(varchar(10),vdc1_dtc,102) >= '2017.01.01'
where convert(varchar(10),vdc1_dtc,102) >= '2015.01.01'
and vdc1_mtpr = cod_mdl


--ITENS DAS NOTAS FISCAIS
ALTER TABLE ftit DISABLE TRIGGER ALL
--select *
update ftit set ftit_MTLN = '0101'
from #new, ftit
--where convert(varchar(10),ftit_dtc,102) >= '2017.01.01'
where convert(varchar(10),ftit_dtc,102) >= '2015.01.01'
and ftit_mtpr = cod_mdl
ALTER TABLE ftit ENABLE TRIGGER ALL

