select *
--update cpct set CPCT_CTO = 'ELIANE'
from cpct
where CPCT_STA = 'OK'
and CPCT_GLXX = 1890

select *
--update cppc set CPPC_CTO = 'ELIANE'
from cppc
where CPPC_GLXX = 1890
and CPPC_CTO = 'ELIANE / MARCUS'
