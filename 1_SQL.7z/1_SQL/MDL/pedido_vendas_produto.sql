select VDPI_SIES,VDPI_SIDO,VDPI_SISE,VDPI_VDPD,VDPI_COD,VDPI_MTPC,VDPI_QTD,VDPI_QNF,VDPI_VAL,VDPI_NFOP,
  VDPD_GLCL,VDPD_GLCL_DIG,VDPD_GLVD,VDPD_GLPG,VDPD_GLMD,VDPD_DTC, VDPI_DENT, VDPD_GLUF_DES, GLPA_CID, MTPR_NOM 
from VDPI, VDPD, GLPA, MTPR
where (vdpd_sta='OK' or vdpd_sta='EC')
 and convert(char(10),vdpd_dtc,102)>='2014.01.01'
 and convert(char(10),vdpd_dtc,102)<='2016.12.31'
 and vdpi_sta<>'CA'
 and vdpd_sies=vdpi_sies
 and vdpd_sido=vdpi_sido
 and vdpd_sise=vdpi_sise
 and vdpd_cod =vdpi_vdpd
 and vdpd_glpa=glpa_cod
 and vdpi_mtpr = mtpr_cod
 order by vdpi_mtpc, vdpi_sies, vdpi_sido, vdpi_sise, vdpi_vdpd, vdpi_cod