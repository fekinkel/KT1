--exec RL_FAT_FaturamentoMtpc 0,'T','*','0500','*','*','01/01/2010','31/01/2010','0'
drop table #new

select year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(FTIT_QTD) TOTAL, 99999.999999 BALCAO, 99999.999999 MEDIA, 99999.999999 DIF
into #new
 from FTNF, FTIT, MTDV, MTLN, MTFM where ftnf_sies=ftit_sies and ftnf_sido=ftit_sido and ftnf_sise=ftit_sise and ftnf_cod=ftit_ftnf and ftnf_sta='OK'
 and convert(char(10),ftnf_dat,102) between '2010.01.01' and '2016.12.31'
 and ftit_mtdv in ('0500')
 --and ftit_mtdv in ('1000', '1500', '0500')
 --and ftit_mtdv in ('1000', '1500', '0500')
 and mtdv_cod=ftit_mtdv
 and mtln_mtdv=ftit_mtdv and mtln_cod=ftit_mtln
 and mtfm_mtdv=ftit_mtdv and mtfm_mtln=ftit_mtln and mtfm_cod=ftit_mtfm
 --order by convert(char(10),ftnf_dat,102), ftit_sies, ftit_sido, ftit_sise, ftit_ftnf, ftit_cod
group by year(ftnf_dat), month(ftnf_dat)
order by year(ftnf_dat), month(ftnf_dat)


--93735

drop table #new2
select year(ftnf_dat) ANO_2, month(ftnf_dat) MES_2, sum(FTIT_QTD) VAL
into #new2
 from FTNF, FTIT, MTDV, MTLN, MTFM 
 where ftnf_sies=ftit_sies and ftnf_sido=ftit_sido and ftnf_sise=ftit_sise and ftnf_cod=ftit_ftnf and ftnf_sta='OK'
 and convert(char(10),ftnf_dat,102) between '2010.01.01' and '2016.12.31'
 and ftit_mtdv in ('0500')
 --and ftit_mtdv in ('1000', '1500', '0500')
 --and ftit_mtdv in ('1000', '1500', '0500')
 and FTNF_GLTR = 10
 --and ftnf_cod = 93735
 and mtdv_cod=ftit_mtdv
 and mtln_mtdv=ftit_mtdv and mtln_cod=ftit_mtln
 and mtfm_mtdv=ftit_mtdv and mtfm_mtln=ftit_mtln and mtfm_cod=ftit_mtfm
 --order by convert(char(10),ftnf_dat,102), ftit_sies, ftit_sido, ftit_sise, ftit_ftnf, ftit_cod
group by year(ftnf_dat), month(ftnf_dat)
order by year(ftnf_dat), month(ftnf_dat)

--select *
update #new set BALCAO = val, MEDIA =convert(decimal(12,2),(val * 100)/Total)
from #new, #new2
where ano = ano_2
and mes = mes_2


drop table #med
select top 4 *
into #med
from #new
order by MEDIA desc

insert into #med
select top 4 *
from #new
order by MEDIA

drop table #avg
select media MED
into #avg
from #new
where convert(varchar(4),ano)+'/'+convert(varchar(2),mes) not in (select convert(varchar(4),ano)+'/'+convert(varchar(2),mes) from #med)
declare
@i decimal(12,2)

select @i = avg(med)
from #avg

update #new set DIF = MEDIA - @i
from #new, #new2, #avg
where ano = ano_2
and mes = mes_2

select *--, @i
from #new

select *, TOTAL+(((ANO*100)+(MES))/201410)*6000 TOTAL_NOVO, BALCAO+(((ANO*100)+(MES))/201410)*6000 BALCAO_NOVO
from #new
