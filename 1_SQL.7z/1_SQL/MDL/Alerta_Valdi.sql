--PRODU��O BS400
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'BS400'
and PROT_PROP in ('RPB' )--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP

--PRODU��O BS500 
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'BS500'
and PROT_PROP in ('FR')--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP

--PRODU��O BS550
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'BS550'
and PROT_PROP in ('RD')--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP

--PRODU��O BS600
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'BS600'
and PROT_PROP in ('CNC', 'CNC-1')--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP

--PRODU��O BS800 
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'BS800'
and PROT_PROP in ('RB', 'MT')--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP

--PLANEJAMENTO PL000
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'PL000'
and PROT_PROP in ('PL', 'CRM', 'OX', 'DXF', 'CAM' )--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
and prot_memo not like '%*OK*%'
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP

--PRODU��O TV000
select 'ATEN��O - ORDEM '+CONVERT(VARCHAR(10),max(PROT_PROR))+' TEMPO EXECUTADO '+CONVERT(VARCHAR(20),sum(PRAH_QTDR)) +' MAIOR QUE PLANEJADO '+ CONVERT(VARCHAR(20),(max(PROT_TVAR)+max(PROT_TFIX)))+' ('+CONVERT(VARCHAR(20),convert(decimal(12,2),(sum(PRAH_QTDR))*100/(max(PROT_TVAR)+max(PROT_TFIX))-100))+'%) OP. '+PROT_PROP --PRAH_QTDR, PROT_TVAR /(max(PROT_PROR))))
from prot, prah
where prot_sies = prah_sies
and prot_sido = prah_pror_sido
and prot_sise = prah_pror_sise
and prot_pror = prah_pror_cod
and prot_cod  = prah_prot
--and sum(PRAH_QTDR) > max(prot_tvar)
and prot_sies = 5
and PROT_PRGT = 'TV000'
and PROT_PROP in ('DEM')--'CAM'
and (prah_dtfi) between getdate()-5 and getdate()
--AND prot_pror = 75555
group by PROT_PROR, PROT_PROP
HAVING sum(PRAH_QTDR) > (max(PROT_TVAR)+max(PROT_TFIX))
and (max(PROT_TVAR)+max(PROT_TFIX)) > 0.01
order by PROT_PROR, PROT_PROP
