select count(1), count(1)/20, count(1)/20/8
from vdco
where convert(varchar(10),vdco_dtc,102) between '2017.03.01' and '2017.03.31'
			and vdco_usc = 'anac'


select convert(varchar(10),vdco_dtc,102), count(1), count(1)/8
from vdco
where convert(varchar(10),vdco_dtc,102) between '2014.07.01' and '2014.07.31'
group by convert(varchar(10),vdco_dtc,102)



select count(1), count(1)/32, count(1)/32/8
from vdpd
where convert(varchar(10),vdpd_dtc,102) between '2014.07.01' and '2014.07.31'



select convert(varchar(10),vdpd_dtc,102), count(1), count(1)/8
from vdpd
where convert(varchar(10),vdpd_dtc,102) between '2014.07.01' and '2014.07.31'
group by convert(varchar(10),vdpd_dtc,102)

