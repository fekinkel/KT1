select MTES_MTPR, MTPR_NIV 
from MTES, MTPR 
where mtes_sies=5 
			and mtpr_cod=mtes_mtpr
order by MTPR_NIV


update MTSW set mtsw_qent=0,mtsw_qsai=0,mtsw_vmer=0,mtsw_vmsr=0,mtsw_vmem=0,mtsw_vmsm=0,mtsw_vmea=0,mtsw_vmsa=0,mtsw_usu ='KINKEL' ,mtsw_dtu =GETDATE()
-- N�o posso excluir pois n�o atualizo Nec/Orde quando o saldo fica zerado por exclus�o de movimento
--               delete MTSW
where MTSW_SIES=5 and MTSW_ANO=2014 and MTSW_MES>=01

declare
@vMtpr varchar(20)

set @vMtpr='????????????????????'
set @vMtpr='A05.006.012'
set @vMtpr='OSBA'
select * from MTSW
where (MTSW_SIES=5 and MTSW_ANO=2014 and MTSW_MES>=01
			and @vMtpr = '????????????????????')or
			(MTSW_SIES=5 and MTSW_ANO=2014 and MTSW_MES>=01
			and MTSW_MTPR =  @vMtpr)

--select * from MTSZ where MTSZ_MTPR = 'OSBA' and MTSZ_SUBL like '%13049%' and MTSZ_SIES=5 and MTSZ_ANO=2014 and MTSZ_MES=01
select MTSZ_MTAL, MTSZ_SUBL=isnull(MTSZ_SUBL,'')
                ,MTSZ_QENT=round(sum(isnull(MTSZ_QENT,0)),3)
                ,MTSZ_VMER=round(sum(isnull(MTSZ_VMER,0)),3)
                ,MTSZ_VMEM=round(sum(isnull(MTSZ_VMEM,0)),3)
                ,MTSZ_QSAI=round(sum(isnull(MTSZ_QSAI,0)),3)
                ,MTSZ_VMSR=round(sum(isnull(MTSZ_VMSR,0)),3)
                ,MTSZ_VMSM=round(sum(isnull(MTSZ_VMSM,0)),3)
                ,MTSZ_QSUC=round(sum(isnull(MTSZ_QSUC,0)),3)
                ,MTSZ_VSUC=round(sum(isnull(MTSZ_VSUC,0)),3)
                ,MTSZ_VSUM=round(sum(isnull(MTSZ_VSUM,0)),3)
               from MTSZ where MTSZ_MTPR=@vMTPR and MTSZ_SIES=5 and MTSZ_ANO=2014 and MTSZ_MES=01
               group by MTSZ_MTAL, MTSZ_SUBL
