CREATE TABLE address (
 ID int NOT NULL identity(1,1),
 CITY varchar(50) DEFAULT NULL,
 COUNTRY varchar(50) DEFAULT NULL,
 STREET varchar(50) DEFAULT NULL,
 SUBURB varchar(50) DEFAULT NULL,
 PRIMARY KEY (ID)
) 
 
CREATE TABLE role (
 ID int NOT NULL identity(1,1),
 ROLEDESC varchar(255) DEFAULT NULL,
 ROLENAME varchar(255) DEFAULT NULL,
 PRIMARY KEY (ID)
) 
 
CREATE TABLE user1 (
 ID int NOT NULL identity(1,1),
 EMAIL varchar(50) DEFAULT NULL,
 FIRSTNAME varchar(50) DEFAULT NULL,
 LASTNAME varchar(50) DEFAULT NULL,
 PASSWORD1 varchar(64) DEFAULT NULL,
 USERNAME varchar(50) NOT NULL,
 ADDRESS_ID int DEFAULT NULL,
 PRIMARY KEY (ID)),
 KEY FK_USER_ADDRESS_ID (ADDRESS_ID),
 CONSTRAINT FK_USER_ADDRESS_ID FOREIGN KEY (ADDRESS_ID) REFERENCES address (ID)
) 
 
CREATE TABLE user_roles (
 Role_roleid int NOT NULL,
 User_userid int NOT NULL,
 PRIMARY KEY (Role_roleid,User_userid)),
 KEY `FK_user_roles_User_userid` (`User_userid`),
 CONSTRAINT `FK_user_roles_User_userid` FOREIGN KEY (`User_userid`) REFERENCES `user` (`ID`),
 CONSTRAINT `FK_user_roles_Role_roleid` FOREIGN KEY (`Role_roleid`) REFERENCES `role` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8$$
