drop table #new

select MTPC_COD,	MTPC_MTPR
into #new
from mtpc
where substring(mtpc_cod,1,4) = 'BLKH'
			and substring(mtpc_cod,6,1)<> '.'


drop table #del
select a.*
into #del
from #new a left join mtpc b on a.mtpc_mtpr = b.mtpc_cod --and b.MTPC_COD is not NULL
where b.MTPC_COD is not NULL

drop table #del1
select a.*
into #del1
from #new a left join mtpc b on a.mtpc_mtpr = b.mtpc_cod --and b.MTPC_COD is not NULL
where b.MTPC_COD is NULL

select * from #new
select * from #del
select * from #del1

IF OBJECT_ID('TempDB.dbo.#MTPC') IS NOT NULL DROP TABLE #MTPCSELECT * INTO #MTPC FROM MTPC WHERE 1 = 0INSERT INTO #MTPCSELECT 		MTPC_COD = CONVERT(varchar(20),a.mtpc_mtpr)      --CONVERT(varchar(20),'') Refer�ncia
	, b.MTPC_MTPR --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo
	, b.MTPC_NOM --= CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome
	, b.MTPC_GLMD --= CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda
	, b.MTPC_PRE --= CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Pre�o
	, b.MTPC_PRE_USU --= Null      --CONVERT(varchar(15),'') Alterado por
	, b.MTPC_PRE_DTU --= Null      --CONVERT(datetime(10),'') em
	, MTPC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPC_DTU = Null      --CONVERT(datetime(10),'') em
--select *from #del1 a, MTPC bWHERE a.MTPC_COD = b.MTPC_CODINSERT INTO MTPCSELECT MTPC_COD ,MTPC_MTPR ,MTPC_NOM ,MTPC_GLMD ,MTPC_PRE ,MTPC_PRE_USU ,MTPC_PRE_DTU ,MTPC_USC ,MTPC_DTC ,MTPC_USU ,MTPC_DTUFROM #MTPCWHERE MTPC_COD not IN (SELECT MTPC_COD FROM MTPC)
--MTPC_COD ,MTPC_MTPR ,MTPC_NOM ,MTPC_GLMD ,MTPC_PRE ,MTPC_PRE_USU ,MTPC_PRE_DTU ,MTPC_USC ,MTPC_DTC ,MTPC_USU ,MTPC_DTU ,




select rcit_mtpc,*
--update rcit set rcit_mtpc = mtpc_mtpr
from rcit, #del
where rcit_mtpc = mtpc_cod

select mtci_mtpc,*
--update mtci set mtci_mtpc = mtpc_mtpr
from mtci, #del
where mtci_mtpc = mtpc_cod

select nfit_mtpc,*
--update nfit set nfit_mtpc = mtpc_mtpr
from nfit, #del
where nfit_mtpc = mtpc_cod

select ftit_mtpc,*
--update ftit set ftit_mtpc = mtpc_mtpr
from ftit, #del
where ftit_mtpc = mtpc_cod

ALTER TABLE VDPI DISABLE TRIGGER ALL
--select vdpi_mtpc,*
update vdpi set vdpi_mtpc = mtpc_mtpr
from vdpi, #del
where vdpi_mtpc = mtpc_cod
ALTER TABLE VDPI ENABLE TRIGGER ALL

ALTER TABLE VDPS DISABLE TRIGGER ALL
--select vdps_mtpc,*
update vdps set vdps_mtpc = mtpc_mtpr
from vdps, #del
where vdps_mtpc = mtpc_cod
ALTER TABLE VDPS ENABLE TRIGGER ALL

select *
--update vdcx set vdcx_mtpc = mtpc_mtpr, VDCX_PUN_VAL = 1
from vdcx, #del
where vdcx_mtpc = mtpc_cod


delete mtpc
--select *
from mtpc a, #del b
where a.mtpc_cod = b.mtpc_cod
