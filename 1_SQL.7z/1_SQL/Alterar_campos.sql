select *
--update sidc set sidc_gnat = 'S'
from SIDC
where SIDC_SITB = 'PRRO'
			and SIDC_COD like 'prro_t%'