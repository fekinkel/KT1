--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 06/07/2017--DEPARTAMENTO : 06/07/2017--ASSUNTO      : 06/07/2017------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#VDET') IS NOT NULL DROP TABLE #VDETSELECT * INTO #VDET FROM VDET WHERE 1 = 0INSERT INTO #VDETSELECT 		VDET_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, VDET_SIDO --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, VDET_SISE --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, VDET_VDCO --= CONVERT(int(6),'')      --CONVERT(int(6),'') N�mero(N�mero da cota��o)
	, VDET_COD = CONVERT(int,vdc1_cod)      --CONVERT(int(3),'') Item(Item principal da cota��o)
	, VDET_GLHP --= Null      --CONVERT(varchar(5),'') Hist�rico(C�digo do hist�rico padr�o)
	, VDET_TXT --= Null      --CONVERT(varchar(800),'') Texto(Texto do hist�rico padr�o)
	, VDET_NOC1 --= Null      --CONVERT(varchar(25),'') Campo 1(Nome do campo 1 para macro substitui��o)
	, VDET_COC1 --= Null      --CONVERT(varchar(25),'') Conte�do 1(Conte�do do campo 1 para macro substitui��o)
	, VDET_NOC2 --= Null      --CONVERT(varchar(25),'') Campo 2(Nome do campo 2 para macro substitui��o)
	, VDET_COC2 --= Null      --CONVERT(varchar(25),'') Conte�do 2(Conte�do do campo 2 para macro substitui��o)
	, VDET_NOC3 --= Null      --CONVERT(varchar(25),'') Campo 3(Nome do campo 3 para macro substitui��o)
	, VDET_COC3 --= Null      --CONVERT(varchar(25),'') Conte�do 3(Conte�do do campo 3 para macro substitui��o)
	, VDET_NOC4 --= Null      --CONVERT(varchar(25),'') Campo 4(Nome do campo 4 para macro substitui��o)
	, VDET_COC4 --= Null      --CONVERT(varchar(25),'') Conte�do 4(Conte�do do campo 4 para macro substitui��o)
	, VDET_NOC5 --= Null      --CONVERT(varchar(25),'') Campo 5(Nome do campo 5 para macro substitui��o)
	, VDET_COC5 --= Null      --CONVERT(varchar(25),'') Conte�do 5(Conte�do do campo 5 para macro substitui��o)
	, VDET_NOC6 --= Null      --CONVERT(varchar(25),'') Campo 6(Nome do campo 6 para macro substitui��o)
	, VDET_COC6 --= Null      --CONVERT(varchar(25),'') Conte�do 6(Conte�do do campo 6 para macro substitui��o)
	, VDET_NOC7 --= Null      --CONVERT(varchar(25),'') Campo 7(Nome do campo 7 para macro substitui��o)
	, VDET_COC7 --= Null      --CONVERT(varchar(25),'') Conte�do 7(Conte�do do campo 7 para macro substitui��o)
	, VDET_NOC8 --= Null      --CONVERT(varchar(25),'') Campo 8(Nome do campo 8 para macro substitui��o)
	, VDET_COC8 --= Null      --CONVERT(varchar(25),'') Conte�do 8(Conte�do do campo 8 para macro substitui��o)
	, VDET_OBS --= Null      --CONVERT(varchar(250),'') Obs.(Observa��o)
	, VDET_EMIT --= CONVERT(int(3),'')      --CONVERT(int(3),'') Emitida(N� de emiss�es (0=N�o emitida ; 1=Emitida ; 2,3,4...=N� de reemiss�es))
	, VDET_USC --= CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, VDET_DTC --= CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, VDET_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, VDET_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
--select b.*
from vdet a, vdc1 b
where 5	= vdc1_sies
and 'vdco'	= vdc1_sido
and '001'	= vdc1_sise
and VDET_VDCO	= vdc1_vdco
--and VDET_COD = vdc1_cod

and vdc1_sub = 0
and vdet_vdco = 357785
INSERT INTO VDETSELECT *FROM #VDETWHERE CONVERT(VARCHAR(20),VDET_vdco)+'/'+CONVERT(VARCHAR(20),VDET_cod) NOT IN (SELECT CONVERT(VARCHAR(20),VDET_vdco)+'/'+CONVERT(VARCHAR(20),VDET_cod) FROM VDET)
--VDET_SIES ,VDET_SIDO ,VDET_SISE ,VDET_VDCO ,VDET_COD ,VDET_GLHP ,VDET_TXT ,VDET_NOC1 ,VDET_COC1 ,VDET_NOC2 ,VDET_COC2 ,VDET_NOC3 ,VDET_COC3 ,VDET_NOC4 ,VDET_COC4 ,VDET_NOC5 ,VDET_COC5 ,VDET_NOC6 ,VDET_COC6 ,VDET_NOC7 ,VDET_COC7 ,VDET_NOC8 ,VDET_COC8 ,VDET_OBS ,VDET_EMIT ,VDET_USC ,VDET_DTC ,VDET_USU ,VDET_DTU ,

