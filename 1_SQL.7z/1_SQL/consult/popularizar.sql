
INSERT INTO address (line1, line2, city, region, country, postal_code) VALUES ('100 Data Street', 'Suite 432', 'San Francisco', 'California', 'USA', '94103');
INSERT INTO client (client_name, client_department_number, billing_address, contact_email, contact_password) VALUES ('Big Data Corp.', 2000, 1, 'accounting@bigdatacorp.com', 'accounting');
INSERT INTO project (client_name, client_department_number, project_name, contact_email, contact_password) VALUES ('Big Data Corp.', 2000, 'Secret Project', 'project.manager@bigdatacorp.com', 'project.manager');
INSERT INTO recruiter (email, password, client_name, client_department_number) VALUES ('bob@jsfcrudconsultants.com', 'bob', 'Big Data Corp.', 2000);
INSERT INTO consultant_status (status_id, description) VALUES ('A', 'Active');
INSERT INTO consultant (status_id, email, password1, hourly_rate, billable_hourly_rate, hire_date, recruiter_id) VALUES ('A', 'janet.smart@jsfcrudconsultants.com', 'janet.smart', 80, 120, '2007-2-15', 1);
INSERT INTO project_consultant (client_name, client_department_number, project_name, consultant_id) VALUES ('Big Data Corp.', 2000, 'Secret Project', 1);
INSERT INTO billable (consultant_id, client_name, client_department_number, project_name, startdate, enddate, hours1, hourly_rate, billable_hourly_rate, description1) VALUES (1, 'Big Data Corp.', 2000, 'Secret Project', '13/10/2008 00:00:00.0', '17/10/2008 00:00:00.0', 40, 80, 120, 'begin gathering requirements');
INSERT INTO billable (consultant_id, client_name, client_department_number, project_name, startdate, enddate, hours1, hourly_rate, billable_hourly_rate, description1) VALUES (1, 'Big Data Corp.', 2000, 'Secret Project', '20/10/2008 00:00:00.0', '24/10/2008 00:00:00.0', 40, 80, 120, 'finish gathering requirements');
