--insert into [192.168.4.2\sqlexpress].[mdlmex].[dbo].[mtfo]
--		 MTFO_MTPR             MTFO_SIES        MTFO_GLFO    MTFO_DEFA  MTFO_GLFO_GLPA  MTFO_GLFO_NRDZ   MTFO_CPCO                  MTFO_CPUN  MTFO_NOM                                            MTFO_CPFT                                MTFO_OBS                                                                                                                                                                                                                                                                  MTFO_USC                   MTFO_DTC                      MTFO_USU              MTFO_DTU                 MTFO_CPCT                  MTFO_CPDT
select MTFO_MTPR            ,MTFO_SIES   ,837 MTFO_GLFO   ,MTFO_DEFA ,MTFO_GLFO_GLPA ,MTFO_GLFO_NRDZ  ,MTFO_CPCO            ,'PZ' MTFO_CPUN ,MTFO_NOM                                           ,MTFO_CPFT                               ,MTFO_OBS                                                                                                                                                                                                                                                        ,'KINKEL' MTFO_USC        ,GETDATE() MTFO_DTC                ,NULL MTFO_USU        ,NULL MTFO_DTU                ,MTFO_CPCT                 ,MTFO_CPDT
from mtfo
where mtfo_glfo = 61322
			AND MTFO_MTPR IN (SELECT MTES_MTPR
FROM [192.168.4.2\sqlexpress].[mdlmex].[dbo].[mtES]
)

SELECT TOP 1 *
FROM [192.168.4.2\sqlexpress].[mdlmex].[dbo].[mtfo]
