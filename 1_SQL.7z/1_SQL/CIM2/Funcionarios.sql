--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 02/08/2017--DEPARTAMENTO : RH--ASSUNTO      : LER DBF (APONTAMENTOS FUNCIONARIO 1326)------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#prcMAPEAR') IS NOT NULL DROP procedure #prcMAPEARDECLARE@PROC nVARCHAR(4000)
SET @PROC = 'CREATE procedure DBO.#prcMAPEAR
	@vPATH_WORK nVARCHAR(255),
	@vPATH_DIR nVARCHAR(255),
	@vNOME_PROJETO VARCHAR(255)
AS BEGIN
	DECLARE 
	@EXEC nVARCHAR(4000)

	Exec xp_cmdshell '+CHAR(39)+'net use s: /delete'+CHAR(39)+'
	IF SUBSTRING(@vPATH_DIR,1,2) = '+CHAR(39)+'\\'+CHAR(39)+' BEGIN 
		set @exec = '+CHAR(39)+'net use s: '+Char(39)+'+@vPATH_DIR+'+char(39)+' mdl168@@ /USER:MDL\administrator'+CHAR(39)+'
		print @exec
		Exec xp_cmdshell @exec
	END
END'
EXEC (@PROC)

	DECLARE
		@PATH_WORK nVARCHAR(255),
		@PATH_WORK_NEW nVARCHAR(255),
		@PATH_DIR nVARCHAR(255),
		@ARQUIVO nVARCHAR(255),
		@NOME_PROJETO nVARCHAR(255),
		@PATH nvarchar(255),
		@MODELO nVARCHAR(255),		--MVC PASTAS
		@VIEW nVARCHAR(255),			--MVC PASTAS
		@CONTROLE nVARCHAR(255),	--MVC PASTAS
		@EXEC nvarchar(4000),
		@TABELAS VARCHAR(4000),
		@i int,
		@j int,
		@n int

	--SET @PATH_DIR = '\\192.168.3.85\1_Geral\'
	SET @PATH_DIR = '\\192.168.3.3\disk_w_ti'
	SET @PATH_WORK = '\ATUAL\1_Jsf\Workspace'
	SET @MODELO = '\src\br\com\mdl\modelo'
	SET @VIEW = '\src\br\com\mdl\telas'
	SET @CONTROLE ='\src\br\com\mdl\controle'
	--SET @NOME_PROJETO = 'APONTAMENTO'
	SET @NOME_PROJETO = 'ZippER'
	SET @TABELAS = 'BKAG;BKZP;'
	SELECT @NOME_PROjeto = upper(substring(@NOME_PROjeto,1,1))+substring(lower(@NOME_PROjeto),2,len(@NOME_PROjeto))

	set @PATH = @PATH_WORK+'\'+@NOME_PROJETO
	EXEC #prcMAPEAR @PATH_WORK, @PATH_DIR, @NOME_PROJETO


SELECT * 
FROM OPENROWSET
(
'MICROSOFT.ACE.OLEDB.12.0',
'dBase IV;HDR=NO;IMEX=2;DATABASE=S:\ATUAL\DBF\',
'SELECT * FROM DBFUNHAP.dbf'
)
where CFUN = '1326'
order by dtap


SELECT convert(varchar(10),DTAP,103)DTAP,	[TRAN],	CITM,	NUOR,	IDCT,	NOPE,	TPRE,	TEXE,	FCON,	CFUN,	NUDC,	SALD,	EQPR,	EQEX
FROM OPENROWSET
(
'MICROSOFT.ACE.OLEDB.12.0',
'dBase IV;HDR=NO;IMEX=2;DATABASE=D:\DBF\',
'SELECT * FROM DBFUNHAP.dbf'
)
where CFUN = '1405'
and IDCT = 'RC602'
order by dtap

SELECT convert(varchar(10),DTAP,103)DTAP,	[TRAN],	CITM,	NUOR,	IDCT,	NOPE,	TPRE,	TEXE,	FCON,	CFUN,	NUDC,	SALD,	EQPR,	EQEX
FROM OPENROWSET
(
'MICROSOFT.ACE.OLEDB.12.0',
'dBase IV;HDR=NO;IMEX=2;DATABASE=D:\DBF\',
'SELECT * FROM DBFUNHAP.dbf'
)
where CFUN = '1405'
--and IDCT = 'RC602'
and convert(varchar(10),dtap,102) between '2008.06.09' and '2008.06.13'
order by dtap

SELECT * 
FROM OPENROWSET
(
'MICROSOFT.ACE.OLEDB.12.0',
'dBase IV;HDR=NO;IMEX=2;DATABASE=S:\ATUAL\DBF\',
'SELECT * FROM DBFUNHPA.dbf'
)
where CFUN = '1326'
order by dtap

SELECT * 
FROM OPENROWSET
(
'MICROSOFT.ACE.OLEDB.12.0',
'dBase IV;HDR=NO;IMEX=2;DATABASE=S:\ATUAL\DBF\',
'SELECT * FROM DBFUNHRE.dbf'
)
where CFUN = '1326'
order by dtap

SELECT * 
FROM OPENROWSET
(
'MICROSOFT.ACE.OLEDB.12.0',
'dBase IV;HDR=NO;IMEX=2;DATABASE=S:\ATUAL\DBF\',
'SELECT * FROM DBFUNHmv.dbf'
)
where CFUN = '1326'
order by dtap
