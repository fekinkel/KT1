exec sp_helpserver

exec sp_serveroption @server='192.168.4.2\SQLEXPRESS', @optname='rpc', @optvalue='true'
exec sp_serveroption @server='192.168.4.2\SQLEXPRESS', @optname='rpc OUT', @optvalue='true'
