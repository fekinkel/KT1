DECLARE
@t varchar(12),
@s varchar(4000),
@c varchar(1000),
@r varchar(4000),
@q varchar(4000)

set nocount on
set @s= ''

set @t = upper('cpsc')

set @c= replicate('-',120)+CHAR(13)
set @c = @c +
'--AUTOR        : FERNANDO KINKEL SEREJO'+CHAR(13)+
'--DATA         : '+CONVERT(VARCHAR(10), GETDATE(), 103)+CHAR(13)+
'--DEPARTAMENTO : '+CONVERT(VARCHAR(10), GETDATE(), 103)+CHAR(13)+
'--ASSUNTO      : '+CONVERT(VARCHAR(10), GETDATE(), 103)+CHAR(13)+
replicate('-',120)
print @c

--DROP TABLE #MTDV--SELECT * INTO #MTDV FROM MTDV WHERE 1 = 0--INSERT INTO #MTDV --IF OBJECT_ID('TempDB.dbo.#NEW_OLD') IS NOT NULL
set @c=+'IF OBJECT_ID('+CHAR(39)+'TempDB.dbo.#'+@T+CHAR(39)+') IS NOT NULL DROP TABLE #'+@t+CHAR(13)+
		'SELECT * INTO #'+@t+' FROM '+@t+' WHERE 1 = 0'+CHAR(13)+
		'INSERT INTO #'+@t+CHAR(13)+
		'SELECT '+CHAR(13)
print @c
SELECT '	, '+SIDC_COD+' = '+replace(REPLACE(SIDC_NULO,'N', 'CONVERT('+SIDC_TIPO+'('+CONVERT(VARCHAR(6),SIDC_COMP)+'),'''')'),'S','Null')+ '      --CONVERT('+SIDC_TIPO+'('+CONVERT(VARCHAR(6),SIDC_COMP)+'),'''') '+SIDI_TEXT+'('+SIDI_HINT+')'
FROM SIDC, sidi
WHERE SIDC_SITB = @t
			and SIDC_COD  = SIDI_SIDC
			and SIDC_SITB = SIDI_SITB
			and SIDI_COD  = '01'
			AND SIDC_FISI = 'S'
order by SIDC_SEQU

set @r='/* -----COLOCAR AQUI O SELECT QUE PRECISA --'+CHAR(13)+
'	--SELECT * '+CHAR(13)+
'FROM [dbfmex]...prod'+CHAR(13)+
'WHERE '+@t+'_cod = CONVERT(int,)'+CHAR(13)+
'	and '+@t+'_dig = CONVERT(int,)*/'+CHAR(13)+CHAR(13)+

'-------N�O ESQUECER DE TIRAR O COMENTARIO DO INSERT '+@t+CHAR(13)+
'--INSERT INTO '+@t+CHAR(13)+
'SELECT *'+CHAR(13)+
'FROM #'+@T+CHAR(13)+
'WHERE CONVERT(VARCHAR(6),'+@t+'_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),'+@t+'_SIES)FROM '+@t+')'

print @r

set @q =char(13)+'--'
SELECT @q=@q+SIDC_COD+' ,'
FROM SIDC, sidi
WHERE SIDC_SITB = @t
			and SIDC_COD  = SIDI_SIDC
			and SIDC_SITB = SIDI_SITB
			and SIDI_COD  = '01'
			AND SIDC_FISI = 'S'
order by SIDC_SEQU

print @q
