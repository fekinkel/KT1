
drop table #new
select identity(int,1,1) NUM, *
into #new
--delete
--update ctla set ctla_atv = 'N'
from ctla
where convert(varchar(10), ctla_dat, 102) between '2014.01.01' and '2014.12.31'
and ctla_encf = 'S'
and 
--and CTLA_COD = 1092260


declare
@i int
set @i = 1

while @i <= 986 begin
	
	update ctla set ctla_atv = 'N'
	--select *
	from ctla a, #new b
	where a.ctla_sies = b.ctla_sies
	and a.ctla_sido = b.ctla_sido
	and a.ctla_sise = b.ctla_sise
	and a.ctla_cod  = b.ctla_cod
	and NUM = @i
--and CTLA_COD = 1092260
	

	set @i = @i +1
end
