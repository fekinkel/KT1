--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 02/08/2017--DEPARTAMENTO : SISTEMA--ASSUNTO      : INCLUIR PROJETO ANDROID NO ECLIPSE------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#prcMAPEAR') IS NOT NULL DROP procedure #prcMAPEARDECLARE@PROC nVARCHAR(4000)
SET @PROC = 'CREATE procedure DBO.#prcMAPEAR
	@vPATH_WORK nVARCHAR(255),
	@vPATH_DIR nVARCHAR(255),
	@vNOME_PROJETO VARCHAR(255)
AS BEGIN
	DECLARE 
	@EXEC nVARCHAR(4000)

	Exec xp_cmdshell '+CHAR(39)+'net use s: /delete'+CHAR(39)+'
	IF SUBSTRING(@vPATH_DIR,1,2) = '+CHAR(39)+'\\'+CHAR(39)+' BEGIN 
		set @exec = '+CHAR(39)+'net use s: '+Char(39)+'+@vPATH_DIR+'+char(39)+' mdl168@@ /USER:MDL\administrator'+CHAR(39)+'
		Exec xp_cmdshell @exec
	END
END'
EXEC (@PROC)
--CAMINHO ONDE EST� O WORKSPACE
IF OBJECT_ID('TempDB.dbo.#prcCRUD') IS NOT NULL DROP procedure #prcCRUDSET @PROC = 'CREATE procedure DBO.#prcCRUD
	@vTABELA nVARCHAR(255),
	@vNOME_PROJETO VARCHAR(255)
AS BEGIN
	DECLARE 
	@EXEC nVARCHAR(4000)
	--IF SUBSTRING(@vPATH_DIR,1,2) = '+CHAR(39)+'\\'+CHAR(39)+' BEGIN 
		--set @exec = '+CHAR(39)+'net use s: '+Char(39)+'+@vPATH_DIR+'+char(39)+' mdl168@@ /USER:MDL\administrator'+CHAR(39)+'
		--Exec xp_cmdshell @exec
	--END
END'
EXEC (@PROC)
BEGIN
--goto fim
--end
	DECLARE
		@PATH_WORK nVARCHAR(255),
		@PATH_WORK_NEW nVARCHAR(255),
		@PATH_DIR nVARCHAR(255),
		@ARQUIVO nVARCHAR(255),
		@NOME_PROJETO nVARCHAR(255),
		@PATH nvarchar(255),
		@MODELO nVARCHAR(255),		--MVC PASTAS
		@VIEW nVARCHAR(255),			--MVC PASTAS
		@CONTROLE nVARCHAR(255),	--MVC PASTAS
		@EXEC nvarchar(4000),
		@TABELAS VARCHAR(4000),
		@i int,
		@j int,
		@n int

	SET @PATH_DIR = '\\192.168.3.85\1_Geral\'
	SET @PATH_DIR = '\\192.168.3.3\disk_w_ti'
	SET @PATH_WORK = '\ATUAL\1_Jsf\Workspace'
	SET @MODELO = '\src\br\com\mdl\modelo'
	SET @VIEW = '\src\br\com\mdl\telas'
	SET @CONTROLE ='\src\br\com\mdl\controle'
	--SET @NOME_PROJETO = 'APONTAMENTO'
	SET @NOME_PROJETO = 'ZippER'
	SET @TABELAS = 'BKAG;BKZP;'
	SELECT @NOME_PROjeto = upper(substring(@NOME_PROjeto,1,1))+substring(lower(@NOME_PROjeto),2,len(@NOME_PROjeto))

	set @PATH = @PATH_WORK+'\'+@NOME_PROJETO
	EXEC #prcMAPEAR @PATH_WORK, @PATH_DIR, @NOME_PROJETO

	IF OBJECT_ID('TempDB.dbo.##path') IS NOT NULL DROP TABLE ##path	select line = convert(nvarchar(4000),space(4000)), identity(int,1,1) num into ##path where 1 = 0
	IF OBJECT_ID('TempDB.dbo.#TMP_FILES') IS NOT NULL DROP TABLE #TMP_FILES
	SELECT IDENTITY(INT,1,1) NUM, convert(nvarchar(500),SPACE(500)) FILE_NAME INTO #TMP_FILES WHERE 1 = 0

------------------------- CRIAR OS DIRET�RIOS
  SET @exec = 'DIR ' + 'S:' + @PATH_WORK+'\alfa_New'+ '/S /B /AD';
  DELETE #TMP_FILES
	INSERT #TMP_FILES EXEC XP_CMDSHELL @exec;
	SELECT *--NUM, FILE_NAME
	FROM #TMP_FILES
	WHERE FILE_NAME IS NOT NULL;

	SELECT @i = 1, @j = max(num) from #TMP_FILES WHERE FILE_NAME IS NOT NULL
	WHILE @I <= @J BEGIN
		delete from ##path
	
		select @PATH_WORK_NEW = REPLACE(FILE_NAME,'alfa_New',@NOME_PROJETO)
		from #TMP_FILES WHERE NUM = @I
		
		set @exec = 'master..xp_cmdshell '+char(39)+'MD '+@PATH_WORK_NEW+char(39)		exec (@exec) 		SET @I = @I + 1
	END
 

  SET @exec = 'DIR ' + 'S:' + @PATH_WORK+'\alfa_New'+ '/S /B /AA';
	DELETE #TMP_FILES
	INSERT #TMP_FILES EXEC XP_CMDSHELL @exec;
	SELECT *--NUM, FILE_NAME
	FROM #TMP_FILES
	WHERE FILE_NAME IS NOT NULL;
------------------------- FIM

------------------------- CRIAR ESTRUTURA DE PASTAS E ARQUIVOS COMUNS
	select @i = min(num), @j = max(num) from #TMP_FILES WHERE FILE_NAME IS NOT NULL
	--set @j = @i
	WHILE @I <= @J BEGIN
		delete from ##path
		
		select 
			@PATH_DIR = REVERSE(SUBSTRING(reverse(FILE_NAME),CHARINDEX('\',reverse(FILE_NAME)),LEN(reverse(FILE_NAME))))
			,@ARQUIVO = REVERSE(SUBSTRING(reverse(FILE_NAME),1,CHARINDEX('\',reverse(FILE_NAME))-1)) 
			,@PATH_WORK_NEW = REPLACE(FILE_NAME,'alfa_New',@NOME_PROJETO)
		from #TMP_FILES WHERE NUM = @I
		
		--SELECT @PATH_DIR, @ARQUIVO, @PATH_WORK_NEW

		DELETE FROM ##path
		INSERT INTO ##path
		SELECT replace(line,'alfa', @NOME_PROJETO) line
		FROM uftReadfileAsTable(@PATH_DIR, @ARQUIVO) 
		select CHARINDEX('.png', @ARQUIVO ) PNG
		IF (select CHARINDEX('.png', @ARQUIVO))>0 BEGIN
			SET  @EXEC =     'master..xp_cmdshell '+char(39)+'copy '+@PATH_DIR+'\'+@ARQUIVO+'  '+ @PATH_WORK_NEW+' '+CHAR(39)
		END ELSE BEGIN
			print @exec
			SET  @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path where ascii(line) is not null order by num " queryout "'+@PATH_WORK_NEW+'" -c -U sa -P mdl1680'+CHAR(39)
		END
		EXEC (@EXEC)
		SET @I = @I + 1
	END
------------------------- FIM
------------------------- CRIAR OS MODELOS (TABELAS)	declare
	@s varchar(255),
	@auxTABELAS VARCHAR(400),
	@tab VARCHAR(255)

	------------------------- PARA CADA TABELA CRIAR ESTA LISTA DE CLASSE
	SET @auxTABELAS = lower(@TABELAS)
	WHILE @auxTABELAS <> '' BEGIN
		SELECT @s = SUBSTRING(@auxTABELAS,1,CHARINDEX(';',@auxTabelas)-1)
		--select @tab
		SELECT @auxTABELAS = SUBSTRING(@auxTABELAS,CHARINDEX(';',@auxTabelas)+1,len(@auxTabelas))
		--select @s = lower(@tab)
		select @s=upper(substring(@s,1,1))+substring(@s,2,len(@s))
		IF OBJECT_ID('TempDB.dbo.#sys') IS NOT NULL DROP TABLE #sys		--select b.name, b.xtype, b.id		--into #sys
		--from sysobjects a, syscolumns b
		--where a.name = @s
		--and a.id = b.id		select b.name, b.xtype, b.id, isnull(ORDINAL_POSITION,0) IsPrimaryKey, colid SEQ
		,Tipo = case 
				when b.xtype = 56 then 'int'
				when b.xtype = 167 then 'String'
				when b.xtype = 175 then 'String'
				when b.xtype = 104 then 'boolean'
				when b.xtype = 61 then 'String'
				else 'var'
		end
		,Tamanho = case 
				when b.xtype = 56 then 0
				when b.xtype = 167 then b.length
				when b.xtype = 175 then b.length
				when b.xtype = 104 then b.length
				when b.xtype = 61 then b.length * 2
				else 'var'
		end					into #sys
		from sysobjects a, syscolumns b left join INFORMATION_SCHEMA.KEY_COLUMN_USAGE c on column_name = b.name
		where a.name = @s
		and a.id = b.id--select * from #sys------------------------MODELO------------------------		delete from ##path
		insert into ##path
		select 'package br.com.mdl.modelo;'
		insert into ##path
		select 'import java.io.Serializable;'
		insert into ##path
		select 'public class '+@s+' implements Serializable {'
		insert into ##path
		select '	private '+ Tipo+
			' '+rtrim(ltrim(lower(name)))+
			' ;'
		from #sys
		--Construtor vavio
		insert into ##path
		select '//-------Construtor vazio---------------'
		insert into ##path
		select '	public '+@s+'(){}'
		---getters and setters
		insert into ##path
		select '//-------getters and setters ---------------'
		insert into ##path
		select '	public '+
			case 
				when xtype = 56 then 'int'
				when xtype = 167 then 'String'
				when xtype = 175 then 'String'
				when xtype = 104 then 'boolean'
				else 'var'
			end+
			' get'+upper(substring(lower(name),1,1))+substring(lower(name),2,len(lower(name)))
			+' () { return this.'+lower(name)+' ;}'
		from #sys
		insert into ##path
		select '	public void'+
			' set'+upper(substring(lower(name),1,1))+substring(lower(name),2,len(lower(name)))+'('+
			case 
				when xtype = 56 then 'int'
				when xtype = 167 then 'String'
				when xtype = 175 then 'String'
				when xtype = 104 then 'boolean'
				else 'var'
			end+
			' '+lower(name)+
			' ) { this.'+lower(name)+' = '+lower(name)+';}'
		from #sys
		insert into ##path
		select '}'
		SET  @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path where ascii(line) is not null order by num " queryout "S:\Atual\1_Jsf\Workspace\'+@NOME_PROJETO+@MODELO+'\'+@s+'.java'+'" -c -U sa -P mdl1680'+CHAR(39)
		print @exec
		EXEC (@EXEC)
------------------------FIM MODELO------------------------


------------------------CONTROLE CTR------------------------
		delete from ##path
		insert into ##path
		select 'package br.com.mdl.controleCTR;'
		insert into ##path
		select 'import java.io.Serializable;'
		insert into ##path
		select 'import java.util.List;'	
		insert into ##path
		SELECT 'public class '+@s+'CTR {'
		insert into ##path
		select '	public '+@s+'CTR() {}'
		--EXEC #prcCRUD @PATH_WORK, @PATH_DIR, @NOME_PROJETO
/*		insert into ##path
		select '		super(new AlbumDAO());	}
		insert into ##path
		select '	@Override
		insert into ##path
		select '	public String listar() {
		insert into ##path
		select '		try{
		insert into ##path
		select '			this.setModelos(this.dao.todos());
		insert into ##path
		select '			return SUCESSO;
		insert into ##path
		select '		} catch (Exception e){
		insert into ##path
		select '			return ERRO;
		insert into ##path
		select '		}
		insert into ##path
		select '	}
		insert into ##path
		select '	@Override
		insert into ##path
		select '	public String detalhar() {
		insert into ##path
		insert into ##path
		select '		select '		try {
		insert into ##path
		select '			this.setModelo(dao.porId(this.getId()));
		insert into ##path
		select '			return SUCESSO;
		insert into ##path
		select '		}catch (Exception e){
		insert into ##path
		select '			return ERRO;
		insert into ##path
		select '		}
		insert into ##path
		select '	}
		insert into ##path
		select '	@Override
		insert into ##path
		select '	public String inserir() {
		insert into ##path
		select '		try{
		insert into ##path
		select '			dao.inserir(getModelo());
		insert into ##path
		select '			return SUCESSO;
		insert into ##path
		select '		}catch (Exception e){
		insert into ##path
		select '			return ERRO;
		insert into ##path
		select '		}
		insert into ##path
		select '	}
		insert into ##path
		select '	@Override
		insert into ##path
		select '	public String prepararAlterar(){
		insert into ##path
		select '		try{
		insert into ##path
		select '			Album album = dao.porId(getId());
		insert into ##path
		select '			setModelo(album);
		insert into ##path
		select '			return SUCESSO;
		insert into ##path
		select '		}catch (Exception e){
		insert into ##path
		select '			return ERRO;
		insert into ##path
		select '		}
		insert into ##path
		select '	}
		insert into ##path
		select '	@Override
		insert into ##path
		select '	public String alterar() {
		insert into ##path
		select '		try{
		insert into ##path
		select '			dao.atualizar(getModelo());
		insert into ##path
		select '			return SUCESSO;
		insert into ##path
		select '		}catch (Exception e){
		insert into ##path
		select '			return ERRO;
		insert into ##path
		select '		}
		insert into ##path
		select '	}
		insert into ##path
		select '
		insert into ##path
		select '	@Override
		insert into ##path
		select '	public String deletar() {
		insert into ##path
		select '		try{
		insert into ##path
		select '			Album album = dao.porId(getId());
		insert into ##path
		select '			dao.deletar(album);
		insert into ##path
		select '			return SUCESSO;
		insert into ##path
		select '		}catch (Exception e){
		insert into ##path
		select '			return ERRO;
		insert into ##path
		select '		}
		insert into ##path
		select '	}
*/

		insert into ##path
		select '}'
		SET  @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path where ascii(line) is not null order by num " queryout "S:\Atual\1_Jsf\Workspace\'+@NOME_PROJETO+@CONTROLE+'CTR\'+@s+'CTR.java'+'" -c -U sa -P mdl1680'+CHAR(39)
		print @exec
		EXEC (@EXEC)
------------------------FIM CONTROLE CTR------------------------

------------------------CONTROLE DAO------------------------
		delete from ##path
		insert into ##path
		select '}'
		SET  @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path where ascii(line) is not null order by num " queryout "S:\Atual\1_Jsf\Workspace\'+@NOME_PROJETO+@CONTROLE+'DAO\'+@s+'DAO.java'+'" -c -U sa -P mdl1680'+CHAR(39)
		print @exec
		EXEC (@EXEC)
------------------------FIM CONTROLE DAO------------------------




	END
------------------------- FIM

ENDselect * from #sys--select * from ##path
--master..xp_cmdshell 'bcp "select line from ##path where ascii(line) is not null order by num " queryout "S:\ATUAL\1_Jsf\Workspace\aponta\.classpath" -c -U sa -P mdl1680'/*		select b.name, b.xtype, b.id, isnull(ORDINAL_POSITION,0) IsPrimaryKey, colid SEQ
		,Tipo = case 
				when b.xtype = 56 then 'int'
				when b.xtype = 167 then 'String'
				when b.xtype = 175 then 'String'
				when b.xtype = 104 then 'boolean'
				when b.xtype = 61 then 'String'
				else 'var'
			end
		,Tamanho = case 
				when b.xtype = 56 then 0
				when b.xtype = 167 then b.length
				when b.xtype = 175 then b.length
				when b.xtype = 104 then b.length
				when b.xtype = 61 then b.length * 2
				else 'var'
			end
					from sysobjects a, syscolumns b left join INFORMATION_SCHEMA.KEY_COLUMN_USAGE c on column_name = b.name
		where a.name = 'bkag'
		and a.id = b.id*/FIM: