--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 02/08/2017--DEPARTAMENTO : SISTEMA--ASSUNTO      : INCLUIR PROJETO ANDROID NO ECLIPSE------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#prcMAPEAR') IS NOT NULL DROP procedure #prcMAPEARDECLARE@PROC VARCHAR(4000)
SET @PROC = 'CREATE procedure DBO.#prcMAPEAR
	@vPATH_WORK VARCHAR(255),
	@vPATH_DIR VARCHAR(255),
	@vNOME_PROJETO VARCHAR(255)
AS BEGIN
	DECLARE 
	@EXEC VARCHAR(4000)

	Exec xp_cmdshell '+CHAR(39)+'net use s: /delete'+CHAR(39)+'
	IF SUBSTRING(@vPATH_DIR,1,2) = '+CHAR(39)+'\\'+CHAR(39)+' BEGIN 
		set @exec = '+CHAR(39)+'net use s: '+Char(39)+'+@vPATH_DIR+'+char(39)+' mdl168@@ /USER:MDL\administrator'+CHAR(39)+'
		Exec xp_cmdshell @exec
	END
END'
--PRINT @PROC
EXEC (@PROC)
--CAMINHO ONDE EST� O WORKSPACE
BEGIN
	DECLARE
		@PATH_WORK VARCHAR(255),
		@PATH_WORK_NEW VARCHAR(255),
		@PATH_DIR VARCHAR(255),
		@ARQUIVO VARCHAR(255),
		@NOME_PROJETO VARCHAR(255),
		@PATH varchar(255),
		@MODELO VARCHAR(255),		--MVC PASTAS
		@VIEW VARCHAR(255),			--MVC PASTAS
		@CONTROLE VARCHAR(255),	--MVC PASTAS
		@EXEC varchar(4000),
		@i int,
		@j int,
		@n int

	SET @PATH_DIR = '\\192.168.3.85\1_Geral\'
	SET @PATH_DIR = '\\192.168.3.3\disk_w_ti'
	SET @PATH_WORK = '\ATUAL\1_Jsf\Workspace'
	SET @MODELO = '\src\br\com\mdl\modelo'
	SET @VIEW = '\src\br\com\mdl\telas'
	SET @CONTROLE ='\src\br\com\mdl\controle'
	--SET @NOME_PROJETO = 'APONTAMENTO'
	SET @NOME_PROJETO = 'aponta'
	set @PATH = @PATH_WORK+'\'+@NOME_PROJETO
	EXEC #prcMAPEAR @PATH_WORK, @PATH_DIR, @NOME_PROJETO

	IF OBJECT_ID('TempDB.dbo.##path') IS NOT NULL DROP TABLE ##path	select line = space(4000), identity(int,1,1) num into ##path where 1 = 0
	IF OBJECT_ID('TempDB.dbo.#TMP_FILES') IS NOT NULL DROP TABLE #TMP_FILES
	SELECT IDENTITY(INT,1,1) NUM, SPACE(500) FILE_NAME INTO #TMP_FILES WHERE 1 = 0

	-- CRIAR OS DIRET�RIOS
  SET @exec = 'DIR ' + 'S:' + @PATH_WORK+'\alfa_New'+ '/S /B /AD';
	INSERT #TMP_FILES EXEC XP_CMDSHELL @exec;
	SELECT *--NUM, FILE_NAME
	FROM #TMP_FILES
	WHERE FILE_NAME IS NOT NULL;

	SELECT @i = 1, @j = max(num) from #TMP_FILES WHERE FILE_NAME IS NOT NULL
	WHILE @I <= @J BEGIN
		delete from ##path
	
		select @PATH_WORK_NEW = REPLACE(FILE_NAME,'alfa_New',@NOME_PROJETO)
		from #TMP_FILES WHERE NUM = @I
		
		set @exec = 'master..xp_cmdshell '+char(39)+'MD '+@PATH_WORK_NEW+char(39)		exec (@exec) 		SET @I = @I + 1
	END
 

  SET @exec = 'DIR ' + 'S:' + @PATH_WORK+'\alfa_New'+ '/S /B /AA';
	INSERT #TMP_FILES EXEC XP_CMDSHELL @exec;
	SELECT *--NUM, FILE_NAME
	FROM #TMP_FILES
	WHERE FILE_NAME IS NOT NULL;


	select @i = 1, @j = max(num) from #TMP_FILES WHERE FILE_NAME IS NOT NULL
	set @j = 2
	WHILE @I <= @J BEGIN
		delete from ##path
		
		select 
			@PATH_DIR = REVERSE(SUBSTRING(reverse(FILE_NAME),CHARINDEX('\',reverse(FILE_NAME)),LEN(reverse(FILE_NAME))))
			,@ARQUIVO = REVERSE(SUBSTRING(reverse(FILE_NAME),1,CHARINDEX('\',reverse(FILE_NAME))-1)) 
			,@PATH_WORK_NEW = REPLACE(FILE_NAME,'alfa_New',@NOME_PROJETO)
		from #TMP_FILES WHERE NUM = @I
		
		SELECT @PATH_DIR, @ARQUIVO, @PATH_WORK_NEW

		DELETE FROM ##path
		INSERT INTO ##path
		SELECT replace(line,'alfa', @NOME_PROJETO) line
		FROM uftReadfileAsTable(@PATH_DIR, @ARQUIVO) 

		SET  @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path order by num " queryout "'+'S:'+@PATH_WORK_NEW+'" -c -U sa -P mdl1680'+CHAR(39)
		EXEC (@EXEC)


		SELECT * FROM ##path

		SET @I = @I + 1
	END


END-- select * from #TMP_FILES--master..xp_cmdshell 'bcp "select * from ##path " queryout "S:\ATUAL\1_Jsf\Workspace\APONTAMENTO\.classpath" -c -U sa -P mdl1680'

--select @exec = line from ##path order by line
--exec spWriteStringToFile @exec, 'S:\ATUAL\1_Jsf\Workspace\APONTAMENTO\', '.classpath'