--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 02/08/2017--DEPARTAMENTO : SISTEMA--ASSUNTO      : INCLUIR PROJETO ANDROID NO ECLIPSE------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#prcMAPEAR') IS NOT NULL DROP procedure #prcMAPEARDECLARE@PROC VARCHAR(4000)
SET @PROC = 'CREATE procedure DBO.#prcMAPEAR
	@vPATH_WORK VARCHAR(255),
	@vPATH_DIR VARCHAR(255),
	@vNOME_PROJETO VARCHAR(255)
AS BEGIN
	DECLARE 
	@EXEC VARCHAR(4000)

	Exec xp_cmdshell '+CHAR(39)+'net use s: /delete'+CHAR(39)+'
	IF SUBSTRING(@vPATH_DIR,1,2) = '+CHAR(39)+'\\'+CHAR(39)+' BEGIN 
		set @exec = '+CHAR(39)+'net use s: '+Char(39)+'+@vPATH_DIR+'+char(39)+' mdl168@@ /USER:MDL\administrator'+CHAR(39)+'
		Exec xp_cmdshell @exec
	END
END'
--PRINT @PROC
EXEC (@PROC)
--CAMINHO ONDE EST� O WORKSPACE
BEGIN
	DECLARE
		@PATH_WORK VARCHAR(255),
		@PATH_DIR VARCHAR(255),
		@NOME_PROJETO VARCHAR(255),
		@PATH varchar(255),
		@MODELO VARCHAR(255),		--MVC PASTAS
		@VIEW VARCHAR(255),			--MVC PASTAS
		@CONTROLE VARCHAR(255),	--MVC PASTAS
		@EXEC varchar(4000)

	SET @PATH_DIR = '\\192.168.3.85\1_Geral\'
	SET @PATH_DIR = '\\192.168.3.3\disk_w_ti'
	SET @PATH_WORK = '\ATUAL\1_Jsf\Workspace'
	SET @MODELO = '\src\br\com\mdl\modelo'
	SET @VIEW = '\src\br\com\mdl\telas'
	SET @CONTROLE ='\src\br\com\mdl\controle'
	--SET @NOME_PROJETO = 'APONTAMENTO'
	SET @NOME_PROJETO = 'aponta'
	set @PATH = @PATH_WORK+'\'+@NOME_PROJETO
	EXEC #prcMAPEAR @PATH_WORK, @PATH_DIR, @NOME_PROJETO

	--IF OBJECT_ID('TempDB.dbo.#GLPR') IS NOT NULL DROP TABLE #GLPR	--SELECT * INTO #GLPR FROM GLPR WHERE 1 = 0	
	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+'\'++char(39)	--print @exec	exec (@exec) 	--CRIAR PASTAS MVC E UTILITARIOS	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+@MODELO+char(39)	exec (@exec) 	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+@VIEW+char(39)	exec (@exec) 	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+@CONTROLE+char(39)	exec (@exec) 	--CRIAR PASTAS AUXILIAR	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+'\src\br\com\mdl\util'+char(39)	exec (@exec) 	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+'\src\br\com\mdl\repositorio'+char(39)	exec (@exec) --	set @exec = 'master..xp_cmdshell '+char(39)+'MD S:'+@PATH+'\scr\br\com\mdl\telas'+char(39)--	exec (@exec) 	IF OBJECT_ID('TempDB.dbo.##path') IS NOT NULL DROP TABLE ##path	select line = space(255), identity(int,1,1) num into ##path where 1 = 0	insert into ##path select '<?xml version="1.0" encoding="UTF-8"?>'
	insert into ##path select '<classpath>'
	insert into ##path select '	<classpathentry kind="src" path="src"/>'
	insert into ##path select '	<classpathentry kind="src" path="gen"/>'
	insert into ##path select '	<classpathentry kind="con" path="com.android.ide.eclipse.adt.ANDROID_FRAMEWORK"/>'
	insert into ##path select '	<classpathentry exported="true" kind="con" path="com.android.ide.eclipse.adt.LIBRARIES"/>'
	insert into ##path select '	<classpathentry exported="true" kind="con" path="com.android.ide.eclipse.adt.DEPENDENCIES"/>'
	insert into ##path select '	<classpathentry kind="output" path="bin/classes"/>'
	insert into ##path select '</classpath>'	--into ##path	--set @STR_EXEC = 'master..xp_cmdshell '+char(39)+'bcp "select filtro from ##FILTRO ORDER BY item desc " queryout "'+'S:\'+@dir_perfil+@str_dir+'\msgFilterRules.dat'+'" -c -U sa -P mdl1680'+CHAR(39)	set @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path order by num           " queryout "'+'S:'+@PATH+'\.classpath'+'"                            -c -U sa -P mdl1680'+CHAR(39)
	exec (@EXEC) 

	delete from ##path
	insert into ##path select '<?xml version="1.0" encoding="UTF-8"?>'
	insert into ##path select '<projectDescription>'
	insert into ##path select '	<name>'+lower(@NOME_PROJETO)+'</name>'
	insert into ##path select '	<comment></comment>'
	insert into ##path select '	<projects>'
	insert into ##path select '	</projects>'
	insert into ##path select '	<buildSpec>'
	insert into ##path select '	<buildCommand>'
	insert into ##path select '		<name>com.android.ide.eclipse.adt.ResourceManagerBuilder</name>'
	insert into ##path select '		<arguments>'
	insert into ##path select '		</arguments>'
	insert into ##path select '	</buildCommand>'
	insert into ##path select '	<buildCommand>'
	insert into ##path select '		<name>com.android.ide.eclipse.adt.PreCompilerBuilder</name>'
	insert into ##path select '		<arguments>'
	insert into ##path select '		</arguments>'
	insert into ##path select '	</buildCommand>'
	insert into ##path select '	<buildCommand>'
	insert into ##path select '		<name>org.eclipse.jdt.core.javabuilder</name>'
	insert into ##path select '		<arguments>'
	insert into ##path select '		</arguments>'
	insert into ##path select '	</buildCommand>'
	insert into ##path select '	<buildCommand>'
	insert into ##path select '		<name>com.android.ide.eclipse.adt.ApkBuilder</name>'
	insert into ##path select '		<arguments>'
	insert into ##path select '		</arguments>'
	insert into ##path select '	</buildCommand>'
	insert into ##path select '</buildSpec>'
	insert into ##path select '<natures>'
	insert into ##path select '	<nature>com.android.ide.eclipse.adt.AndroidNature</nature>'
	insert into ##path select '	<nature>org.eclipse.jdt.core.javanature</nature>'
	insert into ##path select '</natures>'
	insert into ##path select '</projectDescription>'

	set @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path order by num           " queryout "'+'S:'+@PATH+'\.project'+'"                            -c -U sa -P mdl1680'+CHAR(39)
	exec (@EXEC) 

	delete from ##path
	insert into ##path select '<?xml version="1.0" encoding="utf-8"?>'
	insert into ##path select '<manifest xmlns:android="http://schemas.android.com/apk/res/android"'
  insert into ##path select '  package="br.com.mdl.telas'+'"'
  insert into ##path select '  android:versionCode="1"'
  insert into ##path select '  android:versionName="1.0" >'
	insert into ##path select '    <uses-sdk'
  insert into ##path select '      android:minSdkVersion="17"'
  insert into ##path select '      android:targetSdkVersion="17" />'
	insert into ##path select '    <application'
  insert into ##path select '      android:allowBackup="true"'
  insert into ##path select '      android:icon="@drawable/ic_launcher"'
  insert into ##path select '      android:label="@string/app_name"'
  insert into ##path select '      android:theme="@style/AppTheme" >'
  insert into ##path select '      <activity'
  insert into ##path select '          android:name=".PrincipalActivity"'
  insert into ##path select '          android:label="@string/app_name" >'
  insert into ##path select '          <intent-filter>'
  insert into ##path select '              <action android:name="android.intent.action.MAIN" />'
	insert into ##path select '                <category android:name="android.intent.category.LAUNCHER" />'
  insert into ##path select '          </intent-filter>'
  insert into ##path select '      </activity>'
  insert into ##path select '  </application>'
	insert into ##path select '</manifest>'
	set @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path order by num           " queryout "'+'S:'+@PATH+'\AndroidManifest.xml'+'"                            -c -U sa -P mdl1680'+CHAR(39)
	exec (@EXEC) 
	delete from ##path
	insert into ##path select '# This file is automatically generated by Android Tools.'
	insert into ##path select '# Do not modify this file -- YOUR CHANGES WILL BE ERASED!'
	insert into ##path select '#'
	insert into ##path select '# This file must be checked in Version Control Systems.'
	insert into ##path select '#'
	insert into ##path select '# To customize properties used by the Ant build system edit'
	insert into ##path select '# "ant.properties", and override values to adapt the script to your'
	insert into ##path select '# project structure.'
	insert into ##path select '#'
	insert into ##path select '# To enable ProGuard to shrink and obfuscate your code, uncomment this (available properties: sdk.dir, user.home):'
	insert into ##path select '#proguard.config=${sdk.dir}/tools/proguard/proguard-android.txt:proguard-project.txt'
	insert into ##path select '# Project target.'
	insert into ##path select 'target=android-17'	set @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path order by num           " queryout "'+'S:'+@PATH+'\project.properties'+'"                            -c -U sa -P mdl1680'+CHAR(39)
	exec (@EXEC)

	delete from ##path
	insert into ##path select 'package br.com.mdl.telas'+';'
	insert into ##path select 'import android.app.Activity;'
	insert into ##path select 'import android.os.Bundle;'
	insert into ##path select 'import android.view.Menu;'
	insert into ##path select 'import android.view.MenuItem;'
	insert into ##path select 'public class PrincipalActivity extends Activity {'
	insert into ##path select '	@Override'
	insert into ##path select '	protected void onCreate(Bundle savedInstanceState) {'
	insert into ##path select '		super.onCreate(savedInstanceState);'
	insert into ##path select '		setContentView(R.layout.principal);'
	insert into ##path select '	}'
	insert into ##path select '	@Override'
	insert into ##path select '	public boolean onCreateOptionsMenu(Menu menu) {'
	insert into ##path select '	// Inflate the menu; this adds items to the action bar if it is present.'
	insert into ##path select '		getMenuInflater().inflate(R.menu.principal, menu);'
	insert into ##path select '		return true;'
	insert into ##path select '	}'
	insert into ##path select '	@Override'
	insert into ##path select '	public boolean onOptionsItemSelected(MenuItem item) {'
	insert into ##path select '	// Handle action bar item clicks here. The action bar will'
	insert into ##path select '		// automatically handle clicks on the Home/Up button, so long'
	insert into ##path select '		// as you specify a parent activity in AndroidManifest.xml.'
	insert into ##path select '		int id = item.getItemId();'
	insert into ##path select '		if (id == R.id.action_settings) {'
	insert into ##path select '			return true;'
	insert into ##path select '		}'
	insert into ##path select '		return super.onOptionsItemSelected(item);'
	insert into ##path select '	}'
	insert into ##path select '}'
	set @EXEC =     'master..xp_cmdshell '+char(39)+'bcp "select line from ##path order by num           " queryout "'+'S:'+@PATH+@VIEW+'\PrincipalActivity.java'+'"                            -c -U sa -P mdl1680'+CHAR(39)
	exec (@EXEC)

	--@PATH_WORK
	delete from ##path
	insert into ##path
	select replace(line,'alfa', @NOME_PROJETO) line
	from uftReadfileAsTable('S:\ATUAL\1_Jsf\Workspace\alfa_New','AndroidManifest.xml') 


	IF OBJECT_ID('TempDB.dbo.#TMP_FILES') IS NOT NULL DROP TABLE #TMP_FILES
	CREATE TABLE #TMP_FILES
    (
        ID INT IDENTITY(1,1),
        FILE_NAME VARCHAR(500)
    );
 
    SET @exec = 'DIR ' + 'S:' + @PATH_WORK+'\alfa_new'+ '/S /B';
 
    INSERT #TMP_FILES EXEC XP_CMDSHELL @exec;
 
    SELECT ID, FILE_NAME
    FROM #TMP_FILES
    WHERE FILE_NAME IS NOT NULL;

ENDselect *from #TMP_FILES--master..xp_cmdshell 'bcp "select * from ##path " queryout "S:\ATUAL\1_Jsf\Workspace\APONTAMENTO\.classpath" -c -U sa -P mdl1680'

--select @exec = line from ##path order by line
--exec spWriteStringToFile @exec, 'S:\ATUAL\1_Jsf\Workspace\APONTAMENTO\', '.classpath'