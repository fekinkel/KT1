select EQUI_SO, COUNT(1) QTD
from EQUI
where substring(EQUI_IP,1,10) in ('192.168.1.','192.168.1.')
			and EQUI_GRUPO = 'server'
group by EQUI_SO

select *
from EQUI
where substring(EQUI_IP,1,10) in ('192.168.1.','192.168.1.')
			and EQUI_GRUPO = 'server'


select EQUI_SO, COUNT(1) QTD
from EQUI
where substring(EQUI_IP,1,10) in ('192.168.2.','192.168.2.')
			and EQUI_GRUPO <> 'server'
group by EQUI_SO

select substring(EQUI_IP,1,10), EQUI_SO, COUNT(1) QTD
from EQUI
where substring(EQUI_IP,1,10) in ('192.168.1.','192.168.2.')
			and EQUI_GRUPO <> 'server'
group by substring(EQUI_IP,1,10), EQUI_SO

select EQUI_GRUPO, *
from EQUI a
where substring(EQUI_IP,1,10) in ('192.168.2.','192.168.1.')
			and EQUI_GRUPO <> 'server'
order by a.EQUI_GRUPO
