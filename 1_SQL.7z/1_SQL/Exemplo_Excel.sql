drop table #new

------------------XLS---------------------
select *--nome--, identity(int,1,1) NUM
--into #new
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\MX_punc_v212_header.xls',plan1$) 
where insumo is not null


------------------XLSX--------------------
select *
FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;Database=N:\Temp\MX_punc_v212_header.xlsx', 'SELECT * FROM [plan1$]')
 -- where isnull(cod1,'*')<>'*'



insert into #new
select (replace(insumo,'.',' ')) COD, qtd#prevista QDE, 'BUC', tipo 'ETI'
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\india\buchacamisa.xls',plan1$) 
where insumo is not null

insert into #new
select (replace(insumo,'.',' ')) COD, qtd#prevista QDE, 'GAI', tipo 'ETI'
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\india\gaiolas.xls',plan1$) 
where insumo is not null


select sum(qde), sum(qde)/8000
from #new
where eti = 1
select sum(qde), sum(qde)/3000
from #new
where eti = 2
select sum(qde), sum(qde)/1400
from #new
where eti = 3




drop table #cod

declare
@i int,
@j int

set @i = 1
select 'MDL' Empresa, 'WWWWWWWWWWWW' C�digo into #cod where 1 = 0
while @i <= (select max(num) from #new ) begin
	set @j = 1
	while @j <= (select qde from #new where num = @i) begin
		insert into #cod 
		select 'MDL', cod
		from #new
		where num = @i
		set @j = @j +1
	end
	set @i = @i +1
end

select *
from #cod
