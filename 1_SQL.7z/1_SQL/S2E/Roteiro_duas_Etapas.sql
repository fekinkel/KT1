select EXLI_SIDM,	EXLI_SISM,	EXLI_CODM, *
--,exmp_sies2
--,exmp_sido2
--,exmp_sise2
--,exmp_expr=2209
--,exmp_pedc
--,exrs_exro
--,exrs_cod
--,exrs_eori
--,exrs_lori
--,exrs_edes
--,exrs_ldes
--,exrs_glpg
--,exmp_cod
--,exmp_pedc
--,expi_cod
--,EXPI_MTPE=CASE MTPU_ESPE 
--	WHEN 'S' THEN rtrim(EXPI_MTPE)+'-'+rtrim(EXMP_PEDC)+'/'+CAST(EXMI_ITEC AS VARCHAR) 
--	ELSE EXPI_MTPE 
--	END
--,exmi_mtpu
--,expi_nom
--,mtpe_val
--,exli_qtdf
--,exmi_qtdf
--,exmi_pliq
--,exli_pbrt
--,exli_pliq
--,exli_pbrt
--,mtpx_exgr 
from [192.168.3.38\SQLEXPRESS].S2E.dbo.EXPR expr
, [192.168.3.38\SQLEXPRESS].S2E.dbo.EXLI exli
, [192.168.3.38\SQLEXPRESS].S2E.dbo.EXRS exrs
, [192.168.3.38\SQLEXPRESS].S2E.dbo.EXMP exmp
, [192.168.3.38\SQLEXPRESS].S2E.dbo.EXMI exmi
, [192.168.3.38\SQLEXPRESS].S2E.dbo.EXPI expi
, [192.168.3.38\SQLEXPRESS].S2E.dbo.MTPX mtpx
, [192.168.3.38\SQLEXPRESS].S2E.dbo.MTPU mtpu 
, [192.168.3.38\SQLEXPRESS].S2E.dbo.EXGR exgr 
where expr_sies=3 
and expr_sido='PEX ' 
and expr_sise='001' 
and expr_cod=2209 

and exli_sies=expr_sies 
and exli_sido=expr_sido 
and exli_sise=expr_sise 
and exli_expr=expr_cod 
and exli_qtdf<>0 

and exrs_exro=exmp_exro 

and exmp_sies=exli_sies 
and exmp_sido=exli_sidm 
and exmp_sise=exli_sism 
and exmp_cod=exli_codm 

and exmi_sies=exmp_sies 
and exmi_sido=exmp_sido 
and exmi_sise=exmp_sise 
and exmi_exmp=exmp_cod 
and exmi_cod=exli_codi 

and expi_sies=exmi_sies 
and expi_sido=exmi_sido 
and expi_sise=exmi_sise 
and expi_exmp=exmi_exmp 
and expi_cod=exmi_cod 
and expi_expv=exrs_cod 

and mtpx_mtpu=exmi_mtpu 
and mtpx_siex=EXRS_EDES --exmi_sies 

and mtpu_cod=mtpx_mtpu 

and MTPX_EXGR = EXGR_COD
order by exrs_exro,exrs_cod,mtpx_exgr,expi_mtpe

--group by EXLI_SIDM,	EXLI_SISM,	EXLI_CODM
--Select sum(isnull(exlv_pemb,0)) from [192.168.3.38\SQLEXPRESS].S2E.dbo.EXLV EXLV where exlv_sies=3   and exlv_sido='PEX '   and exlv_sise='001'   and exlv_expr=2209
