--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 26/02/2018--DEPARTAMENTO : EXPORTA��O--ASSUNTO      : PEDIDO DE VENDAS EM ABERTO------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#EXMI') IS NOT NULL DROP TABLE #EXMISELECT * INTO #EXMI FROM EXMI WHERE 1 = 0
--AJUSTAR OS VALORES
select EXMI_QTDP, EXMI_QTDF, VDPI_QTD, VDPI_QNF, *
--update EXMI set EXMI_QTDP = VDPI_QTD 
from EXMI, EXMP, [192.168.3.39\sqlexpress].[sidor].[dbo].vdpi
WHERE EXMI_SIES = EXMP_SIES
AND EXMI_SIDO = EXMP_SIDO
AND	EXMI_SISE	= EXMP_SISE
AND EXMI_EXMP = EXMP_COD
AND EXMP_PSCR = vdpi_vdpd
AND EXMI_COD  = VDPI_COD

and EXMI_QTDP <> EXMI_QTDF

and VDPI_QTD <> EXMI_QTDP
and VDPI_QNF <> 0.000
and VDPI_QTD = VDPI_QNF

and VDPI_STA <> 'EC'

--31774

select EXMP_EXRO, EXMI_QTDP, EXMI_QTDF, VDPI_QTD, VDPI_QNF, *
--update EXMI set EXMI_QTDP = VDPI_QTD 
from EXMI, EXMP, [192.168.3.39\sqlexpress].[sidor].[dbo].vdpi
WHERE EXMI_SIES = EXMP_SIES
AND EXMI_SIDO = EXMP_SIDO
AND	EXMI_SISE	= EXMP_SISE
AND EXMI_EXMP = EXMP_COD
AND EXMP_PSCR = vdpi_vdpd
AND EXMI_COD  = VDPI_COD

and EXMI_QTDP <> EXMI_QTDF
--and VDPI_QNF <> 0.000
and VDPI_STA <> 'EC'

ORDER BY EXMP_EXRO
