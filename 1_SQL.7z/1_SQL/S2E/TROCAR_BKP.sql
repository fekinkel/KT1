
-- em 192.168.3.38
use BKP
update GLPR set GLPR_VALS='BKP', GLPR_USU='SQLqaSMR', GLPR_DTU=getdate()
where GLPR_COD ='VGINST' and GLPR_CHAV='LINKRVDB'
go

-- em 192.168.3.39
use BKP
select *
--update GLPR set GLPR_VALS='BKP', GLPR_USU='SQLqaSMR', GLPR_DTU=getdate()
from GLPR
where GLPR_COD ='VGINST' and (GLPR_CHAV='LINKEDDB' or GLPR_CHAV='LINKRVDB')
