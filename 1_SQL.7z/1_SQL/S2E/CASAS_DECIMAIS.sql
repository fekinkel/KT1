--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 24/01/2018--DEPARTAMENTO : EXPORTA��O--ASSUNTO      : TROCAR AS CASAS DECIMAIS PARA INTEIRO------------------------------------------------------------------------------------------------------------------------
--IF OBJECT_ID('TempDB.dbo.#MTEP') IS NOT NULL DROP TABLE #MTEP--select EXMI_QTDP%EXMI_QTDP,*
update exmi set EXMI_QTDP = convert(int,round(EXMI_QTDP,0))
from exmi
where EXMI_QTDP <> 0
and EXMI_QTDP%convert(int,EXMI_QTDP) <> 0


--select convert(int,round(EXPI_QTDP,0)), *
update expi set EXPI_QTDP = convert(int,round(EXPI_QTDP,0))
from expi
where EXPI_QTDP <> 0
and EXPI_QTDP%convert(int,EXPI_QTDP) <> 0

