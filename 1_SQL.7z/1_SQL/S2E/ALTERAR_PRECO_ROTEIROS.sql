--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 05/02/2018--DEPARTAMENTO : S2E--ASSUNTO      : ALTERAR O PRE�O DA SEGUNDA ETAPA DOS PROCESSOS.--DATA 09/02/2018 (2218, 2219,2220,2221)
------------------------------------------------------------------------------------------------------------------------

IF OBJECT_ID('TempDB.dbo.#EXLI') IS NOT NULL DROP TABLE #EXLI
select *
INTO #EXLI
from exli
where EXLI_EXPR in (2261,2262,2263,2264)
--(2244,2245,2246,2247)
--(2242)
--(2227, 2228, 2229, 2230)
--(2218, 2219,2220,2221)
--(2193, 2194, 2195, 2196)

--SELECT * FROM #EXLI

--select MTPV_VAL, MTPE_VAL, a.*
UPDATE EXPI SET MTPE_VAL = MTPV_VAL
from expi a, #EXLI b, EXMI c, MTPV d
where EXPI_SIES = 3
AND EXLI_SIDM = EXPI_SIDO
AND	EXLI_SISM	= EXPI_SISE
AND EXLI_CODM = EXPI_EXMP
AND EXLI_CODI = EXPI_COD

AND EXPI_EXPV = 2

AND EXPI_SIES = EXMI_SIES
AND EXLI_SIDM = EXMI_SIDO
AND	EXLI_SISM	= EXMI_SISE
AND EXLI_CODM = EXMI_EXMP
AND EXLI_CODI = EXMI_COD

AND EXMI_MTPU = MTPV_MTPU
AND MTPV_MTTV = 23

AND MTPV_VAL <> MTPE_VAL

--S�O 392 
--ALTEROU 388

