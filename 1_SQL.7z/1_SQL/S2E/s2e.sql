
--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 21/02/2018--DEPARTAMENTO : 21/02/2018--ASSUNTO      : 21/02/2018------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#exli') IS NOT NULL DROP TABLE #exliselect *
into #exli
from exli
where exli_expr = 2234

select * from #exli


select *
from exmp, #exli
where EXLI_SIDM = EXMP_SIDO
and EXLI_SISM	= EXMP_SISE
and EXLI_CODM = EXMP_COD

select *
from expv, #exli
where EXLI_SIDM = EXPV_SIDO
and EXLI_SISM	= EXPV_SISE
and EXLI_CODM = EXPV_EXMP

ORDER BY EXPV_EXMP,	EXLI_EXLV,	EXLI_COD,	EXPV_COD

select *
from expi, #exli
where EXLI_SIDM = EXPV_SIDO
and EXLI_SISM	= EXPV_SISE
and EXLI_CODM = EXPV_EXMP

ORDER BY EXPV_EXMP,	EXLI_EXLV,	EXLI_COD,	EXPV_COD
		

select *
--update mtpx set MTPX_CLAS = ''
from mtpx
where mtpx_mtpu = '0005123'

