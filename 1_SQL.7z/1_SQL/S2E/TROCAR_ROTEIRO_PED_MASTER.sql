--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 18/01/2018--DEPARTAMENTO : ADMINISTRATIVO(RENATA)--ASSUNTO      : TROCAR O ROTEIRO DO PEDIDO MASTER S2E.--OBS.: ESSA ALTERA��O PODE GERAR ITENS IGUAIS MAS COM VALOR DIFERENTE.
------------------------------------------------------------------------------------------------------------------------

ALTER TABLE EXMP DISABLE TRIGGER ALL
--select *
update exmp set EXMP_EXRO = 'MDL EU 2018'
from exmp
where EXMP_COD in (8809, 8810, 8811)
--where EXMP_COD = 8797
--where EXMP_PSCR in (45060)--(45249, 45250, 45251, 45074, 45075, 44883)
ALTER TABLE EXMP ENABLE TRIGGER ALL

select EXMP_COD, EXMP_PSCR, *
from exmp
where EXMP_COD in (8809, 8810, 8811)
--EXMP_PSCR in (45060)--(45249, 45250, 45251, 45074, 45075, 44883)

