/*
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
declare @open varchar(400)
SET @PATH = N'\\192.168.3.3\disk_w_ti'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

set @dir='N:\ATUAL\Temp\'

set @pla='List_MDL_France.xls'

set @aba='MDL_Line'
set @aba='PB_Line'

print @open IF OBJECT_ID('TempDB.dbo.##pre') IS NOT NULL DROP TABLE ##preset @sql = 'SELECT *'
set @sql = @sql +'into ##pre'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'

EXEC (@SQL)

select * from ##pre

Exec xp_cmdshell 'net use N: /delete'

*/

SELECT * into ##pre     FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 8.0;HDR=YES;Database=D:\00\PLANILHA MASTER BRASIL V_1.xls', 'SELECT * FROM [BLANK PUNCH$]')
SELECT * INTO #BOVESPA FROM OPENROWSET ('Microsoft.ACE.OLEDB.12.0','EXCEL 8.0;HDR=YES;Database=C:\Users\Gustavo\Documents\TESTE.XLS','SELECT * FROM [Dados$]')IF OBJECT_ID('PUNC.dbo.PUNC_NEW') IS NOT NULL DROP TABLE PUNC.dbo.PUNC_NEW
SELECT CODB ,PREB ,MDLB ,DAYB ,MOEB ,NOMB ,DIAB ,LENB ,COD1 ,NOM1 ,NOM ,DIA1 ,LEN1 ,DHSTD ,DH1 ,DH2 ,MHSTD ,L2STD ,L2OP1 ,L2OP2 ,MINP ,MAXP ,MINW ,MAXPOG ,CODS ,MDLS ,DAYS ,MOES ,NOMS ,DIAS ,LENS ,CODL ,MDLL ,DAYL ,MOEL ,NOML ,DIAL ,LENL ,CODV ,MDLV ,DAYV1 ,DAYV2 ,MOEV ,NOMV ,DIAV ,LENV ,CODR ,MDLR ,DAYR1 ,DAYR2 ,MOER ,NOMR ,DIAR ,LENR ,CODF ,MDLF ,DAYF ,MOEF ,NOMF ,DIAF ,LENF ,CODH ,MDLH ,DAYH1 ,DAYH2 ,MOEH ,NOMH ,DIAH ,LENH ,CODZ ,MDLZ ,DAYZ ,MOEZ ,NOMZ ,DIAZ ,LENZ ,CODY ,MDLY ,DAYY ,MOEY ,NOMY ,DIAY ,LENY ,CODP ,MDLP ,DAYP ,MOEP ,NOMP ,DIAP ,LENP ,CODQ ,MDLQ ,DAYQ ,MOEQ ,NOMQ ,DIAQ ,LENQ ,MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE
INTO PUNC.dbo.PUNC_NEW
FROM ##PRE
WHERE COD1 IS NOT NULL
and COD1 <> 'Part # with no kit (STOCKING CODE)'
--and DHSTD <> 'Dies only'

select *
--update PUNC.dbo.PUNC_NEW set mtpr_mtdv = '05'
from PUNC.dbo.PUNC_NEW
where nom like '%Metric%'
and mtpr_mtdv = '06'


SELECT * FROM PUNC_NEW
--6849
select len(codb),*
from PUNC_NEW
where len(codb) > 20
order by len(codb) desc

select *--[BASE PRODUCT], punc_codb, punc_mtpr_cod, [Cod correto], *
from ##pre a
where substring([BASE PRODUCT],1,3) = 'QS-'
and MTPR_MTTP = 'PA'

select *--[BASE PRODUCT], punc_codb, punc_mtpr_cod, [Cod correto], *
from ##pre a
where substring([BASE PRODUCT],1,3) = 'QS-'
and MTPR_MTTP <> 'PA'


select *--[BASE PRODUCT], punc_codb, punc_mtpr_cod, [Cod correto], *
--update [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc set punc_nomb = [F4]
--from #pre a, mtpc
--from #pre a, [192.168.3.40].[punc].[dbo].mtpc
from ##pre a, [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc
where punc_codb = [BASE PRODUCT] collate SQL_Latin1_General_CP1_CI_AS
and substring([BASE PRODUCT],1,3) = 'QS-'


select  convert(DECIMAL(10,4),REPLACE([Dies only], ',','.')), *--[BASE PRODUCT], punc_dhstd, [Dies only]
--update [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc set punc_dhstd = convert(DECIMAL(10,4),REPLACE([Dies only], ',','.')), punc_Mhstd = convert(DECIMAL(10,4),REPLACE([F16], ',','.'))
--from #pre a, mtpc
--from #pre a, [192.168.3.40].[punc].[dbo].mtpc
from #pre a, [192.168.4.2\sqlexpress].[mdlmex].[dbo].punc
where punc_codb = [BASE PRODUCT] collate SQL_Latin1_General_CP1_CI_AS
and [Dies only] is not null
and punc_dhstd <> convert(DECIMAL(10,4),REPLACE([Dies only], ',','.'))


IF OBJECT_ID('TempDB.dbo.#pre') IS NOT NULL DROP TABLE #pre
SELECT *
INTO #PRE
FROM ##PRE
WHERE [Dies only] IS NOT NULL
AND [Dies only] <> 'Std H (Dayton)'
