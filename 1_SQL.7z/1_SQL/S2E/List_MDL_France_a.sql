/*
declare @sql varchar(4000)
declare @dir varchar(400)
declare @pla varchar(400)
declare @aba varchar(400)
declare @PATH varchar(400)
declare @exec varchar(400)
declare @open varchar(400)
SET @PATH = N'\\192.168.3.3\disk_w_ti'

set @exec = N'net use N: ' + @PATH + N' serejo /USER:MDL\kinkel'							
Exec xp_cmdshell 'net use N: /delete'
Exec xp_cmdshell @exec

set @dir='N:\ATUAL\Temp\'

set @pla='List_MDL_France.xls'

set @aba='MDL_Line'
--set @aba='PB_Line'

print @open IF OBJECT_ID('TempDB.dbo.##pre') IS NOT NULL DROP TABLE ##preset @sql = 'SELECT *'
set @sql = @sql +'into ##pre'
set @sql=@sql +' FROM OPENROWSET(''Microsoft.ACE.OLEDB.12.0'',''Excel 12.0;Database='+@dir+@pla +''', ''SELECT * FROM ['+@aba+'$]'')'

EXEC (@SQL)

select * from ##pre

Exec xp_cmdshell 'net use N: /delete'

*/

