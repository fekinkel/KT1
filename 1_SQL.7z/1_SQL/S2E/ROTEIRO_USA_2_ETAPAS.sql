--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 18/01/2018--DEPARTAMENTO : ADMINISTRATIVO(RENATA)--ASSUNTO      : ROTEIRO PEDIDO MASTER EM DUAS ETAPAS--OBS.: COLOCAR DUAS ETAPAS NO ROTEIRO USA EXPV.
------------------------------------------------------------------------------------------------------------------------

--ALTER TABLE EXMP DISABLE TRIGGER ALL
IF OBJECT_ID('TempDB.dbo.#EXPV') IS NOT NULL DROP TABLE #EXPVSELECT * INTO #EXPV FROM EXPV WHERE 1 = 0INSERT INTO #EXPVSELECT 		EXPV_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, EXPV_SIDO --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tip.Doc.(Tipo de documento)
	, EXPV_SISE --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�rie(S�rie para o tipo de documento)
	, EXPV_EXMP --= CONVERT(int(6),'')      --CONVERT(int(6),'') N� Ped(N�mero do pedido de exporta��o)
	, EXPV_COD = CONVERT(int,'2')      --CONVERT(int(3),'') Ped.Rot.(Sequencial dos desdobramento do pedido master)
	, EXPV_EORI = CONVERT(int,'106')      --CONVERT(int(6),'') Origem(C�digo do estabelecimento origem)
	, EXPV_EDES = CONVERT(int,'6')      --CONVERT(int(6),'') Destino(C�digo do estabelecimento de destino)
	, EXPV_LORI = CONVERT(varchar(20),'MTV')      --CONVERT(varchar(20),'') Embarque(Local de embarque)
	, EXPV_LDES = CONVERT(varchar(20),'COLUMBUS')      --CONVERT(varchar(20),'') Desembarque(Local de desembarque)
	, EXPV_VIAT --= CONVERT(varchar(12),'')      --CONVERT(varchar(12),'') Transporte(Via de transporte)
	, EXPV_GLPG --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Pagamento(C�digo da condi��o de pagamento)
	, EXPV_MTTV --= CONVERT(varchar(12),'')      --CONVERT(varchar(12),'') Tab.Pre�o(Tabela de pre�os)
	, EXPV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, EXPV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em(Data de cadastro do registro)
	, EXPV_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, EXPV_DTU = Null      --CONVERT(datetime(10),'') Em(Data da �ltima atualiza��o do registro)
	--SELECT *
from EXPV
where EXPV_EXMP in (8752)
--where EXPV_EXMP in (8759)

--ALTER TABLE EXMP ENABLE TRIGGER ALL

INSERT INTO EXPVSELECT *FROM #EXPVWHERE CONVERT(VARCHAR(6),EXPV_SIES)+'/'+EXPV_SIDO+'/'+EXPV_SISE+'/'+CONVERT(VARCHAR(6),EXPV_EXMP)+'/'+CONVERT(VARCHAR(6),EXPV_COD) NOT IN (SELECT CONVERT(VARCHAR(6),EXPV_SIES)+'/'+EXPV_SIDO+'/'+EXPV_SISE+'/'+CONVERT(VARCHAR(6),EXPV_EXMP)+'/'+CONVERT(VARCHAR(6),EXPV_COD) FROM EXPV)
--SELECT *UPDATE EXPV SET EXPV_LORI = 'GUARULHOS/SANTOS',	EXPV_LDES = 'MTV', EXPV_EDES = 106FROM EXPVwhere EXPV_EXMP in (8752)
AND EXPV_COD = 1


SELECT *
from EXPV
where EXPV_EXMP in (8752)
