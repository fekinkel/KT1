--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 15/03/2018--DEPARTAMENTO : EXPORTA��O--ASSUNTO      : TROCAR O GRUPO 032(INEXISTENTE) PELO GRUPO 033 (ACESSORIOS)------------------------------------------------------------------------------------------------------------------------
--IF OBJECT_ID('TempDB.dbo.#MTPX') IS NOT NULL DROP TABLE #MTPXselect *
--update mtpx set MTPX_EXGR = '033'
from mtpx
where MTPX_EXGR = '032'