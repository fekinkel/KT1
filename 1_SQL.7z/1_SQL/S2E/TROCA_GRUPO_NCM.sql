--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 21/02/2018--DEPARTAMENTO : EXPORTA��O--ASSUNTO      : TROCAR O GRUPO DE NCM DE 008 PARA 061------------------------------------------------------------------------------------------------------------------------
select distinct substring(MTPX_COD,1,3)
--update mtpx set MTPX_EXGR = '061'
from mtpx
where MTPX_SIEX	= 5
and MTPX_COD like 'C1%'
       