drop table #rcit
--select rcit_rcnf, rcit_cod, RCIT_VAL,RCIT_IPI_VAL,RCIT_VAL_ACE,RCIT_VAL_FRE,RCIT_VAL_SEG,RCIT_VAL_PIS,RCIT_VAL_COF, rcnf_val--SUM(RCIT_VAL+RCIT_IPI_VAL+RCIT_VAL_ACE+RCIT_VAL_FRE+RCIT_VAL_SEG+RCIT_VAL_PIS+RCIT_VAL_COF), SUM(RCIT_VAL)
select RCIT_RCNF, SUM(isnull(RCIT_VAL,0)+isnull(RCIT_IPI_VAL,0)+isnull(RCIT_VAL_ACE,0)+isnull(RCIT_VAL_FRE,0)+isnull(RCIT_VAL_SEG,0)+isnull(RCIT_VAL_PIS,0)+isnull(RCIT_VAL_COF,0)) RCIT_VAL, SUM(isnull(RCIT_VAL,0)) RCNF_VAL
into #rcit
from RCNF a, RCIT b
where convert(char(10),RCNF_DAT,102) between '2013.04.01' and '2013.04.30'
			and RCNF_SIES = 7
			and RCNF_STA = 'ok'
			and RCNF_SISX <> 'D1'
			and RCNF_SIES = RCIT_SIES
			and RCNF_SIDO = RCIT_SIDO
			and RCNF_SISE = RCIT_SISE
			and RCNF_COD  = RCIT_RCNF
			
group by RCIT_RCNF
order by RCIT_RCNF

drop table #rcnf
select rcnf_cod, SUM(RCNF_VAL) RCNF_VAL
into #rcnf
from RCNF
where convert(char(10),RCNF_DAT,102) between '2013.04.01' and '2013.04.30'
			and RCNF_SIES = 7
			and RCNF_STA = 'ok'
			and RCNF_SISX <> 'D1'
group by RCNF_COD

update #rcit
set RCNF_VAL = a.rcnf_val
from #rcit b, #rcnf a
where RCNF_COD = RCIT_RCNF

select sum(RCIT_VAL - RCNF_VAL)
from #rcit
where RCIT_VAL <> RCNF_VAL
