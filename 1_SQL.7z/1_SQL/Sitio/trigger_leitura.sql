

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[USUA](
	[USUA_ID] [varchar](50) NOT NULL,
	[USUA_APLI] [varchar](10) NOT NULL,
	[USUA_NOME] [varchar](100) NULL,
	[USUA_GRUPO] [varchar](50) NULL,
	[USUA_DATA] [datetime] NULL,
 CONSTRAINT [PK_USUA] PRIMARY KEY CLUSTERED 
(
	[USUA_ID] ASC,
	[USUA_APLI] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

/****** Object:  UserDefinedTableType [dbo].[user_adn]    Script Date: 11/03/2016 16:01:27 ******/
CREATE TYPE [dbo].[user_adn] AS TABLE(
	[ok] [bit] NULL,
	[grupo] [varchar](50) NULL,
	[nome_completo] [varchar](255) NULL,
	[nome_login] [varchar](50) NULL,
	[data_niver] [varchar](10) NULL
)
GO



SET QUOTED_IDENTIFIER ON
GO


create PROCEDURE [dbo].[USU_AD_new] 
	--@ok varchar(1) output,
	--@nomec varchar(100) output,
	--@grupo varchar(100) output,
	@aplicativo varchar(10),
	@name varchar(50),
	@pwd varchar(50)
AS
BEGIN

DECLARE
--CRIA UMA VARI�VEL DE UMA TIPO TABELA
@exec nvarchar(4000),
@tabela as user_adn,
@data datetime,
@data_new datetime,
@nome_c varchar(255),
@grupo varchar(50),
@ok bit


	begin try
		--COLOCA O USU�RIO E SENHA NO ADSI
		set @exec = 'master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'+char(39)+'ADSI'+char(39)+',@useself=N'+char(39)+'False'+char(39)+',@locallogin=NULL,@rmtuser=N'+char(39)+'mdl\'+@name+CHAR(39)+',@rmtpassword='+CHAR(39)+@pwd+CHAR(39)
		exec (@exec)

		--EXECUTA O ADSI, SE DER CERTO PQ A SENHA EST� CORRETA
		set @exec = '
		select  '+char(39)+'True'+CHAR(39)+', substring(substring(ADsPath,CHARINDEX('+CHAR(39)+',OU'+CHAR(39)+',ADsPath)+4,100),1,charindex('+CHAR(39)+',OU'+CHAR(39)+',substring(ADsPath,CHARINDEX('+CHAR(39)+',OU'+CHAR(39)+',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login], '+CHAR(39)+'01/01/2000'+CHAR(39)+'
		from  openquery(adsi, '+CHAR(39)+'
		select ADsPath,
		sAMAccountName, displayName, userPassword, userPrincipalName, lastLogon, pwdLastSet
		from    '+char(39)+char(39)+'LDAP://dc=mdl,dc=com,dc=br'+char(39)+char(39)+CHAR(10)+
		'where   objectCategory = '+char(39)+char(39)+'Person'+char(39)+char(39)+CHAR(10)+
		'and objectClass = '+char(39)+char(39)+'*'+char(39)+char(39)+' and sAMAccountName = '+char(39)+char(39)+@name+char(39)+Char(39) +char(39)+'  )'

		insert into @tabela exec (@exec)

	end try begin catch
		insert into @tabela select 'False', 'Erro', 'Usu�rio/Senha inv�lido','Inv�lido', ''
	end catch
	--RETORNA O USU�RIO E SEU GRUPO
	select @ok = ok, @data=getdate(), @data_new=getdate(), @nome_c = nome_completo, @grupo = grupo
	from @tabela
	IF (SELECT @OK ) = 1 BEGIN
		IF (SELECT COUNT(1) FROM USUA WHERE USUA_ID = @name AND usua_apli = @aplicativo)>0 BEGIN
			SELECT @data = USUA_DATA
			FROM USUA 
			WHERE USUA_ID = @name
				AND usua_apli = @aplicativo

			UPDATE USUA SET USUA_DATA = @data_new
			FROM USUA 
			WHERE USUA_ID = @name
				AND usua_apli = @aplicativo
		END ELSE BEGIN
			INSERT INTO USUA
			SELECT @name, @aplicativo, @nome_c, @grupo, @data_new
		END	
	END
	select *, @data [data]--@ok = CONVERT(char(1),ok), @grupo = grupo, @nomec = nome_completo
	from @tabela

END

GO


