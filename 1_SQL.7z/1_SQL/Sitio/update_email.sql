
select a.stmd_email, b.stmd_email
--update [192.168.2.39].[SITIO].[dbo].stmd set a.stmd_email =  b.stmd_email
from [192.168.2.39].[SITIO].[dbo].stmd a, stmd b
where a.stmd_id = b.stmd_id
