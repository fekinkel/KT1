function TfrmVdaCotIte.fCalcCustoPlan(vQtde:Extended;vTipo,vDtox:string):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa:Extended;
  vCttr : string;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo de planejamento
  vProp  := 'PL';
  vPrgt  := 'PL000';
  vPrct  := 'PL101';
  vUnct  := 'H';

  result:= True;
  vTempoPrep:=0;
  vTempoExec:=0;
  vTaxa:=vF036;
  vCttr:= 'F036';
  if vTipo='OSPL' then begin
    vTempoExec:=vF044;
    if vDtox='S' then
      vTempoExec:= vTempoExec +vF047 +vF050
    else
      vTempoExec:= vTempoExec +vF046;
  end else if vTipo='OSBA' then begin
    vTempoExec:=vF045;
    if vDtox='S' then
      vTempoExec:= vTempoExec +vF049 +vF050
    else
      vTempoExec:= vTempoExec +vF048;
  end;
  if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
    vMemo :='Planning';
  end else if (Application.Title='S2RMEX') then begin
    vMemo :='Planificaci�n';
  end else begin
    vMemo :='Planejamento';
  end;
  // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoFuro(vQtde,vPeso:Extended;vIcqt:Integer;vIcrc:string):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa:Extended;
  vCttr: String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo de furos de i�amento
  vProp  := 'RD';
  vPrgt  := 'BS550';
  vPrct  := 'BS506';
  vUnct  := 'H';
// 11/03/2013 10:37 -- SCIED -- Coer�ncia com defini��o da furadeira radial em MDL MQ
  vPrct  := 'BS553';

  result:= True;
  vTempoPrep:=0;
  vTempoExec:=0;
  vTaxa :=0;
  vMemo :='';
  // Tempo de execu��o dos furos
  if vIcqt>0 then begin
    // Tempo de preparo p/ execu��o dos furos
    if vPeso>vF061 then
      if vPeso>vF055 then
        vTempoPrep:= vF058+vF060*(vQtde-1)
      else
        vTempoPrep:= vF057+vF059*(vQtde-1)
    else
      vTempoPrep:=0;

    // Tempo de execu��o dos furos
    if Pos(vIcrc,vF051)>0 then
      vTempoExec:=vF053*vIcqt*vQtde
    else if Pos(vIcrc,vF052)>0 then
      vTempoExec:=vF054*vIcqt*vQtde
    else
      vTempoExec:=0;

    // Defini��o da Taxa em fun��o do peso
    if vPeso>vF061 then begin
      vCttr:= 'F038';
      vTaxa:= vF038;
// 11/03/2013 10:37 -- SCIED -- Coer�ncia com defini��o da furadeira radial em MDL MQ
//      vPrct := 'BS506'
      vPrct  := 'BS553';
    end else begin
      vCttr:= 'F040';
      vTaxa:= vF040;
// 11/03/2013 10:37 -- SCIED -- Coer�ncia com defini��o da furadeira radial em MDL MQ
//      vPrct := 'BS506'
      vPrct  := 'BS553';
    end;
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Lifting holes';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Agujeros para levantar';
    end else begin
      vMemo :='Furos de i�amento';
    end;
  end;
  // Custo total dos furos de i�amento
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoRemocao(vQtde,vEspe,vBito,vArea,vDiag:Extended;vActp:String):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa,vVrem:Extended;
  vCttr : String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo de remo��o
  vProp  := 'DEM';
  vPrgt  := 'BS550';
  vPrct  := 'BS504';
  vUnct :='H';
  vMemo :='';

  result:= True;
  vTempoPrep:=0;
  vTempoExec:=0;
  vTaxa:=0;
  vCttr := 'F038';
  // Espessura de remo��o
  vErem:= vBito-vEspe;
  if ((vErem>vF062) and ((vActp='P7') or (vActp='P9')))then begin
    vErem:= vErem-vF063;
  end else begin
    vErem:=0.000;
  end;

  if vErem>0 then begin
    vVrem:= vErem*vArea;
    if vDiag>vF069A then begin
      // Fresa de Desbaste
      vTempoPrep:= vF070+vF071*(vQtde-1);     // Preparo
      vTempoExec:= (vVrem/vF016)*vQtde;       // Execu��o
      vTaxa := vF038*vF072;

      vProp := 'DEM';
      vPrgt := 'BS550';
      vPrct := 'BS504';
      if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
        vMemo :='Roughing in milling cutter';
      end else if (Application.Title='S2RMEX') then begin
        vMemo :='Desbaste en molino';
      end else begin
        vMemo :='Desbaste em fresa';
      end;
    end else begin
      // Torno vertical
      // 11/09/2008 : Reuni�o : Marchesini : Taxa � unica, o tempo que � fun��o da diagonal
      // taxa �nica p/ torno vertical
      vTaxa :=vF038*vF069;
      vProp := 'TV';
      vPrgt := 'TV000';
      vPrct := 'BS507';
      if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
        vMemo :='Roughing in vertical lathe';
      end else if (Application.Title='S2RMEX') then begin
        vMemo :='Desbaste en torno vertical';
      end else begin
        vMemo :='Desbaste em torno vertical';
      end;

      // tempo b�sico
      vTempoPrep:= vF064+vF065*(vQtde-1);    // Preparo
      vTempoExec:= (vVrem/vF015)*vQtde;      // Execu��o
      // Majorado c/ par�metro
      if vDiag>vF002 then begin
        if vDiag>vF003 then begin
          if vDiag>vF004 then begin
            vTempoPrep  := vTempoPrep*vF068; // extra-grande
            vTempoExec  := vTempoExec*vF068; // extra-grande
          end else begin
            vTempoPrep  := vTempoPrep*vF068; // grande
            vTempoExec  := vTempoExec*vF068; // grande
          end;
        end else begin
          vTempoPrep  := vTempoPrep*vF067; // m�dia
          vTempoExec  := vTempoExec*vF067; // m�dia
        end;
      end else begin
        vTempoPrep  := vTempoPrep*vF066;      // pequena
        vTempoExec  := vTempoExec*vF066;      // pequena
      end;
{
      vTempoExec:= (vVrem/vF015)*vQtde;      // Execu��o
      // Taxa de Custo varia com a diagonal
      if vDiag>vF002 then
        if vDiag>vF003 then
          if vDiag>vF004 then
              vTaxa:= vF038*vF069*vF068 // extra-grande
          else
            vTaxa:= vF038*vF069*vF068   // grande
        else
          vTaxa:= vF038*vF069*vF067     // m�dia
      else
        vTaxa:= vF038*vF069*vF066;      // pequena
}
    end;
  end else begin
    // Publica valor nao negativo
    vErem:=0.000;
  end;
  // Custo total da remocao
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR





function TfrmVdaCotIte.fCalcCavidade(vTipo: String;vComp,vLarg,vEspe,vRaio:Extended; vPass:String):Boolean;
var
  vRaioMin:Extended;
  vTempoExec,vTempoPrep,vTaxa:Extended;
  vNomePara, vCttr: String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo de remo��o
  vProp  := 'CNC';
  vPrgt  := 'BS400';
  vPrct  := 'BS402';
  vUnct :='H';
  vMemo :='';

  result:= True;
{   vF143 := StrToFloat(parValues[parItems.IndexOf('F143')]); // Comprimento m�nimo da cavidade em MM
    vF144 := StrToFloat(parValues[parItems.IndexOf('F144')]); // Comprimento m�ximo da cavidade em MM
    vF145 := StrToFloat(parValues[parItems.IndexOf('F145')]); // Largura m�nima da cavidade em MM
    vF146 := StrToFloat(parValues[parItems.IndexOf('F146')]); // Largura m�xima da cavidade em MM
    vF147 := StrToFloat(parValues[parItems.IndexOf('F147')]); // Profundidade m�nima da cavidade em MM
    vF148 := StrToFloat(parValues[parItems.IndexOf('F148')]); // Profundidade m�xima da cavidade em MM
    }
  //Criticas adicionais
  if RoundSMR(vComp-vF143,-2)<0.00 then begin
    Result:= False;
    cdsCadVdcd_comp.FocusControl;
//    MessageDlg(Format('Comprimento de %s mm inferior ao m�nimo permitido (%s mm)...',[floatToStrF(vComp,ffFixed,12,2),floatToStrF(vF143,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80071, floatToStrF(vComp,ffFixed,12,2), floatToStrF(vF143,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSMR(vComp-vF144,-2)>0.00 then begin
    Result:= False;
    cdsCadVdcd_comp.FocusControl;
//    MessageDlg(Format('Comprimento de %s mm superior ao m�ximo permitido (%s mm)...',[floatToStrF(vComp,ffFixed,12,2),floatToStrF(vF144,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80072, floatToStrF(vComp,ffFixed,12,2), floatToStrF(vF144,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSMR(vLarg-vF145,-2)<0.00 then begin
    Result:= False;
    cdsCadVdcd_larg.FocusControl;
//    MessageDlg(Format('Largura de %s mm inferior � m�nima permitida (%s mm)...',[floatToStrF(vLarg,ffFixed,12,2),floatToStrF(vF145,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80073, floatToStrF(vLarg,ffFixed,12,2), floatToStrF(vF145,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSMR(vLarg-vF146,-2)>0.00 then begin
    Result:= False;
    cdsCadVdcd_larg.FocusControl;
//    MessageDlg(Format('Largura de %s mm superior � m�xima permitida (%s mm)...',[floatToStrF(vLarg,ffFixed,12,2),floatToStrF(vF146,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80074, floatToStrF(vLarg,ffFixed,12,2), floatToStrF(vF146,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSMR(vEspe-vF147,-2)<0.00 then begin
    Result:= False;
    cdsCadVdcd_espe.FocusControl;
//    MessageDlg(Format('Profundidade de %s mm inferior � m�nima permitida (%s mm)...',[floatToStrF(vEspe,ffFixed,12,2),floatToStrF(vF147,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80075, floatToStrF(vEspe,ffFixed,12,2), floatToStrF(vF147,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSMR(vEspe-vF148,-2)>0.00 then begin
    Result:= False;
    cdsCadVdcd_espe.FocusControl;
//    MessageDlg(Format('Profundidade de %s mm superior � m�xima permitida (%s mm)...',[floatToStrF(vEspe,ffFixed,12,2),floatToStrF(vF148,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80076, floatToStrF(vEspe,ffFixed,12,2), floatToStrF(vF148,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSmr(vEspe-vLarg,-2)>0.00 then begin
    Result:= False;
    cdsCadVdcd_espe.FocusControl;
//    MessageDlg('Profundidade deve ser no m�ximo igual a largura...',mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80077),mtError,[mbOk],0);
    Exit;
  end;
  if RoundSmr(vLarg-vComp,-2)>0.00 then begin
    Result:= False;
    cdsCadVdcd_larg.FocusControl;
//    MessageDlg('Largura deve ser no m�ximo igual ao comprimento...',mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80078),mtError,[mbOk],0);
    Exit;
  end;
  // Cr�tica ao raio de concord�ncia
  if          RoundSMR(vEspe-21,-2)<=0.00 then begin
    vRaioMin  := 5;
  end else if RoundSMR(vEspe-37,-2)<=0.00 then begin
    vRaioMin  :=10;
  end else if RoundSMR(vEspe-90,-2)<=0.00 then begin
    vRaioMin  :=15;
  end else begin
    vRaioMin  :=21;
  end;
  if RoundSMR(vRaio-vRaioMin,-2)<0.00 then begin
    Result:= False;
    cdsCadVdcd_raio.FocusControl;
//    MessageDlg(Format('Raio de %s mm inferior ao m�nimo permitido (%s mm)...',[floatToStrF(vRaio,ffFixed,12,2),floatToStrF(vRaioMin,ffFixed,12,2)]),mtError,[mbOk],0);
    MessageDlg(MessageIdio(vgUsuarioIdio, 80079, floatToStrF(vRaio,ffFixed,12,2), floatToStrF(vRaioMin,ffFixed,12,2)),mtError,[mbOk],0);
    Exit;
  end;

  vTempoPrep:=0;
  if vPass='S' then begin
    vTempoExec:= vF140 +(vComp+vLarg)*2*vEspe*vF141/100000;
  end else begin
    vTempoExec:= vF142*(vF140 +(vComp+vLarg)*2*vEspe*vF141/100000);
  end;
  if vTipo='OPPM' then begin
    vTaxa := StrToFloat(vOrcttrVal[vOrcttr.IndexOf('BS607')]); // Taxa hora do centro de custo BS607
    vNomePara := 'ORCTTR';
    vCttr    := 'BS607';
    vPrgt  := 'BS600';
    vPrct  := 'BS607';
  end else begin
    vTaxa := vF039;
    vNomePara := 'ORPARA';
    vCttr     := 'F039';
    vPrgt  := 'BS400';
    vPrct  := 'BS402';
  end;
  if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
    vMemo :='Running cavity';
  end else if (Application.Title='S2RMEX') then begin
    vMemo :='Ejecuci�n de la cavidad';
  end else begin
    vMemo :='Execu��o de Cavidade';
  end;
  // Custo total da remocao
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcFuro(vRosca: String; vDiam, vEspe:Extended; vAcab: String):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa,vVcol:Extended;
  vCttr : String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo de furo
  vProp  := 'CNC';
  vPrgt  := 'BS600';
  vPrct  := 'BS601';
  vUnct :='H';
  vMemo :='';
  Result:= True;
  //Criticas adicionais
  if vRosca='M00' then begin
    if RoundSMR(vDiam-vF152,-2)<0.00 then begin
      Result:= False;
      cdsCadVdce_diam.FocusControl;
//      MessageDlg(Format('Di�metro de %s mm inferior ao m�nimo permitido (%s mm)...',[floatToStrF(vDiam,ffFixed,12,2),floatToStrF(vF152,ffFixed,12,2)]),mtError,[mbOk],0);
      MessageDlg(MessageIdio(vgUsuarioIdio, 80080, floatToStrF(vDiam,ffFixed,12,2), floatToStrF(vF152,ffFixed,12,2)),mtError,[mbOk],0);
      Exit;
    end;
    if RoundSMR(vDiam-vF153,-2)>0.00 then begin
      Result:= False;
      cdsCadVdce_diam.FocusControl;
//      MessageDlg(Format('Di�metro de %s mm superior ao m�ximo permitido (%s mm)...',[floatToStrF(vDiam,ffFixed,12,2),floatToStrF(vF153,ffFixed,12,2)]),mtError,[mbOk],0);
      MessageDlg(MessageIdio(vgUsuarioIdio, 80081, floatToStrF(vDiam,ffFixed,12,2), floatToStrF(vF153,ffFixed,12,2)),mtError,[mbOk],0);
      Exit;
    end;
  end;
  vTempoPrep:=0;
  if vRosca='M00' then begin
    // C�lculo do Volume a ser removido
    vVcol := 3.1416*vDiam*vDiam*vEspe/4;
    // Tempo de execu��o adotado acrescimo p/ material serrado
    vTempoExec  := ((vVcol/vF021)*vF110 +vF111);
    // Redu��o do tempo de Execu��o de
    if vAcab='N' then vTempoExec  := vTempoExec*vF151;
    // Defini��o da Taxa em Fun��o da Diagonal
    vTaxa:=vF039*vF118;     // m�dia
    vCttr := 'F039';
    vPrct  := 'BS601';
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Aditional drilling';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Perforaci�n adicional';
    end else begin
      vMemo :='Fura��o adicional';
    end;
  end else begin
    // Tempo de execu��o dos furos
    if Pos(vRosca,vF051)>0 then
      vTempoExec:=vF053
    else if Pos(vRosca,vF052)>0 then
      vTempoExec:=vF054
    else
      vTempoExec:=0;
    // Defini��o da Taxa em fun��o do peso (Sempre pelo Maior) vPeso>vF061
    vTaxa:= vF038;
    vCttr := 'F038';
    vPrct  := 'BS603';
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Aditional drilling screw';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Perforaci�n adicional (c/ tornillo)';
    end else begin
      vMemo :='Fura��o adicional c/ rosca';
    end;
  end;


  // Custo Total de Furos Adicionais
  // Solicita��o para majorar o valor do furo por 3x -- Kinkel, Marchesine 01/10/2010
  vTempoPrep  := vTempoPrep * 3;
  vTempoExec  := vTempoExec * 3;
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoBlanchard(vQtde,vEspe,vBito,vErem,vArea,vDiag,vPeso:Extended;vActp:String):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa:Extended;
  vDiEs,vEbla,vVbla,vPlacasPorMesada,vQtdMesadas,vAreT,vCoefAcab:Extended;
  vRoundMode: TFPURoundingMode;
  vCttr : String;
//type TFPURoundingMode = (rmNearest, rmDown, rmUp, rmTruncate);
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo Blanchard
  vProp  := 'RPB';
  vPrgt  := 'BS400';
  vPrct  := 'BS406';
  vUnct :='H';
  vMemo :='';

  result:= True;
//  vTempoPrep:=0;
//  vTempoExec:=0;
//  vTaxa:=0;
  vCttr :=  'F037';
  // Valores p/ blanchard
  vEbla:=0; // Espessura a ser removido na blanchard
//  vVbla:=0; // Volume a ser removido na blanchard
  if (vActp='P1') or (vActp='P3') then
//    vEbla := vBito -vEspe -vErem -vF073     //Eliminar ok?
    vEbla := vBito -vEspe -vF073
  else if (vActp='P7') or (vActp='P9') then
    vEbla := vBito -vEspe -vErem;
  if vEbla<vF063 then
    vEbla:=vF063;
  vVbla := vEbla*vArea;

  // Tempo de preparo
  if vPeso>vF061 then
    if vPeso>vF055 then
      vTempoPrep:= vF078+vF079*(vQtde-1) // Preparo Pesado
    else
      vTempoPrep:= vF076+vF077*(vQtde-1) // Preparo Leve
  else
    vTempoPrep:= vF074+vF075*(vQtde-1);  // Preparo Manual

  // Acrescimo para espessura fina (rela�ao diagonal/espessura
  vDiEs := vDiag/vEspe;
//  if vEspe<vF094 then
  if vDiEs>vF094 then
    vTempoPrep := vTempoPrep*vF095;

  // Tempo de Execu��o
  vAreT := vArea*vQtde;
  // Coeficente de acabamento igual para qualquer tamanho de blanchard
  if (vActp='P1') or (vActp='P3') then
    vCoefAcab:=1.000
  else if (vActp='P7') or (vActp='P9') then
    vCoefAcab:=vF093
  else
    vCoefAcab:=0.000;

// alerta : tamanho da m�quina muda e deve mudar a m�quina
  vMemo := '';
  if (vAreT<=vF085) and (vDiag<=vF086) then begin
    // Pequena
    vPrct := 'BS406';
    vTaxa := vF037*vF080;
    vTempoExec:= (vVbla/vF017)*vCoefAcab*vQtde;
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Blanchard grinding small';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Blanchard molienda peque�o';
    end else begin
      vMemo :='Retifica Blanchard pequena';
    end;
  end else if (vAreT<=vF087) and (vDiag<=vF088) then begin
    // M�dia
    vPrct := 'BS402';
    vTaxa := vF037*vF081;
    vTempoExec:= (vVbla/vF018)*vCoefAcab*vQtde;
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Blanchard grinding medium';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Blanchard molienda promedio';
    end else begin
      vMemo :='Retifica Blanchard m�dia';
    end;
  end else begin
    // Grande
    vPrct := 'BS401';
    vTaxa := vF037*vF082;
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Blanchard grinding large';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Blanchard molienda grande';
    end else begin
      vMemo :='Retifica Blanchard grande';
    end;
    if vArea<vF096 then begin
    end;
    if (vAreT<=vF089) and (vDiag<=vF090) then
      vTempoExec:= (vVBla/vF019)*vCoefAcab*vQtde
    else if (vAreT<=vF091) then
      vTempoExec:= (vVBla/vF019)*vF083*vCoefAcab*vQtde
    else
      if vArea>=vF096 then begin
        vTempoExec:= (vVBla/vF019)*vF084*vCoefAcab*vQtde;
      end else begin
        // Define o n�mero de mesadas
        vRoundMode  := GetRoundMode;
        SetRoundMode(rmDown);
        vPlacasPorMesada:= Round(vF096/vArea);
        SetRoundMode(rmUp);
        vQtdMesadas:= Round(vQtde/vPlacasPorMesada);
        SetRoundMode(vRoundMode);
        vTempoExec:= (vVBla/vF019)*vF083*vCoefAcab*vPlacasPorMesada*vQtdMesadas;
      end;
  end;

  // Acrescimo para espessura fina (rela�ao diagonal/espessura
//  if vEspe<vF094 then
  if vDiEs>vF094 then
    vTempoExec := vTempoExec*vF095;
  // Custo Total Blanchard
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoFuraCol(vQtde,vDiag,vEspe,vQtdf:Extended;vDiam,vActp,vMateClass:String):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa,vVcol:Extended;
  vCttr : String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo Fura��o de coluna
  vProp  := 'CNC';
  vPrgt  := 'BS600';
  vPrct  := 'BS607';
  vUnct :='H';
  vMemo :='';
  Result:= True;
//  vTempoPrep:=0;
//  vTempoExec:=0;
//  vTaxa:=0;
  vCttr := 'F039';
  // Recursividades
  if vQtdf>0 then begin
    // C�lculo do Volume a ser removido
    vVcol := 3.1416*strToFloat(vDiam)*strToFloat(vDiam)*vEspe/4;
    // Tempo de preparo varia com a diagonal
    if vDiag>vF002 then
      if vDiag>vF003 then
        if vDiag>vF004 then
            vTempoPrep:= vF116+vF117*(vQtde-1) // extra-grande
        else
          vTempoPrep:= vF116+vF117*(vQtde-1)   // grande
      else
        vTempoPrep:= vF114+vF115*(vQtde-1)     // m�dia
    else
      vTempoPrep:= vF112+vF113*(vQtde-1);      // pequena

    // Tempo de execu��o
    if (vMateClass = 'Serrado') then
      // Acr�scimo na execu��o se material Serrado
      vTempoExec  := ((vVcol/vF021)*vF110 +vF111)*vQtde*vQtdf
    else
      vTempoExec  := ((vVcol/vF021)       +vF111)*vQtde*vQtdf;

    // Defini��o da Taxa em Fun��o da Diagonal
// alerta : tamanho da m�quina muda e deve mudar a m�quina
    if vDiag>vF002 then
      if vDiag>vF003 then
        if vDiag>vF004 then
            vTaxa:=vF039*vF119A // extra-grande
        else
          vTaxa:=vF039*vF119   // grande
      else
        vTaxa:=vF039*vF118     // m�dia
    else
      vTaxa:=vF039; // pequena

    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Drilling for columns';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Perforaci�n para las columnas';
    end else begin
      vMemo :='Fura��o de colunas';
    end;
  end else begin
    vTempoPrep:=0;
    vTempoExec:=0;
    vTaxa:=0;
  end;
  // Custo Total da Fura��o das Colunas
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoFresaLat(vQtde,vComp,vLarg,vEspe,vDiag,vPeri:Extended;vActp:String):Boolean;
var
  vTempoExec,vTempoPrep,vTaxa,vVfre:Extended;
  vQtdPacotes, vPlacasPorPacote: Extended;
  vRoundMode: TFPURoundingMode;
  vCttr : String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo Fresa Lateral
  vProp  := 'FR';
  vPrgt  := 'BS500';
  vPrct  := 'BS505';
  vUnct :='H';
  vMemo :='';

  Result:= True;
  vTempoPrep:=0;
  vTempoExec:=0;
  vTaxa:=vF038;
  // ??? d�vida
  vCttr := 'F039';
  if ((vActp='P3') or (vActp='P9')) then begin
    // Volume a ser removido
    vVfre:= vPeri*vEspe*vF001A/2;
    // C�culo do pacote
    if vEspe>vF097 then begin
      vQtdPacotes:= vQtde;
    end else begin
      if vQtde*vEspe>vF097 then begin
        // Define o n�mero de pacotes
        vRoundMode  := GetRoundMode;
        SetRoundMode(rmDown);
        vPlacasPorPacote:= Round(vF097/vEspe);
        SetRoundMode(rmUp);
        vQtdPacotes:= Round(vQtde/vPlacasPorPacote);
        SetRoundMode(vRoundMode);
      end else begin
        vQtdPacotes:= 1;
      end;
    end;

    // Tempo de preparo varia com a diagonal
    if vDiag>vF002 then
      if vDiag>vF003 then
        if vDiag>vF004 then
            vTempoPrep:= vF104+vF105*(vQtde-1) + vF106*(vQtdPacotes-1) // extra-grande
        else
          vTempoPrep:= vF104+vF105*(vQtde-1) + vF106*(vQtdPacotes-1)   // grande
      else
        vTempoPrep:= vF101+vF102*(vQtde-1) + vF103*(vQtdPacotes-1)     // m�dia
    else
      vTempoPrep:= vF098+vF099*(vQtde-1) + vF100*(vQtdPacotes-1);      // pequena

    // Majora tempo de preparo com fator se comprimento ou largura grandes
    if vComp>vF107 then
      if vLarg>vF107 then
        vTempoPrep  := vTempoPrep*vF109
      else
        vTempoPrep  := vTempoPrep*vF108;

    // Tempo de execu��o
    vTempoExec  := (vVfre/vF020)*vQtde;

    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Side cutter';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Fresa lateral';
    end else begin
      vMemo :='Fresa lateral';
    end;
  end;
  // Custo Total Fresa Lateral
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoChanfro(vQtde,vEspe,vPeri,vPeso:Extended;vAcch:String):Boolean;
var
  vTempoPrep,vTempoExec,vTaxa:Extended;
  vCttr : string;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo Chanfro
  vProp  := 'FR';
  vPrgt  := 'BS500';
  vPrct  := 'BS505';
  vUnct :='H';
  vmemo :='';

  result:= True;
  vTempoPrep:=0;
  vTempoExec:=0;
  vTaxa:=0;
  vCttr := 'F040';
  if vAcch='S' then begin
    // Tempo do chanfro em fun��o do peso
    if vPeso>vF061 then begin
      vTempoExec:= ((2*vPeri +4*vEspe)*vF030A/1000 +vF030B)*vQtde
    end else begin
      vTempoExec:= ((2*vPeri +4*vEspe)*vF030/1000)*vQtde;
    end;
    // Tempo m�nimo de execu��o
    if vTempoExec<vF030C then
      vTempoExec:=vF030C;
    vTaxa:= vF040;
    if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
      vMemo :='Bevel side';
    end else if (Application.Title='S2RMEX') then begin
      vMemo :='Bisel lateral';
    end else begin
      vMemo :='Chanfro lateral';
    end;
  end;
  // Custo total do chanframento
  if (vTempoPrep+vTempoExec)*vTaxa>0 then begin
    // Insere tamb�m em VDCR



function TfrmVdaCotIte.fCalcCustoMonta(vTipo:String;vQtde,vEspe,vQtdf,vPeri:Extended;vDiam,vActp,vAcch:String):Boolean;
var
  vTempoRebarbCont,vTempoRebarbFuro,vTempoMonta,vTempoPinta,vTaxa:Extended;
//  vDes: String;
  vCttr : String;
  vProp, vPrgt, vPrct, vUnct, vMemo: String;
begin
  // Custo
  vProp  := 'MT';
  vPrgt  := 'BS800';
  vPrct  := 'BS800';
  vUnct :='H';
  vMemo :='';

  Result:= True;
  vTaxa := vF040;
  vCttr := 'F040';
  // Tempo p/ Rebarbar contornos
//  if (vDtox='N') then
// Correcao : chanfro lateral Nao rebarba contornos
  if (vAcch='N') then
    if vPeso<=vF061 then
      vTempoRebarbCont  := (2*vPeri+4*vEspe)*(vF031/1000)*vQtde
    else
      vTempoRebarbCont  := ((2*vPeri+4*vEspe)*vF031/1000+vF032)*vQtde
  else
    vTempoRebarbCont  :=0;

  // Tempo p/ Rebarbar Furos
  if (vTipo='OSBA') then
    if strToFloat(vDiam)>=vF035A then
      vTempoRebarbFuro  := vQtdf*vQtde*vF035
    else
      vTempoRebarbFuro  := vQtdf*vQtde*vF034
  else
    vTempoRebarbFuro  :=0;

  // Tempo p/ Furar Montar e Roscar
  if vTipo='OSBA' then
    if vPeso>=vF061 then
      vTempoMonta := vQtde*vF121
    else
      vTempoMonta := vQtde*vF120
  else
    vTempoMonta  :=0;

  // Tempo p/ Pintar
  if (vActp='P1') or (vActp='P7') then
     vTempoPinta  := vPeri*vEspe*vQtde*vF033/1000000
  else
    vTempoPinta  :=0;

  vMemo  := '';
  if (Application.Title='S2RIND') or (Application.Title='S2RUSA') then begin
    if vTempoRebarbCont>0 then
      vMemo := vMemo +'Deb.Contour, ';
    if vTempoRebarbFuro>0 then
      vMemo := vMemo +'Deb.Holes, ';
    if vTempoMonta>0 then
      vMemo := vMemo +'Mounting, ';
    if vTempoPinta>0 then
      vMemo := vMemo +'Painting.';
  end else if (Application.Title='S2RMEX') then begin
    if vTempoRebarbCont>0 then
      vMemo := vMemo +'Des.Contorno, ';
    if vTempoRebarbFuro>0 then
      vMemo := vMemo +'Des.Agujeros, ';
    if vTempoMonta>0 then
      vMemo := vMemo +'Montaje, ';
    if vTempoPinta>0 then
      vMemo := vMemo +'Pintura.';
  end else begin
    if vTempoRebarbCont>0 then
      vMemo := vMemo +'Reb.Contorno, ';
    if vTempoRebarbFuro>0 then
      vMemo := vMemo +'Reb.Furos, ';
    if vTempoMonta>0 then
      vMemo := vMemo +'Montagem, ';
    if vTempoPinta>0 then
      vMemo := vMemo +'Pintura.';
  end;

  // Custo Total da Montagem
  if (vTempoRebarbCont+vTempoRebarbFuro+vTempoMonta+vTempoPinta)*vTaxa>0 then begin
    // Insere tamb�m em VDCR




