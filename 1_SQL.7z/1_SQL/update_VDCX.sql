select mtpc_pre, VDCX_PUN_VAL = 65*mtpc_pre/100, 100-35, VDCX_PUN_PCT, *
--update VDCX set VDCX_PUN_PCT = 65, VDCX_PUN_MOD = 'N', VDCX_PUN_VAL = 65*mtpc_pre/100,  VDCX_USU = 'KINKEL',	VDCX_DTU = GETDATE()
from vdcx, mtpc
where vdcx_vdcv in (85, 10, 50)
and vdcx_mtpc like '9-%'
and mtpc_cod = vdcx_mtpc



