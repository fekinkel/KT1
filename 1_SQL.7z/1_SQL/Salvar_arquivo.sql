set @STR_EXEC = 'master..xp_cmdshell '+char(39)+'bcp "select * from ##path " queryout "'+@str_Caminho_Local+'\Criar_Pastas.bat'+'" -c -U sa -P mdl1680'+CHAR(39)
print 'Criar_Pastas '+@STR_EXEC
exec(@STR_EXEC) 