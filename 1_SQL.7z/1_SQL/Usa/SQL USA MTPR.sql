use [MDL-USA]

IF OBJECT_ID('TempDB.dbo.##MTPR_ANT') IS NOT NULL DROP TABLE ##MTPR_ANT
SELECT distinct * INTO ##MTPR_ANT FROM MTPR WHERE 1 = 0
INSERT INTO ##MTPR_ANT
SELECT 
	  MTPR_COD = MTPR_COD-- CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = MTPR_MTTP --'PA-PRODUCTO ACABADO' -- CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = MTPR_MS -- CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = 'N' -- CONVERT(char(1),'')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, MTPR_NOM = substring(MTPR_NOM, 0,80) -- CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = MTPR_MTDV -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = MTPR_MTLN -- CONVERT(varchar(4),'')      --CONVx'ERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = MTPR_MTFM  -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = MTPR_MTUN -- CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = MTPR_MTNC -- CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = MTPR_ORI -- CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = MTPR_PES -- CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = MTPR_DES -- Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = MTPR_NIV -- Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = MTPR_ESUN -- Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = MTPR_ESFT --  Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = MTPR_CPUN -- Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = MTPR_CPFT -- Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = MTPR_ATVV -- CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = MTPR_CFOV -- Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = MTPR_ATVC -- CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = MTPR_CFOC -- Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = MTPR_TOLE -- CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST = MTPR_FEST
	, MTPR_USC = 'MARCIOSS' -- CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = GETDATE() -- CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = MTPR_USU -- Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = MTPR_DTU -- Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	FROM 
		MTPR
	WHERE MTPR_MTUN = 'BG'
--	AND MTPR_MTTP = 'PA/COMP' 


IF OBJECT_ID('TempDB.dbo.##MTPR') IS NOT NULL DROP TABLE ##MTPR
SELECT distinct * INTO ##MTPR FROM MTPR WHERE 1 = 0
INSERT INTO ##MTPR
SELECT 
	  MTPR_COD = MTPR_COD + 'B'-- CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = 'PA/COMP'  --'PA-PRODUCTO ACABADO' -- CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = MTPR_MS -- CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = 'N' -- CONVERT(char(1),'')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, MTPR_NOM = substring(MTPR_NOM, 0,80)  -- CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = MTPR_MTDV -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = MTPR_MTLN -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = MTPR_MTFM  -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = MTPR_MTUN -- CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = MTPR_MTNC -- CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = MTPR_ORI -- CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = MTPR_PES -- CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = MTPR_DES -- Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = MTPR_NIV -- Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = MTPR_ESUN -- Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = MTPR_ESFT --  Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = MTPR_CPUN -- Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = MTPR_CPFT -- Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = MTPR_ATVV -- CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = MTPR_CFOV -- Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = MTPR_ATVC -- CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = MTPR_CFOC -- Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = MTPR_TOLE -- CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST = MTPR_FEST --Null      --CONVERT(varchar(7),'') CEST(C�digo Especificador da Substitui��o Tribut�ria (CEST) - Confaz Conv�nio ICMS N� 92/2015)
	, MTPR_USC = 'MARCIOSS' -- CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = GETDATE() -- CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU = MTPR_USU -- Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU = MTPR_DTU -- Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	FROM 
		MTPR
	WHERE MTPR_MTUN = 'BG'
	--AND MTPR_MTTP = 'PI/FABR' 



IF OBJECT_ID('TempDB.dbo.##MTES') IS NOT NULL DROP TABLE ##MTES
SELECT distinct * INTO ##MTES FROM MTES WHERE 1 = 0
INSERT INTO ##MTES
SELECT 
	  MTES_MTPR = MTES_MTPR + 'B'--CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTES_SIES = MTES_SIES      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTES_MTAL = MTES_MTAL      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, MTES_MTAN = MTES_MTAN      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, MTES_MTAP = MTES_MTAP      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, MTES_LOTE = MTES_LOTE      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, MTES_GLMD = MTES_GLMD      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, MTES_QATU = MTES_QATU      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, MTES_VATU = MTES_VATU      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, MTES_VATM = MTES_VATM      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, MTES_QVIS = MTES_QVIS      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, MTES_QNEC = MTES_QNEC      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, MTES_QPRO = MTES_QPRO      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, MTES_PCME = MTES_PCME      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, MTES_PCMR = MTES_PCMR      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, MTES_PMIN = MTES_PMIN      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, MTES_POBJ = MTES_POBJ      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, MTES_POEM = MTES_POEM      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, MTES_PPMI = MTES_PPMI      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, MTES_PLEM = MTES_PLEM      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, MTES_PMUL = MTES_PMUL      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, MTES_PLEC = MTES_PLEC      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, MTES_UCDO = MTES_UCDO      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, MTES_LEAD = MTES_LEAD      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, MTES_LEEM = MTES_LEEM      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, MTES_EXPL = MTES_EXPL      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, MTES_MRP  = MTES_MRP       --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, MTES_CREP = MTES_CREP      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, MTES_CPDR = MTES_CPDR      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, MTES_FGGF = MTES_FGGF      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, MTES_FRAT = MTES_FRAT      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, MTES_CTGT = MTES_CTGT      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, MTES_CPO1 = MTES_CPO1      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, MTES_CPO2 = MTES_CPO2      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, MTES_CPO3 = MTES_CPO3      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, MTES_CPO4 = MTES_CPO4      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, MTES_PRAT = MTES_PRAT      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, MTES_USC  = 'MARCIOSS'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTES_DTC  = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTES_USU  = NULL      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTES_DTU  = NULL      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM 
	MTES 
INNER JOIN ##MTPR ON SUBSTRING(MTPR_COD, 1, LEN(MTPR_COD) - 1) = MTES_MTPR

------------------------------------------------------------------------------------------------------------------------
--CRIANDO A TABELA TEMPORARIA MTES COM OS DADOS GERADOS NA MTPR
------------------------------------------------------------------------------------------------------------------------

IF OBJECT_ID('TempDB.dbo.##MTPC') IS NOT NULL DROP TABLE ##MTPC
SELECT distinct * INTO ##MTPC FROM MTPC WHERE 1 = 0
--SELECT * FROM ##MTPC
INSERT INTO ##MTPC
SELECT 
	  MTPC_COD		 = MTPC_COD	+ 'B'	 --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, MTPC_MTPR		 = MTPC_MTPR + 'B'	 --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTPC_NOM		 = MTPC_NOM		 --CONVERT(varchar(80),'') Nome(Nome do produto comercial)
	, MTPC_GLMD		 = MTPC_GLMD	 --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, MTPC_PRE		 = MTPC_PRE		 --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, MTPC_PRE_USU	 = MTPC_PRE_USU  --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_PRE_DTU	 = MTPC_PRE_DTU  --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do pre�o do registro)
	, MTPC_PREC		 = MTPC_PREC     --CONVERT(decimal(12),'') Pre�o C(Valor unit�rio do pre�o de venda do principal concorrente)
	, MTPC_USC		 = 'MARCIOSS'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPC_DTC		 = GETDATE()     --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPC_USU		 = MTPC_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_DTU		 = MTPC_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM 
	MTPC 
INNER JOIN  ##MTPR ON MTPR_COD= MTPC_COD + 'B'
	
------------------------------------------------------------------------------------------------------------------------
--INSERINDO AS TABELA TEMPORARIA DE MTPR NA MTPR DO BANCO [192.168.2.39]
------------------------------------------------------------------------------------------------------------------------
	
IF OBJECT_ID('TempDB.dbo.##FTIT') IS NOT NULL DROP TABLE ##FTIT
SELECT * INTO ##FTIT FROM FTIT WHERE 1 = 0
INSERT INTO ##FTIT
SELECT 
	 FTIT_SIES = FTIT_SIES      --CONVERT(int(6),'') E(C�digo do estabelecimento)
	, FTIT_SIDO = FTIT_SIDO      --CONVERT(varchar(4),'') Tipo(Tipo do documento interno)
	, FTIT_SISE = FTIT_SISE      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, FTIT_FTNF = FTIT_FTNF      --CONVERT(int(6),'') N� Doc.(N�mero do documento)
	, FTIT_COD = FTIT_COD      --CONVERT(int(3),'') Item(Item do documento)
	, FTIT_CODF = FTIT_CODF      --CONVERT(int(3),'') Item(Item do documento de devolu��o)
	, FTIT_SIDP = FTIT_SIDP      --CONVERT(varchar(4),'') Tipo(Tipo do documento)
	, FTIT_SISP = FTIT_SISP      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, FTIT_CODP = FTIT_CODP      --CONVERT(int(6),'') Pedido(N�mero do pedido)
	, FTIT_CODI = FTIT_CODI      --CONVERT(int(3),'') It.Ped.(Item do pedido de venda)
	, FTIT_MTPC = FTIT_MTPC + 'B'      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, FTIT_NOM = FTIT_NOM      --CONVERT(varchar(255),'') Descri��o(Descri��o do item da nota)
	, FTIT_MTPR = FTIT_MTPR + 'B'      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, FTIT_MS = FTIT_MS      --CONVERT(varchar(2),'') M/S(Mercadoria ou Servi�o)
	, FTIT_MTUN = FTIT_MTUN      --CONVERT(varchar(3),'') Unidade(Unidade do produto)
	, FTIT_MTNC = FTIT_MTNC      --CONVERT(varchar(8),'') NCM(C�digo de NCM do produto)
	, FTIT_ORI = FTIT_ORI      --CONVERT(char(1),'') Origem(Origem do produto)
	, FTIT_MTDV = FTIT_MTDV      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, FTIT_MTLN = FTIT_MTLN      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, FTIT_MTFM = FTIT_MTFM      --CONVERT(varchar(4),'') Fam�lia(C�digo da fam�lia do produto)
	, FTIT_PLIQ = FTIT_PLIQ      --CONVERT(decimal(12),'') Peso L�q.(Peso l�quido)
	, FTIT_PLQT = FTIT_PLQT      --CONVERT(decimal(13),'') Peso Tot.(Peso liquido total em Kg)
	, FTIT_PBRT = FTIT_PBRT      --CONVERT(decimal(13),'') Peso Bruto(Peso bruto total em Kg)
	, FTIT_COMPO = FTIT_COMPO      --CONVERT(char(1),'') Composto(Indica se produto � composto, ou seja, possui estrutura)
	, FTIT_EST = FTIT_EST      --CONVERT(char(1),'') Estoque(Indica se estoque controlado (S ou N))
	, FTIT_VDCV = FTIT_VDCV      --CONVERT(int(6),'') Contrato(C�digo do contrato de venda)
	, FTIT_DENT = FTIT_DENT      --CONVERT(datetime(10),'') Entrega(Data de entrega)
	, FTIT_MTTR = FTIT_MTTR      --CONVERT(varchar(6),'') Transa��o(C�digo da transa��o)
	, FTIT_STA = FTIT_STA      --CONVERT(int(3),'') Reserva(Reserva de estoque (0 : Sucesso, 1: Insucesso))
	, FTIT_CTPC = FTIT_CTPC      --CONVERT(varchar(15),'') Cont�bil(C�digo da conta cont�bil)
	, FTIT_RDPC = FTIT_RDPC      --CONVERT(varchar(7),'') Rdz.(C�digo reduzido da conta cont�bil)
	, FTIT_CTCC = FTIT_CTCC      --CONVERT(varchar(15),'') C.C.(C�digo do centro de lucro/custo)
	, FTIT_RDCC = FTIT_RDCC      --CONVERT(varchar(7),'') Rdz.(C�digo reduzido do centro de lucro/custo)
	, FTIT_QTD = FTIT_QTD      --CONVERT(decimal(12),'') Quantidade(Quantidade faturada)
	, FTIT_PUN = FTIT_PUN      --CONVERT(decimal(12),'') Valor Unit�rio(Valor unit�rio do produto/servi�o)
	, FTIT_PUND = FTIT_PUND      --CONVERT(decimal(12),'') Pre�o c/ Desc.(Valor unit�rio do produto comercial com desconto expresso na moeda do pedido)
	, FTIT_DESC = FTIT_DESC      --CONVERT(decimal(9),'') Desconto %(Desconto concedido em percentual)
	, FTIT_VAL = FTIT_VAL      --CONVERT(decimal(12),'') Valor do Item(Valor total do produto/servi�o)
	, FTIT_REV = FTIT_REV      --CONVERT(char(1),'') Destina��o(Define se item � para consumo (N) , revenda (S), revenda equiparada (E) ou industrializacao (I))
	, FTIT_NFOP = FTIT_NFOP     --CONVERT(varchar(8),'') Oper.(C�digo da opera��o fiscal)
	, FTIT_CFOP = FTIT_CFOP      --CONVERT(varchar(6),'') CFOP(C�digo fiscal de opera��o e presta��o de servi�os)
	, FTIT_TIT = FTIT_TIT      --CONVERT(char(1),'') Gera t�tulos(Se opera��o gera t�tulos (S=Sim ou N=N�o))
	, FTIT_TBB = FTIT_TBB      --CONVERT(varchar(2),'') Tabela B(C�digo da Tabela B)
	, FTIT_MEN = FTIT_MEN      --CONVERT(varchar(255),'') Mensagem(Mensagem da opera��o)
	, FTIT_IPI_BAS = FTIT_IPI_BAS      --CONVERT(decimal(12),'') Base IPI(Base de c�lculo de IPI)
	, FTIT_IPI_ALI = FTIT_IPI_ALI      --CONVERT(decimal(5),'') % IPI(Al�quota de IPI)
	, FTIT_IPI_VAL = FTIT_IPI_VAL      --CONVERT(decimal(12),'') Valor IPI(Valor do IPI)
	, FTIT_IPI_ISE = FTIT_IPI_ISE      --CONVERT(decimal(12),'') IPI Isento(Valor isento de IPI)
	, FTIT_IPI_OUT = FTIT_IPI_OUT      --CONVERT(decimal(12),'') IPI Outros(Outros valores de IPI)
	, FTIT_ISS_BAS = FTIT_ISS_BAS      --CONVERT(decimal(12),'') Base de ISS(Base de c�lculo de ISS)
	, FTIT_ISS_ALI = FTIT_ISS_ALI      --CONVERT(decimal(5),'') % ISS(Al�quota de ISS)
	, FTIT_ISS_VAL = FTIT_ISS_VAL      --CONVERT(decimal(12),'') Valor do ISS(Valor do ISS)
	, FTIT_ISS_ISE = FTIT_ISS_ISE      --CONVERT(decimal(12),'') ISS Isento(Valor isento de ISS)
	, FTIT_ISS_OUT = FTIT_ISS_OUT      --CONVERT(decimal(12),'') ISS Isento(Valor isento de ISS)
	, FTIT_ICM_BAS = FTIT_ICM_BAS      --CONVERT(decimal(12),'') Base ICMS(Base de c�lculo de ICMS)
	, FTIT_ICM_ALI = FTIT_ICM_ALI      --CONVERT(decimal(5),'') % ICMS(Al�quota de ICMS)
	, FTIT_ICM_VAL = FTIT_ICM_VAL      --CONVERT(decimal(12),'') Valor do ICMS(Valor do ICMS)
	, FTIT_ICM_ISE = FTIT_ICM_ISE      --CONVERT(decimal(12),'') ICMS Isento(Valor isento de ICMS)
	, FTIT_ICM_OUT = FTIT_ICM_OUT      --CONVERT(decimal(12),'') ICMS Outros(Outros valores de ICMS)
	, FTIT_IST_BAS = FTIT_IST_BAS      --CONVERT(decimal(12),'') Base ICMS - ST(Base de c�lculo de ICMS por Substitui��o Tribut�ria)
	, FTIT_IST_ALI = FTIT_IST_ALI      --CONVERT(decimal(5),'') % ICMS - ST(Al�quota de ICMS por Substitui��o Tribut�ria)
	, FTIT_IST_VAL = FTIT_IST_VAL      --CONVERT(decimal(12),'') Valor do ICMS - ST(Valor do ICMS por Substitui��o Tribut�ria)
	, FTIT_IST_ISE = FTIT_IST_ISE      --CONVERT(decimal(12),'') ICMS Isento - ST(Valor isento de ICMS por Substitui��o Tribut�ria)
	, FTIT_IST_OUT = FTIT_IST_OUT      --CONVERT(decimal(12),'') ICMS Outros - ST(Outros valores de ICMS por Substitui��o Tribut�ria)
	, FTIT_IST_IVA = FTIT_IST_IVA      --CONVERT(decimal(12),'') ST- IVA %(�ndice de valor agregado setorial por Substitui��o Tribut�ria)
	, FTIT_ICP_ALI = FTIT_ICP_ALI      --CONVERT(decimal(6),'') %ICMS Complem.(Define o percentual de incid�ncia do ICMS Complementar nas vendas destinas ao estado (uso pr�prio))
	, FTIT_ICP_VAL = FTIT_ICP_VAL      --CONVERT(decimal(12),'') Valor ICMS Complem.(Valor do ICMS Complementar nas vendas destinas ao estado (uso pr�prio))
	, FTIT_VAL_FRE = FTIT_VAL_FRE      --CONVERT(decimal(12),'') Frete(Valor do frete (rateio por peso))
	, FTIT_VAL_SEG = FTIT_VAL_SEG      --CONVERT(decimal(12),'') Seguro(Valor do seguro (rateio por valor))
	, FTIT_VAL_ACE = FTIT_VAL_ACE      --CONVERT(decimal(12),'') Desp. Aces.(Valor das despesas acess�rias (rateio por valor))
	, FTIT_VAL_DES = FTIT_VAL_DES      --CONVERT(decimal(12),'') Desconto(Valor do desconto do produto/servi�o)
	, FTIT_IMP_ALI = FTIT_IMP_ALI      --CONVERT(decimal(5),'') % II(Al�quota de Imposto de Importa��o (associada ao NCM))
	, FTIT_IMP_ADU = FTIT_IMP_ADU      --CONVERT(decimal(12),'') Valor Aduaneiro(Valor aduaneiro, normalmente valor do item sem imposto de importa��o (v�lido p/ importa��es))
	, FTIT_IMP_DAD = FTIT_IMP_DAD      --CONVERT(decimal(12),'') Desp. Aduaneiras(Despesas aduaneiras, normalmente rateio das despesas aduaneiras (v�lido p/ importa��es))
	, FTIT_VAL_PIS = FTIT_VAL_PIS      --CONVERT(decimal(12),'') Valor do PIS(Valor do PIS)
	, FTIT_VAL_COF = FTIT_VAL_COF      --CONVERT(decimal(12),'') Valor da COFINS(Valor da COFINS)
	, FTIT_MTTP_SPED = FTIT_MTTP_SPED      --CONVERT(varchar(2),'') Tipo SPED(Tipo de produto de acordo com tabela para o SPED)
	, FTIT_USC = FTIT_USC      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, FTIT_DTC = FTIT_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, FTIT_USU = FTIT_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, FTIT_DTU = FTIT_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM FTIT
INNER JOIN ##MTPR ON MTPR_COD = FTIT_MTPR + 'B'
	

IF OBJECT_ID('TempDB.dbo.##VDPI') IS NOT NULL DROP TABLE ##VDPI
SELECT * INTO ##VDPI FROM VDPI WHERE 1 = 0
INSERT INTO ##VDPI
SELECT 
	  VDPI_SIES =  VDPI_SIES      --CONVERT(int(6),'') E(C�digo do estabelecimento)
	, VDPI_SIDO = VDPI_SIDO      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, VDPI_SISE = VDPI_SISE      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, VDPI_VDPD = VDPI_VDPD      --CONVERT(int(6),'') Pedido(N�mero do pedido)
	, VDPI_COD = VDPI_COD      --CONVERT(int(3),'') Item(Item do pedido de venda)
	, VDPI_STA = VDPI_STA      --CONVERT(char(2),'') Status(Situa��o do item pedido (EA, OK, EC) define valida��es)
	, VDPI_MTPC = VDPI_MTPC + 'B'      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, VDPI_NOM = VDPI_NOM      --CONVERT(varchar(255),'') Descri��o(Descri��o do produto comercial)
	, VDPI_MTPR = VDPI_MTPR + 'B'      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, VDPI_MS = VDPI_MS      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, VDPI_MTUN = VDPI_MTUN      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, VDPI_MTNC = VDPI_MTNC      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, VDPI_ORI = VDPI_ORI      --CONVERT(char(1),'') Origem(Origem do produto)
	, VDPI_MTDV = VDPI_MTDV      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, VDPI_MTLN = VDPI_MTLN      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, VDPI_MTFM = VDPI_MTFM      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, VDPI_PLIQ = VDPI_PLIQ      --CONVERT(decimal(13),'') Peso L�q.(Peso liquido unit�rio em Kg)
	, VDPI_PLQT = VDPI_PLQT      --CONVERT(decimal(13),'') Peso Tot.(Peso liquido total em Kg)
	, VDPI_PBRT = VDPI_PBRT      --CONVERT(decimal(13),'') Peso Bruto(Peso bruto total em Kg)
	, VDPI_COMPO = VDPI_COMPO      --CONVERT(char(1),'') Composto(Indica se produto � composto, ou seja, possui estrutura)
	, VDPI_EST = VDPI_EST      --CONVERT(char(1),'') Estoque(Indica se estoque controlado (S ou N))
	, VDPI_QTD = VDPI_QTD      --CONVERT(decimal(12),'') Quantidade(Quantidade total do item do pedido)
	, VDPI_QOR = VDPI_QOR      --CONVERT(decimal(12),'') Qtde em OF(Quantidade em OF do item do pedido)
	, VDPI_QNF = VDPI_QNF      --CONVERT(decimal(12),'') Qtde Faturada(Quantidade faturada do item do pedido)
	, VDPI_PUN = VDPI_PUN      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial expresso na moeda do pedido)
	, VDPI_PUND = VDPI_PUND      --CONVERT(decimal(12),'') Pre�o c/ Desc.(Valor unit�rio do produto comercial com desconto expresso na moeda do pedido)
	, VDPI_DESC = VDPI_DESC      --CONVERT(decimal(9),'') Desconto %(Desconto concedido em percentual)
	, VDPI_VAL = VDPI_VAL      --CONVERT(decimal(12),'') Total(Valor total do item c/ desconto s/ IPI)
	, VDPI_PENT = VDPI_PENT      --CONVERT(int(3),'') Entrega (dias)(Prazo de entrega em dias)
	, VDPI_DENT = VDPI_DENT      --CONVERT(datetime(10),'') Entrega(Data de entrega)
	, VDPI_OBS = VDPI_OBS      --CONVERT(varchar(4000),'') Obs.(Observa��o do item)
	, VDPI_REV = VDPI_REV      --CONVERT(char(1),'') Destina��o(Define a destina��o que ser� dada ao produto)
	, VDPI_NFOP = VDPI_NFOP      --CONVERT(varchar(8),'') Oper.(C�digo da opera��o fiscal)
	, VDPI_CFOP = VDPI_CFOP      --CONVERT(varchar(6),'') CFOP(C�digo fiscal de opera��o e presta��o de servi�os)
	, VDPI_TIT = VDPI_TIT      --CONVERT(char(1),'') Gera t�tulos(Se opera��o gera t�tulos (S=Sim ou N=N�o))
	, VDPI_MEN = VDPI_MEN      --CONVERT(varchar(255),'') Mensagem(Mensagem da opera��o)
	, VDPI_VAL_FRE = VDPI_VAL_FRE      --CONVERT(decimal(12),'') Frete(Valor do frete)
	, VDPI_VAL_SEG = VDPI_VAL_SEG      --CONVERT(decimal(12),'') Seguro(Valor do seguro)
	, VDPI_VAL_ACE = VDPI_VAL_ACE      --CONVERT(decimal(12),'') Desp. Acess�rias(Valor das despesas acess�rias)
	, VDPI_VAL_DES = VDPI_VAL_DES      --CONVERT(decimal(12),'') Descontos(Valor dos descontos)
	, VDPI_IPI_BAS = VDPI_IPI_BAS      --CONVERT(decimal(12),'') Base IPI(Base de c�lculo de IPI)
	, VDPI_IPI_ALI = VDPI_IPI_ALI      --CONVERT(decimal(5),'') % IPI(Al�quota de IPI)
	, VDPI_IPI_VAL = VDPI_IPI_VAL      --CONVERT(decimal(12),'') Valor IPI(Valor do IPI)
	, VDPI_IPI_ISE = VDPI_IPI_ISE      --CONVERT(decimal(12),'') IPI Isento(Valor isento de IPI)
	, VDPI_IPI_OUT = VDPI_IPI_OUT      --CONVERT(decimal(12),'') IPI Outros(Outros valores de IPI)
	, VDPI_ISS_BAS = VDPI_ISS_BAS      --CONVERT(decimal(12),'') Base de ISS(Base de c�lculo de ISS)
	, VDPI_ISS_ALI = VDPI_ISS_ALI      --CONVERT(decimal(5),'') % ISS(Al�quota de ISS)
	, VDPI_ISS_VAL = VDPI_ISS_VAL      --CONVERT(decimal(12),'') Valor do ISS(Valor do ISS)
	, VDPI_ISS_ISE = VDPI_ISS_ISE      --CONVERT(decimal(12),'') ISS Isento(Valor isento de ISS)
	, VDPI_ISS_OUT = VDPI_ISS_OUT      --CONVERT(decimal(12),'') ISS Outros(Outros valores de ISS)
	, VDPI_ICM_BAS = VDPI_ICM_BAS      --CONVERT(decimal(12),'') Base ICMS(Base de c�lculo de ICMS)
	, VDPI_ICM_ALI = VDPI_ICM_ALI      --CONVERT(decimal(5),'') % ICMS(Al�quota de ICMS)
	, VDPI_ICM_VAL = VDPI_ICM_VAL      --CONVERT(decimal(12),'') Valor do ICMS(Valor do ICMS)
	, VDPI_ICM_ISE = VDPI_ICM_ISE      --CONVERT(decimal(12),'') ICMS Isento(Valor isento de ICMS)
	, VDPI_ICM_OUT = VDPI_ICM_OUT      --CONVERT(decimal(12),'') ICMS Outros(Outros valores de ICMS)
	, VDPI_IST_BAS = VDPI_IST_BAS      --CONVERT(decimal(12),'') Base ICMS - ST(Base de c�lculo de ICMS por Substitui��o Tribut�ria)
	, VDPI_IST_ALI = VDPI_IST_ALI      --CONVERT(decimal(5),'') % ICMS - ST(Al�quota de ICMS por Substitui��o Tribut�ria)
	, VDPI_IST_VAL = VDPI_IST_VAL      --CONVERT(decimal(12),'') Valor do ICMS - ST(Valor do ICMS por Substitui��o Tribut�ria)
	, VDPI_IST_ISE = VDPI_IST_ISE      --CONVERT(decimal(12),'') ICMS Isento - ST(Valor isento de ICMS por Substitui��o Tribut�ria)
	, VDPI_IST_OUT = VDPI_IST_OUT      --CONVERT(decimal(12),'') ICMS Outros - ST(Outros valores de ICMS por Substitui��o Tribut�ria)
	, VDPI_IST_IVA = VDPI_IST_IVA      --CONVERT(decimal(12),'') ST- IVA %(�ndice de valor agregado setorial por Substitui��o Tribut�ria)
	, VDPI_ICP_ALI = VDPI_ICP_ALI      --CONVERT(decimal(6),'') %ICMS Complem.(Define o percentual de incid�ncia do ICMS Complementar nas vendas destinas ao estado (uso pr�prio))
	, VDPI_ICP_VAL = VDPI_ICP_VAL      --CONVERT(decimal(12),'') Valor ICMS Complem.(Valor do ICMS Complementar nas vendas destinas ao estado (uso pr�prio))
	, VDPI_MTTR = VDPI_MTTR      --CONVERT(varchar(6),'') Transa��o(C�digo da transa��o)
	, VDPI_CTPC = VDPI_CTPC      --CONVERT(varchar(15),'') Cont�bil(C�digo da conta cont�bil)
	, VDPI_RDPC = VDPI_RDPC      --CONVERT(varchar(7),'') Rdz.(C�digo reduzido da conta cont�bil)
	, VDPI_CTCC = VDPI_CTCC      --CONVERT(varchar(15),'') C.C.(C�digo do centro de lucro/custo)
	, VDPI_RDCC = VDPI_RDCC      --CONVERT(varchar(7),'') Rdz.(C�digo reduzido do centro de lucro/custo)
	, VDPI_VDCV = VDPI_VDCV      --CONVERT(int(6),'') Contrato(C�digo do contrato de venda)
	, VDPI_USC = VDPI_USC      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, VDPI_DTC = VDPI_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, VDPI_USU = VDPI_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, VDPI_DTU = VDPI_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM VDPI
INNER JOIN ##MTPR ON MTPR_COD = VDPI_MTPR + 'B'



IF OBJECT_ID('TempDB.dbo.##CPIP') IS NOT NULL DROP TABLE ##CPIP
SELECT * INTO ##CPIP FROM CPIP WHERE 1 = 0
INSERT INTO ##CPIP
SELECT 
	  CPIP_SIES = CPIP_SIES      --CONVERT(int(6),'') E(C�digo do estabelecimento)
	, CPIP_SIDO = CPIP_SIDO      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPIP_SISE = CPIP_SISE      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPIP_CPPC = CPIP_CPPC      --CONVERT(int(6),'') Pedido(N�mero do pedido)
	, CPIP_COD = CPIP_COD      --CONVERT(int(3),'') Item(Item do pedido de compra)
	, CPIP_STA = CPIP_STA      --CONVERT(char(2),'') Status(Situa��o do item pedido (EA, OK, EC) define valida��es)
	, CPIP_CPSC_SIES = CPIP_CPSC_SIES      --CONVERT(int(6),'') E.(C�digo do estabelecimento da solicita��o)
	, CPIP_CPSC_SIDO = CPIP_CPSC_SIDO      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPIP_CPSC_SISE = CPIP_CPSC_SISE      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPIP_CPSC_NPAI = CPIP_CPSC_NPAI      --CONVERT(int(6),'') Solicita��o(N�mero da solicita��o de compra)
	, CPIP_CPSC = CPIP_CPSC      --CONVERT(int(3),'') Item(Item da solicita��o de compra)
	, CPIP_MTPR = CPIP_MTPR+ 'B'      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, CPIP_NOM = CPIP_NOM     --CONVERT(varchar(255),'') Descri��o(Descri��o do produto comercial)
	, CPIP_MTPC = CPIP_MTPC + 'B'      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, CPIP_MS = CPIP_MS      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, CPIP_MTUN = CPIP_MTUN      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, CPIP_MTNC = CPIP_MTNC      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, CPIP_ORI = CPIP_ORI      --CONVERT(char(1),'') Origem(Origem do produto)
	, CPIP_MTDV = CPIP_MTDV      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, CPIP_MTLN = CPIP_MTLN      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, CPIP_MTFM = CPIP_MTFM      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, CPIP_PLIQ = CPIP_PLIQ      --CONVERT(decimal(13),'') Peso L�q.(Peso liquido unit�rio em Kg)
	, CPIP_PLIQ_GLFO = CPIP_PLIQ_GLFO      --CONVERT(decimal(13),'') Peso L�q.Forn.(Peso liquido unit�rio na unidade do fornecedor)
	, CPIP_PLQT = CPIP_PLQT      --CONVERT(decimal(13),'') Peso Tot.(Peso liquido total em Kg)
	, CPIP_PLQT_GLFO = CPIP_PLQT_GLFO      --CONVERT(decimal(13),'') Peso Tot.Forn.(Peso liquido total na unidade do fornecedor)
	, CPIP_PBRT = CPIP_PBRT      --CONVERT(decimal(13),'') Peso Bruto(Peso bruto total em Kg)
	, CPIP_PBRT_GLFO = CPIP_PBRT_GLFO      --CONVERT(decimal(13),'') Peso Bruto Forn.(Peso bruto total na unidade do fornecedor)
	, CPIP_COMPO = CPIP_COMPO      --CONVERT(char(1),'') Composto(Indica se produto � composto, ou seja, possui estrutura)
	, CPIP_EST = CPIP_EST      --CONVERT(char(1),'') Estoque(Indica se estoque controlado (S ou N))
	, CPIP_QTD = CPIP_QTD      --CONVERT(decimal(12),'') Quantidade(Quantidade total do item do pedido)
	, CPIP_QTD_GLFO = CPIP_QTD_GLFO      --CONVERT(decimal(12),'') Qtd.Forn.(Quantidade total do item do pedido na unidade do fornecedor)
	, CPIP_QOR = CPIP_QOR      --CONVERT(decimal(12),'') Qtde em OR(Quantidade em OR do item do pedido)
	, CPIP_QNF = CPIP_QNF      --CONVERT(decimal(12),'') Qtde Recebida(Quantidade recebida do item do pedido)
	, CPIP_PUN = CPIP_PUN      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial expresso na moeda da cota��o)
	, CPIP_PUN_GLFO = CPIP_PUN_GLFO      --CONVERT(decimal(12),'') Pre�o Un. Forn.(Valor unit�rio do produto comercial expresso na moeda da cota��o na unidade do fornecedor)
	, CPIP_PUND = CPIP_PUND      --CONVERT(decimal(12),'') Pre�o c/ Desc.(Valor unit�rio do produto comercial com desconto expresso na moeda do pedido)
	, CPIP_PUND_GLFO = CPIP_PUND_GLFO      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.(Valor unit�rio do produto comercial com desconto expresso na moeda do pedido na unidade do fornecedo)
	, CPIP_CPID = CPIP_CPID      --CONVERT(varchar(20),'') Ref.Forn.(C�digo utilizado pelo fornecedor do produto ou insumo)
	, CPIP_CPUN = CPIP_CPUN      --CONVERT(varchar(3),'') Un.Forn.(C�digo da unidade do insumo utilizado pelo fornecedor)
	, CPIP_CPFT = CPIP_CPFT      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do insumo em rela��o a unidade do fornecedor)
	, CPIP_VAL = CPIP_VAL      --CONVERT(decimal(12),'') Total(Valor total do item c/ desconto s/ IPI)
	, CPIP_VNF = CPIP_VNF      --CONVERT(decimal(12),'') Valor faturado(Valor total faturado do item do pedido com desconto (c/ IPI))
	, CPIP_PENT = CPIP_PENT      --CONVERT(int(3),'') Entrega (dias)(Prazo de entrega em dias)
	, CPIP_DENT = CPIP_DENT      --CONVERT(datetime(10),'') Entrega(Data de entrega)
	, CPIP_OBS = CPIP_OBS      --CONVERT(varchar(255),'') Obs.(Observa��o do item)
	, CPIP_ESPE = CPIP_ESPE      --CONVERT(varchar(6000),'') Especifica��es(Especifica��es complementares do insumo)
	, CPIP_REV = CPIP_REV      --CONVERT(char(1),'') Destina��o(Define se item � para consumo (N) , revenda (S), revenda equiparada (E) ou industrializacao (I))
	, CPIP_NFOP = CPIP_NFOP      --CONVERT(varchar(8),'') Oper.(C�digo da opera��o fiscal)
	, CPIP_CFOP = CPIP_CFOP      --CONVERT(varchar(6),'') CFOP(C�digo fiscal de opera��o e presta��o de servi�os)
	, CPIP_IPI_BAS = CPIP_IPI_BAS      --CONVERT(decimal(12),'') Base IPI(Base de c�lculo de IPI)
	, CPIP_IPI_ALI = CPIP_IPI_ALI      --CONVERT(decimal(5),'') % IPI(Al�quota de IPI)
	, CPIP_IPI_VAL = CPIP_IPI_VAL      --CONVERT(decimal(12),'') Valor IPI(Valor do IPI)
	, CPIP_IPI_ISE = CPIP_IPI_ISE      --CONVERT(decimal(12),'') IPI Isento(Valor isento de IPI)
	, CPIP_IPI_OUT = CPIP_IPI_OUT      --CONVERT(decimal(12),'') IPI Outros(Outros valores de IPI)
	, CPIP_ISS_BAS = CPIP_ISS_BAS      --CONVERT(decimal(12),'') Base de ISS(Base de c�lculo de ISS)
	, CPIP_ISS_ALI = CPIP_ISS_ALI      --CONVERT(decimal(5),'') % ISS(Al�quota de ISS)
	, CPIP_ISS_VAL = CPIP_ISS_VAL      --CONVERT(decimal(12),'') Valor do ISS(Valor do ISS)
	, CPIP_ISS_ISE = CPIP_ISS_ISE      --CONVERT(decimal(12),'') ISS Isento(Valor isento de ISS)
	, CPIP_ISS_OUT = CPIP_ISS_OUT      --CONVERT(decimal(12),'') ISS Outros(Outros valores de ISS)
	, CPIP_ICM_BAS = CPIP_ICM_BAS      --CONVERT(decimal(12),'') Base ICMS(Base de c�lculo de ICMS)
	, CPIP_ICM_ALI = CPIP_ICM_ALI      --CONVERT(decimal(5),'') % ICMS(Al�quota de ICMS)
	, CPIP_ICM_VAL = CPIP_ICM_VAL      --CONVERT(decimal(12),'') Valor do ICMS(Valor do ICMS)
	, CPIP_ICM_ISE = CPIP_ICM_ISE      --CONVERT(decimal(12),'') ICMS Isento(Valor isento de ICMS)
	, CPIP_ICM_OUT = CPIP_ICM_OUT      --CONVERT(decimal(12),'') ICMS Outros(Outros valores de ICMS)
	, CPIP_IST_BAS = CPIP_IST_BAS      --CONVERT(decimal(12),'') Base ICMS - ST(Base de c�lculo de ICMS por Substitui��o Tribut�ria)
	, CPIP_IST_ALI = CPIP_IST_ALI      --CONVERT(decimal(5),'') % ICMS - ST(Al�quota de ICMS por Substitui��o Tribut�ria)
	, CPIP_IST_VAL = CPIP_IST_VAL      --CONVERT(decimal(12),'') Valor do ICMS - ST(Valor do ICMS por Substitui��o Tribut�ria)
	, CPIP_IST_ISE = CPIP_IST_ISE      --CONVERT(decimal(12),'') ICMS Isento - ST(Valor isento de ICMS por Substitui��o Tribut�ria)
	, CPIP_IST_OUT = CPIP_IST_OUT      --CONVERT(decimal(12),'') ICMS Outros - ST(Outros valores de ICMS por Substitui��o Tribut�ria)
	, CPIP_IST_IVA = CPIP_IST_IVA      --CONVERT(decimal(12),'') ST- IVA %(�ndice de valor agregado setorial por Substitui��o Tribut�ria)
	, CPIP_ICP_ALI = CPIP_ICP_ALI      --CONVERT(decimal(6),'') %ICMS Complem.(Define o percentual de incid�ncia do ICMS Complementar nas vendas destinas ao estado (uso pr�prio))
	, CPIP_ICP_VAL = CPIP_ICP_VAL      --CONVERT(decimal(12),'') Valor ICMS Complem.(Valor do ICMS Complementar nas vendas destinas ao estado (uso pr�prio))
	, CPIP_MTTR = CPIP_MTTR      --CONVERT(varchar(6),'') Transa��o(C�digo da transa��o)
	, CPIP_TIT = CPIP_TIT      --CONVERT(char(1),'') Gera t�tulos(Se opera��o gera t�tulos (S=Sim ou N=N�o))
	, CPIP_TBB = CPIP_TBB      --CONVERT(varchar(2),'') Tabela B(C�digo da Tabela B)
	, CPIP_CTPC = CPIP_CTPC      --CONVERT(varchar(15),'') Cont�bil(C�digo da conta cont�bil)
	, CPIP_RDPC = CPIP_RDPC      --CONVERT(varchar(7),'') Rdz.(C�digo reduzido da conta cont�bil)
	, CPIP_CTCC = CPIP_CTCC      --CONVERT(varchar(15),'') C.C.(C�digo do centro de lucro/custo)
	, CPIP_RDCC = CPIP_RDCC      --CONVERT(varchar(7),'') Rdz.(C�digo reduzido do centro de lucro/custo)
	, CPIP_USC = CPIP_USC      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, CPIP_DTC = CPIP_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, CPIP_USU = CPIP_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, CPIP_DTU = CPIP_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM CPIP
INNER JOIN ##MTPR ON MTPR_COD = CPIP_MTPR + 'B'


IF OBJECT_ID('TempDB.dbo.##CPCT') IS NOT NULL DROP TABLE ##CPCT
SELECT * INTO ##CPCT FROM CPCT WHERE 1 = 0
INSERT INTO ##CPCT
SELECT 
	 CPCT_SIES = CPCT_SIES      --CONVERT(int(6),'') E(C�digo do estabelecimento)
	, CPCT_SIDO = CPCT_SIDO      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPCT_SISE = CPCT_SISE      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPCT_COD = CPCT_COD      --CONVERT(int(3),'') N�mero(N�mero da cota��o de compra)
	, CPCT_STA = CPCT_STA      --CONVERT(char(2),'') Status(Situa��o da cota��o (EA, OK))
	, CPCT_CPSC_SIES = CPCT_CPSC_SIES      --CONVERT(int(6),'') E.(C�digo do estabelecimento)
	, CPCT_CPSC_SIDO = CPCT_CPSC_SIDO      --CONVERT(varchar(4),'') Tipo(Tipo de documento)
	, CPCT_CPSC_SISE = CPCT_CPSC_SISE      --CONVERT(varchar(3),'') S�rie(S�rie do documento)
	, CPCT_CPSC_NPAI = CPCT_CPSC_NPAI      --CONVERT(int(6),'') Solicita��o(N�mero da Solicita��o de Compra)
	, CPCT_CPSC = CPCT_CPSC      --CONVERT(int(3),'') Item(Item da solicita��o de compra)
	, CPCT_MTPR = CPCT_MTPR + 'B'      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, CPCT_MTPC = CPCT_MTPC + 'B'      --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, CPCT_ESPE = CPCT_ESPE      --CONVERT(varchar(6000),'') Especifica��es(Especifica��es complementares do insumo)
	, CPCT_GLTX = CPCT_GLTX      --CONVERT(varchar(4),'') Tipo(Indica o tipo do parceiro (cliente, fornecedor, etc...))
	, CPCT_GLXX = CPCT_GLXX      --CONVERT(int(6),'') Fornecedor(C�digo do parceiro)
	, CPCT_GLXX_DIG = CPCT_GLXX_DIG      --CONVERT(int(3),'') Digito(Digito do C�digo do Fornecedor)
	, CPCT_GLXX_GLPA = CPCT_GLXX_GLPA      --CONVERT(int(6),'') C�d.Parceiro(C�digo do parceiro)
	, CPCT_GLXX_NRDZ = CPCT_GLXX_NRDZ      --CONVERT(varchar(15),'') Apelido(Nome reduzido (apelido) do Parceiro)
	, CPCT_REV = CPCT_REV      --CONVERT(char(1),'') Destina��o(Define se item � para consumo (N) , revenda (S), revenda equiparada (E) ou industrializacao (I))
	, CPCT_QTD = CPCT_QTD      --CONVERT(decimal(12),'') Quantidade(Quantidade total do item da cota��o)
	, CPCT_QTD_GLFO = CPCT_QTD_GLFO      --CONVERT(decimal(12),'') Qtd.Forn.(Quantidade cotada do item na unidade do fornecedor)
	, CPCT_CTO = CPCT_CTO      --CONVERT(varchar(25),'') Contato(Nome do contato do fornecedor p/ a cota��o)
	, CPCT_TEL = CPCT_TEL      --CONVERT(varchar(25),'') Fone(Telefone do fornecedor para a cota��o)
	, CPCT_FAX = CPCT_FAX      --CONVERT(varchar(25),'') Fax(Fax do fornecedor para a cota��o)
	, CPCT_EMAIL = CPCT_EMAIL      --CONVERT(varchar(50),'') Email(Email do fornecedor para a cota��o)
	, CPCT_GLCP = CPCT_GLCP     --CONVERT(int(6),'') Comprador(C�digo do comprador)
	, CPCT_CPID = CPCT_CPID      --CONVERT(varchar(20),'') Ref. Forn.(C�digo utilizado pelo fornecedor do produto ou insumo)
	, CPCT_CPUN = CPCT_CPUN      --CONVERT(varchar(3),'') Un.Forn.(C�digo da unidade do insumo utilizado pelo fornecedor)
	, CPCT_CPFT = CPCT_CPFT      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do insumo em rela��o a unidade do fornecedor)
	, CPCT_PUN = CPCT_PUN      --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial expresso na moeda da cota��o)
	, CPCT_PUN_GLFO = CPCT_PUN_GLFO      --CONVERT(decimal(12),'') Pre�o Un. Forn.(Valor unit�rio do produto comercial na unidade do fornecedor)
	, CPCT_PUND = CPCT_PUND      --CONVERT(decimal(12),'') Pre�o c/ Desc.(Valor unit�rio do produto comercial com desconto expresso na moeda da cota��o)
	, CPCT_PUND_GLFO = CPCT_PUND_GLFO      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.(Valor unit�rio do produto comercial com desconto na unidade do fornecedo)
	, CPCT_VACT = CPCT_VACT      --CONVERT(int(3),'') Validade (dias)(Validade do pre�o do fornecedor em dias)
	, CPCT_GLMD = CPCT_GLMD      --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, CPCT_IPI_ALI = CPCT_IPI_ALI      --CONVERT(decimal(5),'') % IPI(Al�quota de IPI)
	, CPCT_ISS_ALI = CPCT_ISS_ALI      --CONVERT(decimal(5),'') % ISS(Al�quota de ISS)
	, CPCT_ICM_ALI = CPCT_ICM_ALI      --CONVERT(decimal(5),'') % ICMS(Al�quota de ICMS)
	, CPCT_VALT = CPCT_VALT      --CONVERT(decimal(12),'') Total c/ IPI(Total com descontos e IPI)
	, CPCT_GLPG = CPCT_GLPG      --CONVERT(varchar(6),'') Pagamento(C�digo da condi��o de pagamento)
	, CPCT_PENT = CPCT_PENT      --CONVERT(int(3),'') Entrega (dias �teis)(Prazo de entrega em dias �teis)
	, CPCT_DOCF = CPCT_DOCF      --CONVERT(varchar(20),'') Doc.Fornec.(Documento do fornecedor origem da cota��o)
	, CPCT_OBS = CPCT_OBS      --CONVERT(varchar(255),'') Obs.(Observa��o do item)
	, CPCT_USC = CPCT_USC     --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, CPCT_DTC = CPCT_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, CPCT_USU = CPCT_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, CPCT_DTU = CPCT_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, CPCT_CPID_NOM = CPCT_CPID_NOM      --CONVERT(varchar(50),'') Nome For.(Nome do insumo atribu�do pelo fornecedor)
FROM CPCT
INNER JOIN ##MTPR ON MTPR_COD = CPCT_MTPR + 'B'


INSERT INTO MTPR
SELECT  
	  MTPR_COD = MTPR_COD -- CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo(C�digo do produto industrial)
	, MTPR_MTTP = MTPR_MTTP --'PA-PRODUCTO ACABADO' -- CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') Tipo(Define o tipo de insumo para a empresa)
	, MTPR_MS = MTPR_MS -- CONVERT(char(1),'')      --CONVERT(char(1),'') M/S(Mercadoria ou Servico)
	, MTPR_ATV = MTPR_ATV -- CONVERT(char(1),'')      --CONVERT(char(1),'') Ativo(Produto ativo ou n�o)
	, MTPR_NOM = substring(MTPR_NOM, 0,80) -- CONVERT(varchar(80),'')      --CONVERT(varchar(80),'') Nome(Nome do insumo)
	, MTPR_MTDV = MTPR_MTDV -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Divis�o(C�digo da divis�o do produto)
	, MTPR_MTLN = MTPR_MTLN -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Linha(C�digo da linha do produto)
	, MTPR_MTFM = MTPR_MTFM  -- CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Fam�lia(Fam�lia do produto)
	, MTPR_MTUN = MTPR_MTUN -- CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Unidade(C�digo da unidade de produto)
	, MTPR_MTNC = MTPR_MTNC -- CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') NCM(C�digo de NCM)
	, MTPR_ORI = MTPR_ORI -- CONVERT(char(1),'')      --CONVERT(char(1),'') Origem(Origem do produto)
	, MTPR_PES = MTPR_PES -- CONVERT(decimal(13),'')      --CONVERT(decimal(13),'') Peso em Kg(Peso liquido unit�rio em Kg)
	, MTPR_DES = MTPR_DES -- Null      --CONVERT(varchar(240),'') Descri��o(Descri��o complementar do produto)
	, MTPR_NIV = MTPR_NIV -- Null      --CONVERT(int(6),'') N�vel(N�vel de composi��o da estrutura)
	, MTPR_ESUN = MTPR_ESUN -- Null      --CONVERT(varchar(3),'') Un.Estrutura(C�digo da unidade de produto utilizado como componente de estrutura)
	, MTPR_ESFT = MTPR_ESFT --  Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de componente)
	, MTPR_CPUN = MTPR_CPUN -- Null      --CONVERT(varchar(3),'') Un.Compra(C�digo da unidade de produto para compra)
	, MTPR_CPFT = MTPR_CPFT -- Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do produto em rela��o a unidade de compra)
	, MTPR_ATVV = MTPR_ATVV -- CONVERT(char(1),'')      --CONVERT(char(1),'') Vendo(Posso vender o insumo)
	, MTPR_CFOV = MTPR_CFOV -- Null      --CONVERT(varchar(8),'') CFOP Venda(C�digo interno da opera��o fiscal para opera��es de Venda p/ uso pr�prio (se aplic�vel))
	, MTPR_ATVC = MTPR_ATVC -- CONVERT(char(1),'')      --CONVERT(char(1),'') Compro(Posso comprar o insumo)
	, MTPR_CFOC = MTPR_CFOC -- Null      --CONVERT(varchar(8),'') CFOP Compra(C�digo interno da opera��o fiscal para opera��es de Compra (se aplic�vel))
	, MTPR_TOLE = MTPR_TOLE -- CONVERT(decimal(12),'')      --CONVERT(decimal(12),'') Varia��o%(Define o percentual de toler�ncia em quantidade na compra do insumo)
	, MTPR_FEST = MTPR_FEST --Null      --CONVERT(varchar(7),'') CEST(C�digo Especificador da Substitui��o Tribut�ria (CEST) - Confaz Conv�nio ICMS N� 92/2015)
	, MTPR_USC = MTPR_USC -- CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPR_DTC = MTPR_DTC -- CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPR_USU =  Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPR_DTU =  Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro) 
	FROM ##MTPR


INSERT INTO MTES
SELECT
	  MTES_MTPR = MTES_MTPR      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTES_SIES = MTES_SIES      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTES_MTAL = MTES_MTAL      --CONVERT(varchar(6),'') Almox.Padr�o(C�digo de almoxarifado padr�o para o insumo no estabelecimento)
	, MTES_MTAN = MTES_MTAN      --CONVERT(varchar(6),'') Almox.Necessidade(C�digo de almoxarifado default para cria��o da necessidade para o insumo no estabelecimento)
	, MTES_MTAP = MTES_MTAP      --CONVERT(varchar(6),'') Almox.Fabrica��o(C�digo de almoxarifado default para cria��o da provid�ncia FABRICA��O para o insumo no estab.)
	, MTES_LOTE = MTES_LOTE      --CONVERT(char(1),'') Lote Controlado(Define se insumo tem lote controlado (S/N))
	, MTES_GLMD = MTES_GLMD      --CONVERT(varchar(8),'') Moeda Forte(C�digo da Moeda p/ valoriza��o do estoque al�m da moeda corrente)
	, MTES_QATU = MTES_QATU      --CONVERT(decimal(14),'') Saldo Atual(Saldo atual em quantidade do insumo)
	, MTES_VATU = MTES_VATU      --CONVERT(decimal(14),'') Valor Atual(Valor atual em moeda corrente)
	, MTES_VATM = MTES_VATM      --CONVERT(decimal(14),'') Valor M Atual(Valor atual em moeda forte)
	, MTES_QVIS = MTES_QVIS      --CONVERT(decimal(14),'') Saldo Vis�vel(Saldo atual em quantidade do insumo p/ os almoxarifados vis�veis)
	, MTES_QNEC = MTES_QNEC      --CONVERT(decimal(14),'') Necessidades(Quantidade em necessidades (PRNC, VDPD, PROR))
	, MTES_QPRO = MTES_QPRO      --CONVERT(decimal(14),'') Provid�ncias(Quantidade em provid�ncias (PROR) produ��o ou compras)
	, MTES_PCME = MTES_PCME      --CONVERT(decimal(14),'') Consumo Estimado(Consumo m�dio estimado para 30 dias calculado em n (per�odo) dias)
	, MTES_PCMR = MTES_PCMR      --CONVERT(decimal(14),'') Consumo Real(Consumo m�dio real para 30 dias calculado em n (per�odo) dias)
	, MTES_PMIN = MTES_PMIN      --CONVERT(int(8),'') Dispara compra com(N�mero de dias p/ defini��o da quantidade gatilho p/ solicitar compras)
	, MTES_POBJ = MTES_POBJ      --CONVERT(int(8),'') Nec. para suprir(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras)
	, MTES_POEM = MTES_POEM      --CONVERT(int(8),'') Nec. para urg�ncia(N�mero de dias p/ defini��o da quantidade objetivo ao solicitar compras em regime de urg�ncia)
	, MTES_PPMI = MTES_PPMI      --CONVERT(decimal(14),'') Estoque m�nimo(Quantidade p/ qual deve ser disparado compras)
	, MTES_PLEM = MTES_PLEM      --CONVERT(decimal(14),'') Nec. m�nima(Quantidade m�nima a ser comprada)
	, MTES_PMUL = MTES_PMUL      --CONVERT(decimal(14),'') M�ltiplos(Comprar em quantidades m�ltiplas de)
	, MTES_PLEC = MTES_PLEC      --CONVERT(decimal(14),'') Lote econ�mico(Quantidade econ�mica a ser comprada)
	, MTES_UCDO = MTES_UCDO      --CONVERT(varchar(25),'') �ltima Compra(Documento da �ltima compra (SIES/SIDO/SISE/COD de MTMV))
	, MTES_LEAD = MTES_LEAD      --CONVERT(int(3),'') Lead Time (dias)(Tempo em dias entre a solicita��o e o recebimento do item)
	, MTES_LEEM = MTES_LEEM      --CONVERT(int(3),'') LT Urg�ncia (dias)(Tempo em dias entre a solicita��o e o recebimento do item em urg�ncia)
	, MTES_EXPL = MTES_EXPL      --CONVERT(char(1),'') Explode em estrutura(Indica se produto deve ser explodido se componente de ordem de produ��o)
	, MTES_MRP  = MTES_MRP       --CONVERT(char(1),'') Pol�tica(Define se item � providenciado via MRP (S) ou somente sob-encomenda (N))
	, MTES_CREP = MTES_CREP      --CONVERT(decimal(18),'') Custo Reposi��o(Valor unit�rio l�quido da �ltima compra ou custo do material direto da composi��o calculado)
	, MTES_CPDR = MTES_CPDR      --CONVERT(decimal(18),'') Custo Padr�o(Valor unit�rio do custo padr�o ( informado))
	, MTES_FGGF = MTES_FGGF      --CONVERT(decimal(18),'') Fator GGF(Fator dos Gastos Gerais de Fabrica��o)
	, MTES_FRAT = MTES_FRAT      --CONVERT(int(8),'') M�todo de rateio(M�todo de rateio para o c�lculo do custo)
	, MTES_CTGT = MTES_CTGT      --CONVERT(decimal(18),'') Custo Target(Valor unit�rio do custo em moeda forte ( informado))
	, MTES_CPO1 = MTES_CPO1      --CONVERT(varchar(50),'') Campo 1(Campo dispon�vel)
	, MTES_CPO2 = MTES_CPO2      --CONVERT(varchar(50),'') Campo 2(Campo dispon�vel)
	, MTES_CPO3 = MTES_CPO3      --CONVERT(varchar(50),'') Campo 3(Campo dispon�vel)
	, MTES_CPO4 = MTES_CPO4      --CONVERT(varchar(50),'') Campo 4(Campo dispon�vel)
	, MTES_PRAT = MTES_PRAT      --CONVERT(varchar(20),'') Prateleira(Prateleira do insumo)
	, MTES_USC  = MTES_USC      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTES_DTC  = MTES_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTES_USU  = NULL      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTES_DTU  = NULL      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM ##MTES 


DELETE FROM MTPC WHERE MTPC_COD IN (SELECT MTPC_COD FROM ##MTPC)

INSERT INTO MTPC 
SELECT
	  MTPC_COD		 = MTPC_COD		 --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, MTPC_MTPR		 = MTPC_MTPR	 --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTPC_NOM		 = MTPC_NOM		 --CONVERT(varchar(80),'') Nome(Nome do produto comercial)
	, MTPC_GLMD		 = MTPC_GLMD	 --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, MTPC_PRE		 = MTPC_PRE		 --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, MTPC_PRE_USU	 = MTPC_PRE_USU  --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_PRE_DTU	 = MTPC_PRE_DTU  --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do pre�o do registro)
	, MTPC_PREC		 = MTPC_PREC     --CONVERT(decimal(12),'') Pre�o C(Valor unit�rio do pre�o de venda do principal concorrente)
	, MTPC_USC		 = MTPC_USC      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPC_DTC		 = MTPC_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPC_USU		 = MTPC_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_DTU		 = MTPC_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM ##MTPC


UPDATE FTIT 
SET FTIT_MTPC = P.FTIT_MTPC,
    FTIT_MTPR = P.FTIT_MTPR
FROM 
	##FTIT P
WHERE 
	FTIT.FTIT_MTPR = SUBSTRING(P.FTIT_MTPR, 1, LEN(P.FTIT_MTPR) - 1)

ALTER TABLE VDPI DISABLE TRIGGER ALL

UPDATE VDPI
SET VDPI_MTPR = F.VDPI_MTPR,
	VDPI_MTPC = F.VDPI_MTPC
FROM ##VDPI F
WHERE VDPI.VDPI_MTPR = SUBSTRING(F.VDPI_MTPR, 1, LEN(F.VDPI_MTPR) - 1)

ALTER TABLE VDPI ENABLE TRIGGER ALL


UPDATE CPCT 
SET
	--CPCT_MTPR = SUBSTRING(F.CPCT_MTPR, 1, LEN(F.CPCT_MTPR) - 1),
	--CPCT_MTPC = SUBSTRING(F.CPCT_MTPR, 1, LEN(F.CPCT_MTPR) - 1),
	CPCT_CPFT = 1/A.MTPR_CPFT
FROM ##CPCT F
INNER JOIN MTPR A ON A.MTPR_COD = F.CPCT_MTPR
WHERE CPCT.CPCT_MTPR = SUBSTRING(F.CPCT_MTPR, 1, LEN(F.CPCT_MTPR) - 1)


ALTER TABLE CPIP DISABLE TRIGGER ALL

UPDATE CPIP
SET CPIP_MTPR = F.CPIP_MTPR,
	CPIP_MTPC = F.CPIP_MTPC
FROM ##CPIP F
WHERE CPIP.CPIP_MTPR = SUBSTRING(F.CPIP_MTPR, 1, LEN(F.CPIP_MTPR) - 1)

ALTER TABLE CPIP ENABLE TRIGGER ALL

/*
delete mtpr
from ##MTPR
where mtpr.mtpr_cod = ##MTPR.mtpr_cod
*/
UPDATE MTPC
SET  MTPC_COD		 = P.MTPC_COD		 --CONVERT(varchar(20),'') Refer�ncia(C�digo comercial do produto)
	, MTPC_MTPR		 = P.MTPC_MTPR	 --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTPC_NOM		 = P.MTPC_NOM		 --CONVERT(varchar(80),'') Nome(Nome do produto comercial)
	, MTPC_GLMD		 = MTPC_GLMD	 --CONVERT(varchar(8),'') Moeda(C�digo da Moeda)
	, MTPC_PRE		 = P.MTPC_PRE * MTPR_CPFT		 --CONVERT(decimal(12),'') Pre�o(Valor unit�rio do produto comercial)
	, MTPC_PRE_USU	 = P.MTPC_PRE_USU  --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_PRE_DTU	 = P.MTPC_PRE_DTU  --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do pre�o do registro)
	, MTPC_PREC		 = P.MTPC_PREC * MTPR_CPFT    --CONVERT(decimal(12),'') Pre�o C(Valor unit�rio do pre�o de venda do principal concorrente)
	, MTPC_USC		 = P.MTPC_USC      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTPC_DTC		 = P.MTPC_DTC      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTPC_USU		 = P.MTPC_USU      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTPC_DTU		 = P.MTPC_DTU      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
 FROM MTPC P
INNER JOIN ##MTPR_ANT ON MTPR_COD = MTPC_COD


--SELECT
UPDATE MTPR
SET 
MTPR_NOM = REPLACE(SUBSTRING(A.MTPR_NOM, 1, CHARINDEX( '(', A.MTPR_NOM)), '(', '')
FROM ##MTPR_ANT A
WHERE MTPR.MTPR_COD = A.MTPR_COD

UPDATE MTPR
SET MTPR_NOM = 'SPECIAL COMPONENT SPRING'
WHERE MTPR_COD = 'SCSPB'

UPDATE MTPR
SET MTPR_NOM = 'YELLOW SPRING 2 X 3 C'
WHERE MTPR_COD = 'SSY032012CB'

UPDATE MTPR
SET MTPR_NOM = '*SPE YELLOW SPRING 3/4 X 1'
WHERE MTPR_COD = 'SSY012004SB'

UPDATE MTPR
SET MTPR_NOM = 'O PA BLUE SPRING 3/4 X 1'
WHERE MTPR_COD = 'SSB012004-NB'


update mtpr
set mtpr_nom = f.mtpr_nom 
from ##MTPR f
where mtpr.mtpr_cod = f.mtpr_cod

/*
SELECT DISTINCT 'Alter Table ' +  O.NAME + ' ENABLE Trigger All' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTPR%'
AND O.xtype = 'U'
*/

Alter Table CPCT Disable Trigger All
Alter Table CPIP Disable Trigger All
Alter Table CPSC Disable Trigger All
Alter Table FTIS Disable Trigger All
Alter Table FTIT Disable Trigger All
Alter Table GDFI Disable Trigger All
Alter Table GDRI Disable Trigger All
Alter Table MTEA Disable Trigger All
Alter Table MTEL Disable Trigger All
Alter Table MTES Disable Trigger All
Alter Table MTFO Disable Trigger All
Alter Table MTIV Disable Trigger All
Alter Table MTPC Disable Trigger All
Alter Table MTPE Disable Trigger All
Alter Table MTPL Disable Trigger All
Alter Table MTPP Disable Trigger All
Alter Table MTPR Disable Trigger All
Alter Table MTRE Disable Trigger All
Alter Table MTSA Disable Trigger All
Alter Table MTSL Disable Trigger All
Alter Table MTSO Disable Trigger All
Alter Table MTSW Disable Trigger All
Alter Table MTSX Disable Trigger All
Alter Table MTSY Disable Trigger All
Alter Table MTSZ Disable Trigger All
Alter Table NFDS Disable Trigger All
Alter Table NFIT Disable Trigger All
Alter Table NSFI Disable Trigger All
Alter Table NSOI Disable Trigger All
Alter Table OFIS Disable Trigger All
Alter Table OFIT Disable Trigger All
Alter Table ORIT Disable Trigger All
Alter Table PRNC Disable Trigger All
Alter Table PROR Disable Trigger All
Alter Table PRPN Disable Trigger All
Alter Table PRPR Disable Trigger All
Alter Table PRRA Disable Trigger All
Alter Table PRRO Disable Trigger All
Alter Table PRSA Disable Trigger All
Alter Table PUNC Disable Trigger All
Alter Table RCIT Disable Trigger All
Alter Table VDC1 Disable Trigger All
Alter Table VDIC Disable Trigger All
Alter Table VDOI Disable Trigger All
Alter Table VDPI Disable Trigger All
Alter Table VDPS Disable Trigger All
Alter Table VDSC Disable Trigger All

/*
SELECT DISTINCT 'Alter Table ' +  O.NAME + ' ENABLE Trigger All' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTPR%'
AND O.xtype = 'U'

SELECT DISTINCT 'UPDATE ' +  O.NAME + ' SET ' + O.NAME + '_MTPR = P.MTPR_COD ' +
', ' + O.NAME + '_MTPC = P.MTPR_COD FROM ##MTPR P WHERE ' + O.NAME + '_MTPR + ''B'' = P.MTPR_COD ' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTPR%'
AND O.xtype = 'U'


SELECT * FROM CPIP
INNER JOIN ##MTPR_ANT ON CPIP_MTPR = MTPR_COD 

*/
UPDATE CPIP
SET CPIP_MTPR = P.MTPR_COD
, CPIP_MTPC = P.MTPR_COD
FROM ##MTPR P
WHERE CPIP_MTPR + 'B' = P.MTPR_COD

/*
Alter Table MTSL NOCHECK CONSTRAINT
Alter Table MTSO NOCHECK CONSTRAINT
Alter Table MTSW NOCHECK CONSTRAINT
Alter Table MTSX NOCHECK CONSTRAINT
Alter Table MTSY NOCHECK CONSTRAINT
Alter Table MTSZ NOCHECK CONSTRAINT
Alter Table NFDS NOCHECK CONSTRAINT
Alter Table NFIT NOCHECK CONSTRAINT
Alter Table NSFI NOCHECK CONSTRAINT
Alter Table NSOI NOCHECK CONSTRAINT
Alter Table OFIS NOCHECK CONSTRAINT
Alter Table OFIT NOCHECK CONSTRAINT
Alter Table ORIT NOCHECK CONSTRAINT
Alter Table PRNC NOCHECK CONSTRAINT
Alter Table PROR NOCHECK CONSTRAINT
Alter Table PRPN NOCHECK CONSTRAINT
Alter Table PRPR NOCHECK CONSTRAINT
Alter Table PRRA NOCHECK CONSTRAINT
Alter Table PRRO NOCHECK CONSTRAINT
Alter Table PRSA NOCHECK CONSTRAINT
Alter Table PUNC NOCHECK CONSTRAINT
Alter Table RCIT NOCHECK CONSTRAINT
Alter Table VDC1 NOCHECK CONSTRAINT
Alter Table VDIC NOCHECK CONSTRAINT
Alter Table VDOI NOCHECK CONSTRAINT
Alter Table VDPI NOCHECK CONSTRAINT
Alter Table VDPS NOCHECK CONSTRAINT
Alter Table VDSC NOCHECK CONSTRAINT
*/
--SELECT * FROM ##MTPR
--SELECT * FROM MTEL
--SELECT * FROM MTPL INNER JOIN ##MTPR_ANT ON MTPR_COD = MTPL_MTPR

UPDATE GDFI SET GDFI_MTPR = P.MTPR_COD , GDFI_MTPC = P.MTPR_COD FROM ##MTPR P WHERE GDFI_MTPR + 'B' = P.MTPR_COD 
UPDATE GDRI SET GDRI_MTPR = P.MTPR_COD , GDRI_MTPC = P.MTPR_COD FROM ##MTPR P WHERE GDRI_MTPR + 'B' = P.MTPR_COD 
UPDATE MTEA SET MTEA_MTPR = P.MTPR_COD /*, MTEA_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTEA_MTPR + 'B' = P.MTPR_COD 
UPDATE MTEL SET MTEL_MTPR = P.MTPR_COD /*, MTEL_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTEL_MTPR + 'B' = P.MTPR_COD 
UPDATE MTFO SET MTFO_MTPR = P.MTPR_COD /*, MTFO_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTFO_MTPR + 'B' = P.MTPR_COD 
UPDATE MTIV SET MTIV_MTPR = P.MTPR_COD /*, MTIV_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTIV_MTPR + 'B' = P.MTPR_COD 
UPDATE MTPC SET MTPC_MTPR = P.MTPR_COD /*, MTPC_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTPC_MTPR + 'B' = P.MTPR_COD 
UPDATE MTPE SET MTPE_MTPR = P.MTPR_COD /*, MTPE_MTPC = P.MTPR_COD */ FROM ##MTPR P WHERE MTPE_MTPR + 'B' = P.MTPR_COD 
UPDATE MTPL SET MTPL_MTPR = P.MTPR_COD /*, MTPL_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTPL_MTPR + 'B' = P.MTPR_COD 
UPDATE MTPP SET MTPC_MTPR = P.MTPR_COD , MTPC_COD = P.MTPR_COD FROM ##MTPR P WHERE MTPC_MTPR + 'B' = P.MTPR_COD 
UPDATE MTRE SET MTRE_MTPR = P.MTPR_COD /*, MTRE_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTRE_MTPR + 'B' = P.MTPR_COD 
Alter Table MTSA NOCHECK CONSTRAINT FK_MTSA_MES_MTSL, FK_MTSA_MTAL_MTAL
UPDATE MTSA SET MTSA_MTPR = P.MTPR_COD /*, MTSA_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSA_MTPR + 'B' = P.MTPR_COD 
UPDATE MTSL SET MTSL_MTPR = P.MTPR_COD /*, MTSL_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSL_MTPR + 'B' = P.MTPR_COD 
Alter Table MTSA CHECK CONSTRAINT FK_MTSA_MES_MTSL, FK_MTSA_MTAL_MTAL
UPDATE MTSO SET MTSO_MTPR = P.MTPR_COD /*, MTSO_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSO_MTPR + 'B' = P.MTPR_COD 
UPDATE MTSW SET MTSW_MTPR = P.MTPR_COD /*, MTSW_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSW_MTPR + 'B' = P.MTPR_COD 
UPDATE MTSX SET MTSX_MTPR = P.MTPR_COD /*, MTSX_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSX_MTPR + 'B' = P.MTPR_COD 
UPDATE MTSY SET MTSY_MTPR = P.MTPR_COD /*, MTSY_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSY_MTPR + 'B' = P.MTPR_COD 
UPDATE MTSZ SET MTSZ_MTPR = P.MTPR_COD /*, MTSZ_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE MTSZ_MTPR + 'B' = P.MTPR_COD 
UPDATE NFDS SET NFDS_MTPR = P.MTPR_COD /*, NFDS_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE NFDS_MTPR + 'B' = P.MTPR_COD 
UPDATE NFIT SET NFIT_MTPR = P.MTPR_COD , NFIT_MTPC = P.MTPR_COD FROM ##MTPR P WHERE NFIT_MTPR + 'B' = P.MTPR_COD 
UPDATE NSFI SET NSFI_MTPR = P.MTPR_COD , NSFI_MTPC = P.MTPR_COD FROM ##MTPR P WHERE NSFI_MTPR + 'B' = P.MTPR_COD 
UPDATE NSOI SET NSOI_MTPR = P.MTPR_COD , NSOI_MTPC = P.MTPR_COD FROM ##MTPR P WHERE NSOI_MTPR + 'B' = P.MTPR_COD 
UPDATE OFIS SET OFIS_MTPR = P.MTPR_COD , OFIS_MTPC = P.MTPR_COD FROM ##MTPR P WHERE OFIS_MTPR + 'B' = P.MTPR_COD 
UPDATE OFIT SET OFIT_MTPR = P.MTPR_COD , OFIT_MTPC = P.MTPR_COD FROM ##MTPR P WHERE OFIT_MTPR + 'B' = P.MTPR_COD 
UPDATE ORIT SET ORIT_MTPR = P.MTPR_COD , ORIT_MTPC = P.MTPR_COD FROM ##MTPR P WHERE ORIT_MTPR + 'B' = P.MTPR_COD 
UPDATE PRNC SET PRNC_MTPR = P.MTPR_COD /*, PRNC_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PRNC_MTPR + 'B' = P.MTPR_COD 
UPDATE PROR SET PROR_MTPR = P.MTPR_COD /*, PROR_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PROR_MTPR + 'B' = P.MTPR_COD 
UPDATE PRPN SET PRPN_MTPR = P.MTPR_COD /*, PRPN_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PRPN_MTPR + 'B' = P.MTPR_COD 
UPDATE PRPR SET PRPR_MTPR = P.MTPR_COD /*, PRPR_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PRPR_MTPR + 'B' = P.MTPR_COD 
UPDATE PRRA SET PRRA_MTPR = P.MTPR_COD /*, PRRA_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PRRA_MTPR + 'B' = P.MTPR_COD 
UPDATE PRRO SET PRRO_MTPR = P.MTPR_COD /*, PRRO_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PRRO_MTPR + 'B' = P.MTPR_COD 
UPDATE PRSA SET PRSA_MTPR = P.MTPR_COD /*, PRSA_MTPC = P.MTPR_COD */FROM ##MTPR P WHERE PRSA_MTPR + 'B' = P.MTPR_COD 
UPDATE RCIT SET RCIT_MTPR = P.MTPR_COD , RCIT_MTPC = P.MTPR_COD FROM ##MTPR P WHERE RCIT_MTPR + 'B' = P.MTPR_COD 
UPDATE VDC1 SET VDC1_MTPR = P.MTPR_COD , VDC1_MTPC = P.MTPR_COD FROM ##MTPR P WHERE VDC1_MTPR + 'B' = P.MTPR_COD 
UPDATE VDIC SET VDIC_MTPR = P.MTPR_COD , VDIC_MTPC = P.MTPR_COD FROM ##MTPR P WHERE VDIC_MTPR + 'B' = P.MTPR_COD 
UPDATE VDOI SET VDOI_MTPR = P.MTPR_COD , VDOI_MTPC = P.MTPR_COD FROM ##MTPR P WHERE VDOI_MTPR + 'B' = P.MTPR_COD 
UPDATE VDPI SET VDPI_MTPR = P.MTPR_COD , VDPI_MTPC = P.MTPR_COD FROM ##MTPR P WHERE VDPI_MTPR + 'B' = P.MTPR_COD 
UPDATE VDPS SET VDPS_MTPR = P.MTPR_COD , VDPS_MTPC = P.MTPR_COD FROM ##MTPR P WHERE VDPS_MTPR + 'B' = P.MTPR_COD 
UPDATE VDSC SET VDSC_MTPR = P.MTPR_COD , VDSC_MTPC = P.MTPR_COD FROM ##MTPR P WHERE VDSC_MTPR + 'B' = P.MTPR_COD 


Alter Table CPCT ENABLE Trigger All
Alter Table CPIP ENABLE Trigger All
Alter Table CPSC ENABLE Trigger All
Alter Table FTIS ENABLE Trigger All
Alter Table FTIT ENABLE Trigger All
Alter Table GDFI ENABLE Trigger All
Alter Table GDRI ENABLE Trigger All
Alter Table MTEA ENABLE Trigger All
Alter Table MTEL ENABLE Trigger All
Alter Table MTES ENABLE Trigger All
Alter Table MTFO ENABLE Trigger All
Alter Table MTIV ENABLE Trigger All
Alter Table MTPC ENABLE Trigger All
Alter Table MTPE ENABLE Trigger All
Alter Table MTPL ENABLE Trigger All
Alter Table MTPP ENABLE Trigger All
Alter Table MTPR ENABLE Trigger All
Alter Table MTRE ENABLE Trigger All
Alter Table MTSA ENABLE Trigger All
Alter Table MTSL ENABLE Trigger All
Alter Table MTSO ENABLE Trigger All
Alter Table MTSW ENABLE Trigger All
Alter Table MTSX ENABLE Trigger All
Alter Table MTSY ENABLE Trigger All
Alter Table MTSZ ENABLE Trigger All
Alter Table NFDS ENABLE Trigger All
Alter Table NFIT ENABLE Trigger All
Alter Table NSFI ENABLE Trigger All
Alter Table NSOI ENABLE Trigger All
Alter Table OFIS ENABLE Trigger All
Alter Table OFIT ENABLE Trigger All
Alter Table ORIT ENABLE Trigger All
Alter Table PRNC ENABLE Trigger All
Alter Table PROR ENABLE Trigger All
Alter Table PRPN ENABLE Trigger All
Alter Table PRPR ENABLE Trigger All
Alter Table PRRA ENABLE Trigger All
Alter Table PRRO ENABLE Trigger All
Alter Table PRSA ENABLE Trigger All
Alter Table PUNC ENABLE Trigger All
Alter Table RCIT ENABLE Trigger All
Alter Table VDC1 ENABLE Trigger All
Alter Table VDIC ENABLE Trigger All
Alter Table VDOI ENABLE Trigger All
Alter Table VDPI ENABLE Trigger All
Alter Table VDPS ENABLE Trigger All
Alter Table VDSC ENABLE Trigger All

/*
SELECT DISTINCT O.NAME  FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTES%'
AND O.xtype = 'U'


SELECT DISTINCT 'Alter Table ' +  O.NAME + ' DISABLE Trigger All' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTES%'
AND O.xtype = 'U'

SELECT DISTINCT 'UPDATE ' +  O.NAME + ' SET ' + O.NAME + '_MTES = P.MTPR_COD ' +
', ' + O.NAME + '_MTES = P.MTPR_COD FROM ##MTPR P WHERE ' + O.NAME + '_MTES + ''B'' = P.MTPR_COD ' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTES%'
AND O.xtype = 'U'
*/
Alter Table MTCI DISABLE Trigger All
Alter Table MTES DISABLE Trigger All
Alter Table MTMV DISABLE Trigger All
Alter Table MTTD DISABLE Trigger All
Alter Table PUNC DISABLE Trigger All

UPDATE MTCI SET MTCI_MTES = P.MTPR_COD /*, MTCI_MTES = P.MTPR_COD */FROM ##MTPR P WHERE MTCI_MTES + 'B' = P.MTPR_COD 
UPDATE MTMV SET MTMV_MTES = P.MTPR_COD /*, MTMV_MTES = P.MTPR_COD */FROM ##MTPR P WHERE MTMV_MTES + 'B' = P.MTPR_COD 
UPDATE MTTD SET MTTD_MTES_ORI = P.MTPR_COD /*, MTTD_MTES = P.MTPR_COD */FROM ##MTPR P WHERE MTTD_MTES_ORI + 'B' = P.MTPR_COD 

Alter Table MTCI ENABLE Trigger All
Alter Table MTES ENABLE Trigger All
Alter Table MTMV ENABLE Trigger All
Alter Table MTTD ENABLE Trigger All
Alter Table PUNC ENABLE Trigger All

/*

SELECT DISTINCT O.NAME  FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTPC%'
AND O.xtype = 'U'


SELECT DISTINCT 'Alter Table ' +  O.NAME + ' DISABLE Trigger All' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTPC%'
AND O.xtype = 'U'

SELECT DISTINCT 'UPDATE ' +  O.NAME + ' SET ' + O.NAME + '_MTES = P.MTPR_COD ' +
', ' + O.NAME + '_MTES = P.MTPR_COD FROM ##MTPR P WHERE ' + O.NAME + '_MTES + ''B'' = P.MTPR_COD ' FROM SYSOBJECTS O 
INNER JOIN SYSCOLUMNS C ON C.ID = O.ID
WHERE C.NAME LIKE '%MTES%'
AND O.xtype = 'U'
*/
Alter Table ATCA DISABLE Trigger All
Alter Table ATGA DISABLE Trigger All
Alter Table ATOI DISABLE Trigger All
Alter Table ATOS DISABLE Trigger All
Alter Table CPCT DISABLE Trigger All
Alter Table CPIP DISABLE Trigger All
Alter Table CPSC DISABLE Trigger All
Alter Table FTIS DISABLE Trigger All
Alter Table FTIT DISABLE Trigger All
Alter Table GDFI DISABLE Trigger All
Alter Table GDIT DISABLE Trigger All
Alter Table GDRI DISABLE Trigger All
Alter Table MTHL DISABLE Trigger All
Alter Table MTMI DISABLE Trigger All
Alter Table MTPC DISABLE Trigger All
Alter Table MTPP DISABLE Trigger All
Alter Table NFIT DISABLE Trigger All
Alter Table NSFI DISABLE Trigger All
Alter Table NSOI DISABLE Trigger All
Alter Table OFIS DISABLE Trigger All
Alter Table OFIT DISABLE Trigger All
Alter Table ORIT DISABLE Trigger All
Alter Table PUNC DISABLE Trigger All
Alter Table RCIT DISABLE Trigger All
Alter Table VDC1 DISABLE Trigger All
Alter Table VDCX DISABLE Trigger All
Alter Table VDIC DISABLE Trigger All
Alter Table VDOI DISABLE Trigger All
Alter Table VDOS DISABLE Trigger All
Alter Table VDPI DISABLE Trigger All
Alter Table VDPS DISABLE Trigger All
Alter Table VDSC DISABLE Trigger All

/*
SELECT * FROM MTPR F
INNER JOIN ##MTPR C 
ON F.MTPR_COD = C.MTPR_COD

*/
Alter Table MTPR DISABLE Trigger All
UPDATE MTPR
SET MTPR_MTTP = 'PI/FABR'
FROM ##MTPR C 
WHERE MTPR.MTPR_COD = C.MTPR_COD
Alter Table MTPR ENABLE Trigger All

/*

SELECT * FROM MTEP
INNER JOIN ##MTPR_ANT ON MTPR_COD = MTEP_FIL
*/
IF OBJECT_ID('TempDB.dbo.##MTEP') IS NOT NULL DROP TABLE ##MTEP
SELECT * INTO ##MTEP FROM MTEP WHERE 1 = 0
INSERT INTO ##MTEP
SELECT 
	 MTEP_PAI = ##MTPR.MTPR_COD      --CONVERT(varchar(20),'') C�digo (Pai)(C�digo do produto ou insumo)
	, MTEP_FIL = SUBSTRING(##MTPR.MTPR_COD, 1, LEN(##MTPR.MTPR_COD) - 1)      --CONVERT(varchar(20),'') C�digo (Filho)(C�digo do produto ou insumo)
	, MTEP_SEQ = 10      --CONVERT(int(4),'') Sequ�ncia(Sequencia do componente)
	, MTEP_QTD = 1/##MTPR.MTPR_CPFT      --CONVERT(decimal(12),'') Quantidade(Quantidade do componente filho para uma unidade do pai)
	, MTEP_PCT = 0      --CONVERT(decimal(10),'') Perda %(Percentual de perda do insumo no processo produtivo)
	, MTEP_GNEC = 'S'      --CONVERT(char(1),'') Gera Nec.(Define se gera necessidade e exige requisi��o em ordens)
	, MTEP_USC = 'MARCIOSS'      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTEP_DTC = GETDATE()      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
FROM 
	##MTPR
INNER JOIN MTPR ON MTPR.MTPR_COD = ##MTPR.MTPR_COD
--INNER JOIN ##MTPR_ANT ON MTPR.MTPR_COD = ##MTPR.MTPR_COD

Alter Table MTEP DISABLE Trigger All
INSERT INTO MTEP 
SELECT * FROM ##MTEP
Alter Table MTEP ENABLE Trigger All


/*
SELECT * 
FROM MTEP

SELECT * 
FROM MTMV
WHERE MTMV_MTES IN 
(SELECT MTPR_COD FROM ##MTPR)
*/
Alter Table ATCA enable Trigger All
Alter Table ATGA enable Trigger All
Alter Table ATOI enable Trigger All
Alter Table ATOS enable Trigger All
Alter Table CPCT enable Trigger All
Alter Table CPIP enable Trigger All
Alter Table CPSC enable Trigger All
Alter Table FTIS enable Trigger All
Alter Table FTIT enable Trigger All
Alter Table GDFI enable Trigger All
Alter Table GDIT enable Trigger All
Alter Table GDRI enable Trigger All
Alter Table MTHL enable Trigger All
Alter Table MTMI enable Trigger All
Alter Table MTPC enable Trigger All
Alter Table MTPP enable Trigger All
Alter Table NFIT enable Trigger All
Alter Table NSFI enable Trigger All
Alter Table NSOI enable Trigger All
Alter Table OFIS enable Trigger All
Alter Table OFIT enable Trigger All
Alter Table ORIT enable Trigger All
Alter Table PUNC enable Trigger All
Alter Table RCIT enable Trigger All
Alter Table VDC1 enable Trigger All
Alter Table VDCX enable Trigger All
Alter Table VDIC enable Trigger All
Alter Table VDOI enable Trigger All
Alter Table VDOS enable Trigger All
Alter Table VDPI enable Trigger All
Alter Table VDPS enable Trigger All
Alter Table VDSC enable Trigger All

UPDATE MTPR
SET MTPR_ATV = 'S'
WHERE MTPR_COD IN (SELECT MTPR_COD FROM ##MTPR )

--SELECT 
UPDATE MTPR
SET 
	MTPR_ATVC = 'S',
	MTPR_ATV = 'S',
	MTPR_ATVV = 'S',
	MTPR_ESUN = 'PC',
	MTPR_MTUN = 'PC',
	MTPR_CPUN = 'PC',
	MTPR_PES = (A.MTPR_PES*A.MTPR_CPFT)
FROM ##MTPR_ANT A, MTPR
WHERE MTPR.MTPR_COD =A.MTPR_COD

Update MTPC
set MTPC_MTPR = A.MTPR_COD
FROM ##MTPR_ANT A
where MTPC.MTPC_cod = A.MTPR_COD


/*
SELECT * FROM ##MTPR
SELECT * FROM ##MTPR_ANT

*/
UPDATE MTPR
SET MTPR_CPUN = 'BG',
	MTPR_CPFT = 1/A.MTPR_CPFT
FROM ##MTPR_ANT A
WHERE MTPR.MTPR_COD = A.MTPR_COD




/*

SELECT * FROM ##MTPR_ANT

PESO * FATOR
SELECT * FROM MTPR WHERE MTPR_DTC >= GETDATE() -1
*/


IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #new


select 
substring(MTPR_COD, 1, len(MTPR_COD) -1) MTPR_NOVO, MTPR_COD MTPR_ANTIGO, MTPR_MTTP, MTPR_MS, MTPR_ATV, MTPR_NOM,
MTPR_MTDV, MTPR_MTLN, MTPR_MTFM, MTPR_MTUN, MTPR_MTNC,
MTPR_ORI, MTPR_PES, MTPR_DES, MTPR_NIV, MTPR_ESUN,
MTPR_ESFT, MTPR_CPUN, MTPR_CPFT, MTPR_ATVV, MTPR_CFOV,
MTPR_ATVC, MTPR_CFOC, MTPR_TOLE, MTPR_FEST, MTPR_USC,
MTPR_DTC, MTPR_USU, MTPR_DTU
 INTO #NEW
from ##mtpr


IF OBJECT_ID('TempDB.dbo.#MTPC') IS NOT NULL DROP TABLE #MTPC

SELECT IDENTITY(INT,1,1) NUM, *
INTO #MTPC
FROM #NEW


--SELECT * FROM #MTPC


DECLARE
	@i INT,
	@j1 int,
	@j2 int,
	@qtd decimal(12,2),
	@cod varchar(20),
	@cod_new varchar(20),
	@erro varchar(4000),
	@modo char(1),
	@DATA Datetime,
	@ano int,
	@mes int,
	@FATOR DECIMAL(8,6), 
	@VALOR_UNI DECIMAL(12,2)


set @i = 1

set @erro = ''

set @data = GETDATE()

--select * from #mtpc

WHILE @i <= (SELECT MAX(NUM) FROM #MTPC/* WHERE MTPR_ANTIGO = 'SSG006004B' */)
BEGIN
 select @ano = year(getdate()), @mes = month(getdate())

 select @cod = MTPR_ANTIGO, @cod_new = MTPR_NOVO, @FATOR = MTPR_CPFT from #mtpc where num = @i 

 exec MT_MTSW_SALDO @cod, 1, @ano, @mes, 'MSTOCK', '', '', @qtd output, 0, 0, 0

 --exec MT_MTSO_SALDO @cod, 5, @ano, @mes, 'ALMO01', '', @qtd output, 0, 0, 0
 --exec MT_MTSY_SALDO @cod, 5, 'ALMO01', @ano, @mes, @qtd output, 0, 0, 0
  --PRINT @I
  --PRINT @ANO
  --PRINT @MES
  --PRINT @COD
  --PRINT @QTD

 if (select @qtd)>0 begin 

  SELECT @VALOR_UNI = @QTD/@FATOR

  print 'NUM ='+convert(varchar(10),@i)+' - O C�digo � = '+@cod+ ' e seu saldo � '+convert(varchar(20),@qtd)+'  tranferir o saldo para o c�digo = '+@cod_new + 
  ' QTD ' + +convert(varchar(20),@VALOR_UNI) 
  set @modo = 'I'


  Exec MTTD_iae   @modo output  ,@erro output  ,1  ,'MTTD', '001', 0 , @DATA,'GIRKIT' ,@COD   ,'MSTOCK', @qtd, @COD_NEW ,'MSTOCK', @VALOR_UNI,'','KINKEL'  ,@DATA  ,NULL  ,NULL

  --print @modo + '/'+@erro
  --PRINT @COD_NEW
  --PRINT @QTD
 end
 set @i = @i + 1
END


--SELECT * FROM MTLN

INSERT INTO MTFM 
SELECT 
	MTFM_MTDV = 1
	,MTFM_MTLN = 'S'
	,MTFM_COD = 'SBAG'
	,MTFM_NOM = MTFM_NOM + ' BAG'
	,MTFM_MEDI = MTFM_MEDI
	,MTFM_EPRE = MTFM_EPRE
	,MTFM_COD2 = 'SBAG'
	,MTFM_USC = 'MARCIOSS'
	,MTFM_DTC = GETDATE()
	,MTFM_USU = NULL
	,MTFM_DTU = NULL
FROM MTFM
WHERE MTFM_MTDV = 1
AND MTFM_COD = 'SMDL'


UPDATE MTPR
SET MTPR.MTPR_MTFM = 'SBAG'
FROM ##MTPR A
WHERE A.MTPR_COD = MTPR.MTPR_COD + 'B'
AND MTPR.MTPR_MTFM = 'SMDL'

IF OBJECT_ID('TempDB.dbo.##MTEP_BKP') IS NOT NULL DROP TABLE ##MTEP_BKP
SELECT * INTO ##MTEP_BKP FROM MTES 

UPDATE MTES
SET  MTES_PCME = A.MTES_PCMR/##MTPR.MTPR_ESFT
FROM ##MTES A
INNER JOIN ##MTPR ON ##MTPR.MTPR_COD = A.MTES_MTPR
WHERE MTES.MTES_MTPR = A.MTES_MTPR

--SELECT *
UPDATE MTPR
SET MTPR_MTDV = 1,
	MTPR_MTLN = 'S',
	MTPR_MTFM = 'AMZ'
FROM ##MTPR_ANT  V
WHERE V.MTPR_COD = MTPR.MTPR_COD


