

drop table #new
select ordem, substring([C�digo Novo],1,3)+'.'+substring([C�digo Novo],4,3)+'.'+substring([C�digo Novo],7,3) codinto #newFROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\1_Geral\Molas_trap_usa.XLS',plan1$) where ordem is not null

--select * from #new

ALTER TABLE PROR DISABLE TRIGGER ALL
ALTER TABLE PRRA DISABLE TRIGGER ALL
ALTER TABLE PROR NOCHECK CONSTRAINT ALL
ALTER TABLE PRRA NOCHECK CONSTRAINT ALL
--select *
update [192.168.3.39].[BKP].[dbo].pror set pror_mtpr = cod
--select pror_mtpr , cod
from [192.168.3.39].[BKP].[dbo].pror, #new
where pror_cod = ordem --in ()-- 18611

ALTER TABLE PROR ENABLE TRIGGER ALL
ALTER TABLE PRRA ENABLE TRIGGER ALL
ALTER TABLE PROR CHECK CONSTRAINT ALL
ALTER TABLE PRRA CHECK CONSTRAINT ALL
