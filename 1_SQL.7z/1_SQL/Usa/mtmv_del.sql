
insert into [MDL-USA].[dbo].mtmv
select *
from mtmv
where mtmv_cod in (109105, 109106,109108,109109,109111,109112,109113,110436)
			and convert(varchar(6),MTMV_COD)+'/'+CONVERT(varchar(6),mtmv_seq) not in (select convert(varchar(6),MTMV_COD)+'/'+CONVERT(varchar(6),mtmv_seq) from [MDL-USA].[dbo].mtmv)
 
introduzimos - 109105/4 ---> faltam o 1 e 2 e 3
introduzimos - 109106/3 ---> faltam o 1 e 2
introduzimos - 109108/4 ---> faltam o 1 e 2 e 3
introduzimos - 109109/3 ---> faltam o 1 e 2
introduzimos - 109111/4 ---> faltam o 1 e 2 e 3
introduzimos - 109112/4 ---> faltam o 1 e 2 e 3
introduzimos - 109113/3 ---> faltam o 1 e 2
introduzimos - 110436/4 ---> faltam o 1 e 2 e 3
