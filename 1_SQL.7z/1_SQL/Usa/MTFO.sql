--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 29/03/2018--DEPARTAMENTO : 29/03/2018--ASSUNTO      : 29/03/2018------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#MTFO') IS NOT NULL DROP TABLE #MTFOSELECT * INTO #MTFO FROM MTFO WHERE 1 = 0INSERT INTO #MTFOSELECT 		MTFO_MTPR = rtrim(ltrim(MTFO_MTPR))+CONVERT(varchar(20),'-B')      --CONVERT(varchar(20),'') Insumo(C�digo industrial do produto)
	, MTFO_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.(C�digo do estabelecimento)
	, MTFO_GLFO --= CONVERT(int(6),'')      --CONVERT(int(6),'') Fornecedor(C�digo do fornecedor)
	, MTFO_DEFA --= CONVERT(char(1),'')      --CONVERT(char(1),'') Default(Define se fornecedor � o "default")
	, MTFO_GLFO_GLPA --= CONVERT(int(6),'')      --CONVERT(int(6),'') C�d.Parceiro(C�digo do parceiro)
	, MTFO_GLFO_NRDZ --= CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Apelido(Nome reduzido (apelido) do Parceiro)
	, MTFO_CPCO --= Null      --CONVERT(varchar(20),'') Ref.Fornecedor(C�digo do produto ou insumo utilizado pelo fornecedor)
	, MTFO_CPUN --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') Un.Fornec.(C�digo da unidade de produto utilizado pelo fornecdor)
	, MTFO_NOM --= Null      --CONVERT(varchar(50),'') Nome Ref. For.(Nome do insumo atribu�do pelo fornecedor)
	, MTFO_CPFT --= Null      --CONVERT(decimal(10),'') Fator Un.(Fator de convers�o p/ unidade do insumo em rela��o a unidade do fornecedor)
--	, MTFO_CPCT --= Null      --CONVERT(varchar(25),'') �ltima Cota��o(Documento da �ltima cota��o (SIES/SIDO/SISE/COD de CPCT))
	, MTFO_OBS --= Null      --CONVERT(varchar(255),'') Obs.(Observa��o)
	, MTFO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, MTFO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em(Data de cadastro do registro)
	, MTFO_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, MTFO_DTU = Null      --CONVERT(datetime(10),'') em(Data da �ltima atualiza��o do registro)
	, MTFO_CPCT --= Null      --CONVERT(datetime(8),'') Dt Cota��o(Data da �ltima cota��o)
	, MTFO_CPDT --= Null      --CONVERT(datetime(8),'') Dt Cota��o(Data da �ltima cota��o)
	--select *
from mtfo
where mtfo_mtpr like 'S%'
and MTFO_MTPR not in ('SCFS', 'SCBC', 'SCPB', 'SCSP', 'SCSP-B')and mtfo_mtpr not like '%-B'-------N�O ESQUECER DE TIRAR O COMENTARIO DO INSERT MTFO--INSERT INTO MTFOSELECT *FROM #MTFOWHERE mtfo_mtpr+'/'+CONVERT(VARCHAR(6),MTFO_SIES) NOT IN (SELECT mtfo_mtpr+'/'+CONVERT(VARCHAR(6),MTFO_SIES)FROM MTFO)
--and mtfo_mtpr not in (select mtes_mtpr from mtes)--MTFO_MTPR ,MTFO_SIES ,MTFO_GLFO ,MTFO_DEFA ,MTFO_GLFO_GLPA ,MTFO_GLFO_NRDZ ,MTFO_CPCO ,MTFO_CPUN ,MTFO_NOM ,MTFO_CPFT ,MTFO_CPCT ,MTFO_CPDT ,MTFO_OBS ,MTFO_USC ,MTFO_DTC ,MTFO_USU ,MTFO_DTU ,

