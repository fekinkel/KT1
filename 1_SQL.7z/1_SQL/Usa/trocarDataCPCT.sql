select *
--update cpct set CPCT_DTC = convert(datetime,'05/23/2014 13:58:38.900')
from cpct
where cpct_sta = 'OK'
			and cpct_glxx = 1