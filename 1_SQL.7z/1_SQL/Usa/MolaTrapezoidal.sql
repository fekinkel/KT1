DROP TABLE #MTPRSELECT *, mtpr_cod [mtpr_cod_OLD], mtpr_cod [mtpr_cod_S2R], mtpr_cod [mtpr_cod_S2R_old] INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD = stuff(c.MTPX_COD,2,1,'R')      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = MTPR_MTTP      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = MTPR_MS      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = MTPR_NOM      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = MTPR_MTDV      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = MTPR_MTLN     --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = MTPR_MTFM      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = MTPR_MTUN      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = MTPR_MTNC     --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = MTPR_ORI      --CONVERT(char(1),'') Origem
	, MTPR_PES = MTPR_PES      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = MTPR_DES      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = MTPR_NIV      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = MTPR_ESUN      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = MTPR_ESFT      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = MTPR_CPUN      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = MTPR_CPFT      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = MTPR_ATVV      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = MTPR_CFOV      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = MTPR_ATVC      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = MTPR_CFOC      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = MTPR_TOLE      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') Em
	, mtpr_cod
	, SUBSTRING(stuff(c.MTPX_COD,2,1,'R'),1,3)+'.'+SUBSTRING(c.MTPX_COD,4,3)+'.'+SUBSTRING(c.MTPX_COD,7,3)
	, a.MTPX_COD
	--select *--a.mtpx_cod [A], b.mtpx_cod [B], c.MTPX_COD [C], stuff(c.MTPX_COD,2,1,'R') MTPX_COD_NEW, mtpr_cod
from MTPX a, MTPX b, MTPX c, [192.168.6.2\sqlexpress].[mdl-usa].[dbo].[mtpr]-- on mtpr_cod = c.MTPX_COD
where substring(a.MTPX_MTPU,1,6) in ('151519','151520','151521')
			and replace(a.MTPX_COD,'R','S') = b.MTPX_COD
			and b.mtpx_siex = 3
			and b.MTPX_MTPU = c.MTPX_MTPU
			and c.MTPX_SIEX = 6
			and mtpr_cod = c.MTPX_COD
DROP TABLE #MTPCselect MTPR_COD MTPC_COD ,MTPR_COD MTPC_MTPR ,MTPC_NOM ,MTPC_GLMD ,MTPC_PRE ,MTPC_PRE_USU ,MTPC_PRE_DTU ,MTPC_USC ,MTPC_DTC ,MTPC_USU ,MTPC_DTUINTO #MTPC--update [192.168.6.2\sqlexpress].[mdl-usa].[dbo].MTPC set MTPC_PRE = a.MTPR_PREfrom [192.168.6.2\sqlexpress].[mdl-usa].[dbo].MTPC a, #mtprwhere mtpc_mtpr = mtpr_cod_old--CASO N�O ESTEJA CADASTRADO USAR ABAIXO--INSERT INTO [192.168.6.2\sqlexpress].[mdl-usa].[dbo].MTPCSELECT *FROM #MTPC--SEN�O FAZER UMA ATUALIZA��O--UPDATE [192.168.6.2\sqlexpress].[mdl-usa].[dbo].MTPC SET MTPC_PRE = a.MTPC_PRE, MTPC_PREC = a.MTPC_PRECSELECT *FROM #MTPC a, [192.168.6.2\sqlexpress].[mdl-usa].[dbo].MTPC bWHERE a.MTPC_COD = b.MTPC_COD --INSERT INTO [192.168.6.2\sqlexpress].[mdl-usa].[dbo].MTPRSELECT mtpr_cod_OLD, mtpr_cod_s2r, mtpr_cod_s2r_old, MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTUFROM #MTPR--WHERE CONVERT(VARCHAR(6),MTPR_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),MTPR_GLCL)FROM MTPR)
insert into [BKP].[dbo].[MTPR]SELECT mtpr_cod_s2r, b.MTPR_MTTP ,b.MTPR_MS ,'N' MTPR_ATV ,b.MTPR_NOM ,b.MTPR_MTDV ,b.MTPR_MTLN ,b.MTPR_MTFM ,b.MTPR_MTUN ,b.MTPR_MTNC ,b.MTPR_ORI ,b.MTPR_PES ,b.MTPR_DES ,b.MTPR_NIV ,b.MTPR_ESUN ,b.MTPR_ESFT ,b.MTPR_CPUN ,b.MTPR_CPFT ,b.MTPR_ATVV ,b.MTPR_CFOV ,b.MTPR_ATVC ,b.MTPR_CFOC ,b.MTPR_TOLE ,b.MTPR_USC ,b.MTPR_DTC ,b.MTPR_USU ,b.MTPR_DTUFROM #MTPR a, [BKP].[dbo].[MTPR] bwhere b.mtpr_cod = mtpr_cod_s2r_oldinsert into [BKP].[dbo].[MTES]select mtpr_cod_s2r MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTUfrom #MTPR a, [BKP].[dbo].[MTES] bwhere mtpr_cod_s2r_old = mtes_mtprinsert into [BKP].[dbo].[MTPX]select *--mtpr_cod_s2r MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTUfrom [BKP].[dbo].[MTPX] bwhere mtpr_cod_s2r_old = mtes_mtprinsert into [BKP].[dbo].[MTPU] select *--mtpr_cod_s2r MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTUfrom [BKP].[dbo].[MTPU] bDROP TABLE #MTPUSELECT *, 'XXXXXXXXXXXXXXXXXXXX' COD INTO #MTPU FROM [BKP].[dbo].MTPU WHERE 1 = 0INSERT INTO #MTPUSELECT 		MTPU_COD = '000'+CONVERT(varchar(12),(row_number() over (order by MTPR_COD desc))+4470)      --CONVERT(varchar(12),'') Ref.Internacional
	, MTPU_NOM = CONVERT(varchar(50),MTPR_NOM)      --CONVERT(varchar(50),'') Nome
	, MTPU_PLIQ = MTPR_PES      --CONVERT(decimal(12),'') Peso L�q.
	, MTPU_ESPE = CONVERT(char(1),'N')      --CONVERT(char(1),'') Especial
	, MTPU_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPU_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPU_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPU_DTU = Null      --CONVERT(datetime(10),'') em
	, mtpr_cod_s2r
	--select *
FROM #MTPR--INSERT INTO [BKP].[dbo].MTPUINSERT INTO [192.168.1.38\sqlexpress].[S2E].[dbo].MTPUSELECT MTPU_COD ,MTPU_NOM ,MTPU_PLIQ ,MTPU_ESPE ,MTPU_USC ,MTPU_DTC ,MTPU_USU ,MTPU_DTUFROM #MTPUWHERE MTPU_COD NOT IN (SELECT MTPU_COD FROM [192.168.1.38\sqlexpress].[S2E].[dbo].MTPU)
SELECT a.*
--update [192.168.1.38\sqlexpress].[S2E].[dbo].MTPU set mtpu_espe = 'N'
FROM [BKP].[dbo].MTPU a, #MTPU b
WHERE a.MTPU_cod = b.MTPU_COD
order by a.mtpu_cod

SELECT a.*
FROM [BKP].[dbo].MTPU awhere mtpu_cod in ('0004470','0004471')DROP TABLE #MTPXSELECT * INTO #MTPX FROM [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX WHERE 1 = 0INSERT INTO #MTPXSELECT 		MTPX_MTPU = CONVERT(varchar(12),mtpu_cod)      --CONVERT(varchar(12),'') Ref.Internacional
	, MTPX_SIEX = CONVERT(int,'6')      --CONVERT(int(6),'') Estab.X
	, MTPX_COD = CONVERT(varchar(20),COD)      --CONVERT(varchar(20),'') Ref.Industrial
	, MTPX_NOM = CONVERT(varchar(50),mtpu_nom)      --CONVERT(varchar(50),'') Nome
--	, MTPX_ATV = CONVERT(varchar(1),'S')      --CONVERT(varchar(1),'') ATIVO
	, MTPX_EXGR = CONVERT(varchar(12),'001')      --CONVERT(varchar(12),'') Grupo
	, MTPX_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPX_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPX_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPX_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM #MTPUINSERT INTO [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX--		 MTPX_MTPU ,MTPX_SIEX ,MTPX_COD ,MTPX_NOM ,MTPX_EXGR ,MTPX_USC ,MTPX_DTC ,MTPX_USU ,MTPX_DTUSELECT *--MTPX_MTPU ,3 MTPX_SIEX ,mtpr_cod_S2R_old MTPX_COD ,MTPX_NOM ,MTPX_EXGR ,MTPX_USC ,MTPX_DTC ,MTPX_USU ,MTPX_DTUFROM #MTPX, #mtprWHERE mtpx_cod = mtpr_cod_S2Rupdate [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX set MTPX_EXGR = a.MTPX_EXGR--select *from #mtpx a, [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX bwhere a.mtpx_mtpu = b.mtpx_mtpu			and a.mtpx_siex = b.mtpx_siex						--select * from #mtpxINSERT INTO [192.168.1.38\sqlexpress].[S2E].[dbo].MTPVselect c.MTPV_MTTV, d.mtpx_mtpu MTPV_MTPU, c.MTPV_VAL, 'KINKEL' MTPV_USC, getdate() MTPV_DTC, null MTPV_USU, null MTPV_DTUfrom  [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX a, #mtpr b, [192.168.1.38\sqlexpress].[S2E].[dbo].MTPV c, #MTPX dwhere a.mtpx_siex = 3			and a.mtpx_cod = replace(b.mtpr_cod_S2R_old,'R','S')			and mtpv_mttv = 14			and mtpv_mtpu = a.mtpx_mtpu			and d.mtpx_cod = mtpr_cod_S2R--WHERE MTPX_COD NOT IN (SELECT MTPX_COD FROM [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX)
--MTPX_MTPU ,MTPX_SIEX ,MTPX_COD ,MTPX_NOM ,MTPX_ATV ,MTPX_EXGR ,MTPX_USC ,MTPX_DTC ,MTPX_USU ,MTPX_DTU ,
--WHERE CONVERT(VARCHAR(6),MTPR_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),MTPR_GLCL)FROM MTPR)
--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU ,

DECLARE
@I INT,
@J INT

SELECT @I=SISE_NUM, @J = SISE_NUM+81
FROM [192.168.6.2\sqlexpress].[mdl-usa].[dbo].SISE
WHERE SISE_SIDO = 'CPCT'

--INSERT [192.168.6.2\sqlexpress].[mdl-usa].[dbo].CPCT
SELECT CPCT_SIES ,CPCT_SIDO ,CPCT_SISE ,(row_number() over (order by MTPR_COD desc))+@I CPCT_COD ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC ,MTPR_COD CPCT_MTPR , MTPR_COD CPCT_MTPC ,CPCT_ESPE ,CPCT_GLTX ,CPCT_GLXX ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ ,CPCT_REV ,CPCT_QTD ,CPCT_QTD_GLFO ,CPCT_CTO ,CPCT_TEL ,CPCT_FAX ,CPCT_EMAIL ,CPCT_GLCP ,CPCT_CPID ,CPCT_CPUN ,CPCT_CPFT ,CPCT_PUN ,CPCT_PUN_GLFO ,CPCT_PUND ,CPCT_PUND_GLFO ,CPCT_VACT ,CPCT_GLMD ,CPCT_IPI_ALI ,CPCT_ISS_ALI ,CPCT_ICM_ALI ,CPCT_VALT ,CPCT_GLPG ,CPCT_PENT ,CPCT_DOCF ,CPCT_OBS ,'KINKEL' CPCT_USC , GETDATE() CPCT_DTC , NULL CPCT_USU ,NULL CPCT_DTU ,CPCT_CPID_NOM
FROM [192.168.6.2\sqlexpress].[mdl-usa].[dbo].CPCT, #MTPR
WHERE CPCT_MTPR = MTPR_COD_OLD
			AND CPCT_STA = 'OK'

--UPDATE [192.168.6.2\sqlexpress].[mdl-usa].[dbo].SISE SET SISE_NUM = @J
--WHERE SISE_SIDO = 'CPCT'


--SIDOR
SELECT cpct_cpid, mtpr_cod_S2R_old, cpct_mtpr, b.*
--update [192.168.6.2\sqlexpress].[mdl-usa].[dbo].CPCT set cpct_cpid = replace(mtpr_cod_S2R_old,'R','S')
FROM [192.168.6.2\sqlexpress].[mdl-usa].[dbo].CPCT, #mtpr b
WHERE cpct_sta = 'OK'
			and cpct_mtpr = mtpr_cod_old
--			and replace(mtpr_cod_s2r,'.','') = cpct_mtpr

SELECT replace(mtpr_cod_S2R_old,'R','S'), *--MTPC_MTPR, mtpr_cod_S2R_old, b.*
--update [SIDOR].[dbo].MTPC set mtpc_mtpr = replace(mtpr_cod_S2R_old,'R','S')
FROM [SIDOR].[dbo].MTPC, #mtpr b
WHERE --cpct_sta = 'OK'
			mtpc_cod = substring(mtpr_cod_old,1,3)+'.'+substring(mtpr_cod_old,4,3)+'.'+substring(mtpr_cod_old,7,3)
--			and replace(mtpr_cod_s2r,'.','') = cpct_mtpr

select *
from #MTPR


select a.*
--update [sidor].[dbo].mtpc set mtpc_mtpr = replace(mtpr_cod_S2R_old,'R','S'), mtpc_usU = 'KINKEL', MTPC_DTU = GETDATE()
from [sidor].[dbo].mtpc a, #MTPR b
where replace(mtpr_cod_S2R_old,'R','S') = MTPC_COD 

select a.*
from [sidor].[dbo].mtpc a, #MTPR b
where mtpr_cod_S2R_old = MTPC_COD 


select *
--update [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX set MTPX_EXGR = '001'
from [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX
where MTPX_EXGR = 'S'

select MTPX_EXGR, mtpx_cod
--update [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX set MTPX_EXGR = '001'
from [192.168.1.38\sqlexpress].[S2E].[dbo].MTPX
where MTPX_EXGR not in (select EXGR_COD from [192.168.1.38\sqlexpress].[S2E].[dbo].EXGR)
group by MTPX_EXGR, mtpx_cod


