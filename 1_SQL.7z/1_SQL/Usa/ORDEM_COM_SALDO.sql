IF OBJECT_ID('TempDB.dbo.#MTMV') IS NOT NULL DROP TABLE #MTMVSELECT * INTO #MTMV FROM MTMV WHERE 1 = 0INSERT INTO #MTMVSELECT 		a.MTMV_SIES --= CONVERT(int(6),'')      --CONVERT(int(6),'') Estab.
	, a.MTMV_SIDO --= CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tip.Doc.
	, a.MTMV_SISE --= CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�rie
	, MTMV_COD = CONVERT(int,164365)      --CONVERT(int(6),'') N�mero
	, MTMV_SEQ = CONVERT(int,1)      --CONVERT(int(3),'') Seq.
	, MTMV_DAT = CONVERT(datetime,'08/01/2016')      --CONVERT(datetime(10),'') Data
	, a.MTMV_MTES --= CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Insumo
	, a.MTMV_MTTR --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Transa��o
	, a.MTMV_AUTO --= CONVERT(char(1),'')      --CONVERT(char(1),'') Nec.Auto
	, a.MTMV_TRAN --= CONVERT(char(1),'')      --CONVERT(char(1),'') Transforma��o
	, a.MTMV_ACAO --= CONVERT(char(1),'')      --CONVERT(char(1),'') C�lculo
	, a.MTMV_DIRE --= CONVERT(char(1),'')      --CONVERT(char(1),'') Opera��o
	, a.MTMV_VLIN --= CONVERT(char(1),'')      --CONVERT(char(1),'') Inf. Valor
	, a.MTMV_UCIN --= CONVERT(char(1),'')      --CONVERT(char(1),'') Ult. compra
	, a.MTMV_ATUM --= CONVERT(char(1),'')      --CONVERT(char(1),'') Atualiza Consumo
	, a.MTMV_SUCA --= CONVERT(char(1),'')      --CONVERT(char(1),'') Sucata
	, a.MTMV_SIDX --= Null      --CONVERT(varchar(4),'') Doc.Externo
	, a.MTMV_SISX --= Null      --CONVERT(varchar(3),'') S�r.Ext.
	, MTMV_CODX = 459--Null      --CONVERT(int(6),'') N�m.Ext.
	, MTMV_SEQX = 0--Null      --CONVERT(int(8),'') Seq.Ext.
	, a.MTMV_MTAL_ORI --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Origem
	, a.MTMV_SUBL_ORI --= CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local O
	, a.MTMV_TABE_ORI --= Null      --CONVERT(varchar(8),'') Tabela Origem
	, a.MTMV_SIDO_ORI --= Null      --CONVERT(varchar(4),'') Doc.Ori.
	, a.MTMV_SISE_ORI --= Null      --CONVERT(varchar(3),'') S�r.Ori
	, MTMV_COD_ORI = 459--Null      --CONVERT(int(6),'') N�mero Ori
	, MTMV_SEQ_ORI = 0--Null      --CONVERT(int(3),'') Seq.Ori
	, a.MTMV_LOTE_ORI --= Null      --CONVERT(varchar(20),'') Lote Origem
	, a.MTMV_CTPC_ORI --= Null      --CONVERT(varchar(15),'') Conta origem
	, a.MTMV_CTCC_ORI --= Null      --CONVERT(varchar(15),'') C.Custo origem
	, a.MTMV_MTAL_DES --= CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Almox.Destino
	, a.MTMV_SUBL_DES --= CONVERT(char(1),'')      --CONVERT(char(1),'') Sub-local D
	, a.MTMV_TABE_DES --= Null      --CONVERT(varchar(8),'') Tabela Destino
	, a.MTMV_SIDO_DES --= Null      --CONVERT(varchar(4),'') Doc Des
	, a.MTMV_SISE_DES --= Null      --CONVERT(varchar(3),'') S�r.Des
	, MTMV_COD_DES = 5334--Null      --CONVERT(int(6),'') N�mero Des
	, MTMV_SEQ_DES = 1--Null      --CONVERT(int(3),'') Seq.Des
	, a.MTMV_LOTE_DES --= Null      --CONVERT(varchar(20),'') Lote Destino
	, a.MTMV_CTPC_DES --= Null      --CONVERT(varchar(15),'') Conta destino
	, a.MTMV_CTCC_DES --= Null      --CONVERT(varchar(15),'') C.Custo destino
	, a.MTMV_MTAL_AUT --= Null      --CONVERT(varchar(6),'') Almox.Auto
	, b.MTMV_QTD --= 46--Null      --CONVERT(decimal(14),'') Quantidade
	, b.MTMV_VAL --= Null      --CONVERT(decimal(14),'') Valor Total
	, b.MTMV_VALM --= Null      --CONVERT(decimal(14),'') Valor Total M
	, b.MTMV_VALP --= Null      --CONVERT(decimal(14),'') Valor Padr�o
	, b.MTMV_VALA --= Null      --CONVERT(decimal(14),'') Valor Arbitrado
	, a.MTMV_GLHP --= Null      --CONVERT(varchar(5),'') Hist�rico
	, MTMV_MEN = CONVERT(varchar(256),'')      --CONVERT(varchar(256),'') Texto
	, MTMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTMV_DTU = Null      --CONVERT(datetime(10),'') em
	--select b.*
from mtmv a, mtmv b 
where (a.mtmv_cod in (170676, 164365)and a.mtmv_seq = 1)
and (b.mtmv_cod in ( 164364) and b.mtmv_seq = 3)
INSERT INTO MTMVSELECT *FROM #MTMV--W-HERE CONVERT(VARCHAR(6),MTMV_SIES) NOT IN (SELECT CONVERT(VARCHAR(6),MTMV_SIES)FROM MTMV)
--MTMV_SIES ,MTMV_SIDO ,MTMV_SISE ,MTMV_COD ,MTMV_SEQ ,MTMV_DAT ,MTMV_MTES ,MTMV_MTTR ,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX ,MTMV_SEQX ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI ,MTMV_SEQ_ORI ,MTMV_LOTE_ORI ,MTMV_CTPC_ORI ,MTMV_CTCC_ORI ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES ,MTMV_SEQ_DES ,MTMV_LOTE_DES ,MTMV_CTPC_DES ,MTMV_CTCC_DES ,MTMV_MTAL_AUT ,MTMV_QTD ,MTMV_VAL ,MTMV_VALM ,MTMV_VALP ,MTMV_VALA ,MTMV_GLHP ,MTMV_MEN ,MTMV_USC ,MTMV_DTC ,MTMV_USU ,MTMV_DTU ,

