select *
--update ftnf set FTNF_NFE_CHV = '', FTNF_NFE_STA = '', FTNF_NFE_PRO = '', FTNF_NFE_DTP = null
from ftnf
where FTNF_SIES = 5
and convert(varchar(10),FTNF_DTC,102) between '2016.01.01' and '2016.12.31'
--and FTNF_CFOP in('3.127', '3.101')