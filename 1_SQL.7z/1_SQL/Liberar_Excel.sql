SP_CONFIGURE 'show advanced options', 1
SP_CONFIGURE 'Ad Hoc Distributed Queries', 1
sp_configure 'OLE Automation Procedures', 1;
sp_configure 'Agent XPs', 1;
sp_configure 'xp_cmdshell', 1;
sp_configure 'default language', 0;

RECONFIGUREEXEC sp_MSset_oledb_prop N'Microsoft.ACE.OLEDB.12.0', N'AllowInProcess', 1
GO
EXEC sp_MSset_oledb_prop N'Microsoft.ACE.OLEDB.12.0', N'DynamicParameters', 1
GO--Usar esse link e funcionou--http://lgp1985.wordpress.com/2011/07/14/problemas-com-openrowset-no-sql-server-2008-r2/