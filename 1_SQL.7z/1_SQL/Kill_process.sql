drop table #new
SELECT
	num = identity(int,1,1)
	,Processo      = spid
	,Computador   = hostname
	,Usuario      = loginame
	,Status       = a.status
	,BloqueadoPor = blocked
	,TipoComando  = cmd
	,Aplicativo   = program_name
	,b.name
	into #new
	--select *
FROM
	master..sysprocesses a, master..sysdatabases b
WHERE
	a.dbid = b.dbid
	--and program_name <> 'dllhost.exe'
	--and (b.name = 'CFG_MDL' or
	 --b.name = 'BKP' or
	 --b.name = 'SITIO' or
	 --b.name = 'VND')
--	status in ('runnable', 'suspended')
ORDER BY
	blocked desc, status, spid

select * from #new

declare
@i int,
@j int,
@s varchar(255)

set @i = 1

while (select max(num) from #new) >= @i begin

	select @j = processo from #new where num = @i
	set @s = 'KILL '+convert(varchar(6),@j)
	--exec (@s)
	--select * from #new where num = @i	
	set @i = @i + 1
end