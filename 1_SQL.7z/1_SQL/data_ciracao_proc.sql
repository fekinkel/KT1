SELECT  SPECIFIC_NAME, CREATED,	LAST_ALTERED
FROM    information_schema . routines
WHERE   SPECIFIC_NAME  like  'RL_FAT_Mar%'
order by SPECIFIC_NAME