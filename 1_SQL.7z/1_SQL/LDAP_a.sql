	DECLARE
	@tipo char(1),
	@id varchar(50),
	@ip varchar(15),
	@porta int,
	@pc varchar(50),
	@server varchar(15),
		@name varchar(255),
		@exec nvarchar(4000),
		@tabela as user_ad,
		@pwd varchar(255),
		@OK INT	
			set @name = 'sqlserver'
			set @pwd = 'mdlmdl'
			set @tipo = 'C'
			set @id = 'rodrigod'
			begin
				--COLOCA O USU�RIO E SENHA SQLSERVER NO ADSI
				set @exec = 'master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'+char(39)+'ADSI'+char(39)+',@useself=N'+char(39)+'False'+char(39)+',@locallogin=NULL,@rmtuser=N'+char(39)+'mdl\'+@name+CHAR(39)+',@rmtpassword='+CHAR(39)+@pwd+CHAR(39)
				exec (@exec)
				--EXECUTA O ADSI, E CONSULTA USU�RIO
				set @exec = '
				select  '+char(39)+'True'+CHAR(39)+', substring(substring(ADsPath,CHARINDEX('+CHAR(39)+',OU'+CHAR(39)+',ADsPath)+4,100),1,charindex('+CHAR(39)+',OU'+CHAR(39)+',substring(ADsPath,CHARINDEX('+CHAR(39)+',OU'+CHAR(39)+',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login]
				from  openquery(adsi, '+CHAR(39)+'
				select ADsPath,
				sAMAccountName, displayName, userPassword, userPrincipalName, lastLogon, pwdLastSet
				from    '+char(39)+char(39)+'LDAP://dc=mdl,dc=com,dc=br'+char(39)+char(39)+CHAR(10)+
				'where   objectCategory = '+char(39)+char(39)+'Person'+char(39)+char(39)+CHAR(10)+
				'and objectClass = '+char(39)+char(39)+'*'+char(39)+char(39)+' and sAMAccountName = '+char(39)+char(39)+@id+char(39)+Char(39) +char(39)+'  )'
				--SE ENCONTRAR O USUARIO INSERE NA TABELA
				insert into @tabela exec (@exec)
			end
print @exec

select  ADsPath, 'True', substring(substring(ADsPath,CHARINDEX(',OU',ADsPath)+4,100),1,charindex(',OU',substring(ADsPath,CHARINDEX(',OU',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login]
				from  openquery(adsi, '
				select ADsPath,
				sAMAccountName, displayName, userPassword, userPrincipalName, lastLogon, pwdLastSet, mail
				from    ''LDAP://dc=mdl,dc=com,dc=br''
where   objectCategory = ''Person''
and objectClass = ''*'' and sAMAccountName = ''rodrigod'''  )

SELECT distinguishedName         
FROM OPENQUERY(ADSI, 'SELECT distinguishedName              
											FROM ''LDAP://DC=mdl,DC=com,dc=br''
											WHERE objectClass = ''user'' AND sAMAccountName = ''rodrigod'' ')

select  substring(ADsPath,11,charindex(',',ADsPath)-11)--ADsPath, 'True', substring(substring(ADsPath,CHARINDEX(',OU',ADsPath)+4,100),1,charindex(',OU',substring(ADsPath,CHARINDEX(',OU',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login]
from  openquery(adsi, '
				select ADsPath
				from    ''LDAP://dc=mdl,dc=com,dc=br''
where   objectClass = ''group''
and objectClass = ''group'' and member = ''CN=rodrigod,OU=Sistema,OU=MQ,OU=Basico,DC=mdl,DC=com,DC=br'' '  )

--and objectClass = ''group'' and member = ''CN=kinkel,OU=Sistema,OU=MQ,OU=Basico,DC=mdl,DC=com,DC=br'' '  )

/*
SET @Query = 'SELECT ''' + @LdapUsername 
                   + ''' Usuario, name Grupo         FROM OPENQUERY(ADSI,''             SELECT name              
                   FROM ''''LDAP://DC=dominio,DC=com''''             WHERE                  objectClass=''''group'''' AND
                   member=''''' + @Path + '''''         '')         ORDER BY name     ' 
*/

				select  'True', substring(substring(ADsPath,CHARINDEX(',OU',ADsPath)+4,100),1,charindex(',OU',substring(ADsPath,CHARINDEX(',OU',ADsPath)+5,100))) [GRUPO], displayName [Nome Completo], sAMAccountName [Nome Login], Mail Mail
				from  openquery(adsi, '
				select ADsPath,
				sAMAccountName, displayName, userPassword, userPrincipalName, lastLogon, pwdLastSet
				from    ''LDAP://dc=mdl,dc=com,dc=br''
where   objectCategory = ''Person''
and objectClass = ''*'' and sAMAccountName = ''rodrigod'''  )
ADsPath  
