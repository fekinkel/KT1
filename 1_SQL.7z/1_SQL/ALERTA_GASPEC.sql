select 'ATEN��O! COTA��O '+CONVERT(VARCHAR(6),vdc1_vdco)+'/'+CONVERT(VARCHAR(6),vdc1_COD)+' DO CLIENTE 9627/1 (GASPEC) O C�DIGO ('+vdc1_mtpc+ ') DEVE SER ('+vdc1_mtpc+ '*).'--, substring(reverse(vdc1_mtpc),1,1), *
from vdco, vdc1
where vdc1_vdco = vdco_cod
and vdc1_sies = vdco_sies
and vdc1_sido = vdco_sido
and vdc1_sise = vdco_sise
and vdco_glcl = 9627
and vdco_glcl_dig = 1
and convert(varchar(10),VDCO_DTC,102) >= '2016.01.01'
and VDCO_STA in ('EA', 'AO')
and (substring(vdc1_mtpc,1,5) in ('TABL.', 'TABH.', 'TCPM.')
or substring(vdc1_mtpc,1,4) in ('TCM.', 'TFM.'))
and substring(reverse(vdc1_mtpc),1,1) <> '*'


--TABL.xxx*
--TABH.xxx*
--TCPM.xxx*
--TCM.xxx*
--TFM.xxx*
