

declare
@di date, --data inicio
@df date, --data fim
@data date,
@i int,
@j int,
@k int,
@d int


set @data = '2012.01.01'

while (select @data) <> '2015.12.01' begin
	select @di = @data
	select @df = dateadd(day, 32, @di)
	select @k = DAY(@df)-1
	select @data = dateadd(day, - @k, @df)
	
	select @df =DATEADD(day,-1,@data)
	select @j = DAY(@df)
	set @i = 1
	set @d = 0
	WHILE @i <= @j  BEGIN
		--SELECT DATEADD(day,+@i,@di) 
		IF (SELECT (DATEPART(DW,DATEADD(day,+@i,@di) ))-1) IN (1,2,3,4,5) BEGIN
			SET @d = @d + 1 
		END
		--select @i
	
		SET @i = @i + 1
	END 
	--resultado final
	select @j, @k, @di [Data Inicio], @df [Data Fim], @data [Proxima data], @d [Dias Uteis]
	
end
