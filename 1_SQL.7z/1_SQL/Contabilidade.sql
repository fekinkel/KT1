--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 10/08/2017--DEPARTAMENTO : Contabilidade--ASSUNTO      : Darlene------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #newselect PRCC_SIES SIES, PRCC_PRCT PRCT, PRCC_ANO ANO, PRCC_MES MES, PRCC_VALP VALP, PRCC_VALS VALS, PRCC_VALR VALR
into #new
from prcc
where PRCC_ANO = 2017
and PRCC_MES = 6


select PRCC_VALP, PRCC_VALS, PRCC_VALR, VALP, VALS, VALR
--update prcc set PRCC_VALP = VALP, PRCC_VALS = VALS, PRCC_VALR = VALR
from prcc, #new
where PRCC_SIES = SIES
and PRCC_PRCT = PRCT
and PRCC_ANO = ANO
--and a.PRCC_MES =b.PRCC_MES
and PRCC_ANO = 2017
and PRCC_MES = 7
