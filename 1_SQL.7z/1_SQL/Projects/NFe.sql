declare
@nota int,
@@k varchar(5000)

set @nota = 4438

select @@k ='NFE.CriarNFe([Identificacao]'
+'NaturezaOperacao='+upper(NFOP_NOMF)
+'Modelo='+'55'
+'Serie='+'1'
+'Codigo='+convert(varchar(20),FTNF_COD)
+'Numero='+convert(varchar(20),FTNF_COD)
+'Emissao='+convert(char(10),FTNF_DAT,103)
+'Saida='+convert(char(10), FTNF_DATX,103)
+'Tipo='+'1'
+'FormaPag='+'0'
+'Finalidade='+'0'
+'[Emitente]'
+'CNPJ='+SIES_CNPJ
+'IE='+REPLACE(SIES_IE,'.','')
+'Razao='+upper(SIES_NOM)
+'Fantasia='+SIES_NRDZ
+'Fone='+SIES_TEL
+'CEP='+SIES_CEP
+'Logradouro='+SIES_END
+'Numero='+SIES_NUME
+'Complemento='
+'Bairro='+upper(SIES_BAI)
+'CidadeCod='+SIES_GLMN
+'Cidade='+upper(SIES_CID)
+'UF='+SIES_GLUF
+'[Destinatario]'
+'CNPJ='+FTCO_CNPJ
+'IE='+REPLACE(FTCO_IEs,'.','')
+'NomeRazao='+FTNF_GLXX_NOM
+'Fone='+FTCO_TEL
+'CEP='+FTCO_CEP
+'Logradouro='+FTCO_END
+'Numero='+convert(varchar(20),FTCO_NUM)
+'Complemento='
+'Bairro='+FTCO_BAI
+'CidadeCod='+FTCO_MUN
+'Cidade='+FTCO_CID
+'UF='+FTCO_EST
+'www--www--'
+'[Total]'
+'BaseICMS='+convert(varchar(20),FTNF_ICM_BAS)
+'ValorICMS='+convert(varchar(20),FTNF_ICM_VAL)
+'ValorProduto='+convert(varchar(20),FTNF_VAL)
+'ValorNota='+convert(varchar(20),FTNF_VAL)
+'[Transportador]'
+'FretePorConta='+'1'+')'
from ftnf a, nfop b, sies c, ftco d
where ftnf_cod = @nota
			and FTNF_SIDO = 'ft55'
			and FTNF_NFOP = nfop_cod
			and ftnf_sies = sies_cod
			and FTNF_SIES = ftco_sies
			and FTNF_SIDO = ftco_sido
			and FTNF_SISE = ftco_sise
			and FTNF_COD  = ftco_cod


declare
@i int,
@v varchar(3),
@s varchar(5000)
set @i = 1
set @s = ''
while @i <= (select count(1) from ftit a where FTit_SIDO = 'ft55'			and ftit_ftnf = 4438) begin
	set @v = convert(varchar(3),@i)
	set @v = replicate('0',3-len(@v))+@v
	select @s = @s 
		+'[Produto'+@v+']'
		+'CFOP='+replace(FTIT_CFOP,'.','')
		+'NCM='+replace(FTIT_MTNC,'.','')
		+'Codigo='+FTIT_MTPR
		+'Descricao='+FTIT_NOM
		+'Unidade='+FTIT_MTUN
		+'Quantidade='+convert(varchar(20),FTIT_QTD)
		+'ValorUnitario='+convert(varchar(20),FTIT_PUN)
		+'ValorTotal='+convert(varchar(20),FTIT_VAL)
		+'[ICMS'+@v+']'
		+'CST='+FTIT_TBB

	from ftit a
	where FTit_SIDO = 'ft55'
				and ftit_ftnf = @nota
				and ftit_cod = @i
	--print @v+'/'+@s
	set @i = @i + 1
end

drop table ##new

select @@k=replace(@@k, 'www--www--', @s) 
select @@k [num]
into ##new

print @@k

declare
@msg varchar(5000)

select * from ##new

--set @msg = 'bcp "select * from ##new" queryout "\\192.168.2.85\smr\Texto2.txt" -w -t -U sa -P mdl1680'
set @msg = 'bcp "select * from ##new" queryout "\\192.168.3.85\smr\Texto2.txt" -T'

--Executa o comando acima
exec master..xp_cmdshell @msg

select @msg

--select @@k
--queryout "C:\LocaldoARquivo\Arquivo.txt" -S Servidor -T -c

			
--select * from nfop			