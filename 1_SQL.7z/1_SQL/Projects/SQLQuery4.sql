select CPCT_SIES,   CPCT_SIDO ,CPCT_SISE ,identity(int,1,1) CPCT_COD    ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC   ,CPCT_MTPR            ,CPCT_MTPC            ,CPCT_ESPE  ,CPCT_GLTX ,CPCT_GLXX   ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ  ,CPCT_REV ,CPCT_QTD  ,CPCT_QTD_GLFO  ,CPCT_CTO  ,CPCT_TEL  ,CPCT_FAX                  ,CPCT_EMAIL ,CPCT_GLCP   ,CPCT_CPID            ,CPCT_CPUN ,CPCT_CPFT                               ,round(CPCT_PUND*1.3,3-len(convert(int,CPCT_PUND*1.3))) CPCT_PUN                                ,round(CPCT_PUND*1.3,3-len(convert(int,CPCT_PUND*1.3))) CPCT_PUN_GLFO                           ,round(CPCT_PUND*1.3,3-len(convert(int,CPCT_PUND*1.3))) CPCT_PUND                               ,round(CPCT_PUND*1.3,3-len(convert(int,CPCT_PUND*1.3))) CPCT_PUND_GLFO                          ,CPCT_VACT   ,CPCT_GLMD ,CPCT_IPI_ALI                            ,CPCT_ISS_ALI                            ,CPCT_ICM_ALI                            ,CPCT_VALT                               ,CPCT_GLPG ,CPCT_PENT   ,'REF. 11/2010' CPCT_DOCF            ,'CORRE��O NO VALOR REF. 11/2010 ' CPCT_OBS                                                                                                                                                                                                                                                        ,'KINKEL' CPCT_USC        ,getdate() CPCT_DTC                ,null CPCT_USU        ,null CPCT_DTU                ,CPCT_CPID_NOM
into #new
--select cpct_sies, cpct_mtpr COD_MDL, CPCT_MTPC COD_SIDOR, substring(replace(CPCT_PUND,'.',','),1,20) CPCT_PUND, replace(round(CPCT_PUND*1.3,3-len(convert(int,CPCT_PUND*1.3))),'.',',') CPCT_PUND_NEW
from cpct
where CPCT_GLXX = 1890
			and cpct_sta  = 'OK'
			and cpct_mtpc not like 'O%'
			--and cpct_sies = 1
order by cpct_sies, cpct_mtpr

select *

from #new
			