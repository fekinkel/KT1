select *
from [192.168.3.39].[sidor].[dbo].mtpr
