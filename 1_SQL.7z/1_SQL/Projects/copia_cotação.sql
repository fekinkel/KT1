declare
    @Par_erro varchar(255),
    @modo char(1),
    @cod int
set @modo = 'I'
set @cod = 174661
exec [1_cot_copia1] @par_erro output, @modo output, 1, 'vdco', '001', @cod output, 'kinkel'

print @par_erro
Print @modo
print @cod