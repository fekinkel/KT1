drop table #sigo

select SIGO_SIGR, SIGO_SIAP, SIGO_SIMD, SIGO_SIOP, SIGO_SIOP SIGO_SIOP_NEW, identity(int,1,1) NUM
into #sigo
from sigo

update #sigo set SIGO_SIOP_NEW = ''

		update #sigo set SIGO_SIOP_NEW = SIOI_SIOP
		from #sigo, [mdl_menus].[dbo].SIOI
		where SIOI_COD = '01'
					and SIOI_NOM like '%'+SIGO_SIOP+'%'

delete
from SIGA

DELETE
FROM SIAM

delete
from simD

DELETE
FROM SIMO

delete 
FROM SIop

delete 
FROM SIAP

insert into siop
select *
from [mdl_menus].[dbo].SIOP

insert into SIMD
select *
from [mdl_menus].[dbo].SIMD


insert into SIMO
select *
from [mdl_menus].[dbo].SIMO

insert into SIAP  select * from [mdl_menus].[dbo].SIAP

INSERT INTO SIAMSELECT 		SIAM_SIAP = CONVERT(varchar(6),SIAP_COD)      --CONVERT(varchar(6),'') Aplicativo
	, SIAM_SIMD = CONVERT(varchar(20),SIMD_COD)      --CONVERT(varchar(20),'') M�dulo
	, SIAM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, SIAM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIAM_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIAM_DTU = Null      --CONVERT(datetime(10),'') EmFROM SIMD, SIAP



--insert into SIAM select * from [mdl_menus].[dbo].SIAM

-- insert into simo select * from [mdl_menus].[dbo].simo

--siam_siap siam_simd            siam_usc        siam_dtc                siam_usu        siam_dtu
----------- -------------------- --------------- ----------------------- --------------- -----------------------
--S2E       CODIFICA��O          KINKEL          2011-09-08 09:24:10.217                 NULL
if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

INSERT INTO SIGASELECT 		SIGA_SIGR = CONVERT(varchar(15),SIGR_COD)      --CONVERT(varchar(15),'') Grupo
	, SIGA_SIAP = CONVERT(varchar(6),SIAP_COD)      --CONVERT(varchar(6),'') Aplicativo
	, SIGA_NOM = CONVERT(varchar(50),siap_nom)      --CONVERT(varchar(50),'') Nome
	, SIGA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, SIGA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIGA_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIGA_DTU = Null      --CONVERT(datetime(10),'') Em
FROM SIGR, SIAPORDER BY SIGR_COD, SIAP_COD

DELETE 
FROM SIGM

INSERT INTO SIGMSELECT 		SIGM_SIGR = CONVERT(varchar(15),SIGA_SIGR)      --CONVERT(varchar(15),'') Grupo
	, SIGM_SIAP = CONVERT(varchar(6),SIGA_SIAP)      --CONVERT(varchar(6),'') Aplicativo
	, SIGM_SIMD = CONVERT(varchar(20),SIMD_COD)      --CONVERT(varchar(20),'') M�dulo
	, SIGM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, SIGM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIGM_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIGM_DTU = Null      --CONVERT(datetime(10),'') Em
FROM SIGA, SIMD

DELETE
FROM SIGO


--INSERT INTO SIGO
select TOP 10 SIGO_SIGR, SIGO_SIAP, SIGO_SIMD, SIGO_SIOP_NEW, 'KINKEL', GETDATE(), NULL, NULL
FROM #SIGO
where RTRIM(LTRIM(SIGO_SIMD))+RTRIM(LTRIM(SIGO_SIOP_NEW)) NOT IN (SELECT RTRIM(LTRIM(SIMO_SIMD))+RTRIM(LTRIM(SIMO_SIOP)) FROM SIMO)
			AND SIGO_SIOP_NEW <>''
			
INSERT INTO SIGO
select SIGO_SIGR, SIGO_SIAP, SIMO_SIMD, SIGO_SIOP_NEW, 'KINKEL', GETDATE(), NULL, NULL
FROM #SIGO, SIMO
where SIGO_SIOP_NEW ='MNUF7LISTAGEMSIMPLES'--<>''
			AND SIGO_SIOP_NEW = SIMO_SIOP
			--AND RTRIM(LTRIM(SIMO_SIMD))+RTRIM(LTRIM(SIGO_SIOP_NEW)) NOT IN (SELECT RTRIM(LTRIM(SIMO_SIMD))+RTRIM(LTRIM(SIMO_SIOP)) FROM SIMO)
GROUP BY SIGO_SIGR, SIGO_SIAP, SIMO_SIMD, SIGO_SIOP_NEW
ORDER BY COUNT(1) DESC


declare
@i int

set @i = 1

while @i <= (select MAX(num) from #sigo) begin
--	select SIGO_SIOP, '%'+SIOI_NOM+'%', CONVERT(varchar(6),@i) [I] from #sigo, [mdl_menus].[dbo].SIOI 	where SIOI_COD = '01' 				and SIOI_NOM like '%'+SIGO_SIOP+'%' 				and num = @i
	if (select count(1) from #sigo, [mdl_menus].[dbo].SIOI where SIOI_COD = '01' and SIOI_NOM like '%'+SIGO_SIOP+'%' and num = @i) >0 begin
		update #sigo set SIGO_SIOP_NEW = SIOI_SIOP
		from #sigo, [mdl_menus].[dbo].SIOI
		where SIOI_COD = '01'
					and SIOI_NOM like '%'+SIGO_SIOP+'%'
					and num = @i
	end else begin
		select SIGO_SIOP, SIGO_SIOP_NEW, *
		from #sigo
		where num = @i	
	end
	set @i = @i + 1
	print @i
end


select '--',*
from #sigo
where SIGO_SIOP_NEW = ''

--   ACBAUX          S2R       CONT�BIL             ATIVA/INATIVA LAN�AMENTO                           
--   ACBAUX          S2R       CONT�BIL             LAN�AMENTOS CONT�BEIS                              
--   ACBAUX          S2R       CONT�BIL             LAN�AMENTOSF5                                      
--   ACBAUX          S2R       CONT�BIL             LAN�AMENTOSF7                                      
--   ACBAUX          S2R       CONT�BIL             LAN�AMENTOSF8                                      
--   ACBAUX          S2R       CONT�BIL             LAN�AMENTOSF9                                      
--   ACBAUX          S2R       CONT�BIL             MNULANCAMENTOSCONTABEIS                            
--   ACBAUX          S2R       CONT�BIL             PARTIDASF5                                         
--   ACBAUX          S2R       CONT�BIL             PARTIDASF7                                         
select *
from [mdl_menus].[dbo].SIOI
where SIOI_COD = '01'
			and SIOI_NOM like '%ATIVA/INATIVA LAN�AMENTO%'

