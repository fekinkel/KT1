select MTPC_COD, CPCT_PUND_NEW, MTPC_PRE, MTPC_PRE/CPCT_PUND_NEW
--update mtpc set mtpc_pre = CPCT_PUND_NEW
from [dos].[dbo].sidor1, mtpc
where COD_SIDOR = mtpc_cod
			and MTPC_COD not like ('P22%')
			and MTPC_PRE/CPCT_PUND_NEW<=1
			

--select * from sidor1
