if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
declare
@i int,
@j int

--set @i = 17276
set @i = 17309
set @j = 17309

--PARA ALTERAR ESSES LAN�AMENTO FOI PRECISO DESLIGAR AS TRIGGERS

--select * from ctlc 	where CTLC_DOC like '1/FT55/001/17276'
drop table #new
		
select *, identity(int,1,1)[NUM]
into #new
from ctlc
where 1=0

While @i <= @j begin

	insert into #new
	select *
	from ctlc
	where CTLC_DOC like '1/FT55/001/'+convert(varchar(6),@i)

	--select *
	--update CTLC set CTLC_PCCD = '1901010006', CTLC_PCCC = '1901010006'
	--from ctlc a, #new b
	--where a.CTLC_SIES = b.CTLC_SIES
	--			and a.CTLC_SIDO = b.CTLC_SIDO
	--			and a.CTLC_SISE = b.CTLC_SISE
	--			and a.CTLC_CTLA = b.CTLC_CTLA
	--			and a.CTLC_COD  = b.CTLC_COD
	
	set @i = @i + 1
end

select @i=1, @j=max(num) from #new

while @i <= @j begin

	--select *
	update CTLC set CTLC_PCCD = '1901010006', CTLC_PCCC = '1901010006'
	from ctlc a, #new b
	where a.CTLC_SIES = b.CTLC_SIES
				and a.CTLC_SIDO = b.CTLC_SIDO
				and a.CTLC_SISE = b.CTLC_SISE
				and a.CTLC_CTLA = b.CTLC_CTLA
				and a.CTLC_COD  = b.CTLC_COD
				and b.num = @i
	
	print 'De '+convert(varchar(6),@i)+'/'+convert(varchar(6),@j)
	set @i = @i + 1
end
--select * from #new

