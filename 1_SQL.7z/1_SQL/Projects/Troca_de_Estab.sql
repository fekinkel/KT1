if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

--insert into prnc
declare
@npai int,
@cod int,
@SIEX int,
@SIDX varchar(4),
@SISX varchar(3),
@NUMX int,
@sies_de int,
@sies_pa int

--N�mero do pedido de vendas
--Item do pedido de vendas
set @npai = 124275
set @cod = 11
set @sies_de = 5
set @sies_pa = 7

select @siex = PRNC_SIEX   , @sidx=PRNC_SIDX , @sisx = PRNC_SISX , @numx = PRNC_NUMX   
from prnc
where prnc_npai = @npai
			and prnc_cod = @cod
			and prnc_sies  = @sies_de
			
--select 7 PRNC_SIES   ,PRNC_SIDO ,PRNC_SISE ,PRNC_NPAI   ,PRNC_COD    ,PRNC_EMT ,PRNC_STA ,PRNC_MTPR            ,PRNC_ORDE ,PRNC_GLFO   ,PRNC_MTAL ,PRNC_CTPC       ,PRNC_CTCC       ,PRNC_QTD                                ,PRNC_DTE                ,PRNC_QTDA                               ,PRNC_VALA                               ,PRNC_VALAM                              ,PRNC_DTUA               ,PRNC_QTDC                               ,PRNC_VALC                               ,PRNC_VALCM                              ,PRNC_QTDS                               ,PRNC_VALS                               ,PRNC_VALSM                              ,PRNC_PROJ            ,PRNC_CLIE                                          ,PRNC_SIEX   ,PRNC_SIDX ,PRNC_SISX ,PRNC_NUMX   ,PRNC_SEQX   ,PRNC_OBS                                           ,PRNC_ESPE                                                                                                                                                                                                                                                        ,PRNC_USC        ,PRNC_DTC                ,PRNC_USU        ,PRNC_DTU
update prnc set prnc_sies = @sies_pa, prnc_siex = @sies_pa
from prnc
where prnc_npai = @npai
			and prnc_cod = @cod
			and prnc_sies  = @sies_de

--select *
update pror set pror_sies = @sies_pa, pror_siex = @sies_pa
from pror
where pror_sies = @siex
			and pror_sido = @sidx
			and pror_sise = @sisx
			and pror_cod = @numx
		
--select *
update prnc set prnc_sies = @sies_pa, prnc_siex = @sies_pa
from prnc
where prnc_sies = @siex
			and prnc_sido = @sidx
			and prnc_sise = @sisx
			and prnc_npai = @numx

			