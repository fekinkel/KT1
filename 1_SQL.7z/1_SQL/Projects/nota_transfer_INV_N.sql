------------------------------------------------------------------------------------------
-- DATA             - AUTOR - HIST�RICO
-- 21/09/2009 18:59 -- SCIED -- Refeito a partir do RL-MAT-Kardex-Almox10
-- 22/09/2009 08:30 -- SCIED -- Hip�tese fundamental: Ordens somente s�o criadas em:
--                           -- Almoxarifados que n�o s�o do estoque (MTAL-FISI='N')
                             -- Almoxarifados que s�o de sub-local controlado (MTAL-SUBL='S')
                             -- O Sub-local contem 'PROR' (n�o estou usando essa hip�tese)
-- 30/09/2009 15:51 -- SCIED -- Compatibiliza��o com o Reg Inv Cont�bil
-- 01/10/2009 14:40 -- SCIED -- Corre��o do saldo em qtd das ordens
-- 09/10/2009 13:44 -- SCIED -- Adequa��o para Ordens de Compra antigas (08/10/2009)
-- 16/10/2009 17:19 -- SCIED -- No m�todo arbitrado atualiza os custos unit�rios antes de concluir
-- 21/10/2009 19:39 -- SCIED -- Corre��o na Fase 3 Rlri_cod<>0 por�m n�o � ordem
-- 29/10/2009 18:19 -- SCIED -- Atualiza o custo m�dio unit�rio para estoque sempre
-- 29/01/2010 13:37 -- SCIED -- Coment�rio p/ Fahmmy: n�o expurga mttp_inv do insumo se transitou no almox apresenta inv
-- 29/01/2010 14:50 -- SCIED -- Voltamos atr�s: expurga mttp_inv do insumo se transitou no almox apresenta inv
-- 04/03/2010 16:26 -- SCIED -- Ordena��o adicional pelo campo Rlri-orde
-- 30/03/2010 16:26 -- SCIED -- Ordena��o adicional pelo campo Rlri-orde tamb�m p/ op��o cont�bil
------------------------------------------------------------------------------------------
if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

declare
   @vSies    int
  ,@vMtes    varchar(20)  -- Deve ser passado '????????????????????' p/ todos
  ,@vMtal    varchar(6)   -- Deve ser passado '??????' para todos
  ,@vMes     int
  ,@vAno     int
  ,@vPccDe     varchar(15)
  ,@vPccAte    varchar(15)
  ,@vZerados char(1) -- Define se imprime insumos Zerados
  ,@vEstoque char(1) -- Define se so imprime almox de estoque
  ,@vInv     char(1) -- se 'S': S� almox com mtal_inv='S' ou 'N': S� almox com mtal_inv='N'
  ,@vValor   char(1) -- 'S': Custo Real ou 'N': Custo arbitrado
  ,@vRICont  char(1) -- 'S': Registro de invent�rio cont�bil; 'N': Registro de Invent�rio comum (muda ordena��o)
  ,@vOrder   char(1) -- N- Ordena��o pela NCM ; I - Ordena��o pelo Insumo

set @vSies = 1
set @vMtes = '????????????????????'
set @vMtal = '??????'
set @vMes  = 12
set @vAno  = 2010
set @vPccDe		= '0000000000'
set @vPccAte	= '9999999999'
set @vZerados ='N' -- Define se imprime insumos Zerados
set @vEstoque ='N' -- Define se so imprime almox de estoque
set @vInv     ='N' -- se 'S': S� almox com mtal_inv='S' ou 'N': S� almox com mtal_inv='N'
set @vValor   ='S' -- 'S': Custo Real ou 'N': Custo arbitrado
set @vRICont  ='N' -- 'S': Registro de invent�rio cont�bil; 'N': Registro de Invent�rio comum (muda ordena��o)
set @vOrder   ='I' -- N- Ordena��o pela NCM ; I - Ordena��o pelo Insumo

CREATE TABLE #tmpRlri
   ( Rlri_mtes       varchar(20)
   , Rlri_nom        varchar(50)
   , Rlri_mtun       varchar(3)
   , Rlri_mtnc       varchar(8)        -- NCM
   , Rlri_ctpc       varchar(15)
   , Rlri_ctpc_nom   varchar(50)
   , Rlri_mtal       varchar(6)
   , Rlri_fisi       char(1)
   , Rlri_orde       varchar(25)
   , Rlri_subl       varchar(25)
   , Rlri_orde_sido  varchar(4)
   , Rlri_orde_sise  char(3)
   , Rlri_orde_cod   int
   , Rlri_orde_qtdo  decimal(14,3) -- Qtde atual sob o ponto de vista do relat�rio
   , Rlri_qtd_alm    decimal(14,3) -- Qtde atual sob o ponto de vista do relat�rio
   , Rlri_vun_alm    decimal(14,6) -- Valor unit�rio
   , Rlri_mat_alm    decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
   , Rlri_mdo_alm    decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
   , Rlri_val_alm    decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
   , Rlri_qtd_tot    decimal(14,6) -- Qtde atual do insumo no estoque (fisi='S') p/ apurar CMU
   , Rlri_cmur       decimal(14,6) -- Custo m�dio atual p/ valorizar saldos do estoque
   , Rlri_val_tot    decimal(14,6) -- Valor atual insumo no estoque (fisi='S') p/ apurar CMU
   , Rlri_tipo       varchar(2) -- Tipo de insumo para valoriza��o pelo custo arbitrado
   )
-- tipos de insumos
-- 'PA' set @fator= 0.70
-- 'PP' set @fator= 1.50
-- 'MP' set @fator= 1.00
-- 'NA' set @fator= 1.00
-- outros set @fator= 1.00
declare
 @Rlri_mtes       varchar(20)
,@Rlri_nom        varchar(50)
,@Rlri_mtun       varchar(3)
,@Rlri_mtnc       varchar(8)        -- NCM
,@Rlri_ctpc       varchar(15)
,@Rlri_ctpc_nom   varchar(50)
,@Rlri_mtal       varchar(6)
,@Rlri_fisi       char(1)
,@Rlri_orde       varchar(25)
,@Rlri_subl       varchar(25)
,@Rlri_orde_sido  varchar(4)
,@Rlri_orde_sise  char(3)
,@Rlri_orde_cod   int
,@Rlri_orde_qtdo  decimal(14,3) -- Qtde atual sob o ponto de vista do relat�rio
,@Rlri_qtd_alm    decimal(14,3) -- Qtde atual sob o ponto de vista do relat�rio
,@Rlri_vun_alm    decimal(14,6) -- Valor unit�rio
,@Rlri_mat_alm    decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
,@Rlri_mdo_alm    decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
,@Rlri_val_alm    decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
,@Rlri_qtd_tot    decimal(14,6) -- Qtde atual do insumo no estoque (fisi='S') p/ apurar CMU
,@Rlri_cmur       decimal(14,6) -- Custo m�dio atual p/ valorizar saldos do estoque
,@Rlri_val_tot    decimal(14,6) -- Valor atual insumo no estoque (fisi='S') p/ apurar CMU
,@Rlri_tipo       varchar(2) -- Tipo de insumo para valoriza��o pelo custo arbitrado

CREATE TABLE #tmpCmur
   ( mtes varchar(20)
   , cmur decimal(14,6) -- Valor atual insumo no estoque (fisi='S') p/ apurar CMU
   )
DECLARE
    @mtes varchar(20)
   ,@cmur decimal(14,6) -- Valor atual insumo no estoque (fisi='S') p/ apurar CMU


-- 1. Obtenho o cursor MTSZ para relat�rio
-- 2. Crio tempor�rio com custo m�dio para registros do estoque
-- 3. Analiso sub-local
-- 4. Normalizo custo m�dio para itens do estoque
-- 5. Acrescento horas de apontamentos

if @vMtes='????????????????????' begin
   if @vMtal='??????' begin
      declare cMtsz cursor local static for
      Select mtpr=MTSZ_MTPR, mttp_inv=MTTP_INV, mtpr_nom=MTPR_NOM, mtpr_mtun=MTPR_MTUN, mtnc=MTPR_MTNC, mrp=isnull(MTES_MRP,'N'), mttp_ctpc=isnull(MTTP_CTPC,'9999999999'), tipo=MTTP_CPO1, mtal=MTSZ_MTAL, esto=isnull(mtal_fisi,'N'), subc=isnull(mtal_subl,'N'), inv=isnull(mtal_inv,'N'), mtal_ctpc=isnull(mtal_ctpc,'9999999999'), subl=isnull(MTSZ_SUBL,'')
            ,saldo=sum(isnull(MTSz_QENT,0)-isnull(MTSz_QSAI,0))
            ,valor=sum(isnull(MTSz_VMER,0)-isnull(MTSz_VMSR,0))
      from MTSz, mtal, mtes, mtpr, mttp
      where mttp_cod =mtpr_mttp
        and mtpr_cod =mtes_mtpr
        and mtes_mtpr=mtsz_mtpr and mtes_sies=mtsz_sies
        and mtal_sies=mtsz_sies and mtal_cod =mtsz_mtal
        and mtal_salc='S'
      --and mtal_inv='S'
      --and mttp_inv='S'
        -- Restri��es vari�veis
        and MTSz_SIES=@vSies and MTSz_ANO=@vANO and MTSz_MES<=@vMES
      group by MTSz_MTPR, MTTP_INV, MTPR_NOM, MTPR_MTUN, MTPR_MTNC, MTES_MRP, MTTP_CTPC, MTTP_CPO1, MTTP_CPO1, MTSz_MTAL, mtal_fisi, mtal_subl, mtal_inv, mtal_ctpc, MTSz_SUBL
      order by MTSz_MTPR, MTSz_MTAL, MTSz_SUBL
   end else begin -- if @vMtal='??????' begin
      declare cMtsz cursor local static for
      Select mtpr=MTSZ_MTPR, mttp_inv=MTTP_INV, mtpr_nom=MTPR_NOM, mtpr_mtun=MTPR_MTUN, mtnc=MTPR_MTNC, mrp=isnull(MTES_MRP,'N'), mttp_ctpc=isnull(MTTP_CTPC,'9999999999'), tipo=MTTP_CPO1, mtal=MTSZ_MTAL, esto=isnull(mtal_fisi,'N'), subc=isnull(mtal_subl,'N'), inv=isnull(mtal_inv,'N'), mtal_ctpc=isnull(mtal_ctpc,'9999999999'), subl=isnull(MTSZ_SUBL,'')
            ,saldo=sum(isnull(MTSz_QENT,0)-isnull(MTSz_QSAI,0))
            ,valor=sum(isnull(MTSz_VMER,0)-isnull(MTSz_VMSR,0))
      from MTSz, mtal, mtes, mtpr, mttp
      where mttp_cod =mtpr_mttp
        and mtpr_cod =mtes_mtpr
        and mtes_mtpr=mtsz_mtpr and mtes_sies=mtsz_sies
        and mtal_sies=mtsz_sies and mtal_cod =mtsz_mtal
        and mtal_salc='S'
      --and mtal_inv='S'
      --and mttp_inv='S'
        -- Restri��es vari�veis
        and MTSz_SIES=@vSies and MTSz_ANO=@vANO and MTSz_MES<=@vMES
        and MTSz_MTAL=@vMtal
      group by MTSz_MTPR, MTTP_INV, MTPR_NOM, MTPR_MTUN, MTPR_MTNC, MTES_MRP, MTTP_CTPC, MTTP_CPO1, MTTP_CPO1, MTSz_MTAL, mtal_fisi, mtal_subl, mtal_inv, mtal_ctpc, MTSz_SUBL
      order by MTSz_MTPR, MTSz_MTAL, MTSz_SUBL
   end
end else begin --if @vMtes='????????????????????' begin
   if @vMtal='??????' begin
      declare cMtsz cursor local static for
      Select mtpr=MTSZ_MTPR, mttp_inv=MTTP_INV, mtpr_nom=MTPR_NOM, mtpr_mtun=MTPR_MTUN, mtnc=MTPR_MTNC, mrp=isnull(MTES_MRP,'N'), mttp_ctpc=isnull(MTTP_CTPC,'9999999999'), tipo=MTTP_CPO1, mtal=MTSZ_MTAL, esto=isnull(mtal_fisi,'N'), subc=isnull(mtal_subl,'N'), inv=isnull(mtal_inv,'N'), mtal_ctpc=isnull(mtal_ctpc,'9999999999'), subl=isnull(MTSZ_SUBL,'')
            ,saldo=sum(isnull(MTSz_QENT,0)-isnull(MTSz_QSAI,0))
            ,valor=sum(isnull(MTSz_VMER,0)-isnull(MTSz_VMSR,0))
      from MTSz, mtal, mtes, mtpr, mttp
      where mttp_cod =mtpr_mttp
        and mtpr_cod =mtes_mtpr
        and mtes_mtpr=mtsz_mtpr and mtes_sies=mtsz_sies
        and mtal_sies=mtsz_sies and mtal_cod =mtsz_mtal
        and mtal_salc='S'
      --and mtal_inv='S'
      --and mttp_inv='S'
        -- Restri��es vari�veis
        and Mtsz_mtpr=@vMtes
        and MTSz_SIES=@vSies and MTSz_ANO=@vANO and MTSz_MES<=@vMES
      group by MTSz_MTPR, MTTP_INV, MTPR_NOM, MTPR_MTUN, MTPR_MTNC, MTES_MRP, MTTP_CTPC, MTTP_CPO1, MTTP_CPO1, MTSz_MTAL, mtal_fisi, mtal_subl, mtal_inv, mtal_ctpc, MTSz_SUBL
      order by MTSz_MTPR, MTSz_MTAL, MTSz_SUBL
   end else begin -- if @vMtal='??????' begin
      declare cMtsz cursor local static for
      Select mtpr=MTSZ_MTPR, mttp_inv=MTTP_INV, mtpr_nom=MTPR_NOM, mtpr_mtun=MTPR_MTUN, mtnc=MTPR_MTNC, mrp=isnull(MTES_MRP,'N'), mttp_ctpc=isnull(MTTP_CTPC,'9999999999'), tipo=MTTP_CPO1, mtal=MTSZ_MTAL, esto=isnull(mtal_fisi,'N'), subc=isnull(mtal_subl,'N'), inv=isnull(mtal_inv,'N'), mtal_ctpc=isnull(mtal_ctpc,'9999999999'), subl=isnull(MTSZ_SUBL,'')
            ,saldo=sum(isnull(MTSz_QENT,0)-isnull(MTSz_QSAI,0))
            ,valor=sum(isnull(MTSz_VMER,0)-isnull(MTSz_VMSR,0))
      from MTSz, mtal, mtes, mtpr, mttp
      where mttp_cod =mtpr_mttp
        and mtpr_cod =mtes_mtpr
        and mtes_mtpr=mtsz_mtpr and mtes_sies=mtsz_sies
        and mtal_sies=mtsz_sies and mtal_cod =mtsz_mtal
        and mtal_salc='S'
      --and mtal_inv='S'
      --and mttp_inv='S'
        -- Restri��es vari�veis
        and Mtsz_mtpr=@vMtes
        and Mtsz_mtal=@vMtal
        and MTSz_SIES=@vSies and MTSz_ANO=@vANO and MTSz_MES<=@vMES
      group by MTSz_MTPR, MTTP_INV, MTPR_NOM, MTPR_MTUN, MTPR_MTNC, MTES_MRP, MTTP_CTPC, MTTP_CPO1, MTTP_CPO1, MTSz_MTAL, mtal_fisi, mtal_subl, mtal_inv, mtal_ctpc, MTSz_SUBL
      order by MTSz_MTPR, MTSz_MTAL, MTSz_SUBL
   end
end

open cMTSZ
if Cursor_Status('local', 'cMtsz')>0 begin
   -- =================================================================
   -- Fase 1: Insere registro de saldos (qtdade e valor) a partir de MTSZ
   -- =================================================================
   declare @mtsz_mtpr varchar(20), @mttp_inv char(1), @mtpr_nom varchar(50), @mtpr_mtun char(3), @mtpr_mtnc varchar(10), @mtes_mrp char(1), @mttp_ctpc varchar(15), @mttp_cpo1 varchar(2)
         , @mtsz_mtal varchar(6), @mtal_fisi char(1), @mtal_subl char(1), @mtal_inv char(1), @mtal_ctpc varchar(15), @mtsz_subl varchar(25), @mtsz_qsal decimal(14,3), @mtsz_vsal decimal(14,6)
   -- Vari�veis auxiliares
   declare @vData datetime
   declare @LenPccDDe int, @LenPccAte int
   set @LenPccDDe=len(@vPccDe)
   set @LenPccAte=len(@vPccAte)
   declare @mttp_ctpc_nom   varchar(50)
   -- Vari�veis auxiliares p/ o saldo inicial
   declare
      @vMtpr  varchar(20),
   --   @vSies  int,
   --   @vAno   int,        -- Se passado Zero adota o ano corrente
   --   @vMes   int,        -- Se passado Zero adota o mes corrente (deve ser passado -1 para Saldo inicial)
      @vQtd   decimal(14,6),
      @vVal   decimal(14,6),
      @vVam   decimal(14,6),
      @vVaa   decimal(14,6),
      @vQtd_C decimal(14,6),
      @vVal_C decimal(14,6),
      @vVam_C decimal(14,6),
      @vVaa_C decimal(14,6),
      @vQtd_V decimal(14,6)
   declare @vCMU decimal(14,6), @vCMM decimal(14,6)
   declare @vSubl varchar(25)
   declare @cMtpr varchar(20), @cSies varchar(10), @cSido varchar(10), @cSise varchar(10), @cCod varchar(10), @cSeq varchar(10)
   declare @vCod int, @pror_qtdo decimal(16,6), @pror_qtdr decimal(16,6), @pror_sta char(2)
   declare @vEntra char(1)
   -- Calcula a data do �ltimo dia do mes/ano solicitado
   set dateformat YMD
   if @vMes<=9 begin
      set @vData  = cast (cast(@vAno as char(4))+'/0'+cast(@vMes as char(1)) +'/01' as datetime)
   end else begin
      set @vData  = cast (cast(@vAno as char(4))+'/' +cast(@vMes as char(2)) +'/01' as datetime)
   end
   set @vData  = @vData +31
   set @vData  = @vData -day(@vData)

   fetch next from cMTSZ into @mtsz_mtpr, @mttp_inv, @mtpr_nom, @mtpr_mtun, @mtpr_mtnc, @mtes_mrp, @mttp_ctpc, @mttp_cpo1, @mtsz_mtal, @mtal_fisi, @mtal_subl, @mtal_inv, @mtal_ctpc, @mtsz_subl, @mtsz_qsal, @mtsz_vsal
   while @@fetch_status=0 begin
      set @Rlri_mtes = @mtsz_mtpr
      set @Rlri_nom  = @mtpr_nom
      set @Rlri_mtun = @mtpr_mtun
      set @Rlri_mtnc = @mtpr_mtnc
      set @vMtpr     = @mtsz_mtpr
      -- Enquanto for o mesmo insumo : Inicializa dados constantes
      if @mttp_ctpc='9999999999' begin
         set @mttp_ctpc_nom='Insumo sem conta cont�bil definida'
      end else begin
         if exists(select 1 from CTPC where CTPC_COD=@mttp_ctpc) begin
            select @mttp_ctpc_nom=ctpc_nom from CTPC where CTPC_COD=@mttp_ctpc
         end else begin
            set @mttp_ctpc_nom='Conta cont�bil n�o cadastrada'
         end
      end
      while @@fetch_status=0 and @mtsz_mtpr=@Rlri_mtes begin
         -- Restri��es
-- 29/01/2010 13:37 -- SCIED -- Coment�rio p/ Fahmmy: n�o expurga mttp_inv do insumo se transitou no almox apresenta inv
--         if (@vInv='N') or ( (@vInv='S') and (@mtal_inv='S') and (@mttp_inv='S') ) begin
-- 29/01/2010 14:50 -- SCIED -- Voltamos atr�s: expurga mttp_inv do insumo se transitou no almox apresenta inv
--         if (@vInv='N') or ( (@vInv='S') and (@mtal_inv='S') ) begin
         if (@vInv='N') or ( (@vInv='S') and (@mtal_inv='S') and (@mttp_inv='S') ) begin
            if (@vEstoque='N') or (@mtal_fisi='S') begin
               set @Rlri_mtal = @mtsz_mtal -- varchar(6)
               set @Rlri_fisi = @mtal_fisi -- char(1)
               set @Rlri_subl = @mtsz_subl -- char(1)
               -- Inicializo dados da conta cont�bil
               if @mtal_fisi='S' begin
                  set @Rlri_ctpc    =@mttp_ctpc
                  set @Rlri_ctpc_nom=@mttp_ctpc_nom
               end else begin
                  set @Rlri_ctpc=@mtal_ctpc
                  if @mtal_ctpc='9999999999' begin
                     set @Rlri_ctpc_nom='Almoxarifado cont�bil sem conta definida'
                  end else begin
                     if exists (select 1 from CTPC where ctpc_cod=@Rlri_ctpc) begin
                        select @Rlri_ctpc_nom=ctpc_nom from CTPC where ctpc_cod=@Rlri_ctpc
                     end else begin
                        set @Rlri_ctpc_nom='Conta cont�bil n�o cadastrada'
                     end
                  end
               end

               -- Filtro de contas cont�beis
               if substring(@Rlri_ctpc,1,@LenPccDde)>=@vPccDe and substring(@Rlri_ctpc,1,@LenPccAte)<=@vPccAte begin
                  --set @Rlri_mtes       = -- varchar(20)
                  --set @Rlri_nom        = -- varchar(50)
                  --set @Rlri_mtun       = -- varchar(3)
                  --set @Rlri_mtnc       = -- varchar(8)        -- NCM
                  --set @Rlri_ctpc       = -- varchar(15)
                  --set @Rlri_ctpc_nom   = -- varchar(50)
                  --set @Rlri_mtal       = @mtsz_mtal -- varchar(6)
                  --set @Rlri_fisi       = @mtal_fisi -- char(1)
                  set @Rlri_orde       = ''  -- varchar(25)
                  set @Rlri_orde_sido  = ''  -- varchar(4)
                  set @Rlri_orde_sise  = ''  -- char(3)
                  set @Rlri_orde_cod   = 0  -- int
                  set @Rlri_orde_qtdo  = 0  -- int
                  set @Rlri_qtd_alm    = @mtsz_qSal -- decimal(14,3) -- Qtde atual sob o ponto de vista do relat�rio
                  set @Rlri_vun_alm    = 0.00-- decimal(14,6) -- Valor unit�rio
                  set @Rlri_mat_alm    = @mtsz_vSal -- decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
                  set @Rlri_mdo_alm    = 0.00 -- decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
                  set @Rlri_val_alm    = @mtsz_vSal -- decimal(14,2) -- Valor atual sob o ponto de vista do relat�rio
                  set @Rlri_qtd_tot    = 0.00 -- decimal(14,6) -- Qtde atual do insumo no estoque (fisi='S') p/ apurar CMU
                  set @Rlri_cmur       = 0.00 -- decimal(14,6) -- Custo m�dio atual p/ valorizar saldos do estoque
                  set @Rlri_val_tot    = 0.00 -- decimal(14,6) -- Valor atual insumo no estoque (fisi='S') p/ apurar CMU
                  set @Rlri_tipo       = @mttp_cpo1 -- varchar(2) -- Tipo de insumo para valoriza��o pelo custo arbitrado
                  -- An�lise das ordens:
                  -- 1. Ordens s� existem em almox que n�o s�o do estoque (mtal_fisi='N')
                  -- 1. Ordens s� existem em almox que s�o de saldo controlado
                  -- 2. Ordens s� existem em almox de sub-local controlado (mtal_subl='S')
                  if (@mtal_fisi='S') or (@mtal_subl='N') begin -- N�o � poss�vel existir ordem nos almoxs do estoque ou sem sub-local controlado
                     -- Inclui registro no relat�rio
                     if (@vZerados='S') or (@Rlri_qtd_alm<>0.00) begin
                        if exists (select 1 from #tmpRlri where Rlri_mtes=@rlri_mtes and Rlri_mtal=@rlri_mtal and Rlri_orde=@rlri_orde) begin
                           update #tmpRlri set
                            Rlri_qtd_alm=Rlri_qtd_alm+@Rlri_qtd_alm
                           ,Rlri_mat_alm=Rlri_mat_alm+@Rlri_val_alm
                           ,Rlri_val_alm=Rlri_val_alm+@Rlri_val_alm
                           where Rlri_mtes=@rlri_mtes and Rlri_mtal=@rlri_mtal and Rlri_orde=@rlri_orde
                        end else begin
                           insert #tmpRlri
                           values (@Rlri_mtes,@Rlri_nom ,@Rlri_mtun,@Rlri_mtnc,@Rlri_ctpc,@Rlri_ctpc_nom,@Rlri_mtal,@Rlri_fisi,@Rlri_orde,@Rlri_subl,@Rlri_orde_sido,@Rlri_orde_sise,@Rlri_orde_cod,@Rlri_orde_qtdo,@Rlri_qtd_alm,@Rlri_vun_alm,@Rlri_mat_alm,@Rlri_mdo_alm,@Rlri_val_alm,@Rlri_qtd_tot,@Rlri_cmur   ,@Rlri_val_tot,@Rlri_tipo)
                           -- Para valoriza��o pelo custo M�dio
                           if @mtal_fisi='S' begin
                              if not exists (select 1 from #tmpCMUR where mtes=@Rlri_mtes) begin
                                 -- Inicializo os dados de saldo inicial do estoque p/ o primeiro dia do mes da data DE
                                 set @vMtpr=@Rlri_mtes
                                 exec MT_MTSX_SALDO @vMtpr, @vSies, @vAno, @vMes, @vQtd output, @vVal output, @vVam output, @vVaa output, @vQtd_C output, @vVal_C output, @vVam_C output, @vVaa_C output, @vQtd_V output
                                 -- Atualiza o custo m�dio do estoque p/ o insumo
                                 if ((@vQtd<>0) and (@vVal<>0)) begin
                                    -- C�lculo din�mico
                                    set @vCMU  = round(@vVal/@vQtd,6)
                                    set @vCMM  = round(@vVam/@vQtd,6)
                                 end else begin
                                    -- Inicializo o �ltimo bom
                                    exec MT_MTSX_CMU @vMtpr ,@vSies ,@vAno  ,@vMes  ,@vCMU output, @vCMM output
                                 end
                                 insert #tmpCMUR
                                 values (@Rlri_mtes,@vCMU)
                              end
                           end
                        end
                     end
                  end else begin -- if (@mtal_fisi='S') or (@mtal_subl='N') begin -- N�o � poss�vel existir ordem nos almoxs do estoque ou sem sub-local controlado
                     -- Decodifica o sub-local para analisar se � ordem de produ��o
                     exec mt_NumNecOrdStr @Rlri_Subl, @cSies output, @cSido output, @cSise output, @cCod output, @cSeq output
                     --?? cSies pode ser diferente de vSies ???
                     set @vCod= cast(@cCod as int)
--                   set @vSeq= cast(@cSeq as int)
                     set @Rlri_orde_sido=@cSido
                     set @Rlri_orde_sise=@cSise
                     set @Rlri_orde_cod =@vCod

                     set @vEntra='S'

                     -- Verifica a exist�ncia da ordem de fabrica��o
                     if exists (select 1 from PROR where pror_sies=@vSies and pror_sido=@cSido and pror_sise=@cSise and pror_cod=@vCod and pror_orde='N') begin
                        -- Inicializo o insumo da Ordem
                        select @cMtpr=pror_mtpr, @pror_qtdo=pror_qtdo, @pror_sta=isnull(pror_sta,'CA')
                        from pror where pror_sies=@vSies and pror_sido=@cSido and pror_sise=@cSise and pror_cod=@vCod and pror_orde='N'
                        set @Rlri_orde_qtdo =@pror_qtdo

                        if @pror_sta<>'CA' begin
                           if @cMtpr<>@vMtpr begin -- � componente: deve substituir a referencia
                              set @Rlri_mtes       = @cMtpr
                              --set @Rlri_nom        = -- varchar(50)
                              --set @Rlri_mtun       = -- varchar(3)
                              --set @Rlri_mtnc       = -- varchar(8)        -- NCM
                              -- Inicializa Nome, unidade, NCM e conta cont�bil
                              if exists(select 1 from MTPR where MTPR_COD=@cMtpr) begin
                                 select @Rlri_nom=MTPR_NOM, @Rlri_mtun=MTPR_MTUN, @Rlri_mtnc=MTPR_MTNC from MTPR where MTPR_COD=@cMtpr
                              end else begin
                                 select @Rlri_nom='Insumo n�o encontrado em MTPR', @Rlri_mtun='???', @Rlri_mtnc='99999999'
                              end
                           end -- Quando � o pai n�o se altera
                           set @Rlri_orde    = @cSies+'/'+@cSido+'/'+@cSise+'/'+@cCod
                           set @Rlri_tipo    = 'PP'
                        end else begin
                           set @vEntra='N'
                        end

                     -- Verifica a exist�ncia da Ordem de Compra
                     end else if exists (select 1 from PROR where pror_sies=@vSies and pror_sido=@cSido and pror_sise=@cSise and pror_cod=@vCod and pror_orde='S') begin
                        -- Simplesmente n�o entra no Relat�rio
                        set @vEntra='N'
                     -- N�o � ordem
                     end else begin
                        -- Saldo no fatura???
                        -- Fahmy : custo arbitrado
                        -- Sob-encomenda, assume o sub-local por enquanto
                        if @mtes_mrp='N' begin
                           set @Rlri_orde = @cSies+'/'+@cSido+'/'+@cSise+'/'+@cCod+'/'+@cSeq
                           set @Rlri_tipo ='PP'
                        end else begin
                           set @Rlri_orde = ''
                        end
                        -- Anal�tico
                        set @Rlri_orde_cod =0
-- Debug p/ local fatura anal�tico
                        set @Rlri_orde = @cSies+'/'+@cSido+'/'+@cSise+'/'+@cCod+'/'+@cSeq
                        -- Gambiarra : Filtro de res�duo de ordens que n�o existem mais
                        if @Rlri_mtal='PROCES' begin
                           set @vEntra='N'
                        end
                     end

                     -- Insere registro no relat�rio
                     if ((@vZerados='S') or (@Rlri_qtd_alm<>0.00) or (@Rlri_val_alm<>0)) and (@vEntra='S') begin
                        if exists (select 1 from #tmpRlri where Rlri_mtes=@rlri_mtes and Rlri_mtal=@rlri_mtal and Rlri_orde=@rlri_orde) begin
                           update #tmpRlri set
                            Rlri_qtd_alm=Rlri_qtd_alm+@Rlri_qtd_alm
                           ,Rlri_mat_alm=Rlri_mat_alm+@Rlri_val_alm
                           ,Rlri_val_alm=Rlri_val_alm+@Rlri_val_alm
                           where Rlri_mtes=@rlri_mtes and Rlri_mtal=@rlri_mtal and Rlri_orde=@rlri_orde
                        end else begin
                           insert #tmpRlri
                           values (@Rlri_mtes,@Rlri_nom ,@Rlri_mtun,@Rlri_mtnc,@Rlri_ctpc,@Rlri_ctpc_nom,@Rlri_mtal,@Rlri_fisi,@Rlri_orde,@Rlri_subl,@Rlri_orde_sido,@Rlri_orde_sise,@Rlri_orde_cod,@Rlri_orde_qtdo,@Rlri_qtd_alm,@Rlri_vun_alm,@Rlri_mat_alm,@Rlri_mdo_alm,@Rlri_val_alm,@Rlri_qtd_tot,@Rlri_cmur   ,@Rlri_val_tot,@Rlri_tipo)
                        end
                     end
                  end
               end
            end --if (@vEstoque='N') or (@mtal_fisi='S') begin
         end --if (@vInv='N') or (@mtal_inv='S') begin
         fetch next from cMTSZ into @mtsz_mtpr, @mttp_inv, @mtpr_nom, @mtpr_mtun, @mtpr_mtnc, @mtes_mrp, @mttp_ctpc, @mttp_cpo1, @mtsz_mtal, @mtal_fisi, @mtal_subl, @mtal_inv, @mtal_ctpc, @mtsz_subl, @mtsz_qsal, @mtsz_vsal
      end --while @@fetch_status=0 and @mtsz_mtpr=@Rlri_mtes begin
   end --while @@fetch_status=0 begin

   -- =================================================================
   -- Fase 2: Atualiza os valores de MDO sobre as Ordens
   -- =================================================================
   -- Saldo a receber em Valor de M�o de Obra em Aberto para a Ordem por competencia
   if (@vValor='S') begin -- Custo Real
      if (@vEstoque='N') begin -- Hip�tese : Apontamentos s�o em ordens, n�o existem ordens no estoque
         declare cPrak cursor local static for
         select distinct prak_pror_sido, prak_pror_sise, prak_pror_cod
         from PRAK where prak_sies=@vSies
         and convert(char(10), prak_data, 102)>='2009.01.01'
         and convert(char(10), prak_data, 102)<=@vDAta
         open cPrak
         if Cursor_Status('local','cPrak')>0 begin
            declare @vValP decimal(16,6), @vValS decimal(16,6), @vValR decimal(16,6)
            --declare @pras_tipo varchar(2)
            declare @mtal_salc char(1)
   --         fetch next from cPras into @cSido, @cSise, @vCod, @pras_tipo, @vValp
            fetch next from cPrak into @cSido, @cSise, @vCod
            while @@fetch_status=0 begin
               -- Saldo a receber em Valor de M�o de Obra em Aberto para a Ordem por competencia
               exec PR_PRAK_SALDO @vSies, @cSido, @cSise, @vCod, @vData, @vValP output, @vValS output, @vValR output
               if Round(@vValP,2)>0.00 begin
                  -- Se ordem n�o cadastrada apontamento ser� ignorado
                  if exists (select 1 from PROR where pror_sies=@vSies and pror_sido=@cSido and pror_sise=@cSise and pror_cod=@vCod) begin
                     -- Inicializo os dados da ordem
                     select @vMtpr=pror_mtpr, @Rlri_mtal=pror_mtal, @pror_qtdo=pror_qtdo from PROR where pror_sies=@vSies and pror_sido=@cSido and pror_sise=@cSise and pror_cod=@vCod
                     set @Rlri_mtes    = @vMtpr
                     set @Rlri_orde    = Cast(@vSies as varchar)+'/'+@cSido+'/'+@cSise+'/'+cast(@vCod as varchar)
                     set @Rlri_mdo_alm = @vValP
            --debug print 'Insumo:' +@rlri_mtes +' Ordem:'+ @rlri_orde
                     if exists (select 1 from #tmpRlri where Rlri_mtes=@Rlri_mtes and Rlri_mtal=@Rlri_mtal and Rlri_orde=@Rlri_orde) begin
            --debug print 'ordem j� existe existe'
                        update #tmpRlri set
                         Rlri_mdo_alm=Rlri_mdo_alm +@Rlri_mdo_alm
                        ,Rlri_val_alm=Rlri_val_alm +@Rlri_mdo_alm
                        where Rlri_mtes=@Rlri_mtes and Rlri_mtal=@Rlri_mtal and Rlri_orde=@Rlri_orde
                     end else begin
                        -- Para incluir novo registro devo analisar todas as restricoes
                        if (@vMtes=@vMtpr) or (@vMtes='????????????????????') begin
                           if (@vMtal='??????') or (@vMtal=@Rlri_mtal) begin
                              if exists (select 1 from MTAL where mtal_sies=@vSies and mtal_cod=@Rlri_Mtal) begin
                                 select @Mtal_fisi=isnull(mtal_fisi,'N'), @mtal_salc=isnull(mtal_salc,'N'), @mtal_subl=isnull(mtal_subl,'N'), @mtal_ctpc=isnull(mtal_ctpc,'9999999999'), @mtal_inv=isnull(mtal_inv,'N')
                                 from MTAL where mtal_sies=@vSies and mtal_cod=@Rlri_Mtal
                                 if (@vEstoque=@mtal_fisi) or (@vEstoque='N')  begin
                                    if (@vInv=@mtal_inv) or (@vInv='N') begin
                                       if @mtal_salc='S' begin
                                          -- Inicializa Nome, unidade, NCM e conta cont�bil
                                          if exists(select 1 from MTPR where MTPR_COD=@vMtpr) begin
                                             select @mtpr_nom=MTPR_NOM, @mtpr_mtun=MTPR_MTUN, @mtpr_mtnc=MTPR_MTNC from MTPR where MTPR_COD=@vMtpr
                                             -- Inicializa a conta cont�bil de estoque do insumo
                                             if exists (select 1 from MTTP, MTPR where MTTP_COD=MTPR_MTTP and MTPR_COD=@vMtpr) begin
                                                select @mttp_ctpc=isnull(mttp_ctpc,'9999999999'), @mttp_cpo1=isnull(mttp_cpo1,'??') from MTTP, MTPR where MTTP_COD=MTPR_MTTP and MTPR_COD=@vMtpr
                                                if @mttp_ctpc='9999999999' begin
                                                   set @mttp_ctpc_nom='Insumo sem conta cont�bil definida'
                                                end else begin
                                                   if exists(select 1 from CTPC where CTPC_COD=@mttp_ctpc) begin
                                                      select @mttp_ctpc_nom=ctpc_nom from CTPC where CTPC_COD=@mttp_ctpc
                                                   end else begin
                                                      set @mttp_ctpc_nom='Conta cont�bil n�o cadastrada'
                                                   end
                                                end
                                             end else begin
                                                select @mttp_ctpc='9999999999', @mttp_ctpc_nom='Insumo sem conta cont�bil definida', @mttp_cpo1='??'
                                             end
                                          end else begin
                                             select @mtpr_nom='Insumo n�o encontrado em MTPR', @mtpr_mtun='???', @mtpr_mtnc='99999999'
                                             -- Inicializa a conta cont�bil de estoque do insumo
                                             select @mttp_ctpc='9999999999', @mttp_cpo1='??'
                                          end
                                          set @Rlri_nom =@mtpr_nom
                                          set @Rlri_mtun=@mtpr_mtun
                                          set @Rlri_mtnc=@mtpr_mtnc

                                          -- Inicializo dados da conta cont�bil
                                          if @mtal_fisi='S' begin
                                             set @Rlri_ctpc    =@mttp_ctpc
                                             set @Rlri_ctpc_nom=@mttp_ctpc_nom
                                          end else begin
                                             set @Rlri_ctpc=@mtal_ctpc
                                             if @mtal_ctpc='9999999999' begin
                                                set @Rlri_ctpc_nom='Almoxarifado cont�bil sem conta definida'
                                             end else begin
                                                if exists (select 1 from CTPC where ctpc_cod=@Rlri_ctpc) begin
                                                   select @Rlri_ctpc_nom=ctpc_nom from CTPC where ctpc_cod=@Rlri_ctpc
                                                end else begin
                                                   set @Rlri_ctpc_nom='Conta cont�bil n�o cadastrada'
                                                end
                                             end
                                          end
                                          -- Filtro de contas cont�beis
                                          if substring(@Rlri_ctpc,1,@LenPccDde)>=@vPccDe and substring(@Rlri_ctpc,1,@LenPccAte)<=@vPccAte begin
                                             set @Rlri_fisi       = @mtal_fisi
                                             set @Rlri_subl       = ''
                                             set @Rlri_orde_sido  = @cSido
                                             set @Rlri_orde_sise  = @cSise
                                             set @Rlri_orde_cod   = @vCod
                                             set @Rlri_orde_qtdo  = @pror_qtdo
            --                                    set @Rlri_qtd_alm    = 0
                                             if @Rlri_qtd_alm<>0 begin
                                                set @Rlri_vun_alm    = @vValp/@Rlri_qtd_alm -- Residuo
                                             end else begin
                                                set @Rlri_vun_alm    = 0 -- Residuo
                                             end
                                             set @Rlri_mat_alm    = 0
                                             set @Rlri_mdo_alm    = @vValp
                                             set @Rlri_val_alm    = @Rlri_mat_alm +@Rlri_mdo_alm
                                             set @Rlri_qtd_tot    = 0
                                             set @Rlri_cmur       = 0
                                             set @Rlri_val_tot    = 0
                                             set @Rlri_qtd_tot    = 0
            --                                    set @Rlri_tipo       = @mttp_cpo1
                                             set @Rlri_tipo       = 'PP'
                                             insert #tmpRlri
                                             values (@Rlri_mtes,@Rlri_nom ,@Rlri_mtun,@Rlri_mtnc,@Rlri_ctpc,@Rlri_ctpc_nom,@Rlri_mtal,@Rlri_fisi,@Rlri_orde,@Rlri_subl,@Rlri_orde_sido,@Rlri_orde_sise,@Rlri_orde_cod,@Rlri_orde_qtdo
                                             ,@Rlri_qtd_alm,@Rlri_vun_alm,@Rlri_mat_alm,@Rlri_mdo_alm,@Rlri_val_alm,@Rlri_qtd_tot,@Rlri_cmur   ,@Rlri_val_tot,@Rlri_tipo)
                                          end
                                       end --if @mtal_salc='S' begin
                                    end --if (@vInv=@mtal_inv) or (@vInv='N') begin
                                 end --if (@vEstoque=@mtal_fisi='S') or (@vEstoque='N')  begin
                              end --if exists (select 1 from MTAL where mtal_sies=@vSies and mtal_cod=@Rlri_Mtal) begin
                           end --if (@vMtal='??????') or (@vMtal=@Rlri_mtal) begin
                        end --if (@vMtes=@vMtpr) or (@vMtes='????????????????????') begin
                     end -- j� existe registro no relat�rio
                  end -- if exists (select 1 from PROR where pror_sies=@vSies and pror_sido=@cSido and pror_sise=@cSise and pror_cod=@vCod) begin
               end -- if Round(@vValP,2)>0.00 begin
               fetch next from cPrak into @cSido, @cSise, @vCod
   --            fetch next from cPras into @cSido, @cSise, @vCod, @pras_tipo, @vValp
            end --while @@fetch_status=0 begin
         end
         close cPrak
         deallocate cPrak
      end
   end

   -- =================================================================
   -- Fase 3: Atualiza a quantidade em aberto e custo unit�rio p/ as ordens de produ��o
   -- =================================================================
   declare cPror cursor local static for
   -- Local fatura com sub-local: saldo zerado por esse crit�rio
--   select Rlri_mtes, Rlri_mtal, Rlri_orde ,Rlri_orde_sido ,Rlri_orde_sise ,Rlri_orde_cod ,Rlri_orde_qtdo from #tmpRlri where Rlri_orde_cod<>0
   select Rlri_mtes, Rlri_mtal, Rlri_orde ,Rlri_orde_sido ,Rlri_orde_sise ,Rlri_orde_cod ,Rlri_orde_qtdo from #tmpRlri where Rlri_orde<>'' and  Rlri_orde_cod<>0
   open cPror
   if Cursor_Status('local','cPror')>0 begin
      fetch next from cPror into @Rlri_mtes, @Rlri_mtal, @Rlri_orde, @Rlri_orde_sido ,@Rlri_orde_sise ,@Rlri_orde_cod, @Rlri_orde_qtdo
      while @@fetch_status=0 begin
         set @pror_qtdr= [dbo].[fpr_PRORQTDR] (@vSies, @Rlri_orde_sido, @Rlri_orde_sise, @Rlri_orde_cod, @vData)
         set @vQtd=Round(@Rlri_orde_qtdo -@pror_qtdr, 3)
         if (@vQtd>0.000) begin
            update #tmpRlri set
             Rlri_qtd_alm=@vQtd
            ,Rlri_vun_alm=Round(Rlri_val_alm/@vQtd, 6)
            where Rlri_mtes=@rlri_mtes and Rlri_mtal=@rlri_mtal and Rlri_orde=@rlri_orde
         end else begin
            update #tmpRlri set
             Rlri_qtd_alm=0.000
            ,Rlri_vun_alm=0.000000
            where Rlri_mtes=@rlri_mtes and Rlri_mtal=@rlri_mtal and Rlri_orde=@rlri_orde
         end
         fetch next from cPror into @Rlri_mtes, @Rlri_mtal, @Rlri_orde, @Rlri_orde_sido ,@Rlri_orde_sise ,@Rlri_orde_cod, @Rlri_orde_qtdo
      end
   end
   close cPror
   deallocate cPror

   -- =================================================================
   -- Fase 4: Atualiza os custos m�dios segundo o crit�rio de sele��o do relat�rio
   -- =================================================================
   -- Atualiza os valores e custos unit�rios do estoque
   declare cCMUR cursor local static for
   select MTES, CMUR from #tmpCMUR order by mtes
   open cCMUR
   if Cursor_Status('local','cCMUR')>0 begin
      fetch next from cCMUR into @mtes, @cmur
      while @@fetch_status=0 begin
         update #tmpRlri set
          Rlri_vun_alm= @cmur
         ,Rlri_mat_alm= round(Rlri_qtd_alm*@cmur,2)
         ,Rlri_val_alm= round(Rlri_qtd_alm*@cmur,2)
         ,Rlri_cmur   = @cmur
         where Rlri_mtes=@mtes and Rlri_fisi='S'
         fetch next from cCMUR into @mtes, @cmur
      end
   end
   close cCMUR
   deallocate cCMUR
   if (@vValor='S') begin -- Custo Real
      -- Atualiza os custos unit�rios dos almox cont�beis (exceto ordens)
      update #tmpRlri set Rlri_vun_alm=Round(Rlri_val_alm/Rlri_qtd_alm,6)
--      where Rlri_fisi='N' and Rlri_qtd_alm<>0.000 and rlri_orde=''
      where Rlri_fisi='N' and Rlri_qtd_alm<>0.000 and rlri_orde_cod=0
   end else begin -- Custo arbitrado
      if exists(select 1 from #tmpRlri) begin -- Custo arbitrado
--         update #tmpRlri set Rlri_mdo_alm=0 -- Zera todos os valores de MDO
-- debug
--         select distinct Rlri_mtes, Rlri_tipo from #tmpRlri order by Rlri_mtes
         declare cTipo cursor local static for
         select distinct Rlri_mtes, Rlri_tipo from #tmpRlri order by Rlri_mtes
         open cTipo
         if cursor_status('local','cTipo')>0 begin
--            declare @mtpr varchar(20), @tipo char(2), @pMax decimal(16,6), @fator decimal(8,2)
            declare @mtpr varchar(20), @pMax decimal(16,6), @fator decimal(8,2), @tipo char(2)
            fetch next from cTipo into @mtpr, @tipo
            while @@fetch_status=0 begin
               -- Depende do tipo de Insumo
               if          (@tipo='PA') begin
                  set @fator= 0.70
                  set @pMax = 0
                  exec FT_PUN_MAX @mtpr, @vSies, @vAno, @vMes, @pMax output
                  set @Rlri_vun_alm = @pMax*@fator
                  update #tmpRlri set
                   Rlri_vun_alm=@Rlri_vun_alm
                  ,Rlri_mat_alm=Round(@Rlri_vun_alm*Rlri_qtd_alm,2)
                  ,Rlri_val_alm=Round(@Rlri_vun_alm*Rlri_qtd_alm,2)
                  where Rlri_mtes=@mtpr and Rlri_tipo=@tipo
               end else if @tipo='PP' begin
                  set @fator= 1.50
                  update #tmpRlri set
                   Rlri_vun_alm=Round(Rlri_val_alm*@Fator,6) -- Pre�o unit�rio igual ao total (por enquanto)
                  ,Rlri_mat_alm=Round(Rlri_val_alm*@Fator,2)
                  ,Rlri_val_alm=Round(Rlri_val_alm*@Fator,2)
                  where Rlri_mtes=@mtpr and Rlri_tipo=@tipo
               end else if @tipo='MP' begin
                  set @fator= 1.00
               end else if @tipo='NA' begin
                  set @fator= 1.00
               end else begin
                  set @fator= 1.00
               end
               fetch next from cTipo into @mtpr, @tipo
            end
            -- Atualiza o custo unit�rio
            update #tmpRlri set Rlri_vun_alm=round(Rlri_val_alm/Rlri_qtd_alm,6)
            where rlri_qtd_alm<>0
/*
            -- Atualiza o custo unit�rio p/ os insumos tipo PP
            update #tmpRlri set Rlri_vun_alm=round(Rlri_val_alm/Rlri_qtd_alm,6)
            where rlri_qtd_alm<>0 and rlri_tipo='PP'
*/
         end
         close cTipo
         deallocate cTipo
      end
   end
end --if Cursor_Status('local', 'cMtsz')>0 begin
close cMTSZ
deallocate cMTSZ

--select * from #tmpCmur
drop table #tmpCmur

-- Resultado
if @vRICont='S' begin
   if @vOrder='I' begin
      if @vZerados='S' begin
         select * from #tmpRlri
         order by Rlri_ctpc, Rlri_mtal, Rlri_mtes, Rlri_mtnc, Rlri_orde
      end else begin
         select * from #tmpRlri
         where Rlri_qtd_alm<>0 or Rlri_val_alm<>0
         order by Rlri_ctpc, Rlri_mtal, Rlri_mtes, Rlri_mtnc, Rlri_orde
      end
   end else begin
      if @vZerados='S' begin
         select * from #tmpRlri
         order by Rlri_ctpc, Rlri_mtal, Rlri_mtnc, Rlri_mtes, Rlri_orde
      end else begin
         select * from #tmpRlri
         where Rlri_qtd_alm<>0 or Rlri_val_alm<>0
         order by Rlri_ctpc, Rlri_mtal, Rlri_mtnc, Rlri_mtes, Rlri_orde
     end
   end
end else begin
   if @vOrder='I' begin
      if @vZerados='S' begin
         select * from #tmpRlri
         order by Rlri_mtal, Rlri_mtes, Rlri_mtnc, Rlri_orde
      end else begin
         select * from #tmpRlri
         where Rlri_qtd_alm<>0 or Rlri_val_alm<>0
         order by Rlri_mtal, Rlri_mtes, Rlri_mtnc, Rlri_orde
      end
   end else begin
      if @vZerados='S' begin
         select * from #tmpRlri
         order by Rlri_mtal, Rlri_mtnc, Rlri_mtes, Rlri_orde
      end else begin
         select * from #tmpRlri
         where Rlri_qtd_alm<>0 or Rlri_val_alm<>0
         order by Rlri_mtal, Rlri_mtnc, Rlri_mtes, Rlri_orde
      end
   end
end

--drop table #tmpRlri
--drop table #new 
drop table #new1
--CRIA TABELA TEMPOR�RIA ACRESCENTANDO DIVIS�O, LINHA, FAM�LIA E GRUPO
select a.*, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, 99 [gp]
into #new1
from #tmpRlri a, mtpr b
where a.Rlri_mtes = b.mtpr_cod
			AND (Rlri_qtd_alm<>0 or Rlri_val_alm<>0)
			--and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'

--select * from #new1 where mtpr_mtdv = 2500

--ATUALIZA OS C�DIGOS DOS ITENS QUE N�O TEM PONTO
update #new1 set Rlri_mtes = Rlri_mtes+'.'
--select *
from #new1
where charindex('.',Rlri_mtes)<=0			

--CRIA TABELA TEMPOR�RIA AGRUPANDO POR DIVIS�O, LINHA E FAM�LIA PARA CADA CONTA CONT�BIL
select Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))[pre_cod], count(1) [qde], max(Rlri_mtnc) [ncm], identity(int,1,1) [num], 999999 [grupo], 0 [soma], max(Rlri_ctpc) Rlri_ctpc
into #new
from #new1
where Rlri_ctpc = '1110070001'
			and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'
group by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))
order by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))

insert into #new
select '00000000' Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))[pre_cod], count(1) [qde], max(Rlri_mtnc)[ncm], 999999 [grupo], 0 [soma], max(Rlri_ctpc) Rlri_ctpc
from #new1
where (Rlri_ctpc = '1110070004' or	Rlri_ctpc = '1110070003')
			and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'	
group by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))
order by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))

insert into #new
select Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))[pre_cod], count(1) [qde], max(Rlri_mtnc)[ncm], 999999 [grupo], 0 [soma], max(Rlri_ctpc) Rlri_ctpc
from #new1
where Rlri_ctpc = '1110070002'
			and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'			
group by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))
order by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))

insert into #new
select Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))[pre_cod], count(1) [qde], max(Rlri_mtnc)[ncm], 999999 [grupo], 0 [soma], max(Rlri_ctpc) Rlri_ctpc
from #new1
where Rlri_ctpc = '1110070005'
			--and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'			
group by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))
order by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))

insert into #new
select Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))[pre_cod], count(1) [qde], max(Rlri_mtnc)[ncm], 999999 [grupo], 0 [soma], max(Rlri_ctpc) Rlri_ctpc
from #new1
where Rlri_ctpc = '1110070006'
			and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'			
group by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))
order by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))

insert into #new
select Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))[pre_cod], count(1) [qde], max(Rlri_mtnc)[ncm], 999999 [grupo], 0 [soma], max(Rlri_ctpc) Rlri_ctpc
from #new1
where Rlri_ctpc = '1110070007'
			and Rlri_ctpc_nom <> 'PRODUTOS EM PROCESSO'			
group by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))
order by Rlri_mtnc, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, substring(Rlri_mtes, 1, charindex('.', Rlri_mtes))


--select * from #new order by num

--Rlri_mtnc mtpr_mtdv mtpr_mtln mtpr_mtfm pre_cod              qde         ncm      num         grupo       soma        MTPR_COD             MTPR_MTTP                 MTPR_MS MTPR_ATV MTPR_NOM                                                                         MTPR_MTDV MTPR_MTLN MTPR_MTFM MTPR_MTUN MTPR_MTNC MTPR_ORI MTPR_PES                                MTPR_DES                                                                                                                                                                                                                                         MTPR_NIV    MTPR_ESUN MTPR_ESFT                               MTPR_CPUN MTPR_CPFT                               MTPR_ATVV MTPR_CFOV MTPR_ATVC MTPR_CFOC MTPR_TOLE                               MTPR_USC        MTPR_DTC                MTPR_USU        MTPR_DTU                Rlri_mtes            Rlri_nom                                           Rlri_mtun Rlri_mtnc Rlri_ctpc       Rlri_ctpc_nom                                      Rlri_mtal Rlri_fisi Rlri_orde                 Rlri_subl                 Rlri_orde_sido Rlri_orde_sise Rlri_orde_cod Rlri_orde_qtdo                          Rlri_qtd_alm                            Rlri_vun_alm                            Rlri_mat_alm                            Rlri_mdo_alm                            Rlri_val_alm                            Rlri_qtd_tot                            Rlri_cmur                               Rlri_val_tot                            Rlri_tipo
----------- --------- --------- --------- -------------------- ----------- -------- ----------- ----------- ----------- -------------------- ------------------------- ------- -------- -------------------------------------------------------------------------------- --------- --------- --------- --------- --------- -------- --------------------------------------- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ ----------- --------- --------------------------------------- --------- --------------------------------------- --------- --------- --------- --------- --------------------------------------- --------------- ----------------------- --------------- ----------------------- -------------------- -------------------------------------------------- --------- --------- --------------- -------------------------------------------------- --------- --------- ------------------------- ------------------------- -------------- -------------- ------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- ---------
--0         1500      2600      3300      B46.                 1           0        3           1           5           B46.010.011          MP-MAT�RIA PRIMA          M       S        BUCHA CE CPL D1.625" L3.9375"                                                    1500      2600      3300      PC        84669410  0        0.000                                   BUCHA CE CPL D1.625" L3.9375"                                                                                                                                                                                                                    0           PC        1.000000                                PC        1.000000                                S         5.101.B   S         1.101.B   5.0000                                  MDLMIGRA        2005-09-27 14:43:57.530 NULL            NULL                    B46.010.011          BUCHA CE CPL D1.625" L3.9375"                      PC        0         1110070001      ALMOXARIFADO DE COMPONENTES E MATERIA PRIMA        ALMO01    S                                                                                           0             0.000                                   0.000                                   159.297500                              0.00                                    0.00                                    0.00                                    0.000000                                159.297500                              0.000000                                MP
--0         1500      2600      3300      B46.                 1           0        3           1           5           B46.008.007          MP-MAT�RIA PRIMA          M       S        BUCHA CE CPL D1.375" L2.9375"                                                    1500      2600      3300      PC        84669410  0        0.000                                   BUCHA CE CPL D1.375" L2.9375"                                                                                                                                                                                                                    0           PC        1.000000                                PC        1.000000                                S         5.101.B   S         1.101.B   5.0000                                  MDLMIGRA        2005-09-27 14:43:57.530 MARCOS          2010-04-29 15:22:08.277 B46.008.007          BUCHA CE CPL D1.375" L2.9375"                      PC        84669410  1110070001      ALMOXARIFADO DE COMPONENTES E MATERIA PRIMA        ALMO01    S                                                                                           0             0.000                                   0.000                                   104.450000                              0.00                                    0.00                                    0.00                                    0.000000                                104.450000                              0.000000                                MP

--ATUALIZAR A TABELA TEMPOR�RIA (GRUPOS) COLOCANDO O GRUPO, SEPARANDO POR QUANTIDADE DE ITENS NA NOTA
declare
@i int,
@j int,
@k int,
@v int,
@g int,
@ncm_new varchar(8),
@ncm_old varchar(8)
set @i = 2
select @j=max(num) from #new 
select @v=qde, @ncm_old= Rlri_mtnc from #new where num = 1
set @g = 1
update #new set grupo = @g where num = 1
while @i<= @j begin
	select @k=@v+qde, @ncm_new= Rlri_mtnc from #new where num = @i
	print 'Numero da linha'+convert(char(6),@i)
	if (@k < 101)and (@ncm_new= @ncm_old) begin
		set @v=@k
		print 'linha '+convert(varchar(6),@i)+' menor 101, soma '+convert(varchar(6),@v)+ ' NCM '+@ncm_new + ' '+@ncm_old+' GRUPO '+convert(varchar(6),@g)
		update #new set grupo = @g, soma = @v from #new where num = @i
	end else if(@k>190)and (@ncm_new= @ncm_old) begin
		select @v=qde, @ncm_new= Rlri_mtnc from #new where num = @i
		set @g = @g +1
		print 'linha '+convert(varchar(6),@i)+' mair 130, soma '+convert(varchar(6),@v)+ ' NCM '+@ncm_new + ' '+@ncm_old+' GRUPO '+convert(varchar(6),@g)
		update #new set grupo = @g, soma = @v from #new where num = @i
	end else if (@ncm_new<> @ncm_old)begin
		select @v=qde, @ncm_old= Rlri_mtnc  from #new where num = @i
		set @g = @g +1
		print 'linha '+convert(varchar(6),@i)+' ncm diferente, soma '+convert(varchar(6),@v)+ ' NCM '+@ncm_new + ' '+@ncm_old+' GRUPO '+convert(varchar(6),@g)
		update #new set grupo = @g, soma = @v from #new where num = @i		
	end else begin
		set @v=@k
		print 'linha '+convert(varchar(6),@i)+' menor 101 e 130, soma '+convert(varchar(6),@v)+ ' NCM '+@ncm_new + ' '+@ncm_old+' GRUPO '+convert(varchar(6),@g)
		update #new set grupo = @g, soma = @v from #new where num = @i
	end
	
	set @i=@i+1
end

--ATUALIZAR OS GRUPOS NOS ITENS DA TABELA TEMPOR�RIA
update #new1 set gp = grupo
--select *
from #new1 a, #new b
where a.mtpr_mtdv = b.mtpr_mtdv
			and a.mtpr_mtln = b.mtpr_mtln
			and a.mtpr_mtfm = b.mtpr_mtfm
			and a.Rlri_ctpc = b.Rlri_ctpc
--			and a.mtpr_mtdv = '9999'

--RETIRAR O PONTO DO FINAL DO C�DIGO DOS ITENS 			
update #new1 set Rlri_mtes = substring(Rlri_mtes,1, len(Rlri_mtes)-1)
--select substring(Rlri_mtes,1, len(Rlri_mtes)-1)
from #new1 
where substring(Rlri_mtes, len(Rlri_mtes),1) = '.'

select *
into [dos].[dbo].NEW
from #new
select *
into [dos].[dbo].NEW1
from #new1
select *
into [dos].[dbo].TMPRLRI
from #tmpRlri

--select * from #new1 where Rlri_ctpc = '1110070005'

--INSERIR A PRE-NOTA (CABE�ALHO)
--insert into ofnf
--			OFNF_SIES  OFNF_SIDO	OFNF_SISE OFNF_COD				OFNF_ES OFNF_DAT    OFNF_DCA  OFNF_NFOP		OFNF_CFOP OFNF_SIDX OFNF_SISX OFNF_CODX				OFNF_DATX   OFNF_SIDF OFNF_SISF OFNF_CODF OFNF_SIDP OFNF_SISP OFNF_CODP OFNF_STA	OFNF_OBS	OFNF_GLTX OFNF_GLXX OFNF_GLXX_DIG OFNF_GLPA OFNF_GLXX_NOM           OFNF_GLPS_ORI OFNF_GLUF_ORI OFNF_GLPS_DES OFNF_GLUF_DES OFNF_PEDC OFNF_GLMD OFNF_VMDA OFNF_GLCF OFNF_PCTCF  OFNF_GLVD OFNF_PCTCOM OFNF_GLPG OFNF_GLCC OFNF_CART OFNF_GLTR OFNF_VIA	OFNF_FRETE	OFNF_PLACA	OFNF_DTSAIDA  OFNF_QTDVOL OFNF_ESPECIE  OFNF_MARCA	OFNF_NUMERA OFNF_PESOLIQ  OFNF_PESOBRT							OFNF_MENS	OFNF_QTD  OFNF_VAL  OFNF_VAL_TIT  OFNF_VAL_MER  OFNF_VAL_SER  OFNF_VAL_FRE  OFNF_VAL_SEG  OFNF_VAL_ACE  OFNF_VAL_DES  OFNF_VAL_PIS  OFNF_VAL_COF  OFNF_VAL_CSS  OFNF_VAL_INSS OFNF_VAL_IRRF OFNF_IPI_VAL  OFNF_IPI_BAS  OFNF_IPI_OUT  OFNF_IPI_ISE  OFNF_ISS_VAL  OFNF_ISS_BAS  OFNF_ISS_ISE  OFNF_ISS_OUT  OFNF_ICM_VAL  OFNF_ICM_BAS  OFNF_ICM_ISE  OFNF_ICM_OUT  OFNF_IST_BAS  OFNF_IST_ALI  OFNF_IST_VAL  OFNF_IST_ISE	OFNF_IST_OUT  OFNF_IST_IVA  OFNF_ICP_ALI  OFNF_ICP_VAL  OFNF_NLM  OFNF_CLM  OFNF_NLS  OFNF_CLS  OFNF_SIDY OFNF_SISY OFNF_CODY OFNF_NFE_CHV  OFNF_NFE_STA	OFNF_NFE_PRO  OFNF_NFE_DTP  OFNF_USC  OFNF_DTC    OFNF_USU  OFNF_DTU
select	1,				 'OF55',		'001',		90978+grupo,		'S',		getDAte(),	null,			'5.949.ZZ',	'5.949',	'OF55',		'001',		90964+GRUPO,		GETDATE(),	NULL,			NULL,			0,				NULL,			NULL,			0,				'EA',			NULL,			'GLCL',		1,				5,						16741,		'M�QUINAS DANLY LTDA.',	'BRA',				'SP',					'BRA',				'SP',					NULL,			'REAL',		1.00,			'SEM',		0.00,				'9',			0.00,				'00',			NULL,			NULL,			NULL,			'R',			2,					NULL,				NULL,					0.00,				NULL,					NULL,				NULL,				0.00,					0.00,					null,				NULL,			SUM(QDE),	SUM(0),		SUM(0),				SUM(0),				0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0,				0,				0,				0,				null,			null,			0,				null,					null,					null,					null,					'KINKEL',	GETDATE(),	NULL,			NULL
from #new
GROUP BY GRUPO

--INSERIR O COMPLEMENTO DA PRE-NOTA
--insert into ofco
--			OFCO_SIES OFCO_SIDO OFCO_SISE OFCO_COD			OFCO_CNPJ					OFCO_CPF	OFCO_IES            OFCO_RG   OFCO_IMU	OFCO_END							OFCO_NUM	OFCO_COM  OFCO_BAI           OFCO_CID     OFCO_PAIS OFCO_EST	OFCO_MUN		OFCO_CEP		OFCO_TEL											OFCO_FAX                  OFCO_CNPJC				OFCO_CPFC OFCO_IESC          OFCO_RGC OFCO_IMUC OFCO_ENDC             OFCO_NUMC OFCO_COMC OFCO_BAIC          OFCO_CIDC    OFCO_PAISC	OFCO_ESTC OFCO_MUNC		OFCO_CEPC		OFCO_TELC											OFCO_CNPJE				OFCO_CPFE   OFCO_IESE          OFCO_RGE   OFCO_IMUE OFCO_ENDE             OFCO_NUME OFCO_COME		OFCO_BAIE          OFCO_CIDE    OFCO_PAISE	OFCO_ESTE OFCO_MUNE		OFCO_CEPE		OFCO_NOMT OFCO_CNPJT  OFCO_CPFT OFCO_IEST OFCO_RGT  OFCO_IMUT OFCO_ENDT OFCO_NUMT OFCO_COMT OFCO_BAIT OFCO_CIDT OFCO_PAIST	OFCO_ESTT OFCO_MUNT OFCO_CEPT OFCO_USC  OFCO_DTC   OFCO_USU OFCO_DTU
select	1,				'OF55',		'001',		90978+grupo,	'43299791000105', null,			'108.781.369.119',	null,			null,			'R ERNESTO DE FIORE', '85',			null,			'VILA DAS MERCES', 'SAO PAULO', 'BRA',		'SP',			'3550308',	'04297100', '11-2139-9220-11/2139-9290',  '11-2139-9215/2139-9295', '43299791000105', null,			'108.781.369.119', null,		null,			'R ERNESTO DE FIORE', '85',			null,			'VILA DAS MERCES', 'SAO PAULO', 'BRA',			'SP',			'3550308',	'04297100', '11-2139-9220-11/2139-9290',	'43299791000105', null,				'108.781.369.119', null,			null,			'R ERNESTO DE FIORE', '85',			null,				'VILA DAS MERCES', 'SAO PAULO', 'BRA',			'SP',			'3550308',	'04297100', NULL,			NULL,				NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,				NULL,			NULL,			NULL,			'KINKEL', getdate(), NULL,		null
from #new
GROUP BY GRUPO

/*
insert into ftco
--			FTCO_SIES FTCO_SIDO FTCO_SISE FTCO_COD			FTCO_CNPJ					FTCO_CPF  FTCO_IES            FTCO_RG   FTCO_IMU  FTCO_END              FTCO_NUM	FTCO_COM  FTCO_BAI           FTCO_CID     FTCO_PAIS FTCO_EST	FTCO_MUN		FTCO_CEP		FTCO_TEL											FTCO_FAX                  FTCO_CNPJC				FTCO_CPFC FTCO_IESC          FTCO_RGC FTCO_IMUC FTCO_ENDC             FTCO_NUMC FTCO_COMC FTCO_BAIC          FTCO_CIDC		FTCO_PAISC	FTCO_ESTC FTCO_MUNC		FTCO_CEPC		FTCO_TELC											FTCO_CNPJE				FTCO_CPFE   FTCO_IESE          FTCO_RGE   FTCO_IMUE FTCO_ENDE             FTCO_NUME FTCO_COME		FTCO_BAIE          FTCO_CIDE    FTCO_PAISE	FTCO_ESTE FTCO_MUNE		FTCO_CEPE		FTCO_NOMT FTCO_CNPJT  FTCO_CPFT FTCO_IEST FTCO_RGT  FTCO_IMUT FTCO_ENDT FTCO_NUMT FTCO_COMT FTCO_BAIT FTCO_CIDT FTCO_PAIST	FTCO_ESTT FTCO_MUNT FTCO_CEPT FTCO_USC  FTCO_DTC	 FTCO_USU FTCO_DTU
--			OFCO_SIES OFCO_SIDO OFCO_SISE OFCO_COD			OFCO_CNPJ					OFCO_CPF	OFCO_IES            OFCO_RG   OFCO_IMU	OFCO_END							OFCO_NUM	OFCO_COM  OFCO_BAI           OFCO_CID     OFCO_PAIS OFCO_EST	OFCO_MUN		OFCO_CEP		OFCO_TEL											OFCO_FAX                  OFCO_CNPJC				OFCO_CPFC OFCO_IESC          OFCO_RGC OFCO_IMUC OFCO_ENDC             OFCO_NUMC OFCO_COMC OFCO_BAIC          OFCO_CIDC    OFCO_PAISC	OFCO_ESTC OFCO_MUNC		OFCO_CEPC		OFCO_TELC											OFCO_CNPJE				OFCO_CPFE   OFCO_IESE          OFCO_RGE   OFCO_IMUE OFCO_ENDE             OFCO_NUME OFCO_COME		OFCO_BAIE          OFCO_CIDE    OFCO_PAISE	OFCO_ESTE OFCO_MUNE		OFCO_CEPE		OFCO_NOMT OFCO_CNPJT  OFCO_CPFT OFCO_IEST OFCO_RGT  OFCO_IMUT OFCO_ENDT OFCO_NUMT OFCO_COMT OFCO_BAIT OFCO_CIDT OFCO_PAIST	OFCO_ESTT OFCO_MUNT OFCO_CEPT OFCO_USC  OFCO_DTC   OFCO_USU OFCO_DTU
select	1,				'FT55',		'001',		17275+grupo,	'43299791000105', null,			'108.781.369.119',	null,			null,			'R ERNESTO DE FIORE', '85',			null,			'VILA DAS MERCES', 'SAO PAULO', 'BRA',		'SP',			'3550308',	'04297100', '11-2139-9220-11/2139-9290',  '11-2139-9215/2139-9295', '43299791000105', null,			'108.781.369.119', null,		null,			'R ERNESTO DE FIORE', '85',			null,			'VILA DAS MERCES', 'SAO PAULO', 'BRA',			'SP',			'3550308',	'04297100', '11-2139-9220-11/2139-9290',	'43299791000105', null,				'108.781.369.119', null,			null,			'R ERNESTO DE FIORE', '85',			null,				'VILA DAS MERCES', 'SAO PAULO', 'BRA',			'SP',			'3550308',	'04297100', NULL,			NULL,				NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,				NULL,			NULL,			NULL,			'KINKEL', getdate(), NULL,		null
from #new
where grupo <35
GROUP BY GRUPO
*/
--INSERIR OS ITENS DA PRE-NOTA
--OFIT_SIES   OFIT_SIDO OFIT_SISE OFIT_OFNF   OFIT_COD    OFIT_CODF   OFIT_SIDP OFIT_SISP OFIT_CODP   OFIT_CODI   OFIT_MTPC            OFIT_NOM                                                                                                                                                                                                                                                        OFIT_MTPR            OFIT_MS OFIT_MTUN OFIT_MTNC OFIT_ORI OFIT_MTDV OFIT_MTLN OFIT_MTFM OFIT_PLIQ                               OFIT_PLQT                               OFIT_PBRT                               OFIT_EST OFIT_MTTR OFIT_STA    OFIT_CTPC       OFIT_RDPC OFIT_CTCC       OFIT_RDCC OFIT_QTD                                OFIT_PUN                                OFIT_VAL                                OFIT_REV OFIT_DES                                OFIT_NFOP OFIT_CFOP OFIT_TIT OFIT_TBB OFIT_MEN                                                                                                                                                                                                                                                        OFIT_IPI_BAS                            OFIT_IPI_ALI                            OFIT_IPI_VAL                            OFIT_IPI_ISE                            OFIT_IPI_OUT                            OFIT_ISS_BAS                            OFIT_ISS_ALI                            OFIT_ISS_VAL                            OFIT_ISS_ISE                            OFIT_ISS_OUT                            OFIT_ICM_BAS                            OFIT_ICM_ALI                            OFIT_ICM_VAL                            OFIT_ICM_ISE                            OFIT_ICM_OUT                            OFIT_IST_BAS                            OFIT_IST_ALI                            OFIT_IST_VAL                            OFIT_IST_ISE                            OFIT_IST_OUT                            OFIT_IST_IVA                            OFIT_ICP_ALI                            OFIT_ICP_VAL                            OFIT_VAL_FRE                            OFIT_VAL_SEG                            OFIT_VAL_ACE                            OFIT_IMP_ALI                            OFIT_IMP_ADU                            OFIT_IMP_DAD                            OFIT_VAL_PIS                            OFIT_VAL_COF                            OFIT_USC        OFIT_DTC                OFIT_USU        OFIT_DTU
------------- --------- --------- ----------- ----------- ----------- --------- --------- ----------- ----------- -------------------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- -------------------- ------- --------- --------- -------- --------- --------- --------- --------------------------------------- --------------------------------------- --------------------------------------- -------- --------- ----------- --------------- --------- --------------- --------- --------------------------------------- --------------------------------------- --------------------------------------- -------- --------------------------------------- --------- --------- -------- -------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------- ----------------------- --------------- -----------------------
--1           OFNF      001       90962       1           0           VDPD      001       0           NULL        OSAR                 H002 / Aparelho B1B- 1x M3,5 x 0,60 DIN371 Curso m�x.152,4mm - Porca 115mm - Q110-1BM x06 -PED.060533/1 --001/                                                                                                                                                  OSAR                 M       PC        84669490  0        4500      4500      5430      4640.000                                4640.000                                4640.000                                S        NA        0           4101010001      4001      210199          RT099     1.000                                   36646.250                               36646.25                                I        0.00                                    6.101.A   6.101     S        00       EMISS�O AUT. PELA PORT.CAT 69/01 E ART.32 PORTARIA CAT 13/97.                                                                                                                                                                                                   36646.25                                0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    36646.25                                12.00                                   4397.5500                               0.00                                    0.00                                    0.00                                    0.00                                    0.0000                                  0.00                                    0.00                                    0.00                                    0.00                                    0.0000                                  0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    0.00                                    604.66                                  2785.12                                 CLAUDENIRM      2010-12-22 16:49:47.313                 NULL

--select * from #new1 order by gp
declare
@w int,
@q int
select @w = max(grupo)
from #new

print @w
set @q =1
while @q<=@w begin
	
	print 'cria tabela temporaria para o grupo :'+convert(char(3),@q)
	select *, identity(int,1,1) num
	into #tra
	from ofit
	where 1=2
	if (select count(1) from #new1 where gp=@q)> 0 begin
		print 'insere os registros para o grupo :'+convert(char(3),@q)
		if (select count(1) from #new1 where gp = @q and Rlri_ctpc in('1110070005','1110070007'))>0 begin
			insert into #tra
--						OFIT_SIES OFIT_SIDO OFIT_SISE OFIT_OFNF		OFIT_COD	OFIT_CODF   OFIT_SIDP OFIT_SISP OFIT_CODP OFIT_CODI OFIT_MTPC   OFIT_NOM											OFIT_MTPR   OFIT_MS OFIT_MTUN		OFIT_MTNC		OFIT_ORI	OFIT_MTDV OFIT_MTLN OFIT_MTFM OFIT_PLIQ OFIT_PLQT               OFIT_PBRT               OFIT_EST	OFIT_MTTR OFIT_STA  OFIT_CTPC   OFIT_RDPC OFIT_CTCC OFIT_RDCC OFIT_QTD      OFIT_PUN      OFIT_VAL      OFIT_REV	OFIT_DES  OFIT_NFOP		OFIT_CFOP OFIT_TIT	OFIT_TBB	OFIT_MEN  OFIT_IPI_BAS  OFIT_IPI_ALI  OFIT_IPI_VAL  OFIT_IPI_ISE  OFIT_IPI_OUT  OFIT_ISS_BAS  OFIT_ISS_ALI  OFIT_ISS_VAL  OFIT_ISS_ISE  OFIT_ISS_OUT  OFIT_ICM_BAS  OFIT_ICM_ALI  OFIT_ICM_VAL  OFIT_ICM_ISE  OFIT_ICM_OUT  OFIT_IST_BAS  OFIT_IST_ALI  OFIT_IST_VAL  OFIT_IST_ISE  OFIT_IST_OUT  OFIT_IST_IVA  OFIT_ICP_ALI  OFIT_ICP_VAL  OFIT_VAL_FRE  OFIT_VAL_SEG  OFIT_VAL_ACE  OFIT_IMP_ALI  OFIT_IMP_ADU  OFIT_IMP_DAD  OFIT_VAL_PIS  OFIT_VAL_COF  OFIT_USC  OFIT_DTC    OFIT_USU  OFIT_DTU
			select	1,				'OF55',		'001',		90978+gp,		0,				0,					'OF55',		'001',		90978+gp,	null,			Rlri_mtes,	Rlri_nom +' ('+Rlri_orde+')',	Rlri_mtes,	'M',		Rlri_mtun,	Rlri_mtnc,	0,				a.mtpr_mtdv,			a.mtpr_MTLN,			a.mtpr_MTFM,			MTPR_PES,	MTPR_PES*Rlri_qtd_alm,	MTPR_PES*Rlri_qtd_alm,	'S',			'NA',			0,				Rlri_ctpc,	NULL,			NULL,			NULL,			Rlri_qtd_alm+Rlri_orde_qtdo,	Rlri_vun_alm,	Rlri_val_alm,	'S',			0.00,			'5.949.ZZ',	'5.949',	'N',			'00',			'',				Rlri_val_alm,	0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					'KINKEL',	GETDATE(),	NULL,			NULL
			from #new1 a, MTPR b
			WHERE MTPR_COD = Rlri_mtes
						and gp = @q
						--and Rlri_mtes not in (select mtpc_cod  from mtpc)	
		end else begin
			insert into #tra
--						OFIT_SIES OFIT_SIDO OFIT_SISE OFIT_OFNF		OFIT_COD	OFIT_CODF   OFIT_SIDP OFIT_SISP OFIT_CODP OFIT_CODI OFIT_MTPC   OFIT_NOM  OFIT_MTPR   OFIT_MS OFIT_MTUN		OFIT_MTNC		OFIT_ORI	OFIT_MTDV OFIT_MTLN OFIT_MTFM OFIT_PLIQ OFIT_PLQT               OFIT_PBRT               OFIT_EST	OFIT_MTTR OFIT_STA  OFIT_CTPC   OFIT_RDPC OFIT_CTCC OFIT_RDCC OFIT_QTD      OFIT_PUN      OFIT_VAL      OFIT_REV	OFIT_DES  OFIT_NFOP		OFIT_CFOP OFIT_TIT	OFIT_TBB	OFIT_MEN  OFIT_IPI_BAS  OFIT_IPI_ALI  OFIT_IPI_VAL  OFIT_IPI_ISE  OFIT_IPI_OUT  OFIT_ISS_BAS  OFIT_ISS_ALI  OFIT_ISS_VAL  OFIT_ISS_ISE  OFIT_ISS_OUT  OFIT_ICM_BAS  OFIT_ICM_ALI  OFIT_ICM_VAL  OFIT_ICM_ISE  OFIT_ICM_OUT  OFIT_IST_BAS  OFIT_IST_ALI  OFIT_IST_VAL  OFIT_IST_ISE  OFIT_IST_OUT  OFIT_IST_IVA  OFIT_ICP_ALI  OFIT_ICP_VAL  OFIT_VAL_FRE  OFIT_VAL_SEG  OFIT_VAL_ACE  OFIT_IMP_ALI  OFIT_IMP_ADU  OFIT_IMP_DAD  OFIT_VAL_PIS  OFIT_VAL_COF  OFIT_USC  OFIT_DTC    OFIT_USU  OFIT_DTU
			select	1,				'OF55',		'001',		90978+gp,		0,				0,					'OF55',		'001',		90978+gp,	null,			Rlri_mtes,	Rlri_nom,	Rlri_mtes,	'M',		Rlri_mtun,	Rlri_mtnc,	0,				a.mtpr_mtdv,			a.mtpr_MTLN,			a.mtpr_MTFM,			MTPR_PES,	MTPR_PES*Rlri_qtd_alm,	MTPR_PES*Rlri_qtd_alm,	'S',			'NA',			0,				Rlri_ctpc,	NULL,			NULL,			NULL,			Rlri_qtd_alm+Rlri_orde_qtdo,	Rlri_vun_alm,	Rlri_val_alm,	'S',			0.00,			'5.949.ZZ',	'5.949',	'N',			'00',			'',				Rlri_val_alm,	0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					'KINKEL',	GETDATE(),	NULL,			NULL
			from #new1 a, MTPR b
			WHERE MTPR_COD = Rlri_mtes
						and gp = @q
						--and Rlri_mtes not in (select mtpc_cod  from mtpc)
		end

		print 'insere os registros temporaria na tabela OFIT, para o grupo :'+convert(char(3),@q)				
		--insert into ofit
		--select OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF		,num						,OFIT_CODF   ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC   ,OFIT_NOM        ,OFIT_MTPR   ,OFIT_MS ,OFIT_MTUN		,OFIT_MTNC		,OFIT_ORI	,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT               ,OFIT_PBRT               ,OFIT_EST	,OFIT_MTTR ,OFIT_STA  ,OFIT_CTPC   ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD      ,OFIT_PUN      ,OFIT_VAL      ,OFIT_REV	,OFIT_DES  ,OFIT_NFOP		,OFIT_CFOP ,OFIT_TIT	,OFIT_TBB	,OFIT_MEN  ,OFIT_IPI_BAS  ,OFIT_IPI_ALI  ,OFIT_IPI_VAL  ,OFIT_IPI_ISE  ,OFIT_IPI_OUT  ,OFIT_ISS_BAS  ,OFIT_ISS_ALI  ,OFIT_ISS_VAL  ,OFIT_ISS_ISE  ,OFIT_ISS_OUT  ,OFIT_ICM_BAS  ,OFIT_ICM_ALI  ,OFIT_ICM_VAL  ,OFIT_ICM_ISE  ,OFIT_ICM_OUT  ,OFIT_IST_BAS  ,OFIT_IST_ALI  ,OFIT_IST_VAL  ,OFIT_IST_ISE  ,OFIT_IST_OUT  ,OFIT_IST_IVA  ,OFIT_ICP_ALI  ,OFIT_ICP_VAL  ,OFIT_VAL_FRE  ,OFIT_VAL_SEG  ,OFIT_VAL_ACE  ,OFIT_IMP_ALI  ,OFIT_IMP_ADU  ,OFIT_IMP_DAD  ,OFIT_VAL_PIS  ,OFIT_VAL_COF  ,OFIT_USC  ,OFIT_DTC    ,OFIT_USU  ,OFIT_DTU
		select OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF		,num						,OFIT_CODF   ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,num ,OFIT_MTPC   ,OFIT_NOM        ,OFIT_MTPR   ,OFIT_MS ,OFIT_MTUN		,OFIT_MTNC		,OFIT_ORI	,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT               ,OFIT_PBRT               ,OFIT_EST	,OFIT_MTTR ,OFIT_STA  ,OFIT_CTPC   ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD      ,OFIT_PUN      ,OFIT_VAL      ,OFIT_REV	,OFIT_DES  ,OFIT_NFOP		,OFIT_CFOP ,OFIT_TIT	,OFIT_TBB	,OFIT_MEN  ,OFIT_IPI_BAS  ,OFIT_IPI_ALI  ,OFIT_IPI_VAL  ,OFIT_IPI_ISE  ,OFIT_IPI_OUT  ,OFIT_ISS_BAS  ,OFIT_ISS_ALI  ,OFIT_ISS_VAL  ,OFIT_ISS_ISE  ,OFIT_ISS_OUT  ,OFIT_ICM_BAS  ,OFIT_ICM_ALI  ,OFIT_ICM_VAL  ,OFIT_ICM_ISE  ,OFIT_ICM_OUT  ,OFIT_IST_BAS  ,OFIT_IST_ALI  ,OFIT_IST_VAL  ,OFIT_IST_ISE  ,OFIT_IST_OUT  ,OFIT_IST_IVA  ,OFIT_ICP_ALI  ,OFIT_ICP_VAL  ,OFIT_VAL_FRE  ,OFIT_VAL_SEG  ,OFIT_VAL_ACE  ,OFIT_IMP_ALI  ,OFIT_IMP_ADU  ,OFIT_IMP_DAD  ,OFIT_VAL_PIS  ,OFIT_VAL_COF  ,OFIT_USC  ,OFIT_DTC    ,OFIT_USU  ,OFIT_DTU
		from #tra
	end
	set @q=@q+1
	
	drop table #tra
end

drop table #mtmv
select *, identity(int,1,1) NUM into #mtmv from mtmv where 1=2
insert into #mtmv
--			MTMV_SIES MTMV_SIDO MTMV_SISE MTMV_COD  MTMV_SEQ  MTMV_DAT			MTMV_MTES   MTMV_MTTR	MTMV_AUTO MTMV_TRAN MTMV_ACAO MTMV_DIRE MTMV_VLIN MTMV_UCIN MTMV_ATUM MTMV_SUCA MTMV_SIDX MTMV_SISX MTMV_CODX MTMV_SEQX MTMV_MTAL_ORI MTMV_SUBL_ORI MTMV_TABE_ORI MTMV_SIDO_ORI MTMV_SISE_ORI MTMV_COD_ORI	MTMV_SEQ_ORI	MTMV_LOTE_ORI MTMV_CTPC_ORI MTMV_CTCC_ORI MTMV_MTAL_DES MTMV_SUBL_DES MTMV_TABE_DES MTMV_SIDO_DES MTMV_SISE_DES MTMV_COD_DES	MTMV_SEQ_DES	MTMV_LOTE_DES MTMV_CTPC_DES MTMV_CTCC_DES MTMV_MTAL_AUT MTMV_QTD      MTMV_VAL				MTMV_VALM         MTMV_VALP MTMV_VALA MTMV_GLHP MTMV_MEN                      MTMV_USC  MTMV_DTC    MTMV_USU  MTMV_DTU
SELECT	1,				'MTMV',		'001',		1,				0,				'12/31/2010',	Rlri_mtes,	'TRASAI',	'N',			'N',			'S',			'S',			'N',			'N',			'S',			'N',			null,			null,			0,				0,				'ALMO01',			0,						null,					null,					null,					0,						0,						null,					Rlri_ctpc,		null,					'EXTCPV',			0,						NULL,					null,					null,					0,						0,						null,					'3101990001',	'130199',			null,					Rlri_qtd_alm,	Rlri_mat_alm ,	Rlri_mat_alm*1.8,	0,				0,				'021',		'MOVIMENTO DE TRANSFER�NCIA',	'KINKEL',	getdate(),	null,			null
from #new1
where Rlri_mtal = 'almo01'
insert into #mtmv
--			MTMV_SIES MTMV_SIDO MTMV_SISE MTMV_COD  MTMV_SEQ  MTMV_DAT			MTMV_MTES   MTMV_MTTR	MTMV_AUTO MTMV_TRAN MTMV_ACAO MTMV_DIRE MTMV_VLIN MTMV_UCIN MTMV_ATUM MTMV_SUCA MTMV_SIDX MTMV_SISX MTMV_CODX MTMV_SEQX MTMV_MTAL_ORI MTMV_SUBL_ORI MTMV_TABE_ORI MTMV_SIDO_ORI MTMV_SISE_ORI MTMV_COD_ORI	MTMV_SEQ_ORI	MTMV_LOTE_ORI MTMV_CTPC_ORI MTMV_CTCC_ORI MTMV_MTAL_DES MTMV_SUBL_DES MTMV_TABE_DES MTMV_SIDO_DES MTMV_SISE_DES MTMV_COD_DES	MTMV_SEQ_DES	MTMV_LOTE_DES MTMV_CTPC_DES MTMV_CTCC_DES MTMV_MTAL_AUT MTMV_QTD      MTMV_VAL				MTMV_VALM         MTMV_VALP MTMV_VALA MTMV_GLHP MTMV_MEN                      MTMV_USC  MTMV_DTC    MTMV_USU  MTMV_DTU
SELECT	7,				'MTMV',		'001',		1,				0,				'01/01/2011',	Rlri_mtes,	'TRAENT',	'N',			'N',			'S',			'S',			'N',			'N',			'S',			'N',			null,			null,			0,				0,				'EXTCPV',			0,						null,					null,					null,					0,						0,						null,					'3101990001',	'130199',			'ALMO01',			0,						NULL,					null,					null,					0,						0,						null,					Rlri_ctpc,		NULL,					null,					Rlri_qtd_alm,	Rlri_mat_alm ,	Rlri_mat_alm*1.8,	0,				0,				'021',		'MOVIMENTO DE TRANSFER�NCIA',	'KINKEL',	getdate(),	null,			null
from #new1
where Rlri_mtal = 'almo01'

declare
@i int,
@j int

select @i=SISE_NUM from sise where sise_sies = 1 	and sise_sido = 'MTMV' 	and sise_cod  = '001'
select @j = max(num)+@i from #mtmv where mtmv_sies = 1
insert into mtmv
select MTMV_SIES, MTMV_SIDO, MTMV_SISE, NUM+@i,  MTMV_SEQ  ,MTMV_DAT			,MTMV_MTES   ,MTMV_MTTR	,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX ,MTMV_SEQX ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI	,MTMV_SEQ_ORI	,MTMV_LOTE_ORI ,MTMV_CTPC_ORI ,MTMV_CTCC_ORI ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES	,MTMV_SEQ_DES	,MTMV_LOTE_DES ,MTMV_CTPC_DES ,MTMV_CTCC_DES ,MTMV_MTAL_AUT ,MTMV_QTD      ,MTMV_VAL				,MTMV_VALM         ,MTMV_VALP ,MTMV_VALA ,MTMV_GLHP ,MTMV_MEN                      ,MTMV_USC  ,MTMV_DTC    ,MTMV_USU  ,MTMV_DTU
from #mtmv
where mtmv_sies  = 1
update sise set SISE_NUM=@j from sise where sise_sies = 1 and sise_sido = 'MTMV' 	and sise_cod  = '001'

select @i=SISE_NUM from sise where sise_sies = 7 	and sise_sido = 'MTMV' 	and sise_cod  = '001'
select @j = max(num)+@i from #mtmv where mtmv_sies = 7
insert into mtmv
select MTMV_SIES, MTMV_SIDO, MTMV_SISE, NUM+@i,  MTMV_SEQ  ,MTMV_DAT			,MTMV_MTES   ,MTMV_MTTR	,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX ,MTMV_SEQX ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI	,MTMV_SEQ_ORI	,MTMV_LOTE_ORI ,MTMV_CTPC_ORI ,MTMV_CTCC_ORI ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES	,MTMV_SEQ_DES	,MTMV_LOTE_DES ,MTMV_CTPC_DES ,MTMV_CTCC_DES ,MTMV_MTAL_AUT ,MTMV_QTD      ,MTMV_VAL				,MTMV_VALM         ,MTMV_VALP ,MTMV_VALA ,MTMV_GLHP ,MTMV_MEN                      ,MTMV_USC  ,MTMV_DTC    ,MTMV_USU  ,MTMV_DTU
from #mtmv
where mtmv_sies  = 7
update sise set SISE_NUM=@j from sise where sise_sies = 7 and sise_sido = 'MTMV' 	and sise_cod  = '001'
