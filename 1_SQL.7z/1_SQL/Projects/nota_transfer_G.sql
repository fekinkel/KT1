if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

--drop table #new
--drop table #new1

select *, identity(int,1,1) NUM, 0 grupo into #new from [dos].[dbo].spmq order by NCM, Insumo

select ncm, identity(int,1,1) num into #new1 from #new group by ncm

update #new set grupo = b.num from #new a, #new1 b where a.ncm = b.ncm

select * from #new

insert into ofnf
--			OFNF_SIES  OFNF_SIDO	OFNF_SISE OFNF_COD				OFNF_ES OFNF_DAT    OFNF_DCA  OFNF_NFOP		OFNF_CFOP OFNF_SIDX OFNF_SISX OFNF_CODX				OFNF_DATX   OFNF_SIDF OFNF_SISF OFNF_CODF OFNF_SIDP OFNF_SISP OFNF_CODP OFNF_STA	OFNF_OBS	OFNF_GLTX OFNF_GLXX OFNF_GLXX_DIG OFNF_GLPA OFNF_GLXX_NOM           OFNF_GLPS_ORI OFNF_GLUF_ORI OFNF_GLPS_DES OFNF_GLUF_DES OFNF_PEDC OFNF_GLMD OFNF_VMDA OFNF_GLCF OFNF_PCTCF  OFNF_GLVD OFNF_PCTCOM OFNF_GLPG OFNF_GLCC OFNF_CART OFNF_GLTR OFNF_VIA	OFNF_FRETE	OFNF_PLACA	OFNF_DTSAIDA  OFNF_QTDVOL OFNF_ESPECIE  OFNF_MARCA	OFNF_NUMERA OFNF_PESOLIQ  OFNF_PESOBRT	OFNF_MENS	OFNF_QTD  OFNF_VAL					OFNF_VAL_TIT  OFNF_VAL_MER  OFNF_VAL_SER  OFNF_VAL_FRE  OFNF_VAL_SEG  OFNF_VAL_ACE  OFNF_VAL_DES  OFNF_VAL_PIS  OFNF_VAL_COF  OFNF_VAL_CSS  OFNF_VAL_INSS OFNF_VAL_IRRF OFNF_IPI_VAL  OFNF_IPI_BAS  OFNF_IPI_OUT  OFNF_IPI_ISE  OFNF_ISS_VAL  OFNF_ISS_BAS  OFNF_ISS_ISE  OFNF_ISS_OUT  OFNF_ICM_VAL  OFNF_ICM_BAS  OFNF_ICM_ISE  OFNF_ICM_OUT  OFNF_IST_BAS  OFNF_IST_ALI  OFNF_IST_VAL  OFNF_IST_ISE	OFNF_IST_OUT  OFNF_IST_IVA  OFNF_ICP_ALI  OFNF_ICP_VAL  OFNF_NLM  OFNF_CLM  OFNF_NLS  OFNF_CLS  OFNF_SIDY OFNF_SISY OFNF_CODY OFNF_NFE_CHV  OFNF_NFE_STA	OFNF_NFE_PRO  OFNF_NFE_DTP  OFNF_USC  OFNF_DTC    OFNF_USU		OFNF_DTU
select	7,				 'OF55',		'001',		90978+grupo,		'S',		getDAte(),	null,			'5.949.ZZ',	'5.949',	'OF55',		'001',		90964+grupo,		GETDATE(),	NULL,			NULL,			0,				NULL,			NULL,			0,				'EA',			NULL,			'GLCL',		1,				2,						9861,			'M�QUINAS DANLY LTDA.',	'BRA',				'SP',					'BRA',				'SP',					NULL,			'REAL',		1.00,			'SEM',		0.00,				'9',			0.00,				'00',			NULL,			NULL,			NULL,			'R',			2,					NULL,				NULL,					0.00,				NULL,					NULL,				NULL,				0.00,					0.00,					null,			NULL,			SUM(Quantidade),	SUM(0),				SUM(0),				SUM(0),				0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,			0,				0,				0,				0,				null,			null,			0,						null,					null,					null,					'KINKEL',	GETDATE(),	NULL,				NULL
from #new
GROUP BY grupo

--INSERIR O COMPLEMENTO DA PRE-NOTA
insert into ofco
--			OFCO_SIES OFCO_SIDO OFCO_SISE OFCO_COD			OFCO_CNPJ					OFCO_CPF	OFCO_IES            OFCO_RG   OFCO_IMU	OFCO_END							OFCO_NUM	OFCO_COM  OFCO_BAI           OFCO_CID     OFCO_PAIS OFCO_EST	OFCO_MUN		OFCO_CEP		OFCO_TEL											OFCO_FAX                  OFCO_CNPJC				OFCO_CPFC OFCO_IESC          OFCO_RGC OFCO_IMUC OFCO_ENDC             OFCO_NUMC OFCO_COMC OFCO_BAIC          OFCO_CIDC    OFCO_PAISC	OFCO_ESTC OFCO_MUNC		OFCO_CEPC		OFCO_TELC											OFCO_CNPJE				OFCO_CPFE   OFCO_IESE          OFCO_RGE   OFCO_IMUE OFCO_ENDE             OFCO_NUME OFCO_COME		OFCO_BAIE          OFCO_CIDE    OFCO_PAISE	OFCO_ESTE OFCO_MUNE		OFCO_CEPE		OFCO_NOMT OFCO_CNPJT  OFCO_CPFT OFCO_IEST OFCO_RGT  OFCO_IMUT OFCO_ENDT OFCO_NUMT OFCO_COMT OFCO_BAIT OFCO_CIDT OFCO_PAIST	OFCO_ESTT OFCO_MUNT OFCO_CEPT OFCO_USC  OFCO_DTC   OFCO_USU OFCO_DTU
--select	7,				'OF55',		'001',		90978+grupo,	'43299791000105', null,			'108.781.369.119',	null,			null,			'R ERNESTO DE FIORE', '85',			null,			'VILA DAS MERCES', 'SAO PAULO', 'BRA',		'SP',			'3550308',	'04297100', '11-2139-9220-11/2139-9290',  '11-2139-9215/2139-9295', '43299791000105', null,			'108.781.369.119', null,		null,			'R ERNESTO DE FIORE', '85',			null,			'VILA DAS MERCES', 'SAO PAULO', 'BRA',			'SP',			'3550308',	'04297100', '11-2139-9220-11/2139-9290',	'43299791000105', null,				'108.781.369.119', null,			null,			'R ERNESTO DE FIORE', '85',			null,				'VILA DAS MERCES', 'SAO PAULO', 'BRA',			'SP',			'3550308',	'04297100', NULL,			NULL,				NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,				NULL,			NULL,			NULL,			'KINKEL', getdate(), NULL,		null
select	7,				'OF55',		'001',		90978+grupo,	'43299791000377', null,			'432.024.460.119',	null,			null,			'AV. PRINK', '151',			null,			'MAIRINQUE', 'MAIRINQUE', 'BRA',		'SP',			'3528403',	'18120000', '11-2107-0443-11/2107-0443',  '11-2107-0435', '43299791000377', null,			'432.024.460.119', null,		null,			'AV. PRINK', '151',			null,			'MAIRINQUE', 'MAIRINQUE', 'BRA',			'SP',			'3528403',	'18120000', '11-2107-0443-11/2107-0443',	'43299791000377', null,				'432.024.460.119', null,			null,			'AV. PRINK', '151',			null,				'MAIRINQUE', 'MAIRINQUE', 'BRA',			'SP',			'3528403',	'18120000', NULL,			NULL,				NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,				NULL,			NULL,			NULL,			'KINKEL', getdate(), NULL,		null
from #new
GROUP BY GRUPO


declare
@w int,
@q int
select @w = max(grupo)
from #new

print @w
set @q =1
while @q<=@w begin
	
	print 'cria tabela temporaria para o grupo :'+convert(char(3),@q)
	select *, identity(int,1,1) num
	into #tra
	from ofit
	where 1=2
	if (select count(1) from #new where grupo=@q)> 0 begin
		print 'insere os registros para o grupo :'+convert(char(3),@q)
		if (select count(1) from #new where grupo = @q and @q in (8,9,10)  )>0 begin
			insert into #tra
--						OFIT_SIES OFIT_SIDO OFIT_SISE OFIT_OFNF				OFIT_COD	OFIT_CODF OFIT_SIDP		OFIT_SISP OFIT_CODP		OFIT_CODI OFIT_MTPC OFIT_NOM		OFIT_MTPR   OFIT_MS OFIT_MTUN		OFIT_MTNC						OFIT_ORI	OFIT_MTDV			OFIT_MTLN			OFIT_MTFM			OFIT_PLIQ OFIT_PLQT             OFIT_PBRT             OFIT_EST	OFIT_MTTR OFIT_STA  OFIT_CTPC   OFIT_RDPC OFIT_CTCC OFIT_RDCC OFIT_QTD    OFIT_PUN  OFIT_VAL				OFIT_REV	OFIT_DES  
			select	7,				'OF55',		'001',		90978+grupo,		0,				0,				'VDPD',			null,			0,					null,			mtpr_cod,	mtpr_nom ,	mtpr_cod,		'M',		mtpr_mtun,	substring(ncm,2,8),	0,				a.mtpr_mtdv,	a.mtpr_MTLN,	a.mtpr_MTFM,	MTPR_PES,	MTPR_PES*quantidade,	MTPR_PES*quantidade,	'S',			'NA',			0,				MTTP_CTPC,	NULL,			NULL,			NULL,			quantidade,	unit�rio,	[valor total],	'S',			0.00,			
							--OFIT_NFOP		
							'5.151.NA',
							--OFIT_CFOP 
							'5.151',
							--	OFIT_TIT	OFIT_TBB	OFIT_MEN  OFIT_IPI_BAS	OFIT_IPI_ALI  OFIT_IPI_VAL  OFIT_IPI_ISE  OFIT_IPI_OUT  OFIT_ISS_BAS  OFIT_ISS_ALI  OFIT_ISS_VAL  OFIT_ISS_ISE  OFIT_ISS_OUT  OFIT_ICM_BAS								OFIT_ICM_ALI  OFIT_ICM_VAL											OFIT_ICM_ISE													OFIT_ICM_OUT  OFIT_IST_BAS  OFIT_IST_ALI  OFIT_IST_VAL  OFIT_IST_ISE  OFIT_IST_OUT  OFIT_IST_IVA  OFIT_ICP_ALI  OFIT_ICP_VAL  OFIT_VAL_FRE  OFIT_VAL_SEG  OFIT_VAL_ACE  OFIT_IMP_ALI  OFIT_IMP_ADU  OFIT_IMP_DAD  OFIT_VAL_PIS  OFIT_VAL_COF  OFIT_USC  OFIT_DTC    OFIT_USU  OFIT_DTU
									'N',			'00',			'',				0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					[valor total]*0.7334,	12.00,				([valor total]*73.34/100)*.12,	([valor total])-([valor total]*0.7334),	0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					'KINKEL',	GETDATE(),	NULL,			NULL
			from #new b, MTPR a, mttp
			WHERE MTPR_COD = insumo
						and MTPR_MTTP = mttp_cod
						and grupo = @q
						
						--and Rlri_mtes not in (select mtpc_cod  from mtpc)	
		end else begin
			insert into #tra
--						OFIT_SIES OFIT_SIDO OFIT_SISE OFIT_OFNF				OFIT_COD	OFIT_CODF OFIT_SIDP		OFIT_SISP OFIT_CODP		OFIT_CODI OFIT_MTPC OFIT_NOM		OFIT_MTPR   OFIT_MS OFIT_MTUN		OFIT_MTNC						OFIT_ORI	OFIT_MTDV			OFIT_MTLN			OFIT_MTFM			OFIT_PLIQ OFIT_PLQT             OFIT_PBRT             OFIT_EST	OFIT_MTTR OFIT_STA  OFIT_CTPC   OFIT_RDPC OFIT_CTCC OFIT_RDCC OFIT_QTD    OFIT_PUN  OFIT_VAL				OFIT_REV	OFIT_DES  
			select	7,				'OF55',		'001',		90978+grupo,		0,				0,				'VDPD',			null,			0,					null,			mtpr_cod,	mtpr_nom ,	mtpr_cod,		'M',		mtpr_mtun,	substring(ncm,2,8),	0,				a.mtpr_mtdv,	a.mtpr_MTLN,	a.mtpr_MTFM,	MTPR_PES,	MTPR_PES*quantidade,	MTPR_PES*quantidade,	'S',			'NA',			0,				MTTP_CTPC,	NULL,			NULL,			NULL,			quantidade,	unit�rio,	[valor total],	'S',			0.00,			
							--OFIT_NFOP		
							convert(char(8),replace(replace(replace(replace(replace(replace(replace(replace((mttp_ctpc), '1110070001', '5.152.NA'), '1110070002', '5.152.NA'), '1110070003', '5.152.NA'), '1110070004', '5.152.NA'), '1110070005', '5.151.NA'), '1110070006', '5.152.NA'), '1110070007', '5.152.NA'),'3101070002','5.152.NA')),
							--OFIT_CFOP 
							convert(char(5),replace(replace(replace(replace(replace(replace(replace(replace((mttp_ctpc), '1110070001', '5.152'), '1110070002', '5.152'), '1110070003', '5.152'), '1110070004', '5.152'), '1110070005', '5.151'), '1110070006', '5.152'), '1110070007', '5.152'),'3101070002','5.152')),
							--	OFIT_TIT	OFIT_TBB	OFIT_MEN  OFIT_IPI_BAS	OFIT_IPI_ALI  OFIT_IPI_VAL  OFIT_IPI_ISE  OFIT_IPI_OUT  OFIT_ISS_BAS  OFIT_ISS_ALI  OFIT_ISS_VAL  OFIT_ISS_ISE  OFIT_ISS_OUT  OFIT_ICM_BAS		OFIT_ICM_ALI  OFIT_ICM_VAL					OFIT_ICM_ISE  OFIT_ICM_OUT  OFIT_IST_BAS  OFIT_IST_ALI  OFIT_IST_VAL  OFIT_IST_ISE  OFIT_IST_OUT  OFIT_IST_IVA  OFIT_ICP_ALI  OFIT_ICP_VAL  OFIT_VAL_FRE  OFIT_VAL_SEG  OFIT_VAL_ACE  OFIT_IMP_ALI  OFIT_IMP_ADU  OFIT_IMP_DAD  OFIT_VAL_PIS  OFIT_VAL_COF  OFIT_USC  OFIT_DTC    OFIT_USU  OFIT_DTU
									'N',			'00',			'',				0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					[valor total],	18.00,				[valor total]*18/100,	0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					'KINKEL',	GETDATE(),	NULL,			NULL
			from #new b, MTPR a, mttp
			WHERE MTPR_COD = insumo
						and MTPR_MTTP = mttp_cod
						and grupo = @q
						
						--and Rlri_mtes not in (select mtpc_cod  from mtpc)	
		end 

		print 'insere os registros temporaria na tabela OFIT, para o grupo :'+convert(char(3),@q)				
		insert into ofit
		--select	OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF		,num						,OFIT_CODF   ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC   ,OFIT_NOM        ,OFIT_MTPR   ,OFIT_MS ,OFIT_MTUN		,OFIT_MTNC		,OFIT_ORI	,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT               ,OFIT_PBRT               ,OFIT_EST	,OFIT_MTTR ,OFIT_STA  ,OFIT_CTPC   ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD      ,OFIT_PUN      ,OFIT_VAL      ,OFIT_REV	,OFIT_DES  ,OFIT_NFOP		,OFIT_CFOP ,OFIT_TIT	,OFIT_TBB	,OFIT_MEN  ,OFIT_IPI_BAS  ,OFIT_IPI_ALI  ,OFIT_IPI_VAL  ,OFIT_IPI_ISE  ,OFIT_IPI_OUT  ,OFIT_ISS_BAS  ,OFIT_ISS_ALI  ,OFIT_ISS_VAL  ,OFIT_ISS_ISE  ,OFIT_ISS_OUT  ,OFIT_ICM_BAS  ,OFIT_ICM_ALI  ,OFIT_ICM_VAL  ,OFIT_ICM_ISE  ,OFIT_ICM_OUT  ,OFIT_IST_BAS  ,OFIT_IST_ALI  ,OFIT_IST_VAL  ,OFIT_IST_ISE  ,OFIT_IST_OUT  ,OFIT_IST_IVA  ,OFIT_ICP_ALI  ,OFIT_ICP_VAL  ,OFIT_VAL_FRE  ,OFIT_VAL_SEG  ,OFIT_VAL_ACE  ,OFIT_IMP_ALI  ,OFIT_IMP_ADU  ,OFIT_IMP_DAD  ,OFIT_VAL_PIS  ,OFIT_VAL_COF  ,OFIT_USC  ,OFIT_DTC    ,OFIT_USU  ,OFIT_DTU
		select		OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF		,num						,OFIT_CODF   ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC   ,OFIT_NOM        ,OFIT_MTPR   ,OFIT_MS ,OFIT_MTUN		,OFIT_MTNC		,OFIT_ORI	,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT               ,OFIT_PBRT               ,OFIT_EST	,OFIT_MTTR ,OFIT_STA  ,OFIT_CTPC   ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD      ,OFIT_PUN      ,OFIT_VAL      ,OFIT_REV	,OFIT_DES  ,OFIT_NFOP		,OFIT_CFOP ,OFIT_TIT	,OFIT_TBB	,OFIT_MEN  ,OFIT_IPI_BAS  ,OFIT_IPI_ALI  ,OFIT_IPI_VAL  ,OFIT_IPI_ISE  ,OFIT_IPI_OUT  ,OFIT_ISS_BAS  ,OFIT_ISS_ALI  ,OFIT_ISS_VAL  ,OFIT_ISS_ISE  ,OFIT_ISS_OUT  ,OFIT_ICM_BAS  ,OFIT_ICM_ALI  ,OFIT_ICM_VAL  ,OFIT_ICM_ISE  ,OFIT_ICM_OUT  ,OFIT_IST_BAS  ,OFIT_IST_ALI  ,OFIT_IST_VAL  ,OFIT_IST_ISE  ,OFIT_IST_OUT  ,OFIT_IST_IVA  ,OFIT_ICP_ALI  ,OFIT_ICP_VAL  ,OFIT_VAL_FRE  ,OFIT_VAL_SEG  ,OFIT_VAL_ACE  ,OFIT_IMP_ALI  ,OFIT_IMP_ADU  ,OFIT_IMP_DAD  ,OFIT_VAL_PIS  ,OFIT_VAL_COF  ,OFIT_USC  ,OFIT_DTC    ,OFIT_USU  ,OFIT_DTU
		from #tra
	end
	set @q=@q+1
	
	drop table #tra
end

