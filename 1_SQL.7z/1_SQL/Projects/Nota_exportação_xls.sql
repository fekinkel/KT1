if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

drop table #new


select *, identity(int,1,1) num
into #new
from ofit
where 1=0

select top 1 *
from ofit
where ofit_ofnf = 2085

SELECT TOP 1 *
from [dos].[dbo].nfiscal
where [M�QUINAS DANLY LTDA] is not null
			and f4 is not null
			and f3 is not null


insert into #new
--			OFIT_SIES   OFIT_SIDO OFIT_SISE OFIT_OFNF   OFIT_COD	OFIT_CODF OFIT_SIDP		OFIT_SISP OFIT_CODP OFIT_CODI OFIT_MTPC									OFIT_NOM												OFIT_MTPR												OFIT_MS OFIT_MTUN OFIT_MTNC		OFIT_ORI	OFIT_MTDV		OFIT_MTLN		OFIT_MTFM		OFIT_PLIQ							OFIT_PLQT																		OFIT_PBRT																		OFIT_EST	OFIT_MTTR OFIT_STA  OFIT_CTPC     OFIT_RDPC OFIT_CTCC OFIT_RDCC OFIT_QTD														OFIT_PUN								OFIT_VAL																													OFIT_REV	OFIT_DES  OFIT_NFOP		OFIT_CFOP OFIT_TIT	OFIT_TBB	OFIT_MEN                                                                                                   OFIT_IPI_BAS OFIT_IPI_ALI  OFIT_IPI_VAL  OFIT_IPI_ISE																											OFIT_IPI_OUT  OFIT_ISS_BAS  OFIT_ISS_ALI  OFIT_ISS_VAL  OFIT_ISS_ISE  OFIT_ISS_OUT  OFIT_ICM_BAS  OFIT_ICM_ALI  OFIT_ICM_VAL  OFIT_ICM_ISE																											OFIT_ICM_OUT  OFIT_IST_BAS  OFIT_IST_ALI  OFIT_IST_VAL  OFIT_IST_ISE	OFIT_IST_OUT  OFIT_IST_IVA  OFIT_ICP_ALI  OFIT_ICP_VAL  OFIT_VAL_FRE  OFIT_VAL_SEG  OFIT_VAL_ACE  OFIT_IMP_ALI  OFIT_IMP_ADU  OFIT_IMP_DAD  OFIT_VAL_PIS  OFIT_VAL_COF  OFIT_USC  OFIT_DTC    OFIT_USU  OFIT_DTU
select	7 ,				'OF55',			'001',		2085,				0,				0,				'VDPD',			'001',		0,				NULL,			convert(varchar(20),F3),	convert(varchar(100),MTPC_NOM),	convert(varchar(20),MTPC_MTPR),	'M',		'PC',			'73202090',	0,				MTPR_MTDV,	MTPR_MTLN,	MTPR_MTFM,	replace(f4,',','.'),	replace(f4,',','.')*[M�QUINAS DANLY LTDA],	replace(f4,',','.')*[M�QUINAS DANLY LTDA],	'S',			'NA',			0,				'4101010005',	'4005',		'210199',	'RT099',	convert(int,[M�QUINAS DANLY LTDA]),	replace(taxa,',','.'),				convert(decimal(12,6),replace(taxa,',','.'))*[M�QUINAS DANLY LTDA],	'N',			0.00,			'7.101.A',	'7.101',	'S',			'40',			'N�O INC.DO ICMS,CONF.ART.7�,INC.V DO RICMS-SP/2000 - IMUNIDADE DE IPI CONF.ART.18,INC.II DO DEC.4544/02.',0.00,				15,						0.00,					convert(decimal(12,6),replace(taxa,',','.'))*[M�QUINAS DANLY LTDA],	0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					convert(decimal(12,6),replace(taxa,',','.'))*[M�QUINAS DANLY LTDA],	0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					0.00,					'ELITAS',	GETDATE(),	NULL,			NULL						
from [dos].[dbo].nfiscal, MTPC, MTPR
where [M�QUINAS DANLY LTDA] is not null
			and f4 is not null
			and f3 is not null
			AND MTPC_COD = F3
			AND MTPC_MTPR = MTPR_COD
			

delete 
--select *
from ofit
where ofit_ofnf = 2085


insert into ofit			
select OFIT_SIES,   OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF   ,num OFIT_COD,    OFIT_CODF   ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP   ,OFIT_CODI   ,OFIT_MTPC            ,OFIT_NOM                                                                                                                                                                                                                                                        ,OFIT_MTPR            ,OFIT_MS ,OFIT_MTUN ,OFIT_MTNC ,OFIT_ORI ,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ                               ,OFIT_PLQT                               ,OFIT_PBRT                               ,OFIT_EST ,OFIT_MTTR ,OFIT_STA    ,OFIT_CTPC       ,OFIT_RDPC ,OFIT_CTCC       ,OFIT_RDCC ,OFIT_QTD                                ,OFIT_PUN                                ,OFIT_VAL                                ,OFIT_REV ,OFIT_DES                                ,OFIT_NFOP ,OFIT_CFOP ,OFIT_TIT ,OFIT_TBB ,OFIT_MEN                                                                                                                                                                                                                                                        ,OFIT_IPI_BAS                            ,OFIT_IPI_ALI                            ,OFIT_IPI_VAL                            ,OFIT_IPI_ISE                            ,OFIT_IPI_OUT                            ,OFIT_ISS_BAS                            ,OFIT_ISS_ALI                            ,OFIT_ISS_VAL                            ,OFIT_ISS_ISE                            ,OFIT_ISS_OUT                            ,OFIT_ICM_BAS                            ,OFIT_ICM_ALI                            ,OFIT_ICM_VAL                            ,OFIT_ICM_ISE                            ,OFIT_ICM_OUT                            ,OFIT_IST_BAS                            ,OFIT_IST_ALI                            ,OFIT_IST_VAL                            ,OFIT_IST_ISE                            ,OFIT_IST_OUT                            ,OFIT_IST_IVA                            ,OFIT_ICP_ALI                            ,OFIT_ICP_VAL                            ,OFIT_VAL_FRE                            ,OFIT_VAL_SEG                            ,OFIT_VAL_ACE                            ,OFIT_IMP_ALI                            ,OFIT_IMP_ADU                            ,OFIT_IMP_DAD                            ,OFIT_VAL_PIS                            ,OFIT_VAL_COF                            ,OFIT_USC        ,OFIT_DTC                ,OFIT_USU        ,OFIT_DTU
from #new
where convert(char(1),OFIT_SIES)+'/'+OFIT_SIDO+'/'+OFIT_SISE+'/'+convert(varchar(6),OFIT_OFNF)+'/'+convert(varchar(6),num) not in (select convert(char(1),OFIT_SIES)+'/'+OFIT_SIDO+'/'+OFIT_SISE+'/'+convert(varchar(6),OFIT_OFNF)+'/'+convert(varchar(6),OFIT_cod) from ofit)
