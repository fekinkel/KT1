exec master.dbo.xp_cmdshell '\\192.168.3.38\disco_j\aplicativos\msgmdl.exe kinkel teste SQL asdsadkasjdksakdk addakjjdkjhdkajsjdk  dsahdjkashdkja sk'
