--select * from CPCT

--                           
drop table #cpct

--select '1', 'CPCT',		'001',		identity(int, 1,1),			 'OK',		NULL,					 NULL,					NULL,					 NULL,					NULL,	REPLACE(MTPX_COD,'.',''), REPLACE(MTPX_COD,'.',''), MTPX_NOM, 'GLFO',		1,					1,						1,						 'SIDOR',					NULL,   1,			 1,							'ELIANE' ,	'55 15 21014512', '55 15 21014515', 'exportsp@sidor.com.br', 1				,	MTPX_COD, 'PC',     1,				MTPV_VAL, MTPV_VAL,			MTPV_VAL, MTPV_VAL,			MTPV_VAL, 'USD',		0.00,					0.00,					0.00,					MTPV_VAL, '00',			1,					'',				'',				'KINKEL', GETDATE(), NULL,		NULL,			''
select '1' CPCT_SIES, 'CPCT' CPCT_SIDO,		'001' CPCT_SISE,		identity(int, 110,1) CPCT_COD,			 'OK' CPCT_STA,		NULL CPCT_CPSC_SIES,
 NULL CPCT_CPSC_SIDO,	NULL CPCT_CPSC_SISE,	NULL CPCT_CPSC_NPAI,	NULL CPCT_CPSC,	REPLACE(MTPX_COD,'.','') CPCT_MTPR,
 REPLACE(MTPX_COD,'.','') CPCT_MTPC, MTPX_NOM CPCT_ESPE, 'GLFO' CPCT_GLTX,		1 CPCT_GLXX,					1 CPCT_GLXX_DIG,						1 CPCT_GLXX_GLPA,
  'SIDOR' CPCT_GLXX_NRDZ,					NULL CPCT_REV,   1 CPCT_QTD,			 1 CPCT_QTD_GLFO,							'ELIANE'CPCT_CTO ,	'55 15 21014512' CPCT_TEL, '55 15 21014515'  CPCT_FAX,
   'exportsp@sidor.com.br' CPCT_EMAIL, 1 CPCT_GLCP,	MTPX_COD CPCT_CPID, 'PC' CPCT_CPUN,     1 CPCT_CPFT,				
   MTPV_VAL CPCT_PUN,  MTPV_VAL  CPCT_PUN_GLFO,			MTPV_VAL CPCT_PUND, MTPV_VAL CPCT_PUND_GLFO,			MTPV_VAL CPCT_VACT,
   'USD' CPCT_GLMD,		0.00 CPCT_IPI_ALI,					0.00 CPCT_ISS_ALI,					0.00 CPCT_ICM_ALI,					MTPV_VAL CPCT_VALT,
    '00' CPCT_GLPG,			1 CPCT_PENT,					'' CPCT_DOCF,				'' CPCT_OBS,				'KINKEL' CPCT_USC, GETDATE() CPCT_DTC, NULL CPCT_USU,		NULL CPCT_DTU,			'' CPCT_CPID_NOM
into #cpct
from [DOS].[dbo].COMPRAS

--insert into CPCT
select *
from #cpct
