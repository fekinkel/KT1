
--Todas as div/lin/fam USA
select SUBSTRING(mtpr_cod,1,3) [COD], MTPR_MTDV, MTPR_MTLN, MTPR_MTFM, IDENTITY(int,1,1) NUM
into [dos].[dbo].PreCod_usa
from MTPR
group by SUBSTRING(mtpr_cod,1,3), MTPR_MTDV, MTPR_MTLN, MTPR_MTFM

--Todas as div/lin/fam M�xico
select SUBSTRING(REF,1,CHARINDEX('.',REF)-1) [COD], DIV_REF MTPR_MTDV, LIN_REF MTPR_MTLN, FAM_REF MTPR_MTFM, IDENTITY(int,1,1) NUM
into PreCod_mex
from [dbfmex]...prod
where CHARINDEX('.',REF) >0
group by SUBSTRING(REF,1,CHARINDEX('.',REF)-1), DIV_REF, LIN_REF, FAM_REF

--Todas as div/lin/fam Brasil
select SUBSTRING(mtpr_cod,1,CHARINDEX('.',mtpr_cod)-1) [COD], MTPR_MTDV, MTPR_MTLN, MTPR_MTFM, IDENTITY(int,1,1) NUM
into [dos].[dbo].PreCod_bra
from MTPR
where charindex('.',MTPR_COD)>0
group by SUBSTRING(mtpr_cod,1,CHARINDEX('.',mtpr_cod)-1), MTPR_MTDV, MTPR_MTLN, MTPR_MTFM
