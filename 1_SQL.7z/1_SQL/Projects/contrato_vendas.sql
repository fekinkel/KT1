if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
--select top 1 * from VDCX where VDCX_VDCV = 8 and VDCX_MTPC like 'PPB.%'
insert into VDCX
--			VDCX_VDCV VDCX_MTPC VDCX_ATV	VDCX_MTPC_NOM VDCX_PUN_MOD	VDCX_PUN_VAL  VDCX_PUN_GLMD VDCX_PUN_PCT  VDCX_COM_TIPO VDCX_COM_PCT  VDCX_QTD  VDCX_USC  VDCX_DTC    VDCX_USU  VDCX_DTU
select 2,					MTPC_COD,	'S',			MTPC_NOM,			'N',					0.00,					'REAL',				75.00,				'N',					0.00,					0.00,			'KINKEL',	GETDATE(),	null,			null					
from MTPC
where MTPC_COD like 'PPB.%'
			and MTPC_COD not in (select VDCX_MTPC from VDCX where VDCX_VDCV = 2 )

select CONVERT(char(10), VDCX_DTC, 102), *
--delete
from VDCX
where VDCX_VDCV = 2
			and CONVERT(char(10), VDCX_DTC, 102) >= '2011.09.08'

select LEN(VDCX_MTPC_NOM), convert(char(50),VDCX_MTPC_NOM) VDCX_MTPC_NOM, convert(char(50),MTPC_NOM) MTPC_NOM, VDCX_MTPC
from VDCX, MTPC
where VDCX_MTPC = MTPC_COD
			and convert(varchar(25),VDCX_MTPC_NOM) <> convert(varchar(25),MTPC_NOM)
			and VDCX_VDCV = 45


