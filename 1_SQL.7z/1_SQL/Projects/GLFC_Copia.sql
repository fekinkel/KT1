insert into glfc
select GLFC_GLFN, GLFC_SIES, 2010 GLFC_ANO, 7 GLFC_MES, GLFC_VALP, GLFC_VALS, GLFC_VALR, GLFC_OBS, 'KINKEL' GLFC_USC, getdate() GLFC_DTC, null GLFC_USU, null GLFC_DTU
from glfc
where	glfc_ano = 2010
		and glfc_mes = 5