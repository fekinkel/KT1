drop table ##sise
select *, identity(int,1,1) NUM
into ##sise
from SISE
--SELECT * FROM ##SISE
declare
@i int,
@@v INT,
@s varchar(4000)
set @i = 1

while @i <= (select max(num) from ##sise) begin
	--select * from ##sise where num = @i
	select @s = 'DECLARE @@J int '+char(13)
	select @s = @s +'if ((select xtype from syscolumns where name = '+char(39)+SISE_SIDO+'_COD'+CHAR(39)+') = 56) and ((select count(1) from sysobjects where name = '+char(39)+SISE_SIDO+''+CHAR(39)+')>0) BEGIN '+CHAR(13) FROM ##SISE WHERE NUM= @I
	select @s = @s+'	SELECT @@J = isnull(MAX('+SISE_SIDO+'_COD),0) FROM '+SISE_SIDO+CHAR(13) FROM ##SISE WHERE NUM= @I
	select @s = @s+'	UPDATE ##SISE SET SISE_INI = @@j WHERE NUM='+CONVERT(varchar(6), @I)+CHAR(13)+'END'
	PRINT @S
	EXEC (@S)
	--select * from ##sise where num = @i
	set @i = @i +1
end

--SELECT MAX(CPPC_COD) FROM CPPC

--if (select xtype from syscolumns where name = 'glpa_cod') = 56 print 'S'


--select a.SISE_INI, b.SISE_NUM
update sise set SISE_NUM = a.SISE_INI 
from sise b, ##SISE a 
where a.SISE_SIES = b.SISE_SIES
			and a.SISE_SIDO = b.SISE_SIDO
			and a.SISE_COD  = b.SISE_COD
			and a.SISE_INI <> 0




