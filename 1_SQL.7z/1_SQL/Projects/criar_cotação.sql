select MTMV_SIES   ,MTMV_SIDO ,MTMV_SISE ,MTMV_COD    ,MTMV_SEQ    ,MTMV_DAT                ,MTMV_MTES            ,MTMV_MTTR ,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX   ,MTMV_SEQX   ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI ,MTMV_SEQ_ORI ,MTMV_LOTE_ORI        ,MTMV_CTPC_ORI   ,MTMV_CTCC_ORI   ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES ,MTMV_SEQ_DES ,MTMV_LOTE_DES        ,MTMV_CTPC_DES   ,MTMV_CTCC_DES   ,MTMV_MTAL_AUT ,MTMV_QTD                                ,MTMV_VAL                                ,MTMV_VALM                               ,MTMV_VALP                               ,MTMV_VALA                               ,MTMV_GLHP ,MTMV_MEN                                                                                                                                                                                                                                                         ,MTMV_USC        ,MTMV_DTC                ,MTMV_USU        ,MTMV_DTU
from mtmv
where mtmv_cod = 398297
			and mtmv_sies = 5

select MTMV_SIES   ,MTMV_SIDO ,MTMV_SISE ,MTMV_COD    ,MTMV_SEQ    ,MTMV_DAT                ,MTMV_MTES            ,MTMV_MTTR ,MTMV_AUTO ,MTMV_TRAN ,MTMV_ACAO ,MTMV_DIRE ,MTMV_VLIN ,MTMV_UCIN ,MTMV_ATUM ,MTMV_SUCA ,MTMV_SIDX ,MTMV_SISX ,MTMV_CODX   ,MTMV_SEQX   ,MTMV_MTAL_ORI ,MTMV_SUBL_ORI ,MTMV_TABE_ORI ,MTMV_SIDO_ORI ,MTMV_SISE_ORI ,MTMV_COD_ORI ,MTMV_SEQ_ORI ,MTMV_LOTE_ORI        ,MTMV_CTPC_ORI   ,MTMV_CTCC_ORI   ,MTMV_MTAL_DES ,MTMV_SUBL_DES ,MTMV_TABE_DES ,MTMV_SIDO_DES ,MTMV_SISE_DES ,MTMV_COD_DES ,MTMV_SEQ_DES ,MTMV_LOTE_DES        ,MTMV_CTPC_DES   ,MTMV_CTCC_DES   ,MTMV_MTAL_AUT ,MTMV_QTD                                ,MTMV_VAL                                ,MTMV_VALM                               ,MTMV_VALP                               ,MTMV_VALA                               ,MTMV_GLHP ,MTMV_MEN                                                                                                                                                                                                                                                         ,MTMV_USC        ,MTMV_DTC                ,MTMV_USU        ,MTMV_DTU
from mtmv
where mtmv_cod = 626606
			and mtmv_sies = 1

--Rlri_mtes            Rlri_nom                                           Rlri_mtun Rlri_mtnc Rlri_ctpc       Rlri_ctpc_nom                                      Rlri_mtal Rlri_fisi Rlri_orde                 Rlri_subl                 Rlri_orde_sido Rlri_orde_sise Rlri_orde_cod Rlri_orde_qtdo                          Rlri_qtd_alm                            Rlri_vun_alm                            Rlri_mat_alm                            Rlri_mdo_alm                            Rlri_val_alm                            Rlri_qtd_tot                            Rlri_cmur                               Rlri_val_tot                            Rlri_tipo mtpr_mtdv mtpr_mtln mtpr_mtfm gp
			
select 1 MTMV_SIES   , 'MTMV' MTMV_SIDO , '001' MTMV_SISE , IDENTITY(INT,626739,1) MTMV_COD    , 1 MTMV_SEQ    , getdate()-6 MTMV_DAT                , Rlri_mtes MTMV_MTES            ,'TRASAI' MTMV_MTTR ,'N' MTMV_AUTO , 'N' MTMV_TRAN , 'S' MTMV_ACAO , 'S' MTMV_DIRE ,'N' MTMV_VLIN , 'N' MTMV_UCIN , 'S' MTMV_ATUM , 'N' MTMV_SUCA ,NULL MTMV_SIDX , NULL MTMV_SISX , 0 MTMV_CODX   , 0 MTMV_SEQX   , Rlri_mtal MTMV_MTAL_ORI , 0 MTMV_SUBL_ORI , NULL MTMV_TABE_ORI , NULL MTMV_SIDO_ORI , NULL MTMV_SISE_ORI , 0 MTMV_COD_ORI , 0 MTMV_SEQ_ORI , NULL MTMV_LOTE_ORI        ,Rlri_ctpc MTMV_CTPC_ORI   ,NULL MTMV_CTCC_ORI   ,'CTACOR' MTMV_MTAL_DES , 0 MTMV_SUBL_DES ,NULL MTMV_TABE_DES , NULL MTMV_SIDO_DES , NULL MTMV_SISE_DES ,0 MTMV_COD_DES , 0 MTMV_SEQ_DES , NULL MTMV_LOTE_DES        , '1299010001' MTMV_CTPC_DES   ,NULL MTMV_CTCC_DES   , 'CTACOR' MTMV_MTAL_AUT , Rlri_qtd_alm MTMV_QTD                                , Rlri_mat_alm MTMV_VAL                                , Rlri_mat_alm/1.7 MTMV_VALM                               , 0.00 MTMV_VALP                               , 0.00 MTMV_VALA                               , NULL MTMV_GLHP , 'TRANSFERENCIA DE ESTAB. 5 PARA 7' MTMV_MEN                                                                                                                                                                                                                                                         , 'KINKEL' MTMV_USC        , getdate()-6 MTMV_DTC                ,NULL MTMV_USU        , NULL MTMV_DTU
INTO #novo
from [dos].[dbo].new1
where Rlri_orde = ''

select *
from [dos].[dbo].tmpRlri
where Rlri_mtes like '%dep%'

select 7 MTMV_SIES   , 'MTMV' MTMV_SIDO , '001' MTMV_SISE , IDENTITY(INT,1,1) MTMV_COD    , 1 MTMV_SEQ    , getdate()-4 MTMV_DAT                , Rlri_mtes MTMV_MTES            ,'TRAENT' MTMV_MTTR ,'N' MTMV_AUTO , 'N' MTMV_TRAN , 'S' MTMV_ACAO , 'S' MTMV_DIRE ,'S' MTMV_VLIN , 'N' MTMV_UCIN , 'N' MTMV_ATUM , 'N' MTMV_SUCA ,NULL MTMV_SIDX , NULL MTMV_SISX , 0 MTMV_CODX   , 0 MTMV_SEQX   , 'CTACOR' MTMV_MTAL_ORI , 0 MTMV_SUBL_ORI , NULL MTMV_TABE_ORI , NULL MTMV_SIDO_ORI , NULL MTMV_SISE_ORI , 0 MTMV_COD_ORI , 0 MTMV_SEQ_ORI , NULL MTMV_LOTE_ORI        , '1299010001' MTMV_CTPC_ORI   ,NULL MTMV_CTCC_ORI   ,Rlri_mtal MTMV_MTAL_DES , 0 MTMV_SUBL_DES ,NULL MTMV_TABE_DES , NULL MTMV_SIDO_DES , NULL MTMV_SISE_DES ,0 MTMV_COD_DES , 0 MTMV_SEQ_DES , NULL MTMV_LOTE_DES        , Rlri_ctpc MTMV_CTPC_DES   ,NULL MTMV_CTCC_DES   , null MTMV_MTAL_AUT , Rlri_qtd_alm MTMV_QTD                                , Rlri_mat_alm MTMV_VAL                                , Rlri_mat_alm/1.7 MTMV_VALM                               , 0.00 MTMV_VALP                               , 0.00 MTMV_VALA                               , NULL MTMV_GLHP , 'TRANSFERENCIA DE ESTAB. 5 PARA 7' MTMV_MEN                                                                                                                                                                                                                                                         , 'KINKEL' MTMV_USC        , getdate()-4 MTMV_DTC                ,NULL MTMV_USU        , NULL MTMV_DTU
--INTO #novo1
from [dos].[dbo].new1
where Rlri_orde = ''


insert into mtmv
select *
from #novo

insert into mtmv
select *
from #novo1

select *
from #novo

drop table #novo
drop table #novo1
			
