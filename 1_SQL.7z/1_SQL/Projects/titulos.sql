if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

select *
--update ctla set CTLA_ATV = 'N'
from ctla
where ctla_usc = 'ROBINB'
			and convert(char(10),CTLA_DTC,102) = '2010.11.30'
			
select *
--delete ctla
from ctla
where ctla_usc = 'ROBINB'
			and convert(char(10),CTLA_DTC,102) = '2010.11.30'			