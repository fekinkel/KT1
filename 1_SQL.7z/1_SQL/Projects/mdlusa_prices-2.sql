SELECT *--substring(PRE_C�DIGO,2,15), substring(DIVISAO_OLD,2,2), substring(LINHA_OLD,2,2) , substring(FAMILIA_OLD,2,2), REPLICATE('0',4-len(substring(DIVISAO_NOVA,2,4)))+rtrim(ltrim(substring(DIVISAO_NOVA,2,4))), REPLICATE('0',4-LEN(substring(LINHA_NOVA,2,4)))+RTRIM(ltrim(substring(LINHA_NOVA,2,4))), REPLICATE('0',4-LEN(substring(FAMILIA_NOVA,2,4)))+LTRIM(rtrim(substring(FAMILIA_NOVA,2,4))), ISNULL(STUFF(substring(TIPO_INSUMO,2,30),3,1,'-'),'MP-Mat�ria Prima')
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=c:\bkp\divisao_mex.XLS',[sheet3$]) 
where [PRE_C�DIGO] <> 'wwwwww'
--DROP TABLE #OLD
SELECT *
into #old
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\bkp\mdlusa_prices-1.XLS',[sheet3$]) 

--DROP TABLE #NEW
SELECT substring([PART #],1,20) [COD], OLD [COMPETIDOR], NEW [NOVO]
into #new
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\bkp\Sales_Price_List_US.XLS',[New$]) 

select * from #old

select [COD], OLD [SISTEMA], [COMPETIDOR], [NOVO]
into #novo
from #new left outer join #old on #old.MDL = #new.COD
where substring([cod],1,2) = 'TA'
order by [COD]

select a.*, replace(MTPC_PRE,'.',',') [S2R]
from #novo a, mtpc
where cod = MTPC_COD
order by cod




--(2089 linha(s) afetadas)