--EXEC sp_dropserver 'dbf2'
--PARA EXCLUIR V� EM OBJETOS DE SERVIDOR->SERVIDORES VINCULADOS->
--EXEC sp_dropserver 'dbf4'
--N�O ESQUECER DA BARRA NO FINAL DO CAMINHO
--EXEC sp_addlinkedserver 'DBF4', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'c:\mexico\scdmex\dados\', NULL, 'dBase III'
EXEC sp_addlinkedserver 'DBF4', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'c:\mexico\scdmex\EMP01\', NULL, 'dBase III'
--EXEC sp_addlinkedserver 'DBF4', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'G:\SCG1012\EMP01\', NULL, 'dBase III'
--EXEC sp_addlinkedserver 'DBF4', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', '\\192.168.2.41\smrdosold\SCG1012\EMP01\', NULL, 'dBase III'
exec sp_addlinkedsrvlogin 'DBF4', true, 'mdl\KINKEL', 'sa', 'mdlmdl'
exec sp_addlinkedsrvlogin 'DBF4', false, NULL, 'admin', NULL

--exec sp_addlinkedserver  'dbf2', '', 'MSDASQL', Null, Null, 'Driver={Microsoft dBASE Driver (*.dbf)};DriverID=277;DBQ=c:\mexico\SCDMEX\DADOS',null
--exec sp_addlinkedsrvlogin 'DBF2', false, 'mdl\KINKEL', 'Admin', NULL

--select * from dbf2...prod

select * 
--delete
from dbf4...[01abem] 
where rtrim(ltrim(COD_BEM)) >= '90-0041%'
			and rtrim(ltrim(COD_BEM)) <= '90-0042%'
order by rtrim(ltrim(COD_BEM))

--INSERT INTO dbf4...[0110amov] select '90-0042/44' COD_BEM,  NUM_MOV, 10 MES_CAL, '14/10/2010' DAT_MOV, 'NR 31310'DOC_MOV, AUT_MOV, COD_MPR, SIT_ATU, SIT_FIM, GRU_ATU, GRU_FIM, DTC_SIS, DTU_SIS, USU_SIS
--delete
--SELECT *
from dbf4...[0110amov] 
where rtrim(ltrim(COD_BEM)) >= '90-0042/42%'
			and rtrim(ltrim(COD_BEM)) <= '90-0042/43%'
			--and MES_CAL = 09
order by rtrim(ltrim(COD_BEM))

--INSERT INTO dbf4...[0110amov] select '90-0042/44' COD_BEM,  NUM_MOV, 12 MES_CAL, '31/12/2010' DAT_MOV, DOC_MOV, AUT_MOV, COD_MPR, SIT_ATU, SIT_FIM, GRU_ATU, GRU_FIM, DTC_SIS, DTU_SIS, USU_SIS
--delete
--SELECT *
from dbf4...[0110amov] 
where rtrim(ltrim(COD_BEM)) >= '90-0042/42%'
			and rtrim(ltrim(COD_BEM)) <= '90-0042/43%'
			and MES_CAL = 11
order by rtrim(ltrim(COD_BEM))

SELECT *
from dbf4...[0110amov] 
where rtrim(ltrim(COD_BEM)) >= '90-0042/43%'
			and rtrim(ltrim(COD_BEM)) <= '90-0042/44%'
			--and MES_CAL = 11
order by rtrim(ltrim(COD_BEM))
