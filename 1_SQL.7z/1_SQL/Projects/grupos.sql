
insert into [mdl].[dbo].[siop]
select *
from siop
where SIOP_COD like '%%'
			and SIOP_COD not in (select SIOP_COD from [mdl].[dbo].siop)


insert into [mdl].[dbo].simo
select *
from simo
where SIMO_SIMD like '%%'
			and SIMO_SIMD+'/'+SIMO_SIOP not in (select SIMO_SIMD+'/'+SIMO_SIOP from [mdl].[dbo].simo)

insert into [mdl].[dbo].sigo
select *--rtrim(ltrim(SIGO_SIGR))+'/'+rtrim(ltrim(SIGO_SIAP))+'/'+rtrim(ltrim(SIGO_SIMD))+'/'+rtrim(ltrim(SIGO_SIOP)), count(1)--*
from sigo
where rtrim(ltrim(SIGO_SIGR))+'/'+rtrim(ltrim(SIGO_SIAP))+'/'+rtrim(ltrim(SIGO_SIMD))+'/'+rtrim(ltrim(SIGO_SIOP)) not in(select rtrim(ltrim(SIGO_SIGR))+'/'+rtrim(ltrim(SIGO_SIAP))+'/'+rtrim(ltrim(SIGO_SIMD))+'/'+rtrim(ltrim(SIGO_SIOP)) from [mdl].[dbo].sigo)
group by rtrim(ltrim(SIGO_SIGR))+'/'+rtrim(ltrim(SIGO_SIAP))+'/'+rtrim(ltrim(SIGO_SIMD))+'/'+rtrim(ltrim(SIGO_SIOP))

--insert into [mdl].[dbo].sigo
select *
from sigo
where SIGO_SIGR like 'fis%'
			and rtrim(ltrim(SIGO_SIGR))+'/'+rtrim(ltrim(SIGO_SIAP))+'/'+rtrim(ltrim(SIGO_SIMD))+'/'+rtrim(ltrim(SIGO_SIOP)) not in(select rtrim(ltrim(SIGO_SIGR))+'/'+rtrim(ltrim(SIGO_SIAP))+'/'+rtrim(ltrim(SIGO_SIMD))+'/'+rtrim(ltrim(SIGO_SIOP)) from [mdl].[dbo].sigo)