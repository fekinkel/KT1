select status, * 
from master..sysprocesses
where status = 'sleeping'
			and hostname = 'SERVERMQ04'
			
kill 65			