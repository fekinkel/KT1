select *
from pai

select *
from filho

insert into filho
select 'kinkel', 'fernando', null

insert into filho
select 'kinkel', 'serejo', null

insert into filho
select 'rodrigo', 'dias', null

select *
from pai

delete 
from filho 
where nome = 'fernando'

select *
from pai
