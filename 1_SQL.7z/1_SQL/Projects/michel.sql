select MTPC_COD [Part#], convert(char(50),MTPC_NOM) [descri��o], convert(char(16),replace(MTPC_PRE,'.',',')) [pre�o de vendas], MTPR_MTDV [Divis�o], MTPR_MTLN [Linha], MTPR_MTFM [Fam�lia]
from mtpc, mtpr
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'S'
			and (substring(MTPC_COD,7,20) not like ('%c%')
			and substring(MTPC_COD,7,20) not like ('%s%')
			and substring(MTPC_COD,7,20) not like ('%u%')
			and substring(MTPC_COD,7,20) not like ('%n%')
			and substring(MTPC_COD,7,20) not like ('%-1%')
			)

select *
from MTPR
where MTPR_COD = 'p16010020'
