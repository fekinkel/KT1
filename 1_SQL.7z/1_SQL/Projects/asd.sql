drop table #vdc1

declare
@cod int,
@mtln char(4)

set @cod = 166523
set @mtln = '3200'

--select *
--from vdpd
--where 
--delete  from vdc1 where vdc1_vdco  = @cod

select 5 VDC1_SIES, 'VDCO' VDC1_SIDO, '001' VDC1_SISE, @cod VDC1_VDCO, identity(int,1,1) VDC1_COD, 0 VDC1_SUB, 'OUTR' VDC1_TIPO, mtpc_cod VDC1_MTPC, mtpc_nom VDC1_MTPC_NOM, '0' VDC1_ORC, 'N' VDC1_REV, 1 VDC1_QTDE, mtpc_pre VDC1_PUNI, 0 VDC1_DESC, mtpc_pre VDC1_PUNID, 0 VDC1_PENT, mtpc_pre VDC1_IPI_BAS, MTNC_IPI VDC1_IPI_ALI, MTNC_IPI*mtpc_pre/100 VDC1_IPI_VAL, 0 VDC1_ICMS_ST, 'N' VDC1_SMDO, null VDC1_OBS, 0 VDC1_CMDO, mtpc_pre VDC1_CMAT, 1 VDC1_FATR, 1 VDC1_FMAT, 1 VDC1_FMDO, 'N' VDC1_ESPE, null VDC1_MTPR, mtpr_pes VDC1_PESO, mtpr_pes VDC1_PBRT, 0 VDC1_VDCV, 'KINKEL' VDC1_USC, getdate() VDC1_DTC, null VDC1_USU, null VDC1_DTU
into #vdc1
from mtpr, mtpc, mtnc
where mtpr_mtln = @mtln
			and mtpr_cod = mtpc_mtpr
			--and mtpc_cod like '9-%'  
			and mtpr_mtnc = mtnc_cod
			and mtpc_pre > 0

select count(1) Contador, VDC1_MTPC
from #vdc1
group by VDC1_MTPC
having count(1)>1

insert into vdc1
select *
from #vdc1
where vdc1_mtpc not in (select VDC1_MTPC from vdc1 where vdc1_vdco  = @cod)

select VDC1_MTPC from vdc1 where vdc1_vdco  = @cod

/*
select *
from vdc1
where vdc1_vdco = 166448

select top 1 *
from mtpr
*/



