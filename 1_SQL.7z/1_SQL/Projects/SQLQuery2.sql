drop table #ctpc
--insert into CTPC
select identity(int,1,1) cod, replace(replace(cc,'.',''),'#','') CTPC_COD        ,UPPER(descr) CTPC_NOM                                           ,replace(ISNULL(reduzido,'#'),'#','') CTPC_NRD , upper(substring(ATIVO,1,1)) CTPC_NAT ,replace(replace(replace(isnull(Statement,'x'),'Balance Sheet','A'),'x','S'),'Income Statement','A') CTPC_AOS ,'S' CTPC_ATV ,'N' CTPC_ECC , 'USD' CTPC_GLMD , 'S' CTPC_MAP ,'KINKEL' CTPC_USC        ,getdate() CTPC_DTC                ,null CTPC_USU        ,null CTPC_DTU
into #ctpc
from [DOS].[dbo].ASSET
where (cc) is not null
order by cc

declare
@i int,
@j int

set @i = 1

select @j = COUNT(1) from #ctpc

while @i < @j begin

	if (select count(1) from #CTPC where cod = @i and ctpc_nom is not null)>0 begin
		insert into CTPC
		select CTPC_COD        ,CTPC_NOM                                           ,CTPC_NRD ,CTPC_NAT ,CTPC_AOS ,CTPC_ATV ,CTPC_ECC ,CTPC_GLMD ,CTPC_MAP ,CTPC_USC        ,CTPC_DTC                ,CTPC_USU        ,CTPC_DTU
		from #CTPC
		where cod = @i
		print 'Primeiro'
		select * from #CTPC	where cod = @i
		
	end else begin
		insert into CTPC
		select a.CTPC_COD        ,b.CTPC_NOM                                           ,a.CTPC_NRD ,a.CTPC_NAT ,a.CTPC_AOS ,a.CTPC_ATV ,a.CTPC_ECC ,a.CTPC_GLMD ,a.CTPC_MAP ,a.CTPC_USC        ,a.CTPC_DTC                ,a.CTPC_USU        ,a.CTPC_DTU
		from #CTPC a, #CTPC b
		where a.cod = @i
					and b.cod = @i-1
		print 'Segundo'
	end
	set @i= @i +1
end

--delete from CTPC

--drop table #ctpc
--select * from [DOS].[dbo].ASSET
