--(1676 linha(s) afetadas)

select MTPC_PRE, VAL, MTPC_PRE/VAL*100, *
--update mtpc set mtpc_pre = val, MTPC_PRE_USU = 'KINKEL', MTPC_PRE_DTU = getdate()
from MTPC a, [dos].[dbo].CTA b
where MTPC_COD = REF
			--and (MTPC_PRE/VAL*100 >= 94
			--or MTPC_PRE/VAL*100 <= 88)