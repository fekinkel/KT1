--select * from #new
drop table #new

select distinct  999999 VDCV_COD, convert(char(50), Clientes) Clientes, glcl_cod, glcl_dig, isnull(div1,'x') div1, isnull(div2,'x')div2, identity(int,1,1) num
into #new
from [dos].[dbo].contratos2011, GLPA, glcl
where clientes = glpa_nrdz
			and glcl_glpa = glpa_cod
			and div1 is not null

insert into #new
select distinct 999999, convert(char(50), Clientes) Clientes, glcl_cod, glcl_dig, isnull(div1,'x'), isnull(div2,'x')
from [dos].[dbo].contratos2011, GLPA, glcl
where clientes = glpa_nOM
			and glcl_glpa = glpa_cod
			and div1 is not null
	

--select VDCV_COD, convert(varchar(15),div1), convert(varchar(15),div2)
--update #new set VDCV_COD = a.VDCV_COD
from vdcv a, #new b
where VDCV_GLCL = glcl_cod  
			and VDCV_GLCL_DIG = glcl_dig
--order by num			

DECLARE
@CONT INT,
@cli int,
@PORC INT,
@div varchar(4)

set @cli = 46; set @cont = 5; set @porc = 15; set @div = '0500'
set @cli = 4536; set @cont = 7; set @porc = 10; set @div = '0500'
--			VDCX_VDCV VDCX_MTPC VDCX_ATV	VDCX_MTPC_NOM VDCX _PUN_MOD	VDCX_PUN_VAL	VDCX_PUN_GLMD VDCX_PUN_PCT  VDCX_COM_TIPO VDCX_COM_PCT  VDCX_QTD  VDCX_USC  VDCX_DTC    VDCX_USU  VDCX_DTU
insert into vdcx
select	@cont ,		mtpc_cod, 'S',			mtpr_nom,			'N',					0.00,					'REAL',				100-@porc,		'N',					0.00,					0.00,			'KINKEL',	GETDATE(),	NULL,			NULL			
from mtpr, mtpc, glcl
where glcl_cod = @cli
			and mtpr_mtdv = @div
			and MTPR_ATVV = 'S'
			and substring(mtpc_cod,1,1) not in ('S','o','r')
			and mtpr_cod  = mtpc_mtpr
			and convert(varchar(6),@cont)+'/'+mtpc_cod not in (select convert(varchar(6),VDCX_VDCV)+'/'+VDCX_MTPC from vdcx)
			
--select top 1 * from vdcx


