---------------------------------------------------------------------------------------------
-- DATA                -- AUTOR          -- HIST�RICO
-- Feb  1 2011  6:23PM -- si_exec_STP   -- Script p/ prepara��o do exec de uma dada STP
---------------------------------------------------------------------------------------------
Declare   @modo varchar(1)  ,@par_erro varchar(255)  ,@vSies int  ,@vSido varchar(4)  ,@vSise varchar(3)  ,@vCod int
,@vSies_ori int  ,@vSido_ori varchar(4)  ,@vSise_ori varchar(3)  ,@vCod_ori int  ,@vUsc varchar(15)  ,@vDtc datetime
  ,@vGlcl int  ,@vGlcl_dig int  ,@GLPR_Nfop_S varchar(255)  ,@vGlfo int  ,@vGlfo_dig int  ,@vGlcp int  ,@GLPR_Nfop_E varchar(255)
Select
   @modo        ='I'
  ,@par_erro    =''
  ,@vSies       =7            -- estab destino do recebimento      -- 7
  ,@vSido       ='ORNF'       -- SIDO destino do recebimento       -- 'ORNR'
  ,@vSise       ='001'        -- Sise destino do recebimento       -- sempre ''
  ,@vCod        =0            -- N�mero da pr�-nota do recebimento -- sempre 0
  ,@vSies_ori   =1            -- Dados da NF origem -- estab       -- 1
  ,@vSido_ori   ='FT55'       -- Dados da NF origem -- sido        -- 'FTNF'
  ,@vSise_ori   ='001'        -- Dados da NF origem -- sise        -- '001'
  ,@vCod_ori    =17388        -- Dados da NF origem -- n�mero      -- ???
  ,@vUsc        ='sqlQA'      -- usu�rio
  ,@vDtc        =getdate()    -- data
  ,@vGlcl       =1            -- Cliente da nota fiscal origem
  ,@vGlcl_dig   =6            -- Digito do cliente da nota fiscal origem
  ,@GLPR_Nfop_S ='5.151.A;5.152.A;5.152.B;5.151.B;5.152.NA;5.151.NA'           -- conjunto de NFOPS dos itens de saida tipo 5.101A;5.101B;
  ,@vGlfo       =31082        -- C�digo do fornecedor para representar o estab da nota origem
  ,@vGlfo_dig   =1            -- Sempre 1
  ,@vGlcp       =4            -- comprador do estab destino
  ,@GLPR_Nfop_E ='1.151.A;1.152.A;1.152.B;1.151.B;1.152.NA;1.151.NA'           -- conjunto de NFOPS dos itens de entrada tipo 1.101A;1.101B;

Exec [dbo].[RC_PRENR_TRANS71]   @modo output  ,@par_erro output  ,@vSies output  ,@vSido output  ,@vSise output  ,@vCod output
  ,@vSies_ori  ,@vSido_ori  ,@vSise_ori  ,@vCod_ori  ,@vUsc  ,@vDtc
  ,@vGlcl  ,@vGlcl_dig  ,@GLPR_Nfop_S  ,@vGlfo  ,@vGlfo_dig  ,@vGlcp  ,@GLPR_Nfop_E
print @modo
print @par_erro
print @vSies
print @vSido
print @vSise
print @vCod