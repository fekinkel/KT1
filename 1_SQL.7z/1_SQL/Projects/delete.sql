if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

insert into [mdl].[dbo].ofnf
select *
--delete
from ofnf
where ofnf_cod >= 90979

insert into [mdl].[dbo].ofco
select *
--delete
from ofco
where ofco_cod >= 90979

insert into [mdl].[dbo].ofit
select *
--delete
from ofit
where ofit_ofnf >= 90979

SELECT TOP 1 *
FROM MTPR

select *--FTIT_MTNC, max(ftit_cfop), max(FTIT_TBB) 
from ftit 
where convert(char(10),ftit_dtc,102)>='2010.11.10' 
group by FTIT_MTNC