--Autor				: Fernando Kinkel
--Data				: 15/03/2011
--Solicitante	: Sr(a). Eliane/ Antonio Carlos
--Objetivo		: Incluir novos itens
--Campos			: Todos
--Restri��es	: Fornecedor Rabourdin
--Observa��es	: n�mero inicial 00004449 estab. 3, 4, 5, 8

drop table #new

--Criar uma tabela tempor�ria com os itens que precisam ser incluidos
--Como referencia vou usar o estab (SIEX) 3

select *,  identity(int, 4449,1) num
into #new
from [dos].[dbo].rabourdin
where mtpc_cod not in (select mtpx_cod from mtpx where mtpx_siex = 3)

--			MTPU_COD										MTPU_NOM  MTPU_PLIQ MTPU_ESPE MTPU_USC  MTPU_DTC    MTPU_USU  MTPU_DTU
insert into MTPU
select	replicate('0',8-len(num))+convert(varchar(8),num),	mtpc_des,	mtpc_pes,	'',				'KINKEL',	GETDATE(),	NULL,			NULL
from #new
where replicate('0',8-len(num))+convert(varchar(8),num) not in (select mtpu_cod from mtpu)

--Estabelecimento
declare
@i int
set @i = 8


insert into MTPX
--			MTPX_MTPU																						MTPX_SIEX MTPX_COD  MTPX_NOM  
--MTPX_EXGR 
--MTPX_USC  MTPX_DTC    MTPX_USU  MTPX_DTU
select	replicate('0',8-len(num))+convert(varchar(8),num),	@i,				mtpc_cod,	mtpc_des,	
case convert(varchar(10),substring(mtpc_cod, 1,charindex('.',mtpc_cod))) 
	when 'BA2.' then '003'
	when 'CA2.' then '003'
	when 'EB2.' then '004'
	when 'GB2.' then '004'
	when 'HB2.' then '004'
	when 'JB2.' then '004'
	when 'NB2.' then '004'
	when 'PA2.' then '008'
	when 'RD2.' then '003'
	when 'RI2.' then '002'
	when 'RM2.' then '003'
	when 'JB2.' then '003'
end,		
'KINKEL',	GETDATE(),	NULL,			NULL
from #new
WHERE ltrim(rtrim(MTPC_COD))+'/'+convert(varchar(3),@i) NOT IN (SELECT ltrim(rtrim(MTPX_COD))+'/'+CONVERT(VARCHAR(2),MTPX_SIEX) FROM MTPX)
order by MTPC_COD

--			MTPV_MTTV   MTPV_MTPU		MTPV_VAL  MTPV_USC  MTPV_DTC    MTPV_USU  MTPV_DTU
insert into mtpv
--select	3,					MTPX_MTPU,	tab_3,		'KINKEL',	getdate(),	null,			null
select '3'+'/'+MTPX_MTPU
from mtpx, [dos].[dbo].rabourdin_price
where convert(char(10),MTPx_DTC,102) = '2011.03.15'
			and mtpx_siex = 3
			and mtpx_cod  = Ins_R
			and tab_3 > 0
			and '3'+'/'+rtrim(ltrim(MTPX_MTPU)) not in (select convert(varchar(2),MTPV_MTPU)+'/'+rtrim(ltrim(MTPV_MTTV)) from mtpv)
			 
insert into mtpv
select	6,					MTPX_MTPU,	tab_6,		'KINKEL',	getdate(),	null,			null
from mtpx, [dos].[dbo].rabourdin_price
where convert(char(10),MTPx_DTC,102) = '2011.03.15'
			and mtpx_siex = 3
			and mtpx_cod  = Ins_R
			and tab_6 > 0
			and MTPX_MTPU+'/'+'6' not in (select MTPV_MTTV+'/'+convert(varchar(2),MTPV_MTPU) from mtpv)
			 
insert into mtpv
select	7,					MTPX_MTPU,	tab_4,		'KINKEL',	getdate(),	null,			null
from mtpx, [dos].[dbo].rabourdin_price
where convert(char(10),MTPx_DTC,102) = '2011.03.15'
			and mtpx_siex = 3
			and mtpx_cod  = Ins_R
			and tab_4 > 0
			and MTPX_MTPU+'/'+'7' not in (select MTPV_MTTV+'/'+convert(varchar(2),MTPV_MTPU) from mtpv)


--select top 1 * from mtpv[dos].[dbo].rabourdin_price
/*
select *
--delete
from mtpu
where convert(char(10),MTPU_DTC,102) = '2011.03.15'

select *
--delete
from mtpx
where convert(char(10),MTPX_DTC,102) = '2011.03.15'

*/
