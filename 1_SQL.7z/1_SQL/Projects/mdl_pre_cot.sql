
---N�O EST� FUNCIONANDO
drop table #cpct

declare
@doc varchar(255),
@obs varchar(255),
@sies int,
@cod int,
@cod_new int

--set @doc = 'REF. 08/2010'
--set @obs = 'CORRE��O DE VALOR (PROG. INCLUIR_PRE�O.SQL)'
set @doc = 'REF. 09/2010'
set @obs = 'CORRE��O DE VALOR (PROG. INCLUIR_PRE�O.SQL)'

set @sies = 1

/*
select  *
from kinp a
where ((mtpc_fator > 0)or(cpct_fator > 0)) 
			and substring(mtpc_cod,1,1) != '9'

select top 10 * from mtpr
*/

select @cod = SISE_NUM
from sise
where SISE_SIES = @sies
			and SISE_SIDO = 'CPCT'
			and SISE_COD  = '001'

select @cod_new = count(1) 
from kinp a, mtpr b
where ((mtpc_fator > 0)or(cpct_fator > 0)) 
			and substring(mtpc_cod,1,1) != '9'
			and a.mtpr_cod  = b.mtpr_cod

print @cod
print @cod_new
set @cod_new = @cod+@cod_new
print @cod_new

/*
select convert(decimal(12,2),MTNC_IPI), NFIA_PCT, CPCT_IPI_ALI, CPCT_ICM_ALI, a.*
--update cpct set CPCT_IPI_ALI = convert(decimal(12,2),MTNC_IPI), CPCT_ICM_ALI = NFIA_PCT
from cpct a, mtpr b, mtnc c, nfop d, nfia e
where CPCT_MTPR = mtpr_cod
			and MTPR_MTNC  = mtnc_cod
			and MTPR_CFOC = NFOP_COD
			and NFOP_ICM_TAB = NFIA_NFIC	
			and NFIA_GLUF_ORI = 'SP'
			and NFIA_GLUF_DES = 'SP'
			and cpct_sta  = 'OK'
			and (MTNC_IPI <> CPCT_IPI_ALI
			or NFIA_PCT <> CPCT_ICM_ALI)
			and substring(CPCT_MTPR,1,3) != 'GEN'
*/			
SELECT * FROM KINP

select 
@sies CPCT_SIES, 'CPCT' CPCT_SIDO, '001' CPCT_SISE, identity(int,1,1) CPCT_COD, 'OK' CPCT_STA, null CPCT_CPSC_SIES, null CPCT_CPSC_SIDO, null CPCT_CPSC_SISE, null CPCT_CPSC_NPAI, null CPCT_CPSC, 
--@sies CPCT_SIES, 'CPCT' CPCT_SIDO, '001' CPCT_SISE, 1 CPCT_COD, 'OK' CPCT_STA, null CPCT_CPSC_SIES, null CPCT_CPSC_SIDO, null CPCT_CPSC_SISE, null CPCT_CPSC_NPAI, null CPCT_CPSC, 
a.mtpc_cod CPCT_MTPR, cpct_cod CPCT_MTPC, mtpr_nom CPCT_ESPE, 'GLFO' CPCT_GLTX, 1890 CPCT_GLXX,  1 CPCT_GLXX_DIG, 835 CPCT_GLXX_GLPA, 'SIDOR' CPCT_GLXX_NRDZ,
'S' CPCT_REV, 1 CPCT_QTD, 1 CPCT_QTD_GLFO, 'ALINE' CPCT_CTO, '(15) 21014513' CPCT_TEL, '(15) 21014515' CPCT_FAX, 'finansor@sidor.com.br' CPCT_EMAIL,
4 CPCT_GLCP, cpct_cod CPCT_CPID, MTPR_CPUN CPCT_CPUN, MTPR_CPFT CPCT_CPFT, cpct_pre_new CPCT_PUN, cpct_pre_new CPCT_PUN_GLFO, cpct_pre_new CPCT_PUND, cpct_pre_new CPCT_PUND_GLFO--,
--365 CPCT_VACT, 'REAL' CPCT_GLMD, convert(decimal(12,2),MTNC_IPI) CPCT_IPI_ALI, 0 CPCT_ISS_ALI, NFIA_PCT CPCT_ICM_ALI, 0 CPCT_VALT, '00' CPCT_GLPG, 3 CPCT_PENT,
--@doc PCT_DOCF, @obs CPCT_OBS,  'mdl_Pre_cot' CPCT_USC, getdate() CPCT_DTC, null CPCT_USU, null CPCT_DTU, null CPCT_CPID_NOM
into #cpct
from kinp a, mtpr b--, mtnc c, nfop d, nfia e
where ((mtpc_fator = 0)or(cpct_fator > 0)) 
			and substring(mtpc_cod,1,1) != '9'
			and a.mtpr_cod  = b.mtpr_cod
			--and b.MTPR_MTNC  = mtnc_cod
			--and b.MTPR_CFOC = NFOP_COD
			--and NFOP_ICM_TAB = NFIA_NFIC	
			--and NFIA_GLUF_ORI = 'SP'
			--and NFIA_GLUF_DES = 'SP'
			
select *
--update cpct set cpct_sta = 'EC'
from cpct
where convert(char(1),cpct_sies)+convert(varchar(10),cpct_mtpr) in (select convert(char(1),cpct_sies)+convert(varchar(10),cpct_mtpr) from #cpct)
			and cpct_sta = 'OK'
			and CPCT_DOCF != @doc

/*
insert into cpct
select 
CPCT_SIES, CPCT_SIDO, CPCT_SISE, CPCT_COD+@cod, CPCT_STA, CPCT_CPSC_SIES, CPCT_CPSC_SIDO, CPCT_CPSC_SISE, CPCT_CPSC_NPAI, CPCT_CPSC, 
CPCT_MTPR, CPCT_MTPC, CPCT_ESPE, CPCT_GLTX, CPCT_GLXX, CPCT_GLXX_DIG, CPCT_GLXX_GLPA, CPCT_GLXX_NRDZ,
CPCT_REV, CPCT_QTD, CPCT_QTD_GLFO, CPCT_CTO, CPCT_TEL, CPCT_FAX, CPCT_EMAIL,
CPCT_GLCP, CPCT_CPID, CPCT_CPUN, CPCT_CPFT, CPCT_PUN, CPCT_PUN_GLFO, CPCT_PUND, CPCT_PUND_GLFO,
CPCT_VACT, CPCT_GLMD, CPCT_IPI_ALI, CPCT_ISS_ALI, CPCT_ICM_ALI, CPCT_VALT, CPCT_GLPG, CPCT_PENT,
CPCT_DOCF, CPCT_OBS, CPCT_USC, CPCT_DTC, CPCT_USU, CPCT_DTU, CPCT_CPID_NOM
from #cpct

update sise set SISE_NUM = @cod_new
--select *
from sise
where SISE_SIES = @sies
			and SISE_SIDO = 'CPCT'
			and SISE_COD  = '001'
*/
			