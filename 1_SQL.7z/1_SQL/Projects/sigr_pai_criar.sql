select *, SIGR_COD SIGR_PAI
into SIGR_NEW
from [MDL_Menus].[dbo].sigr
where 1 = 0
