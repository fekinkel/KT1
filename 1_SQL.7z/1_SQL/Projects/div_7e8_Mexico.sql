
select a.REF , DIV_REF, LIN_REF, FAM_REF, sum(QTD_MOVTO) QTD_MOVTO
from toq_mov a, prod b
where TIP_DOC = 'NFF'
			and DIV_REF = '7'
			and a.ref = b.ref
			and QTD_MOVTO is not null
--order by DT_MOVTO
group by a.REF , DIV_REF, LIN_REF, FAM_REF

select a.REF , DIV_REF, LIN_REF, FAM_REF, sum(QTD_MOVTO) QTD_MOVTO
from toq_mov a, prod b
where TIP_DOC = 'NFF'
			and DIV_REF = '8'
			and a.ref = b.ref
			and QTD_MOVTO is not null
--order by DT_MOVTO
group by a.REF , DIV_REF, LIN_REF, FAM_REF