select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '4720'
from mtpr
where substring(mtpr_cod, 1,3) in('PPF', 'PPL','PPR', 'PPV','BLF', 'BLL','BLR','BLV','TFF', 'TFL', 'TFR', 'TFV')
			
select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '4720'
from mtpr
where substring(mtpr_cod, 1,4) in('PPEF', 'PPEL','PPER', 'PPEV', 'BLKF', 'BLKL', 'BLKR', 'BLKV', 'BLHF', 'BLHL', 'BLHR', 'BLHV', 'BLEF', 'BLEL', 'BLER', 'BLEV','PSMF', 'PSML', 'PSMR', 'PSMV')
			
select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '4720'
from mtpr
where substring(mtpr_cod, 1,5) in('BLKHF', 'BLKHL', 'BLKHR', 'BLKHV', 'BLEHF', 'BLEHL', 'BLEHR', 'BLEHV')


/*
select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '4700'
from mtpr
where substring(mtpr_cod, 1,3) in('PPB', 'blb','TFB', 'PFB')
			and substring(mtpr_cod, len(mtpr_cod),1) = 'D'
			
select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '4700'
from mtpr
where substring(mtpr_cod, 1,4) in('PSMB', 'PPEB','BLKB', 'BLHB', 'BLEB')
			and substring(mtpr_cod, len(mtpr_cod),1) = 'D'
			
select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '4700'
from mtpr
where substring(mtpr_cod, 1,5) in('BLKHB', 'BLEHB')
			and substring(mtpr_cod, len(mtpr_cod),1) = 'D'
*/

/*
select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5075'
from mtpr
where substring(mtpr_cod, 1,3) in('MDS')

select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5075'
from mtpr
where substring(mtpr_cod, 1,4) in('MSDS')

select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5075'
from mtpr
where substring(mtpr_cod, 1,5) in('TPCDS', 'BLMDS')

select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5070'
from mtpr
where substring(mtpr_cod, 1,4) in('BLMS', 'TPCS')

select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5070'
from mtpr
where substring(mtpr_cod, 1,3) in('MPS')

select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5070'
from mtpr
where substring(mtpr_cod, 1,3) in('MS.')

select mtpr_mtfm, *
--update mtpr set mtpr_mtfm = '5070'
from mtpr
where substring(mtpr_cod, 1,2) in('M.')
*/

