select *
from VDCV
where VDCV_COD not in (select vdcx_vdcv from VDCX)

insert into VDCX
select 48 VDCX_VDCV   ,VDCX_MTPC            ,VDCX_ATV ,VDCX_MTPC_NOM                                                                                                                                                                                                                                                  ,VDCX_PUN_MOD ,VDCX_PUN_VAL                            ,VDCX_PUN_GLMD , 
			100-10 VDCX_PUN_PCT                            ,VDCX_COM_TIPO ,VDCX_COM_PCT                            ,VDCX_QTD                                ,VDCX_USC        ,VDCX_DTC                ,VDCX_USU        ,VDCX_DTU
from VDCX
where VDCX_VDCV = 36

