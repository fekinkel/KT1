insert into [mdl].[dbo].siop
select a.*
--delete
from siop a, simo b
where SIMO_SIMD like '%recebi%'
			and SIMO_SIMD+'/'+SIMO_SIOP not in (select SIMO_SIMD+'/'+SIMO_SIOP from [mdl].[dbo].simo)
			and SIMO_SIOP = siop_cod
			and siop_cod not in (select SIOP_cod from [mdl].[dbo].siop)

insert into [mdl].[dbo].simd
select *
from simd
where SIMD_COD not in (select SIMD_COD from [mdl].[dbo].simd)


insert into [mdl].[dbo].simo
select *
--delete
from simo
where SIMO_SIMD like '%recebi%'
			and SIMO_SIMD+'/'+SIMO_SIOP not in (select SIMO_SIMD+'/'+SIMO_SIOP from [mdl].[dbo].simo)

insert into [mdl].[dbo].sigo
select *
--delete
from sigo
where SIGO_SIMD like '%recebi%'
			and SIGO_SIGR+'/'+SIGO_SIAP+'/'+SIGO_SIMD+'/'+SIGO_SIOP not in (select SIGO_SIGR+'/'+SIGO_SIAP+'/'+SIGO_SIMD+'/'+SIGO_SIOP from [mdl].[dbo].sigo)

			
select *
--delete
from sigm
where SIGM_SIMD like '%recebi%'

select *
--delete
from siam
where siam_simd like 'recebi%'
