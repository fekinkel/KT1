drop table #new
select *
into #new
from prcc
where prcc_ano = 2010
			and prcc_mes = 01
			and (convert(char(10),PRCC_DTU,102) >= '2011.04.14'
			or  convert(char(10),PRCC_DTC,102) >= '2011.04.14')
			
select * from #new


declare
@i int,
@j int
			
set @i = 2
while @i <= 12 begin
--/*
	delete
	from prcc
	where prcc_ano = 2010
				and prcc_mes = @i
--*/				
--/*				
	insert into prcc
	select 1 PRCC_SIES   ,PRCC_PRCT ,PRCC_ANO    ,@i PRCC_MES    ,PRCC_VALP                               ,PRCC_VALS                               ,PRCC_VALR                               ,PRCC_OBS                                                                                                                                                                                                                                                        ,PRCC_USC        ,PRCC_DTC                ,PRCC_USU        ,PRCC_DTU
	from #new
	where '1'+'/'+PRCC_PRCT in (select convert(char(1),prct_sies)+'/'+prct_cod from prct)
	
	insert into prcc
	select 5 PRCC_SIES   ,PRCC_PRCT ,PRCC_ANO    ,@i PRCC_MES    ,PRCC_VALP                               ,PRCC_VALS                               ,PRCC_VALR                               ,PRCC_OBS                                                                                                                                                                                                                                                        ,PRCC_USC        ,PRCC_DTC                ,PRCC_USU        ,PRCC_DTU
	from #new
	where '5'+'/'+PRCC_PRCT in (select convert(char(1),prct_sies)+'/'+prct_cod from prct)
--*/	
	set @i = @i +1
end

