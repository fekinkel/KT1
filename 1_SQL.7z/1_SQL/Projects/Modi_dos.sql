drop table #new
select *, IDENTITY(INT,1,1) num
into #new
from [dbfSCD]...[toq_mov]
where 1=0

select * from #new
--select * from [dbfSCD]...[toq_est] where REF = 'mtb.010.200'
--select * from [dbfSCD]...[toq_qal] where REF = 'mtb.010.200'

select 
	1,
	[ref],
	'26/11/2011',
	'AJU',
	880011,
	NUM,
	'T2',
	'EX',
	
from [dbfSCD]...prod_old
where COD_ALM = 'T2'
order by ref

