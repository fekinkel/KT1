drop table #new
drop table #calc

select MTFM_MTDV, MTFM_MTLN, MTFM_COD, SUBSTRING(MTFM_NOM,charindex('(',MTFM_NOM)+1,1) CLAS_MUSA, MTLP_COD, 9999.99 PORC_VALU, MTFM_NOM
into #new
from mtfm, mtlp
where SUBSTRING(MTFM_NOM,charindex('(',MTFM_NOM),1)= '('

UPDATE #new set PORC_VALU = 0.00
--select *
UPDATE #new set PORC_VALU =MTLF_FATO
from #new, MTLf
where MTFM_MTDV = MTLF_MTDV
			and MTFM_MTLN = MTLF_MTLN
			and MTFM_COD  = MTLF_MTFM
			and MTLP_COD  = MTLF_MTLP


select CLAS_MUSA CLAS_MUSA_NEW, MTLP_COD MTLP_COD_NEW, MAX(PORC_VALU) PORC_VALU_NEW
into #calc
from #new
group by CLAS_MUSA, MTLP_COD
order by CLAS_MUSA, MTLP_COD

select *
from #new
order by MTLP_COD, CLAS_MUSA, MTFM_MTDV, MTFM_MTLN, MTFM_COD

--select *
UPDATE #new set PORC_VALU =PORC_VALU_NEW
from #new a, #calc b
where CLAS_MUSA = CLAS_MUSA_NEW
			and MTLP_COD = MTLP_COD_NEW
			and PORC_VALU = 0.00


select *
from #new
order by MTLP_COD, CLAS_MUSA, MTFM_MTDV, MTFM_MTLN, MTFM_COD

select *
from MTLF
where 1=2
--328
--		 MTLF_MTLP MTLF_MTDV  MTLF_MTLN  MTLF_MTFM MTLF_NOM  MTLF_FATO  MTLF_USC  MTLF_DTC   MTLF_USU   MTLF_DTU
insert into MTLF
select MTLP_COD, MTFM_MTDV, MTFM_MTLN, MTFM_COD, MTFM_NOM, PORC_VALU, 'KINKEL', GETDATE(), null,			null
from #new
where PORC_VALU <> 0.00
			and MTLP_COD+'/'+MTFM_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD not in (select MTLF_MTLP+'/'+MTLF_MTDV+'/'+MTLF_MTLN+'/'+MTLF_MTFM from MTLF)