
--At� a data de ontem(19) a MDL tinha cadastrado no S2R 16.070 clientes dos quais 9.058 est�o inativos e 7012 ativos.
--Necessitamos que sejam efetuadas as seguintes altera��es neste cadastro:
--Os clientes inativos devem estar todos com STATUS  de cr�dito CC e LIMITE de cr�dito 00.
--J� os clientes ativos que n�o efetuaram compras na MDL ap�s 20/04/2011, 90 dias, dever�o ter seu STATUS de cr�dito alterado para CC e seu LIMITE de cr�dito alterado para 00.
select GLCL_ATV, COUNT(1)
from glcl
group by GLCL_ATV
order by GLCL_ATV

select b.*
--update glcr set glcr_gllc = '00', GLCR_STA = 'CC'
from glcl a, GLCR b
where GLCL_COD = GLCR_GLCL
			and GLCL_ATV = 'N'

select GLCL_COD, GLCR_ULT_DAT, GLCL_ATV
--update glcr set glcr_gllc = '00', GLCR_STA = 'CC'
from glcl a, GLCR b
where GLCL_COD = GLCR_GLCL
			and GLCL_ATV = 'S'
			and CONVERT(char(10),GLCR_ULT_DAT,102) <= '2011.04.20'

-- select * from GLCR
