if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
select VDPI_VDPD,   VDPI_COD
--update vdpi set VDPI_MTPC = 'OPMX', VDPI_MTPR = 'OPMX'
INTO #NEW
from vdpi
where vdpi_vdpd = 117697
	and vdpi_mtpc like 'OP%'
	and VDPI_NOM like 'MATRIZ%'
	
	SELECT *
	--UPDATE PRNC SET PRNC_MTPR = 'OPMX'
	FROM PRNC, #NEW
	WHERE PRNC_NPAI = 117697
				AND PRNC_COD = VDPI_COD
				
				
	SELECT *
	--UPDATE PROR SET PROR_MTPR = 'OPMX'
	FROM PROR, #NEW
	WHERE PROR_NPAX = 117697
				AND PROR_CODX = VDPI_COD
				
				