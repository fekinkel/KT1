--EXEC sp_dropserver 'dbfMEX'
--PARA EXCLUIR V� EM OBJETOS DE SERVIDOR->SERVIDORES VINCULADOS->
--EXEC sp_dropserver 'dbfMEX'
--N�O ESQUECER DA BARRA NO FINAL DO CAMINHO
--EXEC sp_dropserver 'dbfMEX'
--N�O ESQUECER DA BARRA NO FINAL DO CAMINHO
EXEC sp_addlinkedserver 'dbfSCD', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'C:\MEX\scdmex\dados\', NULL, 'dBase IV'
--exec sp_addlinkedsrvlogin 'dbfMEX', true, 'mdl\KINKEL', 'sa', 'mdlmdl'
exec sp_addlinkedsrvlogin 'dbfSCD', false, NULL, 'admin', NULL

EXEC sp_addlinkedserver 'dbfSCG', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'C:\MEX\scgmex\emp01\', NULL, 'dBase IV'
--exec sp_addlinkedsrvlogin 'dbfMEX', true, 'mdl\KINKEL', 'sa', 'mdlmdl'
exec sp_addlinkedsrvlogin 'dbfSCG', false, NULL, 'admin', NULL


EXEC sp_addlinkedserver 'dbfMEX2', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'd:\disco_f\scdmex\dados\', NULL, 'dBase IV'
--exec sp_addlinkedsrvlogin 'dbfMEX', true, 'mdl\KINKEL', 'sa', 'mdlmdl'
exec sp_addlinkedsrvlogin 'dbfMEX2', false, NULL, 'admin', NULL

--exec sp_addlinkedserver  'dbf2', '', 'MSDASQL', Null, Null, 'Driver={Microsoft dBASE Driver (*.dbf)};DriverID=277;DBQ=c:\mexico\SCDMEX\DADOS',null
--exec sp_addlinkedsrvlogin 'DBF2', false, 'mdl\KINKEL', 'Admin', NULL

--select * from dbf2...prod
--Criar tabela vazia
--select * into [DOS].[dbo].PED from dbfMEX...ped where 1 = 2
--select * into [DOS].[dbo].ITEM from dbfMEX...item where 1 = 2
--select * into [DOS].[dbo].NFNF0000 from dbfMEX...nfnf0000 where 1 = 2
--select * into [DOS].[dbo].NFIT0000 from dbfMEX...nfit0000 where 1 = 2
--select * into [DOS].[dbo].MOV from dbfMEX...mov where 1 = 2
--select * into [DOS].[dbo].APTITU from dbfMEX...aptitu where 1 = 2
select top 1 * from dbfMEX...prod

select top 1 * from dbfMEX...cli



