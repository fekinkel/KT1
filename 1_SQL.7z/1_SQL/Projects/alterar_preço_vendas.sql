--Autor				: Fernando Kinkel
--Data				: 14/07/2011
--Solicitante	: Sr(a).Eliane (SIDOR)
--Objetivo		: Alterar pre�o de venda
--Campos			: Pre�o de vendas com desconto e Pre�o total
--Restri��es	: Criar tabela tempor�ria para armazenar erro quanto exixtir
--Observa��es	: A Eliane n�o sabe o pre�o que ser� vendido ent�o ela coloca o valor de 1, depois � preciso trocar

if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

declare
@cot int,
@item int,
@valor decimal(12,2)

set @cot = 33123; set @item = 1; set @valor = 57.2

--Para atualizar � s� desmarcar a linha de update e marcar o select
select VDPI_PUND, VDPI_VAL, VDPI_QTD, *
--update vdpi set VDPI_PUND = @valor, VDPI_VAL = @valor*VDPI_QTD
from vdpi
where vdpi_vdpd = @cot
			and vdpi_cod = @item

--Caso ocorra algum erro ele ser� apresentado aqui
select *
from #iae			