if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
DROP TABLE #GLUFSELECT * INTO #GLUF FROM GLUF WHERE 1 = 0INSERT INTO #GLUFSELECT 		GLUF_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'') Pa�s
	, GLUF_COD = CONVERT(varchar(2),CODIGO_PAR)      --CONVERT(varchar(2),'') U.F.
	, GLUF_NOM = CONVERT(varchar(50),DESCR_PAR)      --CONVERT(varchar(50),'') Nome
	, GLUF_IBGE = Null      --CONVERT(varchar(2),'') Tabela IBGE
	, GLUF_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLUF_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLUF_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLUF_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
FROM [dbfmex]...parWHERE CHAVE_PAR = 'est'			and CODIGO_PAR <> '****'INSERT INTO GLUFSELECT *FROM #GLUFWHERE GLUF_GLPS+'/'+GLUF_COD NOT IN (SELECT GLUF_GLPS+'/'+GLUF_COD FROM GLUF)
