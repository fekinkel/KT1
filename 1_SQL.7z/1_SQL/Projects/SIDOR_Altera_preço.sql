
select cpct_cod, b.mtpc_cod, b.mtpc_pre, cpct_pre_new, convert(decimal(12,2),(cpct_pre_new*100/b.mtpc_pre)-100)
--update mtpc set MTPC_PRE = cpct_pre_new, MTPC_PRE_USU = 'KINKEL', MTPC_PRE_DTU = getdate()
from kinp a, mtpc b
where mtpc_pre_new > 0 
			and b.mtpc_cod  = cpct_cod
			and substring(a.mtpc_cod,1,1) <> '9'
			--and b.mtpc_pre <> cpct_pre_new
			
select a.mtpc_cod, b.mtpc_cod, mtpc_pre_new, b.mtpc_pre, b.mtpc_pre, *--, convert(decimal(12,2),(cpct_pre_new*100/b.mtpc_pre)-100)
--update mtpc set MTPC_PRE = cpct_pre_new, MTPC_PRE_USU = 'KINKEL', MTPC_PRE_DTU = getdate()
from kinp a, mtpc b
where mtpc_pre_new > 0 
			and b.mtpc_cod  = a.mtpc_cod+'R'
			and substring(a.mtpc_cod,1,1) = '9'
			--and b.mtpc_pre <> cpct_pre_new
			
			