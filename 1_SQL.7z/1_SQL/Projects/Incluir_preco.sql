
	update kinp set mtpc_fator = -1.00, cpct_fator = -1.00, glpa_cod  = 835
	from kinp
	
	


declare 
@i int,
@j numeric(5,2),
@k numeric(5,2),
@c varchar(255)
set @i = 1


set @j = 0.00
set @k = 5.00
if @i = 0 begin
	select * 
	from kinp
	where substring(mtpr_cod, 1, 3) in ('s11', 's21','s26','s36','p10')
end else begin
	update kinp set mtpc_fator = @j, cpct_fator = @k
	from kinp
	where substring(mtpr_cod, 1, 3) in ('s11', 's21','s26','s36','p10')
end

set @j = 8.50
set @k = 8.50
if @i = 0 begin
	select * 
	from kinp
	where substring(mtpc_cod, 1, 3) in ('b21', 'b23')
end else begin
	update kinp set mtpc_fator = @j, cpct_fator = @k
	from kinp
	where substring(mtpc_cod, 1, 3) in ('b21', 'b23')
end

set @j = 16.00
set @k = 16.00
if @i = 0 begin
	select * 
	from kinp
	where substring(mtpc_cod, 1, 3) in ('b30')
end else begin
	update kinp set mtpc_fator = @j, cpct_fator = @k
	from kinp
	where substring(mtpc_cod, 1, 3) in ('b30')
end

set @j = 20.00
set @k = 20.00
if @i = 0 begin
	select * 
	from kinp
	where substring(mtpc_cod, 1, 3) in ('x05', 'x06','x07','x08')
end else begin
	update kinp set mtpc_fator = @j, cpct_fator = @k
	from kinp
	where substring(mtpc_cod, 1, 3) in ('x05', 'x06','x07','x08')
end
select a.MTPC_COD [VENDAS_COD], a.MTPR_COD [ESTOQUE_COD], a.CPCT_cod [COMPRAS_COD], a.glpa_cod [FORNECEDOR], a.mtpc_pre [PRECO_VENDAS], a.cpct_pre [PRECO_COMPRAS], a.mtpr_mtdv [DIVISAO], a.mtpr_mtln [LINHA], a.mtpr_mtfm [FAMILIA], a.mtpc_pre_new [PRECO_VENDAS_NOVO], a.cpct_pre_new [PRECO_COMPRAS_NOVO], a.mtpc_fator [FATOR_AUMENTO_VENDAS], a.cpct_fator [FATOR_AUMENTO_COMPRAS], a.num_sig [DIGITOS_SIGNIFICATIVOS]
from kinp a
where (mtpc_fator > 0)or(cpct_fator > 0) 
			--and a.glpa_cod <> 835
order by mtpc_cod

