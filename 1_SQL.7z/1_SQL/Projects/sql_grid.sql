

drop procedure #nova
go
create procedure #nova (@pre char(3), @saida int)
as


drop table ##suf
drop table ##med
declare
@i int,
@j int,
@cod varchar(20),
@s nvarchar(4000),
@a nvarchar (4000)
--set @pre = 'b11'
set @pre = upper(@pre)
set @a = '[Med\Suf] char(3), '

set @s = '
drop table ##'+@pre
exec sp_executesql @s

select convert(char(3),SUBSTRING(mtpc_cod, 4, 3)) [MED], IDENTITY(int,1,1) [NUM]
into ##med
from MTPC
where SUBSTRING(mtpc_cod, 1, 3) = @pre
group by SUBSTRING(mtpc_cod, 4, 3)

select char(39)+convert(char(3),SUBSTRING(mtpc_cod, 7, 3)) [suf_Tit], convert(char(3),SUBSTRING(mtpc_cod, 7, 3))[SUF], IDENTITY(int,1,1) [NUM]
into ##suf
from MTPC
where SUBSTRING(mtpc_cod, 1, 3) = @pre
			--and SUBSTRING(mtpc_cod, 7, 3)< =20
group by SUBSTRING(mtpc_cod, 7, 3)

/*
select SUBSTRING(mtpc_cod, 7, 3)[SUF]
from MTPC
where SUBSTRING(mtpc_cod, 1, 3) = @pre
group by SUBSTRING(mtpc_cod, 7, 3)
*/
--set @a = '['
select @a = @a+'['+suf_Tit+']'+' char(8), '--+CHAR(10)
from ##suf


select @a = SUBSTRING(@a,1,len(@a)-1)
--select 'INICIO', LEN(@a), substring(@a,len(@a)-20,20)

set @s= 'create table ##'+@pre+' ( '+@a+' )'

--print @s

exec sp_executesql @s

select @s = '
insert into ##'+@pre+' ([Med\Suf])
select [med]
from ##med'

exec sp_executesql @s


--select @s

--select SUBSTRING(mtpc_cod, 1, 3), SUBSTRING(mtpc_cod, 4, 3), SUBSTRING(mtpc_cod, 7, 3), mtpc_cod
--from MTPC
--where SUBSTRING(mtpc_cod, 1, 3) = 'P25'

--create table #P25 ( [010] char(1), [011] char(1), [012] char(1), [013] char(1), [014] char(1), [015] char(1), [016] char(1), [017] char(1), [018] char(1), [019] char(1), [020] char(1) )
set @s = '
select *
from ##'+@pre+' a'

--select @s

--exec sp_executesql @s


set @i = 1
while @i <= (select MAX(num) from ##suf) begin
	--print @i
	set @j = 1
	while @j <= (select MAX(num) from ##med) begin
		set @cod = ''
		select @cod =(@pre+''+[med]+''+[suf]) 
		from ##med a, ##suf b 
		where a.num=@j 
					and b.num=@i
					and (@pre+''+[med]+''+[suf]) in (select mtpr_cod from mtpr)
		if (select @cod) <> '' begin
--			select @s = 'update ##'+@pre+' set ['+ (select [suf] from ##suf where num=@i)+'] = '+CHAR(39)+'   x'+CHAR(39)+
--Pre�o
			if @saida = 1 begin
				select @s = 'update ##'+@pre+' set ['+ (select [suf_tit] from ##suf where num=@i)+'] = '+CHAR(39)+replace(convert(char(12),MTPC_PRE),'.',',')+CHAR(39)+
					' where [Med\Suf] = '+(select [med] from ##med where num = @j)
				from MTPC
				where MTPC_COD = @cod
			
			--select @s
				exec sp_executesql @s
			end
--Pre�o
--Media consumo
			if @saida = 2 begin
				select @s = 'update ##'+@pre+' set ['+ (select [suf_tit] from ##suf where num=@i)+'] = '+CHAR(39)+replace(convert(char(8),convert(decimal(8,0),MTES_PCMR)),'.',',')+CHAR(39)+
					' where [Med\Suf] = '+(select [med] from ##med where num = @j)
				from MTes
				where MTES_MTPR = @cod

				--select @s
				exec sp_executesql @s
			end
--Media consumo
--Custo
			if @saida = 3 begin
				--select @s = 'update ##'+@pre+' set ['+ (select [suf_tit] from ##suf where num=@i)+'] = '+CHAR(39)+replace(convert(char(8),convert(decimal(8,2),MTES_VATU/MTES_QATU*MTPR_CPFT)),'.',',')+CHAR(39)+
				select @s = 'update ##'+@pre+' set ['+ (select [suf_tit] from ##suf where num=@i)+'] = '+CHAR(39)+replace(convert(char(8),convert(decimal(8,2),MTES_VATU/MTES_QATU)),'.',',')+CHAR(39)+
					' where [Med\Suf] = '+(select [med] from ##med where num = @j)
				from MTes, MTPR
				where MTES_MTPR = @cod
							and MTES_MTPR = MTPR_COD
				--select @s
				exec sp_executesql @s
			end
--Custo
		end
		set @j=@j+1
	end	
	set @i = @i+1
end

set @a = replace(REPLACE(@a,'char(8)',''),'[Med\Suf] char(3), ','')
--select '+char(39)+@pre+CHAR(39)+' [Prefixo], *
set @s = '
select '+char(39)+@pre+char(39)+' [Prefixo] , char(39)+[Med\Suf] [Med\Suf], '+ @a+ '
from ##'+@pre+' a'

--select * from ##P20 where [Med\Suf] = '500'

--select @s

exec sp_executesql @s

go

drop table #new
select substring(mtpc_cod,1,3) [cod], IDENTITY(int,1,1) [num]
into #new
from mtpc
group by substring(mtpc_cod,1,3)
order by substring(mtpc_cod,1,3)

declare
@i int,
@val char(3)

set @i = 1

while @i <(select MAX(num) from #new) begin
	set @val = ''
	select @val = cod 
	from #new 
	where num =@i
				--and cod in ('P17', 'P26','B35','B46','C25','C26')
				and cod in ('SSR','SSG','SSY','SSB')
	if @val <> '' 
		--exec #nova @val,1
		--exec #nova @val,3
		exec #nova @val,2
	set @i = @i +1
end

set @servidor = '192.168.2.39'
set @usuario = 'sa'
set @senha = 'mdl1680'
set @banco = 'mdl'
set @procedure = 'select * from tabela ' --poderia ser uma stored Procedure tamb�m
set @arquivoFisico = 'c:\saida.csv'
set @comando = 'sqlcmd -S '+@servidor+' -U '+@usuario+' -P '+@senha+' -d '+@banco+' -q "'+@Procedure+'" -s ";" -f 65001 -o '+@arquivoFisico

exec master.dbo.xp_cmdshell @comando
