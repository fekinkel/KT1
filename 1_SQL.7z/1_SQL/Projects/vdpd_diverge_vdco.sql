if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

select VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD,   VDPI_COD, vdpi_mtpc, VDPI_PUN, VDPI_PUND, VDPI_VAL, VDC1_PUNID, VDC1_IPI_BAS, c.*
--update vdpi set VDPI_PUN = VDC1_PUNID, VDPI_PUND = VDC1_PUNID, VDPI_VAL = VDC1_IPI_BAS
from vdpi b, vdpd a, vdc1 c
where vdpd_sies = VDPI_SIES
			and vdpd_sido = VDPI_SIDO
			and vdpd_sise = VDPI_SISE
			and vdpd_cod  = VDPI_VDPD
			and VDPD_VDCO_SIES = vdc1_sies
			and VDPD_VDCO_SIDO = vdc1_sido
			and VDPD_VDCO_SISE = vdc1_sise
			and VDPD_VDCO_COD = vdc1_vdco
			and VDPI_COD  = vdc1_cod
			and VDC1_SUB = 0
			and vdpi_vdpd = 122202
