declare
@cod int

set @cod = 124

drop table #new


select CPIP_SIES, CPIP_CPSC_SIDO, CPIP_CPSC_SISE, CPIP_CPSC_NPAI, CPIP_CPSC
into #new
from CPIP
where CPIP_CPPC = @cod

--select *
update CPPC set CPPC_STA = 'EC'
from CPPC
where CPPC_SIES = 1
			and CPPC_COD = @cod

--select *
update PRNC set PRNC_STA = 'EC'
from PRNC, #new
where PRNC_SIES = CPIP_SIES		
			and PRNC_SIDO = CPIP_CPSC_SIDO
			and PRNC_SISE = CPIP_CPSC_SISE
			and PRNC_NPAI = CPIP_CPSC_NPAI
			and PRNC_COD  = CPIP_CPSC