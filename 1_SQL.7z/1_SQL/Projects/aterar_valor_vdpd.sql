if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
select *
--update vdpi set VDPI_PUND = 3745.40, VDPI_VAL = 3745.40
from vdpi
where vdpi_vdpd = 121693

select *
--update vdps set VDPS_DENT = '02/10/2011 00:00:00'
from vdps
where vdps_vdpd = 120962
