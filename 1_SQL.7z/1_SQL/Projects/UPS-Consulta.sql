select Sm_customerId, m_shipDataSet, Sm_shipInstructions, Sm_USPSDeliveryNumber, Sm_merchandiseText, Sm_trackingNo, *
from calPkgAgent a, calShipment b, calPackage c
where b.m_foreignkey00 = a.m_primarykey
			and c.m_foreignKey = b.m_primarykey