EXEC sp_addlinkedserver EXCEL,
     'Jet 4.0',
     'Microsoft.Jet.OLEDB.4.0',
     'c:\bkp\divisao_mex.XLS', 
      NULL,
     'Excel 8.0;'

GO

EXEC sp_addlinkedserver   
   @server=N'MDL_1', 
   @srvproduct=N'',
--   @provider=N'192.168.2.39', 
   --@datasrc=N'MDL';
--   @provider=N'SQLNCLI', 
	 @provider=N'MDL', 
   @datasrc=N'192.168.2.39',
   @catalog=N'[MDL]';


select *
from excel...teste

select 'wwwwwwwwwwwwwww' PRE_C�DIGO, 'ww' DIVISAO_OLD, 'ww' LINHA_OLD, 'ww' FAMILIA_OLD, 'wwww' DIVISAO_NOVA, 'wwww' LINHA_NOVA, 'wwww' FAMILIA_NOVA
into depadivi
where 1 = 0

insert into depadivi
SELECT substring(PRE_C�DIGO,2,15), substring(DIVISAO_OLD,2,2), substring(LINHA_OLD,2,2) , substring(FAMILIA_OLD,2,2), substring(DIVISAO_NOVA,2,4), substring(LINHA_NOVA,2,4), substring(FAMILIA_NOVA,2,4) 
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=c:\bkp\divisao_mex.XLS',sheet3$) 
