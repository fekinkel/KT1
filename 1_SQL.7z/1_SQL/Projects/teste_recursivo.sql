drop table #new

select tipo tipo_new, siam_simd simd
into #new
from siam, [DOS].[dbo].SIOI_New
where siam_simd = SIOI_NOM
			and siam_siap = 's2r'
			and len(tipo) = 2 
			--and SIOI_USC like '%s2e%'
order by tipo

--select * from #new

drop table #sigo
--select Tipo+';'+SIOI_NOM+'('+SIOI_SIOP+')'+';'+'1' MENU
select Tipo, SIOI_NOM, SIOI_SIOP, convert(decimal(6,2),LEN(tipo))/2 MENU, simd, 'xxxxxxxxxxxxxxx' PAI, 'yyyyyyyyyyyyyyy' FILHO, identity(int,1,1) NUM
into #sigo
from #new a, [DOS].[dbo].SIOI_New b
where tipo_new = SUBSTRING(tipo,1,2)
			and (SIOI_USC like '%'+'s2r'+'%' or substring(tipo,1,2) = '1.')
			--or substring(tipo,1,2) = '1.'			
order by tipo

select *
from #new

select Tipo, LEN(Tipo), REPLACE(len(tipo),2,'P')
from #sigo

drop procedure #rec

--Transact-SQL Scalar Function Syntax
CREATE procedure #rec ( @atual int, @pai int, @anterior varchar(15))
as begin
	--print '------------------------------------------------------------------------------'
	set nocount on
	declare 
	@s varchar(15)
	while (@atual <= (select MAX(num) from #sigo))and((select LEN(tipo) from #sigo where num = @atual)>=LEN(@anterior)) begin
		if ((select len(tipo) from #sigo where num = @atual)=2) begin 
			select 'Indice = '+convert(char(10),@atual)+' MESTRE - '+tipo+' PAI - '+tipo+' Anterior = '+@anterior from #sigo where num = @atual
			update #sigo set pai = 'P', filho = ''
			where num = @atual
			set @pai = @atual
			select @s= tipo from #sigo where num = @atual
			set @atual = @atual + 1	
			exec #rec @atual, @pai, @s
		end else if (select len(tipo) from #sigo where num = @atual)>((select len(@anterior))) begin 
			--select 'Indice = '+convert(char(10),@atual)+'FILHO - '+a.tipo+' PAI - '+@anterior from #sigo a where a.num = @atual 
			update #sigo set pai = 'F', filho = ''
			where num = @atual
			if (select SUBSTRING(tipo,len(tipo)-2,1) from #sigo where num = @atual) <> 'F' begin
				set @pai = @atual
				select 'Indice = '+convert(char(10),@atual)+'FILHO - '+a.tipo+' PAI - '+b.Tipo from #sigo a, #sigo b where a.num = @atual and b.num = @pai
			end else begin
				--print 'Entrou aqui (F) '+@anterior
				select 'Entrou aqui (F) '+'Indice = '+convert(char(10),@atual)+'FILHO - '+a.tipo+' PAI - '+b.Tipo from #sigo a, #sigo b where a.num = @atual and b.num = @pai
				set @pai = @pai
			end
			select @s= tipo from #sigo where num = @atual
			set @atual = @atual + 1	
			exec #rec @atual, @pai, @s
		end else if (select len(tipo) from #sigo where num = @atual)=((select len(@anterior))) begin 
			select 'Indice = '+convert(char(10),@atual)+'IRM�O - '+a.tipo+' PAI - '+b.Tipo from #sigo a, #sigo b where a.num = @atual and b.num = @pai
			update #sigo set pai = 'F', filho = ''
			where num = @atual
			--set @pai = @atual
			--if (select @anterior) = 0 begin 
			--set @anterior = @atual
			set @atual = @atual + 1		
		end
		print 'Aqui '+convert(varchar(6),@atual)
		--set @atual = @atual + 1	
	end
end


exec #rec 1 ,0, ''

declare
@i int,
@p int,
@f int
set @i = 1; set @p =0; set @f = 0
while (select MAX(num)from #sigo) >= @i begin
	if (select len(tipo) from #sigo where num = @i) = 2 begin
		set @p = @i; set @f = 0
		update #sigo set pai = 'RAIZ', filho = ''
		where num = @i
		print 'Aqui '+convert(varchar(3),@p)
	end
	if (@i>1)and((select len(tipo) from #sigo where num = @i) > (select LEN(tipo) from #sigo where num = @p)) begin
		if (select CHARINDEX('F',tipo) from #sigo where num = @i)>0 begin
			update #sigo set pai = substring(tipo, 1, charindex('F',tipo)-1)
			where num = @i			
			print 'Maior (F) '+convert(varchar(3),@p)
		end else begin
--			update #sigo set a.pai = b.tipo from #sigo where num = @i
			update #sigo set pai = (select tipo
			from #sigo a
			where a.num = @p)
			from #sigo
			where num = @i
			set @p= @i; set @f = @i
			print 'Maior  '+convert(varchar(3),@p)
		end
	end else if (@i>1)and((select len(tipo) from #sigo where num = @i) < (select LEN(tipo) from #sigo where num = @p)) begin
		update #sigo set pai = tipo
		where num = @p
		set @p= @i; set @f = @i
		select tipo from #sigo where num = @i
	end
  
  set @i = @i + 1
end

select tipo, menu, pai, filho,*
from #sigo
where num = 1155
