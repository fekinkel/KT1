select ref [ITEM], MMC_TOQ [MEDIA] from [dbfmex]...toq_est where substring(REF,1,4) in ('P21.', 'P10.', 'P22.', 'B11.', 'B21.')
order by ref

select * from [dbfmex]...prod where DIV_REF = 8 order by ref

select DIV_REF, div_new, DIV_NOME, LIN_REF, lin_new, LIN_NOME, FAM_REF, fam_new, FAM_NOME
from #new 
--where div_new = 0500
order by DIV_REF, LIN_REF, FAM_REF


/*
--			MTDV_COD MTDV_NOM  MTDV_USC		MTDV_DTC    MTDV_USU  MTDV_DTU
INSERT INTO MTDV
select	div_new, div_nome, 'KINKEL',	GETDATE(),	NULL,			NULL
from #NEW
GROUP BY div_new, div_nome


INSERT INTO MTDV
--			MTLN_MTDV MTLN_COD MTLN_NOM  MTLN_USC   MTLN_DTC    MTLN_USU  MTLN_DTU
select	div_new,	lin_new, lin_nome, 'KINKEL',	GETDATE(),	NULL,			NULL
from #NEW
GROUP BY div_new, lin_new, lin_nome

*/

--drop table #new
--select top 1 * from mtln

/*

select DIV_REF, LIN_REF, FAM_REF, SPACE(50) DIV_NOME, SPACE(50) LIN_NOME , SPACE(50) FAM_NOME, space(4) DIV_NEW, space(4) LIN_NEW, space(4) FAM_NEW
into #new
from [dbfMEX]...prod
group by DIV_REF, LIN_REF, FAM_REF

--select *
update #new set DIV_NOME = DESCR_PAR
from [dbfMEX]...[par], #new
where CHAVE_PAR = 'DIV'
			and codigo_par = div_ref

--select *
update #new set LIN_NOME = DESCR_PAR
from [dbfMEX]...[par], #new
where CHAVE_PAR = 'LIN'
			and codigo_par = lin_ref
			
--select *
update #new set FAM_NOME = DESCR_PAR
from [dbfMEX]...[par], #new
where CHAVE_PAR = 'FAM'
			and codigo_par = fam_ref

update #new set DIV_New = '0500'
from #new
where div_ref = 1

update #new set DIV_New = '1000'
from #new
where div_ref = 2

update #new set DIV_New = '2000'
from #new
where div_ref = 3

update #new set DIV_New = '8888'
from #new
where div_ref = 4

update #new set DIV_New = '6000'
from #new
where div_ref = 5

update #new set DIV_New = '3500'
from #new
where div_ref = 7

update #new set DIV_New = '3600'
from #new
where div_ref = 8

update #new set DIV_New = '9999'
from #new
where div_ref = 9

*/
