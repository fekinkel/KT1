/*
select convert(varchar(20),[Referencia]) [COD_MDL], convert(varchar(20),[Referencia1])[COD_SIDOR], 0.00 [CPCT_PUND], [Reajuste2] [CPCT_PUND_NEW]
into SIDOR_molas
from lista_preco_molas
where [Referencia] is not null



select convert(varchar(20),[Refer�ncia]) [COD_MDL], convert(varchar(20),[C�digo Indl#])[COD_SIDOR], 0.00 [CPCT_PUND], [A partir 01/Jul/111] [CPCT_PUND_NEW]
into SIDOR
from lista_preco
where [Refer�ncia] is not null
*/
--select * from [mdl].[dbo].cpct
select a.*
--update sidor_molas set COD_SIDOR = CPCT_MTPC
from sidor_molas a, [mdl].[dbo].mtpc b, [mdl].[dbo].cpct c
where COD_MDL = mtpc_cod
			and mtpc_mtpr = cpct_mtpr
			and cpct_sta = 'OK'
			and cpct_sies = 7
			and CPCT_MTPC like '%D'