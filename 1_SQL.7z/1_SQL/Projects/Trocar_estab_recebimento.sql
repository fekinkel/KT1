--Autor				: Fernando Kinkel
--Data				: 02/02/2011
--Solicitante	: Sr(a).Kinkel
--Objetivo		: Notas de recebimento do Estab. 1 para o Estab. 7
--Campos			: 
--Restri��es	: 
--Observa��es	: 

--Excluir a tabela tempor�ria
drop table #rcnf

--Parametros para criar a nova numera��o de notas de recebimento 
declare 
@i int,
@j int

--Pegar o �ltimo n�mero
select @i = SISE_NUM from sise where sise_sido = 'RCNF' and sise_sies = 7 and sise_cod = '001'

--Criar a tabela tempor�ria Vazia acrescentando um n�mero sequ�ncial
select *, identity(int,1,1) NUM into #rcnf from rcnf where 1=2

print 'O n�mero da pr�xima nota de recebimento �:'
print @i

--Inserir os registro na tabela tempor�ria
insert into #rcnf
select 7 RCNF_SIES   ,RCNF_SIDO ,RCNF_SISE ,RCNF_COD    ,RCNF_ES ,RCNF_DAT                ,RCNF_DCA                ,RCNF_NFOP ,RCNF_CFOP ,RCNF_SIDX ,RCNF_SISX ,RCNF_CODX   ,RCNF_DATX               ,RCNF_SIDF ,RCNF_SISF ,RCNF_CODF   ,null RCNF_SIDP ,null RCNF_SISP ,0 RCNF_CODP   , 'OK' RCNF_STA ,RCNF_OBS                                           ,RCNF_GLTX ,RCNF_GLXX   ,RCNF_GLXX_DIG ,RCNF_GLPA   ,RCNF_GLXX_NOM                                      ,RCNF_GLPS_ORI ,RCNF_GLUF_ORI ,RCNF_GLPS_DES ,RCNF_GLUF_DES ,RCNF_PEDF            ,RCNF_GLMD ,RCNF_VMDA                               ,RCNF_GLCF ,RCNF_PCTCF                              ,RCNF_GLCP   ,RCNF_PCTCOM                             ,RCNF_GLPG ,RCNF_GLCC       ,RCNF_GLTR   ,RCNF_VIA ,RCNF_FRETE ,RCNF_PLACA ,RCNF_DTSAIDA            ,RCNF_QTDVOL                             ,RCNF_ESPECIE         ,RCNF_MARCA ,RCNF_NUMERA          ,RCNF_PESOLIQ                            ,RCNF_PESOBRT                            ,RCNF_MENS                                                                                                                                                                                                                                                       ,RCNF_QTD                                ,RCNF_VAL                                ,RCNF_VAL_TIT                            ,RCNF_VAL_MER                            ,RCNF_VAL_SER                            ,RCNF_VAL_FRE                            ,RCNF_VAL_SEG                            ,RCNF_VAL_ACE                            ,RCNF_VAL_DES                            ,RCNF_VAL_PIS                            ,RCNF_VAL_COF                            ,RCNF_VAL_CSS                            ,RCNF_VAL_INSS                           ,RCNF_VAL_IRRF                           ,RCNF_IPI_VAL                            ,RCNF_IPI_BAS                            ,RCNF_IPI_OUT                            ,RCNF_IPI_ISE                            ,RCNF_ISS_VAL                            ,RCNF_ISS_BAS                            ,RCNF_ISS_ISE                            ,RCNF_ISS_OUT                            ,RCNF_ICM_VAL                            ,RCNF_ICM_BAS                            ,RCNF_ICM_ISE                            ,RCNF_ICM_OUT                            ,RCNF_IST_BAS                            ,RCNF_IST_ALI                            ,RCNF_IST_VAL                            ,RCNF_IST_ISE                            ,RCNF_IST_OUT                            ,RCNF_IST_IVA                            ,RCNF_ICP_ALI                            ,RCNF_ICP_VAL                            ,RCNF_NLM    ,RCNF_CLM    ,RCNF_NLS    ,RCNF_CLS    ,RCNF_SIDY ,RCNF_SISY ,RCNF_CODY   ,RCNF_NFE_CHV                                 ,RCNF_NFE_STA ,RCNF_NFE_PRO    ,RCNF_NFE_DTP            ,RCNF_USC        ,RCNF_DTC                ,RCNF_USU        ,RCNF_DTU
from rcnf
where rcnf_sies = 1
			--and rcnf_cod  in (32149, 32150, 32151, 32153, 32156, 32165, 32166, 32167)
			--and rcnf_cod  in (32154, 32155)
			and rcnf_cod  in (32152)

--Selecionar o �ltimo n�mero da Nota de Recebimento criado
select @j= max(num)+@i from #rcnf


print 'O n�mero da �ltima nota de recebimento �:'
print @j

--Atualizar o n�mero Nota de Recebimento
update sise set  SISE_NUM = @j from sise where sise_sido = 'RCNF' and sise_sies = 7 and sise_cod = '001'

--inserir os registros criados na tabela Original com a nova numera��o de Nota de Recebimento 
insert into rcnf
select RCNF_SIES   ,RCNF_SIDO ,RCNF_SISE ,num+@i RCNF_COD    ,RCNF_ES ,RCNF_DAT                ,RCNF_DCA                ,RCNF_NFOP ,RCNF_CFOP ,RCNF_SIDX ,RCNF_SISX ,RCNF_CODX   ,RCNF_DATX               ,RCNF_SIDF ,RCNF_SISF ,RCNF_CODF   ,null RCNF_SIDP ,null RCNF_SISP ,0 RCNF_CODP   , 'OK' RCNF_STA ,RCNF_OBS                                           ,RCNF_GLTX ,RCNF_GLXX   ,RCNF_GLXX_DIG ,RCNF_GLPA   ,RCNF_GLXX_NOM                                      ,RCNF_GLPS_ORI ,RCNF_GLUF_ORI ,RCNF_GLPS_DES ,RCNF_GLUF_DES ,RCNF_PEDF            ,RCNF_GLMD ,RCNF_VMDA                               ,RCNF_GLCF ,RCNF_PCTCF                              ,RCNF_GLCP   ,RCNF_PCTCOM                             ,RCNF_GLPG ,RCNF_GLCC       ,RCNF_GLTR   ,RCNF_VIA ,RCNF_FRETE ,RCNF_PLACA ,RCNF_DTSAIDA            ,RCNF_QTDVOL                             ,RCNF_ESPECIE         ,RCNF_MARCA ,RCNF_NUMERA          ,RCNF_PESOLIQ                            ,RCNF_PESOBRT                            ,RCNF_MENS                                                                                                                                                                                                                                                       ,RCNF_QTD                                ,RCNF_VAL                                ,RCNF_VAL_TIT                            ,RCNF_VAL_MER                            ,RCNF_VAL_SER                            ,RCNF_VAL_FRE                            ,RCNF_VAL_SEG                            ,RCNF_VAL_ACE                            ,RCNF_VAL_DES                            ,RCNF_VAL_PIS                            ,RCNF_VAL_COF                            ,RCNF_VAL_CSS                            ,RCNF_VAL_INSS                           ,RCNF_VAL_IRRF                           ,RCNF_IPI_VAL                            ,RCNF_IPI_BAS                            ,RCNF_IPI_OUT                            ,RCNF_IPI_ISE                            ,RCNF_ISS_VAL                            ,RCNF_ISS_BAS                            ,RCNF_ISS_ISE                            ,RCNF_ISS_OUT                            ,RCNF_ICM_VAL                            ,RCNF_ICM_BAS                            ,RCNF_ICM_ISE                            ,RCNF_ICM_OUT                            ,RCNF_IST_BAS                            ,RCNF_IST_ALI                            ,RCNF_IST_VAL                            ,RCNF_IST_ISE                            ,RCNF_IST_OUT                            ,RCNF_IST_IVA                            ,RCNF_ICP_ALI                            ,RCNF_ICP_VAL                            ,RCNF_NLM    ,RCNF_CLM    ,RCNF_NLS    ,RCNF_CLS    ,RCNF_SIDY ,RCNF_SISY ,RCNF_CODY   ,RCNF_NFE_CHV                                 ,RCNF_NFE_STA ,RCNF_NFE_PRO    ,RCNF_NFE_DTP            ,RCNF_USC        ,RCNF_DTC                ,RCNF_USU        ,RCNF_DTU
from #rcnf

--Inserir os dados complementares
insert into rcco
select 7 RCCO_SIES   ,RCCO_SIDO ,RCCO_SISE ,num+@i RCCO_COD    ,RCCO_CNPJ      ,RCCO_CPF    ,RCCO_IES             ,RCCO_RG              ,RCCO_IMU             ,RCCO_END                                           ,RCCO_NUM ,RCCO_COM   ,RCCO_BAI                  ,RCCO_CID                  ,RCCO_PAIS ,RCCO_EST ,RCCO_MUN ,RCCO_CEP ,RCCO_TEL                  ,RCCO_FAX                  ,RCCO_CNPJC     ,RCCO_CPFC   ,RCCO_IESC            ,RCCO_RGC             ,RCCO_IMUC            ,RCCO_ENDC                                          ,RCCO_NUMC ,RCCO_COMC  ,RCCO_BAIC                 ,RCCO_CIDC                 ,RCCO_PAISC ,RCCO_ESTC ,RCCO_MUNC ,RCCO_CEPC ,RCCO_TELC                 ,RCCO_CNPJE     ,RCCO_CPFE   ,RCCO_IESE            ,RCCO_RGE             ,RCCO_IMUE            ,RCCO_ENDE                                          ,RCCO_NUME ,RCCO_COME  ,RCCO_BAIE                 ,RCCO_CIDE                 ,RCCO_PAISE ,RCCO_ESTE ,RCCO_MUNE ,RCCO_CEPE ,RCCO_NOMT                                          ,RCCO_CNPJT     ,RCCO_CPFT   ,RCCO_IEST            ,RCCO_RGT             ,RCCO_IMUT            ,RCCO_ENDT                                          ,RCCO_NUMT ,RCCO_COMT  ,RCCO_BAIT                 ,RCCO_CIDT                 ,RCCO_PAIST ,RCCO_ESTT ,RCCO_MUNT ,RCCO_CEPT ,RCCO_USC        ,RCCO_DTC                ,RCCO_USU        ,RCCO_DTU
from rcco, #rcnf
where rcco_sies = 1
			and rcco_cod  = rcnf_cod
			--and rcco_cod  in (32149, 32150, 32151, 32153, 32156, 32165, 32166, 32167)
			--and rcnf_cod  in (32154, 32155)
			and rcnf_cod  in (32152)
--Inserir os itens da Nota de Recebimento
insert into rcit
select 7 RCIT_SIES   ,RCIT_SIDO ,RCIT_SISE ,num+@i RCIT_RCNF   ,RCIT_COD    ,RCIT_CODF   ,null RCIT_SIDP ,null RCIT_SISP ,0 RCIT_CODP   ,0 RCIT_CODI   ,RCIT_MTPC            ,RCIT_NOM                                                                                                                                                                                                                                                        ,RCIT_MTPR            ,RCIT_MS ,RCIT_MTUN ,RCIT_MTNC ,RCIT_ORI ,RCIT_MTDV ,RCIT_MTLN ,RCIT_MTFM ,RCIT_PLIQ                               ,RCIT_PLQT                               ,RCIT_PBRT                               ,RCIT_EST ,RCIT_MTTR ,RCIT_STA    ,RCIT_CTPC       ,RCIT_RDPC ,RCIT_CTCC       ,RCIT_RDCC ,RCIT_QTD                                ,RCIT_PUN                                ,RCIT_VAL                                ,RCIT_REV ,RCIT_DES                                ,RCIT_NFOP ,RCIT_CFOP ,RCIT_TIT ,RCIT_TBB ,RCIT_MEN                                                                                                                                                                                                                                                        ,RCIT_IPI_BAS                            ,RCIT_IPI_ALI                            ,RCIT_IPI_VAL                            ,RCIT_IPI_ISE                            ,RCIT_IPI_OUT                            ,RCIT_ISS_BAS                            ,RCIT_ISS_ALI                            ,RCIT_ISS_VAL                            ,RCIT_ISS_ISE                            ,RCIT_ISS_OUT                            ,RCIT_ICM_BAS                            ,RCIT_ICM_ALI                            ,RCIT_ICM_VAL                            ,RCIT_ICM_OUT                            ,RCIT_ICM_ISE                            ,RCIT_IST_BAS                            ,RCIT_IST_ALI                            ,RCIT_IST_VAL                            ,RCIT_IST_ISE                            ,RCIT_IST_OUT                            ,RCIT_IST_IVA                            ,RCIT_ICP_ALI                            ,RCIT_ICP_VAL                            ,RCIT_VAL_FRE                            ,RCIT_VAL_SEG                            ,RCIT_VAL_ACE                            ,RCIT_IMP_ALI                            ,RCIT_IMP_ADU                            ,RCIT_IMP_DAD                            ,RCIT_VAL_PIS                            ,RCIT_VAL_COF                            ,RCIT_MTTP_SPED ,RCIT_USC        ,RCIT_DTC                ,RCIT_USU        ,RCIT_DTU
from rcit, #rcnf
where rcit_sies = 1
			and rcit_rcnf = rcnf_cod
			--and rcit_rcnf  in (32149, 32150, 32151, 32153, 32156, 32165, 32166, 32167)
			--and rcnf_cod  in (32154, 32155)
			and rcnf_cod  in (32152)

--Excluir as notas de recebimentos antigas
--Obs.: N�O EST� EXCLUINDO AUTOMATICAMENTE PARA EVITAR DESASTRES
select *
--delete
from rcnf
where rcnf_sies = 1
			--and rcnf_cod  in (32149, 32150, 32151, 32153, 32156, 32165, 32166, 32167)
			--and rcnf_cod  in (32154, 32155)
			and rcnf_cod  in (32152)
			
			