
EXEC sp_addlinkedserver 'ADSI', 'Active Directory Services 2.5', 'ADSDSOObject', 'adsdatasource'


SELECT * FROM OpenQuery(ADSI, 'SELECT * FROM ''LDAP://DC=mdl,DC=com,DC=br'' where objectClass = ''User''')
SELECT * FROM OpenQuery(ADSI, 'SELECT * FROM ''LDAP://DC=mdl,DC=com,DC=br'' ')
SELECT * FROM OpenQuery(ADSI, 'SELECT postOfficeBox, givenName, mail, displayName, userPrincipalName FROM ''LDAP://DC=mdl,DC=com,DC=br'' WHERE objectCategory=''user'' ') 
SELECT * FROM OPENQUERY(ADSI, 'SELECT notes, displayName, sAMAccountName,givenName,sn, postOfficeBox FROM ''LDAP://DC=mdl,DC=com,DC=br'' WHERE objectclass= ''person'' AND objectClass = ''user''')
where displayName like '%kinkel%'

--where sAMAccountName = 'kinkel'

USE [master]
GO
sp_configure 'show advanced options',1
GO
reconfigure with override
GO
sp_configure 'Ad Hoc Distributed Queries',1
GO
reconfigure with override
GO

SELECT Name, displayName,givenname,distinguishedName, 
      SAMAccountName
FROM OpenQuery(ADSI,'adsdatasource' ,
'SELECT  Name, displayName,givenname,distinguishedName, 
      SAMAccountName
    FROM ''LDAP://mdl.com.br'' 
    ')
GO
SELECT * 
FROM OpenQuery(ADSI, 'SELECT * FROM ''LDAP://DC=mdl,DC=com,DC=br'' WHERE objectCategory=''user'' ') 

SELECT Name, displayName,givenname,distinguishedName, SAMAccountName
FROM 
OPENROWSET('ADSDSOObject','adsdatasource'; 'MDl.com.br\administrator';'mdl168@@',
'SELECT  Name, displayName,givenname,distinguishedName, SAMAccountName
    FROM ''LDAP://mdl.com.br/ou=mdl,dc=mdl,dc=com,dc=br'' WHERE Name = ''BlackieHong''')
