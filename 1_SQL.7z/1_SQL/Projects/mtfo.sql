if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end


--select *, identity(int,1,1)NUM into #cross from [dos].[dbo].[cross]

--select * from #cross where mdl = 'B43040039'
--delete from #cross where num = 3321

--MTFO_MTPR MTFO_SIES MTFO_GLFO MTFO_DEFA MTFO_GLFO_GLPA	MTFO_GLFO_NRDZ  MTFO_CPCO												MTFO_CPUN MTFO_NOM  MTFO_CPFT MTFO_OBS  MTFO_USC  MTFO_DTC    MTFO_USU  MTFO_DTU  MTFO_CPCT MTFO_CPDT
--insert into MTFO
select MDL, 1,				61322,		'S',			14000,					'DANLY',				substring(COMP1,2,len(COMP1)),	'PC',			[desc],		1,				null,			'KINKEL',	GETDATE(),	null,			null,			null,			null
--select count(1), MDL, substring(COMP1,2,len(COMP1))
from [dos].[dbo].#cross
where COMP1 is not null
			and SUBSTRING(comp1,2,1) <> ''
			and MDL in (select mtes_mtpr from MTES) 
			and num>=4201 and num<=4800
			and mdl+'/'+substring(COMP1,2,len(COMP1))not in(select mtfo_mtpr+'/'+mtfo_cpco from mtfo)
--group by MDL, substring(COMP1,2,len(COMP1))
--having COUNT(1) > 1
order by mdl


select *, identity(int,1,1)NUM into #lempco from [dos].[dbo].[lempco]

--select * from #cross where mdl = 'B43040039'
--delete from #cross where num = 3321

--MTFO_MTPR MTFO_SIES MTFO_GLFO MTFO_DEFA MTFO_GLFO_GLPA	MTFO_GLFO_NRDZ  MTFO_CPCO												MTFO_CPUN MTFO_NOM  MTFO_CPFT MTFO_OBS  MTFO_USC  MTFO_DTC    MTFO_USU  MTFO_DTU  MTFO_CPCT MTFO_CPDT
insert into MTFO
select MDL, 1,				61324,		'S',			14005,					'LEMPCO',				substring(LEMPCO,2,len(LEMPCO)),	'PC',			[desc],		1,				null,			'KINKEL',	GETDATE(),	null,			null,			null,			null
--select count(1), MDL, substring(COMP1,2,len(COMP1))
from [dos].[dbo].#lempco
where COMP1 is not null
			and SUBSTRING(comp1,2,1) <> ''
			and MDL in (select mtes_mtpr from MTES) 
			--and num>=4201 and num<=4800
			and mdl+'/'+substring(LEMPCO,2,len(LEMPCO))not in(select mtfo_mtpr+'/'+mtfo_cpco from mtfo)
--group by MDL, substring(COMP1,2,len(COMP1))
--having COUNT(1) > 1
order by mdl
