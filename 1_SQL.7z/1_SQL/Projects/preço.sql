--INSERT INTO OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=D:\disco_j\Excel\Sales_Price_List_US_novaV1.XLS',sheet2$)
SELECT *, Formula2 = '=SE(E'+convert(varchar(6),a.indice)+'<(C'+convert(varchar(6),a.indice)+'+0,05*E'+convert(varchar(6),a.indice)+');1;0)'
--update OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=D:\disco_j\Excel\Sales_Price_List_US_novaV1.XLS',sheet2$) set AQUI = 8, Formula = a.indice--'=SE(E'+convert(varchar(6),b.indice)+'<(C'+convert(varchar(6),b.indice)+'+0,05*E'+convert(varchar(6),b.indice)+');1;0)'
--into #div
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=D:\disco_j\Excel\Sales_Price_List_US_novaV1.XLS',sheet1$) a

drop table #BRA
select convert(varchar(20),replace(mtpc_mtpr,'.','')) MTPR_BRA, convert(varchar(20),replace(mtpc_cod,'.','')) MTPC_BRA, convert(decimal(12,2),(MTPC_PRE*replace(replace(replace(replace(replace(replace(replace(replace(replace(mtpr_mtdv,'0500', 0.7275), '1000', 0.8195), '1500', 0.8195), '2000', 0.8195), '2500', 0.8195), '3000', 0.7275), '3500', 0.8195), '4000', 0.8195), '4500', 0.8195))/1.9*14.5) PRE_BRA_MXN
into #BRA
from [192.168.2.39].[mdl].[dbo].mtpc a, [192.168.2.39].[mdl].[dbo].mtpr b
where mtpc_mtpr = mtpr_cod
			and mtpr_atvv = 'S'
			and mtpr_mtdv not in ('6000', '9999')
			and substring(mtpc_cod,1,3) not in ('s11','s21','s26','s36','res','s03','vmp')
			and substring(mtpc_cod,1,1) not in ('O')
			and MTPC_PRE > 0.00
order by mtpr_mtdv, mtpc_mtpr
select * from #BRA
drop table #USA
select MTPC_COD, convert(varchar(20),replace(replace(replace(replace(MTPC_MTPR,'ssg','S11'),'ssb','S21'),'ssr','S26'),'ssy','S36')) MTPC_USA , MTPC_PRE*14.5*MTPR_CPFT PRE_USA_MXN
into #USA
from [192.168.6.2\sqlexpress].[mdl-usa].[dbo].mtpc a, [192.168.6.2\sqlexpress].[mdl-usa].[dbo].mtpr b
where mtpc_mtpr = mtpr_cod
			and substring(mtpc_cod,1,3) not in ('scb')
			and MTPC_PRE > 0.00
			and mtpr_atvv = 'S'
order by mtpr_mtdv, mtpc_mtpr


select *
from MTPC
where MTPC_COD 