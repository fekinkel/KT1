if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

drop table #new
drop table #sigo_new

--Criar tabelas para recupera��o
/*
select *
into siop_old
from SIOP

select *
into sigo_old
from SIGO

select *
into sioi_old
from SIOI

select *
into simo_old
from SIMO
*/

select SIOI_NOM, a.* 
into #new
from SIGO a, SIOI b
where SIGO_SIOP = SIOI_SIOP

select distinct a.SIOI_NOM, SIGO_SIGR, SIGO_SIAP, SIGO_SIMD, SIOI_SIOP SIGO_SIOP, SIGO_USC, SIGO_DTC, SIGO_USU, SIGO_DTU--, IDENTITY(int,1,1) NUM
--into #sigo_new
from #new a, [MDL_Menus].[dbo].SIOI b--, [MDL_Menus].[dbo].SIMO c
where a.SIOI_NOM = b.SIOI_NOM
			and a.SIOI_NOM like '%venda%'
			--and c.simo_siop = a.SIGO_SIOP

/*
select SIGO_SIOP--, sigo_sigr, sigo_siap
from #new
where SIOI_NOM not in ( 
select SIOI_NOM
from [MDL_Menus].[dbo].SIOI
)
		and substring(SIGO_SIOP,1,3) <> 'mnu'
group by SIGO_SIOP--, sigo_sigr, sigo_siap
order by SIGO_SIOP--, sigo_sigr, sigo_siap
*/
delete 
from SIGO


insert into SIMD
select *
from [Restore_MDL_Menus].[dbo].SIMD
where SIMD_COD not in (select SIMD_COD from SIMD)

insert into SIMo
select *
from [Restore_MDL_Menus].[dbo].SIMO
where rtrim(ltrim(SIMO_SIMD))+'/'+rtrim(ltrim(SIMO_SIOP)) not in (select rtrim(ltrim(SIMO_SIMD))+'/'+SIMO_SIOP from SIMO)

insert into SIOP
select *
from [Restore_MDL_Menus].[dbo].SIOP
where SIOP_COD not in (
select SIOP_COD
from SIOP
)

--Caso n�o consiga colocar os novos menus, voltar o estado anterior
/*
delete
from SIGO

insert into SIGO
select *
from sigo_old

delete
from SIMO

insert into SIMO
select *
from simo_old


*/

/*
select COUNT(1), SIGO_SIGR,  SIGO_SIAP, SIGO_SIMD, SIGO_SIOP
from #sigo_new
where sigo_siop not in ('MNULIVROSAUXECD', 'MNURELFATFATURAMENTOPORCFOP', 'MNUINCLUIAPONTAMENTOHORAS', 'MNUCONSULTAFATURAMENTO', 'MNUINCLUIAPONTAMENTOHORAS', 'FRMAPONTAMENTOHORASF4', 'FRMAPONTAMENTOHORASF4', 'MNUINCLUIAPONTAMENTOHORAS', 'MNUGERAECD', 'FRMAPONTAMENTOHORASF4')
group by SIGO_SIGR,  SIGO_SIAP, SIGO_SIMD, SIGO_SIOP 
order by COUNT(1)desc
*/


delete
from SIGO


declare
@i int
set @i= 1
while @i <= (select MAX(num) from #sigo_new) begin
--while @i = @i begin
	insert into SIGO
	select SIGO_SIGR, SIGO_SIAP, SIGO_SIMD, SIGO_SIOP, SIGO_USC, SIGO_DTC, SIGO_USU, SIGO_DTU
	from #sigo_new
	where sigo_siop not in ('MNULIVROSAUXECD', 'MNURELFATFATURAMENTOPORCFOP', 'MNUINCLUIAPONTAMENTOHORAS', 'MNUCONSULTAFATURAMENTO', 'MNUINCLUIAPONTAMENTOHORAS', 'FRMAPONTAMENTOHORASF4', 'FRMAPONTAMENTOHORASF4', 'MNUINCLUIAPONTAMENTOHORAS', 'MNUGERAECD', 'FRMAPONTAMENTOHORASF4')
				and sigo_siop in (select siop_cod from SIOP)
				and num = @i
	print @i
	select SIGO_SIGR+'/'+SIGO_SIAP+'/'+SIGO_SIMD+'/'+SIGO_SIOP
	from #sigo_new
	where num = @i

	set @i = @i + 1
end

select *
from SIMO
where SIMO_SIOP= 'MNURELTITULOSAPAGAR'
			--SIMO_SIMD = 'CONTAS A PAGAR'

select *
from SIOP
where SIOP_COD = 'MNURELTITULOSAPAGAR'


--CONTAS A PAGAR       MNURELTITULOSAPAGAR
--FRMBANCOSF4

select top 1 *
from sigo
