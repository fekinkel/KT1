if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
insert into MTEP
select mtpr_cod MTEP_PAI, ACRESCENTAR MTEP_FIL, 3 MTEP_SEQ, 1 MTEP_QTD, 0.0 MTEP_PCT, 'S' MTEP_GNEC, 'KINKEL' MTEP_USC, getdate() MTEP_DTC, null MTEP_USU, null MTEP_DTU
from MTpr, [DOS].[dbo].[kit_mm]
where substring(MTPR_COD,1,6) = REF

