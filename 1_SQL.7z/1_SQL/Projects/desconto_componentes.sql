drop table #new

select  VDPI_PUN, VDPI_PUND, convert(decimal(8,2),100-((VDPI_PUND*100)/VDPI_PUN)) [VDPI_DESC]
into #new
from vdpi, mtpr
where convert(char(10), VDPI_DENT, 102) >= '2010.03.01' 
			and convert(char(10), VDPI_DENT, 102) <= '2010.08.31' 
			and vdpi_mtpr = mtpr_cod
			and mtpr_mtdv in ('1000', '1500')
			and substring(vdpi_mtpc,1,1)!= 'O' 
			
select count(1) [QDE], sum(VDPI_PUN) [VALOR_SEM], sum(VDPI_PUND) [VALRO_COM], 'TOTAL                      '[TIPO] 
into #new1
from #new
			
insert into #new1
select count(1), sum(VDPI_PUN), sum(VDPI_PUND), 'desconto de 0 at� 3,5'[TIPO]
from #new
where VDPI_DESC >=0
			and VDPI_DESC <=3.5
insert into #new1
select count(1), sum(VDPI_PUN), sum(VDPI_PUND), 'desconto de 3,5 at� 5'[TIPO]
from #new
where VDPI_DESC >3.5
			and VDPI_DESC <=5.0
insert into #new1
select count(1), sum(VDPI_PUN), sum(VDPI_PUND), 'desconto de 5 at� 10'[TIPO]
from #new
where VDPI_DESC >5
			and VDPI_DESC <=10.0
insert into #new1
select count(1), sum(VDPI_PUN), sum(VDPI_PUND), 'desconto de 10 at� 30'[TIPO]
from #new
where VDPI_DESC >10.0
			and VDPI_DESC <=10.0
insert into #new1
select count(1), sum(VDPI_PUN), sum(VDPI_PUND), 'desconto de acima 30'[TIPO]
from #new
where VDPI_DESC >30.0
			
select *
from #new1
			
			
			