drop table #MTPR
drop table #MTPC
drop table #mtep

if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
--CRIA UMA TABELA TEMPORARIA VAZIA
select *
into #MTPR
from MTPR
where 1 = 2
select *
into #MTPC
from MTPC
where 1 = 2

--INCLUI OS ITENS DA PLANILHA EXCEL (Produtos EUA.xls)
--MTPR_COD    MTPR_MTTP MTPR_MS MTPR_ATV MTPR_NOM  MTPR_MTDV MTPR_MTLN MTPR_MTFM MTPR_MTUN MTPR_MTNC MTPR_ORI MTPR_PES MTPR_DES MTPR_NIV  MTPR_ESUN MTPR_ESFT MTPR_CPUN MTPR_CPFT MTPR_ATVV MTPR_CFOV MTPR_ATVC MTPR_CFOC MTPR_TOLE MTPR_USC        MTPR_DTC                MTPR_USU        MTPR_DTU
INSERT INTO #MTPR
select distinct CONVERT(VARCHAR(20),[PART #]), REPLACE(REPLACE([STOCK],'PA','PA/COMP'),'PP','PI/COMP'), 'M', 'S', [DESCRIPTION], DIV, LIN, CONVERT(CHAR(4),FAM), 'PC', '00000000', 0, [WEIGHT], [DESCRIPTION], 0, 'PC', 1.00, 'PC', 1.00, 'S', '5.4025', 'S', '1.4550', 5.00, 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].produsa

update #mtpr
set mtpr_mttp = 'PI/COMP'
from #mtpr
where mtpr_mtln = 'P'

--MTPC_COD   MTPC_MTPR     MTPC_NOM  MTPC_GLMD MTPC_PRE MTPC_PRE_USU    MTPC_PRE_DTU MTPC_USC MTPC_DTC MTPC_USU MTPC_DTU
insert into #mtpc
select mtpr_cod, mtpr_cod, mtpr_nom, 'USD', 0.00, null, null, 'KINKEL', GETDATE(), null, null  
from #mtpr
where mtpr_cod not in (select mtpc_cod from #mtpc)

/*
--INCLUI OS ITENS DA PLANILHA EXCEL (KIT EUA.xls)
INSERT INTO #MTPR
select distinct CONVERT(VARCHAR(20),Kitincludes1), 'PA/COMP', 'M', 'S', 'KIT', '9', '9', '9', 'PC', '00000000', 0, 0.0, 'KIT', 0, 'PC', 1.00, 'PC', 1.00, 'S', '5.4025', 'S', '1.660', 5.00, 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].KIT
where Kitincludes1 not in (select mtpr_cod from #mtpr)

INSERT INTO #MTPR
select distinct CONVERT(VARCHAR(20),SUBSTRING(part2,1,9)), 'PA/COMP', 'M', 'S', 'KIT', '9', '9', '9', 'PC', '00000000', 0, 0.0, 'KIT', 0, 'PC', 1.00, 'PC', 1.00, 'S', '5.4025', 'S', '1.660', 5.00, 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].KIT
where SUBSTRING(part2,1,9) not in (select mtpr_cod from #mtpr)

INSERT INTO #MTPR
select distinct CONVERT(VARCHAR(20),SUBSTRING(part3,1,9)), 'PA/COMP', 'M', 'S', 'KIT', '9', '9', '9', 'PC', '00000000', 0, 0.0, 'KIT', 0, 'PC', 1.00, 'PC', 1.00, 'S', '5.4025', 'S', '1.660', 5.00, 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].KIT
where SUBSTRING(part3,1,9) not in (select mtpr_cod from #mtpr)

INSERT INTO #MTPR
select distinct CONVERT(VARCHAR(20),SUBSTRING(part4,1,9)), 'PA/COMP', 'M', 'S', 'KIT', '9', '9', '9', 'PC', '00000000', 0, 0.0, 'KIT', 0, 'PC', 1.00, 'PC', 1.00, 'S', '5.4025', 'S', '1.660', 5.00, 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].KIT
where part4 not in (select mtpr_cod from mtpr) and part4 not in (select mtpr_cod from #mtpr)
*/
select distinct convert(varchar(10),convert(int,ncm))
from [dos].[dbo].CODKIT
where insumo not in (select mtpr_cod from mtpr) and insumo not in (select mtpr_cod from #mtpr)
			and convert(varchar(10),convert(int,ncm)) is not null
			
--Insumo                                                             Nome  Descri��o           Unidade        NCM    Peso em Kg 
INSERT INTO #MTPR
select distinct CONVERT(VARCHAR(20),SUBSTRING(replace(insumo,'.',''),1,9)), 'PI/COMP', 'M', 'S', nome, '9', '9', '9', unidade, convert(varchar(10),convert(int,ncm)), 0, 0.0, [descri��o], 0, unidade, 1.00, unidade, 1.00, 'S', '5.4025', 'S', '1.4550', 5.00, 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].CODKIT
where insumo not in (select mtpr_cod from mtpr) and insumo not in (select mtpr_cod from #mtpr)
			and convert(varchar(10),convert(int,ncm)) is not null

insert into #mtpc
select mtpr_cod, mtpr_cod, mtpr_nom, 'USD', 0.00, null, null, 'KINKEL', GETDATE(), null, null  
from #mtpr
where mtpr_cod not in (select mtpc_cod from #mtpc)

--INCLUIR NA TABELA 
INSERT INTO MTPR
select *
from #mtpr
where mtpr_cod not in (select MTPR_COD from MTPR)

--INCLUIR PRODUTO
insert into MTPC
select *
from #mtpc
where mtpc_cod not in (select mtpc_cod from mtpc)

--CRIAR TABELA TEMPOR�RIA VAZIA DA ESTRUTURA
select *
into #mtep
from MTEP
where 1=2

--Insert KIT Planilha Excel "KIT USA ACMO.xls" WorkSheet "KIT" Filho 1
--MTEP_PAI             MTEP_FIL     MTEP_SEQ    MTEP_QTD  MTEP_PCT MTEP_GNEC MTEP_USC MTEP_DTC MTEP_USU        MTEP_DTU
insert into #mtep
select distinct CONVERT(VARCHAR(20),replace([C�digo do Kit],'.','')), replace([Parafuso],'.',''), 1, [Qt#P], 0.00, 'S', 'KINKEL', GETDATE(), null, null
from [dos].[dbo].KITA
where substring(replace([C�digo do Kit],'.',''),1,len(replace([C�digo do Kit],'.','')))+'/'+substring(replace([Parafuso],'.',''),1,LEN(replace([Parafuso],'.',''))) not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)
			and [C�digo do Kit] is not null
			
--Insert KIT Planilha Excel "KIT USA ACMO.xls" WorkSheet "KIT" Filho 2
insert into #mtep
select distinct CONVERT(VARCHAR(20),replace([C�digo do Kit],'.','')), replace([Anel El�stico],'.',''), 2, [Qt#A], 0.00, 'S', 'KINKEL', GETDATE(), null, null
from [dos].[dbo].KITA
where substring(replace([C�digo do Kit],'.',''),1,len( replace([C�digo do Kit],'.','')))+'/'+substring(replace([Anel El�stico],'.',''),1,LEN(replace([Anel El�stico],'.',''))) not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)
			and [C�digo do Kit] is not null
			and [Anel El�stico] is not null

--Insert KIT Planilha Excel "KIT USA ACMO.xls" WorkSheet "KIT" Filho 3
insert into #mtep
select distinct CONVERT(VARCHAR(20),replace([C�digo do Kit],'.','')), replace([Arruela Mickey],'.',''), 3, [Qt#M], 0.00, 'S', 'KINKEL', GETDATE(), null, null
from [dos].[dbo].KITA
where substring(replace([C�digo do Kit],'.',''),1,len(replace([C�digo do Kit],'.','')))+'/'+substring(replace([Arruela Mickey],'.',''),1,LEN(replace([Arruela Mickey],'.',''))) not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)
			and [C�digo do Kit] is not null
			and [Arruela Mickey] is not null

--Insert KIT Planilha Excel "KIT USA ACMO.xls" WorkSheet "KIT" Filho 4
insert into #mtep
select distinct CONVERT(VARCHAR(20),replace([C�digo do Kit],'.','')), replace([R],'.',''), 4, [Qt#R], 0.00, 'S', 'KINKEL', GETDATE(), null, null
from [dos].[dbo].KITA
where substring(replace([C�digo do Kit],'.',''),1,len(replace([C�digo do Kit],'.','')))+'/'+substring(replace([R],'.',''),1,LEN(replace([R],'.',''))) not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)
			and [C�digo do Kit] is not null
			and [R] is not null
			and [R] not in ('w')

--Insert KIT Planilha Excel "KIT USA ACMO1.xls" WorkSheet "KIT Pol" Filho 1
insert into #mtep			
select b.mtpr_cod, [Item]+[Di�metros (pol)]+SUBSTRING(b.mtpr_cod,(LEN(tipo)+len([Di�metros (pol)]))+1,5), 1, 1, 0.00, 'S', 'KINKEL', GETDATE(), null, null 
from [DOS].[dbo].kitbp, MTPR b
where tipo is not null
			and SUBSTRING(b.mtpr_cod,1,LEN(tipo)+len([Di�metros (pol)])) = tipo +[Di�metros (pol)]
			--and SUBSTRING(c.mtpr_cod,1,LEN(filho)+len([Di�metros (pol)])) = filho +[Di�metros (pol)]
			and [item]+[Di�metros (pol)]+SUBSTRING(b.mtpr_cod,(LEN(tipo)+len([Di�metros (pol)]))+1,5) in (select MTPR_COD from mtpr)
			and b.mtpr_cod +'/'+ [item]+[Di�metros (pol)]+SUBSTRING(b.mtpr_cod,(LEN(tipo)+len([Di�metros (pol)]))+1,5)not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)

--Insert KIT Planilha Excel "KIT USA ACMO1.xls" WorkSheet "KIT Pol" Filho 2
insert into #mtep			
select b.mtpr_cod, replace([C�digo do Kit],'.',''), 2, 1, 0.00, 'S', 'KINKEL', GETDATE(), null, null 
from [DOS].[dbo].kitbp, MTPR b
where tipo is not null
			and SUBSTRING(b.mtpr_cod,1,LEN(tipo)+len([Di�metros (pol)])) = tipo +[Di�metros (pol)]
			--and SUBSTRING(c.mtpr_cod,1,LEN(filho)+len([Di�metros (pol)])) = filho +[Di�metros (pol)]
			and replace([C�digo do Kit],'.','') in (select MTPR_COD from mtpr)
			and b.mtpr_cod +'/'+ replace([C�digo do Kit],'.','') not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)

--Insert KIT Planilha Excel "KIT USA ACMO1.xls" WorkSheet "KIT Pol" Filho 3
insert into #mtep			
select b.mtpr_cod, replace([Engraxadeira],'.',''), 3, 1, 0.00, 'S', 'KINKEL', GETDATE(), null, null 
from [DOS].[dbo].kitbp, MTPR b
where tipo is not null
			and SUBSTRING(b.mtpr_cod,1,LEN(tipo)+len([Di�metros (pol)])) = tipo +[Di�metros (pol)]
			--and SUBSTRING(c.mtpr_cod,1,LEN(filho)+len([Di�metros (pol)])) = filho +[Di�metros (pol)]
			and replace([Engraxadeira],'.','') not in (select MTPR_COD from mtpr)
			and b.mtpr_cod +'/'+ replace([Engraxadeira],'.','') not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)

--Insert KIT Planilha Excel "KIT USA ACMO1.xls" WorkSheet "KIT MM" Filho 1
insert into #mtep			
select b.mtpr_cod, [Cod#pe�a]+[Di�metros (mm)]+SUBSTRING(b.mtpr_cod,(LEN(tipo)+len([Di�metros (mm)]))+1,5), 1, 1, 0.00, 'S', 'KINKEL', GETDATE(), null, null 
from [DOS].[dbo].kitbm, MTPR b
where tipo is not null
			and SUBSTRING(b.mtpr_cod,1,LEN(tipo)+len([Di�metros (mm)])) = tipo +[Di�metros (mm)]
			--and SUBSTRING(c.mtpr_cod,1,LEN(filho)+len([Di�metros (pol)])) = filho +[Di�metros (pol)]
			and [Cod#pe�a]+[Di�metros (mm)]+SUBSTRING(b.mtpr_cod,(LEN(tipo)+len([Di�metros (mm)]))+1,5) in (select MTPR_COD from mtpr)
			and b.mtpr_cod +'/'+ [Cod#pe�a]+[Di�metros (mm)]+SUBSTRING(b.mtpr_cod,(LEN(tipo)+len([Di�metros (mm)]))+1,5)not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)

--Insert KIT Planilha Excel "KIT USA ACMO1.xls" WorkSheet "KIT MM" Filho 2
insert into #mtep			
select b.mtpr_cod, replace([C�digo do Kit],'.',''), 2, 1, 0.00, 'S', 'KINKEL', GETDATE(), null, null 
from [DOS].[dbo].kitbm, MTPR b
where tipo is not null
			and SUBSTRING(b.mtpr_cod,1,LEN(tipo)+len([Di�metros (mm)])) = tipo +[Di�metros (mm)]
			--and SUBSTRING(c.mtpr_cod,1,LEN(filho)+len([Di�metros (pol)])) = filho +[Di�metros (pol)]
			and replace([C�digo do Kit],'.','') in (select MTPR_COD from mtpr)
			and b.mtpr_cod +'/'+ replace([C�digo do Kit],'.','') not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)

--Insert KIT Planilha Excel "KIT USA ACMO1.xls" WorkSheet "KIT MM" Filho 3
insert into #mtep			
select b.mtpr_cod, replace([Engraxadeira],'.',''), 3, 1, 0.00, 'S', 'KINKEL', GETDATE(), null, null 
from [DOS].[dbo].kitbM, MTPR b
where tipo is not null
			and SUBSTRING(b.mtpr_cod,1,LEN(tipo)+len([Di�metros (mm)])) = tipo +[Di�metros (mm)]
			--and SUBSTRING(c.mtpr_cod,1,LEN(filho)+len([Di�metros (pol)])) = filho +[Di�metros (pol)]
			and replace([Engraxadeira],'.','') in (select MTPR_COD from mtpr)
			and b.mtpr_cod +'/'+ replace([Engraxadeira],'.','') not in (select substring(mtep_pai,1,LEN(mtep_pai))+'/'+substring(mtep_fil,1,len(mtep_fil)) from #mtep)
						

insert into MTEP			
select * 
from #MTEP
where mtep_pai+'/'+mtep_fil not in (select MTEP_PAI+'/'+mtep_fil from MTEP)			
--			and mtep_pai in (select mtpr_cod from mtpr)
--			and MTEP_FIL <>''
			 and mtep_fil in (select mtpr_cod from mtpr)
order by MTEP_PAI


--Atualizar pre�o
--SELECT [PART #], COMPETE, 'USD'
update mtpc set mtpc_pre = COMPETE, mtpc_glmd = 'USD', MTPC_PRE_USU ='KINKEL', MTPC_PRE_DTU = getdate()
FROM [dos].[dbo].produsa, MTPC
where [PART #] = MTPC_COD

--		 MTES_MTPR    MTES_SIES   MTES_MTAL   MTES_MTAN   MTES_MTAP   MTES_LOTE   MTES_GLMD   MTES_QATU   MTES_VATU   MTES_VATM   MTES_QVIS   MTES_QNEC   MTES_QPRO   MTES_PCME   MTES_PCMR   MTES_PMIN   MTES_POBJ   MTES_POEM   MTES_PPMI   MTES_PLEM   MTES_PMUL   MTES_PLEC   MTES_UCDO   MTES_LEAD   MTES_LEEM   MTES_EXPL		MTES_MRP	MTES_CREP   MTES_CPDR MTES_FGGF   MTES_FRAT   MTES_CTGT   MTES_CPO1   MTES_CPO2   MTES_CPO3   MTES_CPO4   MTES_PRAT   MTES_USC  MTES_DTC  MTES_USU  MTES_DTU
--		 MTES_MTPR		MTES_SIES		MTES_MTAL		MTES_MTAN		MTES_MTAP		MTES_LOTE		MTES_GLMD		MTES_QATU		MTES_VATU		MTES_VATM		MTES_QVIS		MTES_QNEC		MTES_QPRO		MTES_PCME		MTES_PCMR		MTES_PMIN		MTES_POBJ								MTES_PPMI		MTES_PLEM		MTES_PMUL		MTES_PLEC		MTES_UCDO		MTES_LEAD								MTES_EXPL		MTES_MRP	MTES_CREP		MTES_CPDR	MTES_FGGF		MTES_FRAT		MTES_CTGT		MTES_CPO1		MTES_CPO2		MTES_CPO3		MTES_CPO4		MTES_PRAT		MTES_USC	MTES_DTC	MTES_USU	MTES_DTU
INSERT INTO MTES
SELECT MTPR_COD,		1,					'MSTOCK',		'MSTOCK',		'MSTOCK',		'N',				'USD',			0.0,				0.0,				0.00,				0.00,				0.00,				0.00,				0.00,				0.00,				0.0,				0.0,				0.00,				0.00,				1.0,				1.0,				0.00,				NULL,				10.0,				77.00,			'S',				'S',			0.00,				0.00,			0.00,				1.0,				0.00,				NULL,				NULL,				NULL,				NULL,				NULL,				'KINKEL', GETDATE(),NULL,			NULL
FROM #MTPR
WHERE MTPR_COD NOT IN (SELECT MTES_MTPR FROM MTES)

--SELECT * FROM MTES
--select distinct CONVERT(VARCHAR(20),replace([C�digo do Kit],'.','')), replace([Parafuso],'.',''), 1, [Qt#P], 0.00, 'N', 'KINKEL', GETDATE(), null, null
--AJUSTE DE POLICA DE ESTOQUE

update mtes set MTES_QPRO=11.00, MTES_PCME=media, MTES_PMIN=90, MTES_POBJ=110, MTES_POEM=30, MTES_PPMI=14.00, MTES_PLEM=24.00, MTES_PMUL=12.00, MTES_LEAD=60, MTES_LEEM=21
--select *
from MTES a, MTPR b, [dos].[dbo].Mediausa c
where MTPR_COD = MTES_MTPR
			and MTPR_MTDV = '3' 
			and MTPR_MTLN = 'b'
			and MTPR_MTFM = 'p15'
			and replace(FTIT_MTPR,'.','') = MTPR_COD