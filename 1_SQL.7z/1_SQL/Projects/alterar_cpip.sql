select cpct_mtpr, cpip_mtpr, cpip_pun, cpct_pun, *
from cpip a, cpsc b, cpct c
where cpip_sta = 'OK'
			and CPIP_CPSC_SIES = CPSC_SIES
			and CPIP_CPSC_SIDO = CPSC_SIDO
			and CPIP_CPSC_SISE = CPSC_SISE
			and CPIP_CPSC_NPAI = CPSC_NPAI
			and CPIP_CPSC      = cpsc_cod
			and CPSC_CPCT_SIES = CPCT_SIES
			and CPSC_CPCT_SIDO = CPCT_SIDO
			and CPSC_CPCT_SISE = CPCT_SISE
			and CPSC_CPCT      = cpct_cod
			
			and convert(char(10), CPCT_DTC, 102) >= '2010.07.01'
			and cpip_pun != cpct_pun
			--and substring(cpip_mtpr, 1, 3) not in ('GEN', 'pun', 'esc', 'inf', 'adm', 'man')


/*
select cpct_cpid, mtpc_cod, mtpc_pre, cpct_pun
--update cpct set cpct_pun = mtpc_pre
from cpct, mtpc_sidor
where cpct_cpid = mtpc_cod
			and cpct_sta = 'OK'
			and substring(cpct_cpid, 1, 1) != 'O'
			and mtpc_pre <> cpct_pun

*/