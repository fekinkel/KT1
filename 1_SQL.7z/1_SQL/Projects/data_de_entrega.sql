if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
select convert(char(10), VDPS_DENT, 102),*
--update vdps set VDPS_DENT = '05/03/2011'
from vdps
where vdps_vdpd = 129515
			and VDPS_VDPI = 4