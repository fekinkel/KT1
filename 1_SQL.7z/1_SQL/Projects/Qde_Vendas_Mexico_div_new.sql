select b.div_ref [DIVISAO], ''[LINHA], ''[FAMILIA], ''[ITEM], replace(convert(decimal(12,2),sum(a.VAL_MOVTO)),'.',',') [MOEDA_PESO], CONVERT(DECIMAL(10,0),sum(a.QTD_MOVTO)) QTD_MOVTO, replace(convert(decimal(12,2),sum(a.VLM_MOVTO)),'.',',') [MOEDA_DOLLAR]
from toq_mov a, prod b
where TIP_DOC = 'NFF'
	and a.ref = b.ref
 	and b.div_ref in (7, 8)
group by b.div_ref
order by b.div_ref

select b.div_ref [DIVISAO], b.lin_ref [LINHA], ''[FAMILIA], ''[ITEM], replace(convert(decimal(12,2),sum(a.VAL_MOVTO)),'.',',') [MOEDA_PESO], CONVERT(DECIMAL(10,0),sum(a.QTD_MOVTO)) QTD_MOVTO, replace(convert(decimal(12,2),sum(a.VLM_MOVTO)),'.',',') [MOEDA_DOLLAR]
from toq_mov a, prod b
where TIP_DOC = 'NFF'
	and a.ref = b.ref
 	and b.div_ref in (7, 8)
group by b.div_ref, b.lin_ref
order by b.div_ref, b.lin_ref

select b.div_ref [DIVISAO], b.lin_ref [LINHA], b.fam_ref [FAMILIA], ''[ITEM], replace(convert(decimal(12,2),sum(a.VAL_MOVTO)),'.',',') [MOEDA_PESO], CONVERT(DECIMAL(10,0),sum(a.QTD_MOVTO)) QTD_MOVTO, replace(convert(decimal(12,2),sum(a.VLM_MOVTO)),'.',',') [MOEDA_DOLLAR]
from toq_mov a, prod b
where TIP_DOC = 'NFF'
	and a.ref = b.ref
 	and b.div_ref in (7, 8)
group by b.div_ref, b.lin_ref, b.fam_ref
order by b.div_ref, b.lin_ref, b.fam_ref

select b.div_ref [DIVISAO], b.lin_ref [LINHA], b.fam_ref [FAMILIA], a.ref [ITEM], replace(convert(decimal(12,2),sum(a.VAL_MOVTO)),'.',',') [MOEDA_PESO], CONVERT(DECIMAL(10,0),sum(a.QTD_MOVTO)) QTD_MOVTO, replace(convert(decimal(12,2),sum(a.VLM_MOVTO)),'.',',') [MOEDA_DOLLAR]
from toq_mov a, prod b
where TIP_DOC = 'NFF'
	and a.ref = b.ref
 	and b.div_ref in (7, 8)
group by b.div_ref, b.lin_ref, b.fam_ref, a.ref
order by b.div_ref, b.lin_ref, b.fam_ref, a.ref

