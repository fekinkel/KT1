if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
select *
--UPDATE VDPI SET VDPI_MTPR = 'OPPZ'
from vdpi
where vdpi_vdpd = 121132
			AND VDPI_MTPC = 'OPPZ'
			
select *
--UPDATE ofit SET OFIT_MTPR = 'OPPZ'
from ofit
where OFIT_OFNF = 89648
			and OFIT_MTPC = 'oppz'
			
