select year(FTNF_DAT) ANO,FTNF_GLXX, FTNF_GLXX_DIG, FTNF_GLXX_NOM, FTIT_MTPC, FTIT_MTPR, sum(FTIT_QTD) FTIT_QTD
from vdcv, ftnf, ftit
where vdcv_cod = 8
			and vdcv_glcl = ftnf_glxx
			and vdcv_glcl_dig = ftnf_glxx_dig
			and year(FTNF_DAT) = 2009
			and FTNF_SIES = ftit_sies
			and FTNF_SIDO = ftit_sido
			and FTNF_SISE = ftit_sise
			and FTNF_COD  = ftit_ftnf
group by year(FTNF_DAT), FTNF_GLXX, FTNF_GLXX_DIG, FTNF_GLXX_NOM, FTIT_MTPC, FTIT_MTPR
