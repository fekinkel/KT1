select mtpc_cod, convert(decimal(12,2),mtpc_pre), 12 mtpc_fator, convert(decimal(12,2),round((mtpc_pre*(1+(12.00/100))),(3-len(convert(int,(mtpc_pre*(1+(12.00/100)))))))) mtpc_pre_new, mtpr_mtdv, mtpr_mtln, mtpr_mtfm, round(((1+(12.00/100))),3), *
--update MTPC set mtpc_pre = convert(decimal(12,2),round((mtpc_pre*(1+(12.00/100))),(3-len(convert(int,(mtpc_pre*(1+(12.00/100)))))))), MTPC_PRE_USU = 'KINKEL', MTPC_PRE_DTU = getdate()
from mtpc, mtpr
where mtpc_mtpr = mtpr_cod 
			and mtpr_mtdv = 3500
			and mtpc_pre > 0
			