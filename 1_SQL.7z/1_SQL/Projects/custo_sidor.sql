
drop table ##new

declare
@i int,
@j int,
@k int,
@ano int,
@s varchar(5000),
@mes char(2)

select @k= month(getdate())
set @ano = 2011

select top 1 * from mtsx where mtsx_mtpr = 'A02.042.028'

select MTSX_MTPR,  MTSX_SIES,  MTSX_ANO, MTSX_CMUR [Mes_01], MTSX_CMUR [Mes_02], MTSX_CMUR [Mes_03], MTSX_CMUR [Mes_04], MTSX_CMUR [Mes_05], MTSX_CMUR [Mes_06], MTSX_CMUR [Mes_07], MTSX_CMUR [Mes_08], MTSX_CMUR [Mes_09], MTSX_CMUR [Mes_10], MTSX_CMUR [Mes_11], MTSX_CMUR [Mes_12]
into ##new
from mtsx
where 1=0
set @i = 1
set @s = ''
print 'Entrou no WHILE'
while @i < @k begin
	set @mes = @i
	if len(@mes)<2 set @mes = '0'+@mes

	if @i = 1 begin
		print '  Entrou no mes = '+@mes
		insert into ##new
		select MTSX_MTPR,  MTSX_SIES,  MTSX_ANO, MTSX_CMUR, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00
		from mtsx
		where mtsx_ano = @ano
				and mtsx_mes = @mes
		--order by mtsx_mtpr				  
	end else begin
		print '  Entrou no mes '+@mes
		print @mes
		set @s = 'update ##new set Mes_'+@mes+' = b.MTSX_CMUR from ##new a, mtsx b where a.MTSX_MTPR = b.MTSX_MTPR and a.MTSX_SIES = b.MTSX_SIES and a.MTSX_ANO  = b.MTSX_ANO  and b.MTSX_MES = '+@mes
		--update ##new set Mes_02 = b.MTSX_CMUM 
		--select *
		--from ##new a, mtsx b
		--where a.MTSX_MTPR = b.MTSX_MTPR
					--and a.MTSX_SIES = b.MTSX_SIES
					--and a.MTSX_ANO  = b.MTSX_ANO
		--order by mtsx_mtpr	
		print @s		
		exec (@s)
	end
	print '  Mudou de mes'
	set @i = @i +1
end
print 'Terminou'

--select * from ##new a, mtsx b where a.MTSX_MTPR = b.MTSX_MTPR and a.MTSX_SIES = b.MTSX_SIES and a.MTSX_ANO  = b.MTSX_ANO 
--update ##new set Mes_03 = b.MTSX_CMUM from ##new a, mtsx b where a.MTSX_MTPR = b.MTSX_MTPR and a.MTSX_SIES = b.MTSX_SIES and a.MTSX_ANO  = b.MTSX_ANO 

select MTSX_MTPR [CODIGO], MTSX_SIES [ESTAB.], MTSX_ANO [ANO], REPLACE(Mes_01,'.',',') [JANEIRO], REPLACE(Mes_02,'.',',') [FEVEREIRO], REPLACE(Mes_03,'.',',') [MAR�O], Mes_04, Mes_05, Mes_06, Mes_07, Mes_08, Mes_09, Mes_10, Mes_11, Mes_12 
from ##new --where mtsx_mtpr = 'A02.042.028'