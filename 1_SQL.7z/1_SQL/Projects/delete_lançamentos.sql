
if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

			
select distinct CTLA_SIES   ,CTLA_SIDO ,CTLA_SISE ,CTLA_COD
into #new
--delete ctla
from ctla a, ctlc c
where ctla_sies  = 5
			and convert(char(10),CTLA_DAT,102) >= '2010.08.01'
			and convert(char(10),CTLA_DAT,102) <= '2010.08.31'			
			and ctla_sies = CTLC_SIES
			and ctla_sido = CTLC_SIDO
			and ctla_sise = CTLC_SISE
			and ctla_cod  = CTLC_CTLA
			and CTLC_DOC like '%FTNF%'

--select *
--update ctla set CTLA_ATV = 'N'
from ctla a, #new b
where a.CTLA_SIES = b.CTLA_SIES
			and a.CTLA_SIDO = b.CTLA_SIDO
			and a.CTLA_SISE = b.CTLA_SISE
			and a.CTLA_COD = b.CTLA_COD
			
delete ctla
from ctla a, #new b
where a.CTLA_SIES = b.CTLA_SIES
			and a.CTLA_SIDO = b.CTLA_SIDO
			and a.CTLA_SISE = b.CTLA_SISE
			and a.CTLA_COD = b.CTLA_COD
			
			