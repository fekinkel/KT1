select *
--update cfop set CFOP_HIS = GLPA_NOM +' '+CFOP_NEXT
from cfop, glfo, glpa
where CFOP_GLXX = glfo_cod
			and glfo_glpa = glpa_cod
			and CFOP_HIS = ''

select *
--update cfor set CFOr_HIS = GLPA_NOM +' '+CFOr_NEXT
from cfor, glcl, glpa
where CFOr_GLXX = GLCL_COD
			and GLCL_GLPA = glpa_cod
			and CFOR_HIS = ''


select GLPA_NOM +' '+CFCP_NEXT,CFCP_SIES   ,CFCP_SIDO ,CFCP_SISE ,CFCP_COD    ,CFCP_SEQ 
--update cfcp set CFCP_HIS = GLPA_NOM +' '+CFCP_NEXT
from cfcp, glfo, glpa
where CFCP_GLXX = glfo_cod
			and glfo_glpa = glpa_cod
			and CFCP_HIS = ''

select *
--update cfcc set CFCC_HIS = CFCC_NEXT
from cfcc
where CFCC_HIS = ''
