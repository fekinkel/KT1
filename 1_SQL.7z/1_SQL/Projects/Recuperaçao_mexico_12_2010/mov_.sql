select *
--update dbf4...TOQ_MOV set DT_MOVTO = '24/09/2010'
from dbf4...TOQ_MOV
where TIP_DOC = 'OPT'
			and NUM_DOC >= 000512