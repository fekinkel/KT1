select *
--into #new
--update [dbfSCD]...prod set COD_ALM = 'PA'
from [dbfSCD]...prod
where COD_ALM = 'T1'

select *
from #new

select *
--update [dbfSCD]...toq_qal set COD_ALM = 'PA'
from [dbfSCD]...toq_qal
where --COD_ALM = 'T1'
			ref = 'bhb.037.225'

order by ref

select *
--update [dbfSCD]...toq_qal set COD_ALM = 'PA'
from [dbfSCD]...toq_est
where ref = 'bhb.037.250'
order by ref
