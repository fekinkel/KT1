--select * from diciembre where Fecha is not null

--PEDIDO DE VENDAS
insert into dbf4...PED
--insert into PED
--			NUM_PED				NUM_COT COD_CLI							DIGITO	PED_CLI DIV_REF COD_VEND		COD_COM PGO	PRAZO_PED COR_FIN MDA		COD_OPER	DTC_PED				DTP_PED				DTE_PED				DESC_PED1 ACRE_PED2 COD_TR	VIA_TR	COD_MEM OBS_PED   QTD_PED           VAL_PED							QTD_FAT           VAL_FAT						VAL_IPI         VAL_ICM VAL_ISS DEL_PED CTO_PED   TIP_CLI URV		VLDES_ICM STA_PED USUARIO   STA_PRE REV_PED STA_LB	UNG_PED TPM_PED TIP_SRV COD_ESTAB VAL_REM VAL_RDV QTD_REM QTD_RDV
select convert(char(6),REPLICATE(' ',6-len([No# Pedido]))+convert(varchar(6),[No# Pedido])), null,		convert(char(5),replicate(' ',5-LEN(max([No# Cliente])))+convert(varchar(5),MAX([No# Cliente]))),	'  1',			null,		null,		a.COD_VEND, null,		30,	1,				00,			0,		null,			MAX([fecha]),	MAX([fecha]), MAX([fecha]),	0,				0,				0,			1,			null,		'MANUAL',	SUM([Cantidad]),	MAX([Subtotal]),		SUM([Cantidad]),	MAX([Subtotal]),	MAX([I#V#A# ]),	NULL,		NULL,		NULL,		NULL,			NULL,		NULL,	NULL,			'EC',		'KINKEL',	NULL,		NULL,		'S',		NULL,		NULL,		NULL,		1,				0,			0,			0,			0
--select [No# Pedido], null,		MAX([No# Cliente]),	'1',			null,		null,		a.COD_VEND, null,		30,	1,				00,			0,		null,			MAX([fecha]),	MAX([fecha]), MAX([fecha]),	0,				0,				0,			1,			null,		'MANUAL',	SUM([Cantidad1]),	MAX([Subtotal]),		SUM([Cantidad]),	MAX([Subtotal]),	MAX([I#V#A# ]),	NULL,		NULL,		NULL,		NULL,			NULL,		NULL,	NULL,			'EC',		'KINKEL',	NULL,		NULL,		'S',		NULL,		NULL,		NULL,		1,				0,			0,			0,			0
from dbf4...cli a, diciembre b
where [No# Cliente] = a.COD_CLI
			AND Fecha is not null
			AND [No# Pedido] not in (select num_ped from dbf4...PED c )
GROUP BY [No# Pedido], a.COD_VEND

--ITENS DO PEDIDO DE VENDAS
insert into dbf4...ITEM
--			NUM_PED																																								IT_PED																																				REF           DIG_REF QTP_IT      PUN_ICM					QTF_IT      VAL_IT      DESCR_IT    PCT_IPI STAT_IT DTE_IT    STAT_NE SIT_IT  OBS_IT  COD_OPER	CPE_IT	COMPO_IT	COD_TRA EST_REF QTR_IT  QDV_IT  PCT_COM
select	convert(char(6),REPLICATE(' ',6-len([No# Pedido]))+convert(varchar(6),[No# Pedido])), convert(char(3),replicate(' ',3-LEN(MAX([item])))+convert(varchar(3),MAX([item]))),	[referencia],	null,		MAX([Cantidad]),	MAX([Pecio Unit#]),	MAX([Cantidad]),	MAX([Subtotal]),	MAX(NOM_REF),		15,			NULL,		MAX([FECHA]),	NULL,		NULL,		NULL,		NULL,			NULL,		'N',			'04',		'N',		NULL,		NULL,		0
from diciembre b, dbf4...prod
where Fecha is not null
			and [Referencia] = ref
			AND [No# Pedido] not in (select num_ped from dbf4...item c )
GROUP BY [No# Pedido], [referencia]

--NOTA FISCAL
insert into dbf4...NFNF0000
--			COD_ESTAB ES_NF SER_NF	NUM_NF																																									NUM_OF	STATUS_NF STATUS_OF DT_FAT				DTS_TR  DT_CAN  DT_REC  CXF_NF	MS_OPER NUM_PED							COD_CLI							DIGITO	ORI_ICM DES_ICM COD_FIS COD_OPER	COD_REG PED_CLI TIP_CLI COD_VEND	COD_COM PCT_COM VAL_COM					PGO		DBA_ESTAB COR_FIN PRAZO_PED PCT_FIN NUM_PAR MDA		VAL_MDA VAL_NF        VAL_MER           VAL_SER   VAL_FRE VAL_SEG VAL_ACE VAL_IPI         VFR_IPI VSE_IPI VAC_IPI VAL_ISS VAL_ICM VFR_ICM VSE_ICM VAC_ICM VLDES_ICM VOF_PED           GERA_TIT	VAL_TIT       BAS_IPI           BFR_IPI BSE_IPI BAC_IPI BAS_ISS BAS_ICM BFR_ICM BSE_ICM BAC_ICM COD_TR	CTO_TR  NUM_OBJ VIA_TR	PLA_TR  PLAEST_TR FRECOB_TR MARCA_VOL NUM_VOL QTD_VOL ESP_VOL QTD_NF            PESO_LIQ  PESO_BRT  EMIT_OF EMIT_NF LIN_NF			LIN_ESTAB IDE_ESTAB NLS_NF	NLS_ESTAB LLS_ESTAB TIP_FAT TIP_TIT COD_MEN DES_MEN NFN_DE	NFN_ATE DTC_SIS       DTU_SIS USU_SIS		NUM_REM NUM_ATE, 96
select	1,				'S',	'NFF',	convert(char(6),REPLICATE(' ',6-len([No# Factura]))+convert(varchar(6),[No# Factura])),	NULL,		'FT',			NULL,			max([FECHA]),	NULL,		NULL,		NULL,		'C',		NULL,		max([No# Pedido]),	max([No# Cliente]),	1,			NULL,		null,		null,		null,			null,		null,		null,		COD_VEND,	'DAY',	0,			max([I#V#A#]),	'AT',	0,				00,			1,				0,			1,			0,		1,			max([Total]),	MAX([Subtotal]),	null,			null,		null,		null,		MAX([I#V#A#]),	null,		null,		null,		null,		null,		null,		null,		null,		null,			MAX([Subtotal]),	null,			max([Total]),	MAX([Subtotal]),	0,			0,			0,			null,		null,		null,		null,		null,		0,			null,		0,			1,			null,		null,			1,				null,			null,		1,			null,		SUM([Cantidad]),	1,				1,				0,			0,			count(1)+1,	23,				40,				null,		null,			null,			null,		'F',		null,		null,		null,		null,		MAX([fecha]),	null,		'KINKEL',	NULL,		NULL
from diciembre b, dbf4...CLI a
where Fecha is not null
			AND [No# Cliente] = a.COD_CLI
			AND [No# Factura] not in (select NUM_NF from dbf4...NFNF0000 c )
GROUP BY [No# Factura], a.COD_VEND

--ITENS DA NOTA FISCAL
insert into dbf4...NFIT0000
--			COD_ESTAB CONTA_CONT  COD_IPI INC_DIPI	INC_DIPAM ES_NF SER_NF NUM_NF																																										NUM_OF	IT_NF					NUM_PED							IT_PED				REF           DIG_REF DIV_REF				LIN_REF				FAM_REF				UN_REF				PLQ_REF				COM_REF				ORI_REF NBM_REF				DESCR_IT			LARG_IT LIN_IT	NPC_IT  DTE_IT				QTP_IT						QTF_IT						QOF_IT						PUN_DESC					PCR_DESC					VAL_IT						FRE_IT  SEG_IT  ACE_IT  PCT_IPI PCT_ISS PCT_ICM IPI_OPER	ISS_OPER	ICM_OPER	VIT_IPI					VIT_ISS   VIT_ICM   VDESICM_IT  BIT_IPI						BIT_ISS BIT_ICM VFR_IPI VFR_ICM BFR_IPI BFR_ICM VSE_IPI VSE_ICM BSE_IPI BSE_ICM VAC_IPI VAC_ICM BAC_IPI BAC_ICM PLQ_TOT COD_OPER	NOM_OPER  BAS_OPER  GERA_TIT	MS_OPER CLI_PRO IPI_ICM DESC_ICMS SUB_ICM TIT_IT				COD_TRA STAT_NE STAT_IT STAT_BA COD_ALM EST_REF PCT_COM
select	1,				NULL,				NULL,		1,				1,				'S',	'NFF', convert(char(6),REPLICATE(' ',6-len([No# Factura]))+convert(varchar(6),[No# Factura])),	NULL,		MAX([Item]),	MAX([No# Pedido]),	MAX([Item]),	[Referencia],	null,		MAX(DIV_REF),	MAX(LIN_REF),	MAX(FAM_REF),	MAX(UN_REF),	MAX(PLQ_REF),	MAX(COM_REF),	null,		MAX(NBM_REF),	MAX(NOM_REF),	40,			1,			null,		MAX([fecha]),	MAX([Cantidad]),	MAX([Cantidad]),	MAX([Cantidad]),	MAX([Subtotal]),	MAX([Pecio Unit#]),	MAX([Subtotal]),	0,			0,			0,			16,			0,			0,			null,			null,			null,			MAX([I#V#A#]),	0,				0,				null,				MAX([Subtotal]),	0,			0,			0,			0,			0,			0,			0,			0,			0,			0,			0,			0,			0,			0,			1,			null,			null,			null,			null,			null,		null,		null,		null,			null,		MAX([Total]),	04,			0,			0,			0,			'PA',		'N',		0
from diciembre b, dbf4...prod
where Fecha is not null
			and [Referencia] = ref
			AND [No# Factura] not in (select NUM_NF from dbf4...NFIT0000 c )
GROUP BY [No# Factura], [referencia]

--COMPLEMENTO NOTA FISCAL
insert into dbf4...NFCO0000
--			COD_ESTAB ES_NF SER_NF NUM_NF																																										NUM_OF	COD_SUFRA   NOM_CLI				MARCA_CLI		ID_CLI				IE_CLI				END_CLI				CEP_CLI				BAI_CLI				CID_CLI				EST_CLI				NPA_CLI FONE_CLI  CTO_CLI	ENDE_CLI	ID_E_CLI			IE_E_CLI			END_E_CLI			CEP_E_CLI			BAI_E_CLI			CID_E_CLI			EST_E_CLI			NPA_E_CLI FONE_E_CLI  ENDC_CLI	END_C_CLI			CEP_C_CLI			BAI_C_CLI			CID_C_CLI			EST_C_CLI			NPA_C_CLI FONE_C_CLI  ID_TR   IE_TR NOM_TR  END_TR  CEP_TR  CID_TR  EST_TR	VAL_TIT1          VAL_TIT2  VAL_TIT3  VAL_TIT4  VAL_TIT5  VAL_TIT6  VAL_TIT7  VAL_TIT8  VAL_TIT9  VAL_TIT10 VAL_TIT11 VAL_TIT12 DT_VCTO1					DT_VCTO2  DT_VCTO3  DT_VCTO4  DT_VCTO5  DT_VCTO6  DT_VCTO7  DT_VCTO8  DT_VCTO9  DT_VCTO10 DT_VCTO11 DT_VCTO12 CO_VCTO1  CO_VCTO2  CO_VCTO3  CO_VCTO4  CO_VCTO5  CO_VCTO6  CO_VCTO7  CO_VCTO8  CO_VCTO9  CO_VCTO10 CO_VCTO11 CO_VCTO12
select	1,				'S',	'NFF', convert(char(6),REPLICATE(' ',6-len([No# Factura]))+convert(varchar(6),[No# Factura])),	NULL,		NULL,				MAX(NOM_CLI),	NULL,				MAX(ID_CLI),	MAX(IE_CLI),	MAX(END_CLI),	MAX(CEP_CLI), MAX(BAI_CLI), MAX(CID_CLI),	MAX(EST_CLI),	NULL,		NULL,			NULL,		NULL,			MAX(ID_CLI),	MAX(IE_CLI),	MAX(END_CLI),	MAX(CEP_CLI),	MAX(BAI_CLI),	MAX(CID_CLI),	MAX(EST_CLI),	NULL,			NULL,				null,			MAX(END_CLI),	MAX(CEP_CLI),	MAX(BAI_CLI),	MAX(CID_CLI),	MAX(EST_CLI),	NULL,			NULL,				NULL,		NULL,	NULL,		NULL,		null,		null,		null,		MAX([Subtotal]),	0,				0,				0,				0,				0,				0,				0,				0,				0,				0,				0,				MAX([FECHA]+30),	null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null,			null
from diciembre b, dbf4...CLI a
where Fecha is not null
			AND [No# Cliente] = a.COD_CLI
			AND convert(char(6),REPLICATE(' ',6-len([No# Factura]))+convert(varchar(6),[No# Factura])) not in (select NUM_NF from dbf4...NFCO0000)
GROUP BY [No# Factura], a.COD_VEND

--TITULO A RECEBER
insert into dbf4...artitu
--			TIP_TIT COD_ESTAB NUM_TIT																																									SEQ_TIT COD_CLI																																														COD_VEND		TIP_BX	OPER_TIT COD_BCO COD_AGE	NUM_CTA NUM_TIT_BC  COD_FIS COD_OPER	VAL_FAT       VAL_TIT       VAL_RECEB   DT_EMISS      DT_VCTO           DT_RECEB  OBS_TIT   DEL_TIT NUM_TIT2	JURO_DIA  PED_CLI	COD_CTA NUM_PED																																								PCT_COM COD_COM TIP_CLI DIV_REF DIGITO	CO_VCTO EMI_TIT URV		VAL_URV OCOR_ENV	OCOR_RET	DATA_ENV  DATA_RET  NNU_TIT CART_TIT	VAL_DESC  DTC_SIS       DTU_SIS USU_SIS   MDA_TIT
select	'F',		1,				convert(char(6),REPLICATE(' ',6-len([No# Factura]))+convert(varchar(6),[No# Factura])),	'A',		convert(char(5),replicate(' ',5-LEN(max([No# Cliente])))+convert(varchar(5),MAX([No# Cliente]))),	a.COD_VEND,	NULL,		1,			'999',	'999999',	NULL,		NULL,				NULL,		NULL,			max([Total]),	max([Total]),	NULL,				MAX([FECHA]),	MAX([FECHA]+30),	null,			null,			null,		null,			5,				NULL,		null,		convert(char(6),REPLICATE(' ',6-len(MAX([No# Pedido])))+convert(varchar(6),MAX([No# Pedido]))),	0,			'SIN',	'NM',		null,		1,			null,		1,			null,	null,		null,			null,			null,			null,			null,		null,			null,			MAX([FECHA]),	null,		'KINKEL',	0
from diciembre b, dbf4...CLI a
where Fecha is not null
			AND [No# Cliente] = a.COD_CLI
			AND convert(char(6),REPLICATE(' ',6-len([No# Factura]))+convert(varchar(6),[No# Factura])) not in (select NUM_TIT from dbf4...ARTITU)
GROUP BY [No# Factura], a.COD_VEND


--MOVIMENTO DE BAIXA DO FATURAMENTO
insert into dbf4...TOQ_MOV
--			COD_ESTAB REF						DT_MOVTO  TIP_DOC NUM_DOC																																									SEQ_DOC	ORI_ALM DES_ALM QTD_MOVTO   VAL_MOVTO					VLM_MOVTO								OBS_MOVTO             COD_TRA VL_TRA	UC_TRA	DTC_SIS   DTU_SIS   USU_SIS
select	1,				[REFERENCIA],	[FECHA],	'NFF',	convert(char(6),REPLICATE('0',6-len([No# Factura]))+convert(varchar(6),[No# Factura])),	[ITEM],	'PA',		'EX',		[CANTIDAD],	CMUR*[CANTIDAD],	(CMUR*[CANTIDAD])/11.5,	'MANUAL:FATURAMENTO',	'04',		0,			0,			[FECHA],	null,			'KINKEL'
from diciembre b, dbf4...TOQ_EST a, dbf4...prod c
where Fecha is not null
			AND [REFERENCIA] = a.REF
			AND [REFERENCIA] = c.REF
			and COMPO_REF = 'N'
			AND convert(char(6),REPLICATE('0',6-len([No# Factura]))+convert(varchar(6),[No# Factura])) not in (select NUM_DOC from dbf4...TOQ_MOV)
			and [Sub-Item] is null

insert into dbf4...TOQ_MOV
--			COD_ESTAB REF					DT_MOVTO  TIP_DOC NUM_DOC																																									SEQ_DOC	ORI_ALM DES_ALM QTD_MOVTO			VAL_MOVTO					VLM_MOVTO									OBS_MOVTO             COD_TRA VL_TRA	UC_TRA	DTC_SIS   DTU_SIS   USU_SIS
select	1,				[Sub-Item],	[FECHA],	'NFF',	convert(char(6),REPLICATE('0',6-len([No# Factura]))+convert(varchar(6),[No# Factura])),	[ITEM],	'PA',		'EX',		[CANTIDAD1],	CMUR*[CANTIDAD1],	(CMUR*[CANTIDAD1])/11.5,	'MANUAL:FATURAMENTO',	'04',		0,			0,			[FECHA],	null,			'KINKEL'
from diciembre b, dbf4...TOQ_EST a, dbf4...prod c
where Fecha is not null
			AND [Sub-Item] = a.REF
			AND [Sub-Item] = c.REF

			AND convert(char(6),REPLICATE('0',6-len([No# Factura]))+convert(varchar(6),[No# Factura])) not in (select NUM_DOC from dbf4...TOQ_MOV)
			and [Sub-Item] is not null
