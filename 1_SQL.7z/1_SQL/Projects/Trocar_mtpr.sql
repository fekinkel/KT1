if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
SELECT *
--UPDATE VDPI SET VDPI_MTPC = 'OSBA', VDPI_MTPR = 'OSBA'
FROM VDPI
WHERE VDPI_VDPD = 124143

SELECT *
--UPDATE PRNC SET PRNC_MTPR = 'OSBA'
FROM PRNC
WHERE PRNC_NPAI = 124143

SELECT *
--UPDATE PROR SET PROR_MTPR = 'OSBA'
FROM PROR
WHERE PROR_PROJ LIKE '%124143%'
