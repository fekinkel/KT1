
drop table #new
drop table #c

declare
@c char(10),
@i int

set @i = 1
set @c = 'sistema'

select @c [grupo], identity(int,1,1) [NUM]
into #c

--select campo1 [GRUPO], campo4 [EMAIL], (@i*10)+num [NIVEL]
select campo1 [GRUPO], campo4 [EMAIL], @i [NIVEL], NUM
into #new
from aaaa, #c
where campo1 = grupo

print 'primeiro'
select * from #new

--select * from aaaa, #c where campo3=grupo and campo3 is not null

while (select count(1) from aaaa, #c where campo3=grupo and campo3 is not null)>0 begin
	set @i=@i+1
	print 'Antes:='
	select * from #c
	
	
	select campo1
	into #d
	from aaaa a, #c
	where a.campo3 = grupo
	
	delete #c
	insert into #c
	select *
	from #d
	
	drop table #d
	print 'Depois:= '
	select * from #c
	
	insert into #new
	--select campo1 , campo4, (@i*10)+num
	select campo1 , campo4, @i, num
	from aaaa, #c
	where campo1 = grupo
				and campo5 = 0
end			

select *
from #new
order by nivel