if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
DELETE 
FROM CPCT

delete
from CPSC

delete
from CPPC

delete
from PRNC

delete
from MTPC

delete 
from MTES

delete 
from MTEP

delete 
from MTPR

DELETE
FROM MTTP

delete
from NFOP

delete
from MTTR

delete
from MTAL

delete 
from MTTA

delete 
from MTAP

delete
from GLMC

delete 
from CTPC
