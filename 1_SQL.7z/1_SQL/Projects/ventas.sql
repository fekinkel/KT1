DROP TABLE #VDICSELECT *, IDENTITY(INT,1,1) num INTO #VDIC FROM VDIC WHERE 1 = 0INSERT INTO #VDICSELECT 		VDIC_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') E
	, VDIC_SIDO = CONVERT(varchar(4),'VDCO')      --CONVERT(varchar(4),'') Tipo
	, VDIC_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, VDIC_VDCO = CONVERT(int,'74')      --CONVERT(int(6),'') Cota��o
	, VDIC_COD = CONVERT(int,'1')      --CONVERT(int(3),'') Item
	, VDIC_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, VDIC_NOM = CONVERT(varchar(255),MTPC_NOM)      --CONVERT(varchar(255),'') Descri��o
	, VDIC_MTPR = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, VDIC_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, VDIC_MTUN = CONVERT(varchar(3),MTPR_MTUN)      --CONVERT(varchar(3),'') Unidade
	, VDIC_MTNC = CONVERT(varchar(8),'73202090')      --CONVERT(varchar(8),'') NCM
	, VDIC_ORI = CONVERT(char(1),'1')      --CONVERT(char(1),'') Origem
	, VDIC_MTDV = CONVERT(varchar(4),MTPR_MTDV)      --CONVERT(varchar(4),'') Divis�o
	, VDIC_MTLN = CONVERT(varchar(4),MTPR_MTLN)      --CONVERT(varchar(4),'') Linha
	, VDIC_MTFM = CONVERT(varchar(4),MTPR_MTFM)      --CONVERT(varchar(4),'') Fam�lia
	, VDIC_PLIQ = Null      --CONVERT(decimal(13),'') Peso L�q.
	, VDIC_PLQT = Null      --CONVERT(decimal(13),'') Peso Tot.
	, VDIC_PBRT = Null      --CONVERT(decimal(13),'') Peso Bruto
	, VDIC_COMPO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Composto
	, VDIC_EST = CONVERT(char(1),'S')      --CONVERT(char(1),'') Estoque
	, VDIC_QTD = 1      --CONVERT(decimal(12),'') Quantidade
	, VDIC_PUN = CONVERT(decimal(12,2),MTPC_PRE)      --CONVERT(decimal(12),'') Pre�o
	, VDIC_PUND = CONVERT(decimal(12,2),MTPC_PRE)      --CONVERT(decimal(12),'') Pre�o c/ Desc.
	, VDIC_DESC = 0.00      --CONVERT(decimal(9),'') Desconto %
	, VDIC_VAL = 0.00      --CONVERT(decimal(12),'') Total
	, VDIC_PENT = 1      --CONVERT(int(3),'') Entrega (dias)
	, VDIC_OBS = Null      --CONVERT(varchar(4000),'') Obs.
	, VDIC_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, VDIC_NFOP = CONVERT(varchar(8),'6.4101')      --CONVERT(varchar(8),'') Oper.
	, VDIC_CFOP = CONVERT(varchar(8),'6.4101')      --CONVERT(varchar(6),'') CFOP
	, VDIC_TIT = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera t�tulos
	, VDIC_MEN = Null      --CONVERT(varchar(255),'') Mensagem
	, VDIC_VAL_FRE = 0.00      --CONVERT(decimal(12),'') Frete
	, VDIC_VAL_SEG = 0.00      --CONVERT(decimal(12),'') Seguro
	, VDIC_VAL_ACE = 0.00      --CONVERT(decimal(12),'') Desp. Acess�rias
	, VDIC_VAL_DES = 0.00      --CONVERT(decimal(12),'') Descontos
	, VDIC_IPI_BAS = MTPC_PRE      --CONVERT(decimal(12),'') Base IPI
	, VDIC_IPI_ALI = 16.00      --CONVERT(decimal(5),'') % IPI
	, VDIC_IPI_VAL = MTPC_PRE*16.00/100      --CONVERT(decimal(12),'') Valor IPI
	, VDIC_IPI_ISE = 0.00      --CONVERT(decimal(12),'') IPI Isento
	, VDIC_IPI_OUT = 0.00      --CONVERT(decimal(12),'') IPI Outros
	, VDIC_ISS_BAS = 0.00      --CONVERT(decimal(12),'') Base de ISS
	, VDIC_ISS_ALI = 0.00      --CONVERT(decimal(5),'') % ISS
	, VDIC_ISS_VAL = 0.00      --CONVERT(decimal(12),'') Valor do ISS
	, VDIC_ISS_ISE = 0.00      --CONVERT(decimal(12),'') ISS Isento
	, VDIC_ISS_OUT = 0.00      --CONVERT(decimal(12),'') ISS Outros
	, VDIC_ICM_BAS = 0.00      --CONVERT(decimal(12),'') Base ICMS
	, VDIC_ICM_ALI = 0.00      --CONVERT(decimal(5),'') % ICMS
	, VDIC_ICM_VAL = 0.00      --CONVERT(decimal(12),'') Valor do ICMS
	, VDIC_ICM_ISE = 0.00      --CONVERT(decimal(12),'') ICMS Isento
	, VDIC_ICM_OUT = 0.00      --CONVERT(decimal(12),'') ICMS Outros
	, VDIC_IST_BAS = 0.00      --CONVERT(decimal(12),'') Base ICMS - ST
	, VDIC_IST_ALI = 0.00      --CONVERT(decimal(5),'') % ICMS - ST
	, VDIC_IST_VAL = 0.00      --CONVERT(decimal(12),'') Valor do ICMS - ST
	, VDIC_IST_ISE = 0.00      --CONVERT(decimal(12),'') ICMS Isento - ST
	, VDIC_IST_OUT = 0.00      --CONVERT(decimal(12),'') ICMS Outros - ST
	, VDIC_IST_IVA = 0.00      --CONVERT(decimal(12),'') ST- IVA %
	, VDIC_ICP_ALI = 0.00      --CONVERT(decimal(6),'') %ICMS Complem.
	, VDIC_ICP_VAL = 0.00      --CONVERT(decimal(12),'') Valor ICMS Complem.
	, VDIC_MTTR = 'SAIFAT'      --CONVERT(varchar(6),'') Transa��o
	, VDIC_CTPC = '4101010001'      --CONVERT(varchar(15),'') Cont�bil
	, VDIC_RDPC = '4101'      --CONVERT(varchar(7),'') Rdz.
	, VDIC_CTCC = Null      --CONVERT(varchar(15),'') C.C.
	, VDIC_RDCC = Null      --CONVERT(varchar(7),'') Rdz.
	, VDIC_VDCV = Null      --CONVERT(int(6),'') Contrato
	, VDIC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDIC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDIC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDIC_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM MTPC, MTPRwhere MTPC_COD like 'S%'
			AND MTPC_MTPR = MTPR_CODINSERT INTO VDICSELECT VDIC_SIES ,VDIC_SIDO ,VDIC_SISE ,VDIC_VDCO ,num ,VDIC_MTPC ,VDIC_NOM ,VDIC_MTPR ,VDIC_MS ,VDIC_MTUN ,VDIC_MTNC ,VDIC_ORI ,VDIC_MTDV ,VDIC_MTLN ,VDIC_MTFM ,VDIC_PLIQ ,VDIC_PLQT ,VDIC_PBRT ,VDIC_COMPO ,VDIC_EST ,VDIC_QTD ,VDIC_PUN ,VDIC_PUND ,VDIC_DESC ,VDIC_VAL ,VDIC_PENT ,VDIC_OBS ,VDIC_REV ,VDIC_NFOP ,VDIC_CFOP ,VDIC_TIT ,VDIC_MEN ,VDIC_VAL_FRE ,VDIC_VAL_SEG ,VDIC_VAL_ACE ,VDIC_VAL_DES ,VDIC_IPI_BAS ,VDIC_IPI_ALI ,VDIC_IPI_VAL ,VDIC_IPI_ISE ,VDIC_IPI_OUT ,VDIC_ISS_BAS ,VDIC_ISS_ALI ,VDIC_ISS_VAL ,VDIC_ISS_ISE ,VDIC_ISS_OUT ,VDIC_ICM_BAS ,VDIC_ICM_ALI ,VDIC_ICM_VAL ,VDIC_ICM_ISE ,VDIC_ICM_OUT ,VDIC_IST_BAS ,VDIC_IST_ALI ,VDIC_IST_VAL ,VDIC_IST_ISE ,VDIC_IST_OUT ,VDIC_IST_IVA ,VDIC_ICP_ALI ,VDIC_ICP_VAL ,VDIC_MTTR ,VDIC_CTPC ,VDIC_RDPC ,VDIC_CTCC ,VDIC_RDCC ,VDIC_VDCV ,VDIC_USC ,VDIC_DTC ,VDIC_USU ,VDIC_DTUFROM #VDICWHERE CONVERT(VARCHAR(6),VDIC_SIES)+'/'+VDIC_SIDO+'/'+VDIC_SISE+'/'+CONVERT(VARCHAR(6),VDIC_VDCO)+'/'+CONVERT(VARCHAR(6),num) NOT IN (SELECT CONVERT(VARCHAR(6),VDIC_SIES)+'/'+VDIC_SIDO+'/'+VDIC_SISE+'/'+CONVERT(VARCHAR(6),VDIC_VDCO)+'/'+CONVERT(VARCHAR(6),VDIC_cod) FROM VDIC)

select *
from VDic
where VDIC_VDCO = 74

