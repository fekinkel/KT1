declare
@vdco int,
@vdc1 int, 
@s varchar(10),
@obs varchar(255),
@val_new decimal(12,2),
@val_old decimal(12,2)

set @vdco = 202688
set @vdc1 = 1
select @val_old = 205.34


--select @val_old = 8.38--VDC1_PUNID, @val_new = replace(substring(replace(VDC1_OBS,'','0.0'),1,10),',','.')
--select @val_old = replace(substring(replace(rtrim(ltrim(VDC1_OBS)),'','0.0'),1,10),',','.')
select @s = substring(VDC1_OBS,1,charindex(',',vdc1_obs)+2), @obs = VDC1_OBS
from vdc1 
where vdc1_vdco = @vdco
			and VDC1_TIPO = 'OUTR'
			and VDC1_SUB  = 0
			and VDC1_COD  = @vdc1
			and len(VDC1_OBS)>0

set @val_old = replace(substring(replace(rtrim(ltrim(@s)),'','0.0'),1,10),',','.')
--------->> OR�AMOS A CAMISA COM � 40, VERIFIQUE SE ATENDE SUA NECESSIDADES <<-------
--print @obs

select @obs=REPLACE(@obs, @s,'')

--print @obs

--print @val_old

--select @val_old, VDC1_IPI_VAL, VDC1_IPI_ALI*@val_old*VDC1_QTDE/100, VDC1_IPI_BAS, @val_old*VDC1_QTDE, VDC1_QTDE, VDC1_PUNI, VDC1_PUNID, @val_old, @val_new
--update vdc1 set VDC1_IPI_BAS = @val_old*VDC1_QTDE, VDC1_OBS = '', VDC1_PUNI = @val_old, VDC1_PUNID = @val_old, VDC1_IPI_VAL =VDC1_IPI_ALI*@val_old*VDC1_QTDE/100
--update vdc1 set VDC1_IPI_BAS = @val_old*VDC1_QTDE, VDC1_OBS = '', VDC1_PUNID = @val_old, VDC1_IPI_VAL =VDC1_IPI_ALI*@val_old*VDC1_QTDE/100
update vdc1 set VDC1_IPI_BAS = @val_old*VDC1_QTDE, VDC1_OBS = @obs, VDC1_PUNID = @val_old, VDC1_IPI_VAL =VDC1_IPI_ALI*@val_old*VDC1_QTDE/100
from vdc1
where vdc1_vdco = @vdco
			and VDC1_TIPO = 'OUTR'
			and VDC1_SUB  = 0
			and VDC1_COD  = @vdc1

			