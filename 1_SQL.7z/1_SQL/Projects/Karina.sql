/*
select *
from CFBP, CFcp, RCNF
where CONVERT(char(10), CFBP_DAT, 102) >= '2011.01.01'
			and CONVERT(char(10), CFBP_DAT, 102) <= '2011.01.31'
			and CFBP_SIEX = cfcp_sies
			and CFBP_SIDX = cfcp_sido
			and CFBP_SISX = CFCP_sise
			and CFBP_NUMX = CFCP_COD
			and CFBP_SEQX = CFCP_seq
			and CFBP_SIEX = RCNF_SIES
			and CFBP_SIDX = RCNF_SIDO
			and CFBP_SISX = RCNF_SISE
			and CFBP_NUMX = RCNF_COD

--(365 linha(s) afetadas)
*/


--convert(char(1),CFCP_SIES)+'/'+CFCP_SIDO+'/'+CFCP_SISE+'/'+convert(varchar(6),CFCP_COD)+'/'+convert(varchar(3),CFCP_SEQ)

--opera�ao nr, parcela, data emissao, data vencimento, data da baixa, valor parcela, status, tipo de baixa, fornecedor 
select GLFO_COD, GLPA_NOM, char(39)+convert(char(8),RCNF_NFOP)[RCNF_NFOP], char(39)+convert(char(5),RCNF_CFOP) [RCNF_CFOP], convert(char(1),CFCP_SIES)+'/'+CFCP_SIDO+'/'+CFCP_SISE+'/'+convert(varchar(6),CFCP_COD)+'/'+convert(varchar(3),CFCP_SEQ), convert(char(10),CFCP_DAT,103)[EMISS�O], convert(char(10),CFCP_DTV,103) [VENCIMENTO], convert(char(10),CFBP_DAT,103)[BAIXA], CFCP_STA, CFBP_TOP, CONVERT(CHAR(70),CFBP_HIS) [CFBP_HIS], replace(CFCP_VAL,'.',',')[CFCP_VAL], replace(CFBP_VAL,'.',',')[CFBP_VAL]
from CFCP a, RCNF b, cfbp c, GLFO, GLPA
where CONVERT(char(10), CFBP_DAT, 102) >= '2011.01.01'
			and CONVERT(char(10), CFBP_DAT, 102) <= '2011.01.31'
			and CFBP_SIEX = cfcp_sies
			and CFBP_SIDX = cfcp_sido
			and CFBP_SISX = CFCP_sise
			and CFBP_NUMX = CFCP_COD
			and CFBP_SEQX = CFCP_seq
			and CFBP_SIEX = RCNF_SIES
			and CFBP_SIDX = RCNF_SIDO
			and CFBP_SISX = RCNF_SISE
			and CFBP_NUMX = RCNF_COD
			and CFCP_GLXX = GLFO_COD
			and GLFO_GLPA = GLPA_COD

/*
where CONVERT(char(10), CFBP_DAT, 102) >= '2011.01.01'
			and CONVERT(char(10), CFBP_DAT, 102) <= '2011.07.31'
			and CFCP_SIDO = 'rcnf'
			and CFCP_SIEX = RCNF_SIES
			and CFCP_SIDX = RCNF_SIDO
			and CFCP_SISX = RCNF_SISE
			and CFCP_NUMX = RCNF_CODX
			and CFCP_GLXX = RCNF_GLXX
			and CFCP_SIES = CFBP_SIEX
			and CFCP_SIDO = CFBP_SIDX
			and CFCP_SISE = CFBP_SISX
			and CFCP_COD = CFBP_NUMX
			and CFCP_SEQ  = CFBP_SEQX
			and CFCP_COD  = 9023--6640--9023
			and CFCP_GLXX = GLFO_COD
			and GLFO_GLPA = GLPA_COD
			--and CFCP_SEQX =
*/

order by CFCP_NEXT			
			
--select top 1 * from cfcp where /*CFbp_SIDO = 'rcnf' and*/ CFBP_CFCC = 214

--CFCP_SIES   CFCP_SIDO CFCP_SISE CFCP_COD    CFCP_SEQ    CFCP_DAT                CFCP_SIEX   CFCP_SIDX CFCP_SISX CFCP_NUMX   CFCP_SEQX   CFCP_NEXT                      CFCP_STA CFCP_GLXX   CFCP_GLXX_DIG CFCP_DTV                CFCP_GLMD CFCP_VTOT                               CFCP_VAL                                CFCP_VBX                                CFCP_GLPG CFCP_GLCC       CFCP_GLHP CFCP_HIS                                                                                                                                                                                                                                                        CFCP_PCC        CFCP_PCR CFCP_CTC        CFCP_CTR CFCP_USC        CFCP_DTC                CFCP_USU        CFCP_DTU                RCNF_SIES   RCNF_SIDO RCNF_SISE RCNF_COD    RCNF_ES RCNF_DAT                RCNF_DCA                RCNF_NFOP RCNF_CFOP RCNF_SIDX RCNF_SISX RCNF_CODX   RCNF_DATX               RCNF_SIDF RCNF_SISF RCNF_CODF   RCNF_SIDP RCNF_SISP RCNF_CODP   RCNF_STA RCNF_OBS                                           RCNF_GLTX RCNF_GLXX   RCNF_GLXX_DIG RCNF_GLPA   RCNF_GLXX_NOM                                      RCNF_GLPS_ORI RCNF_GLUF_ORI RCNF_GLPS_DES RCNF_GLUF_DES RCNF_PEDF            RCNF_GLMD RCNF_VMDA                               RCNF_GLCF RCNF_PCTCF                              RCNF_GLCP   RCNF_PCTCOM                             RCNF_GLPG RCNF_GLCC       RCNF_GLTR   RCNF_VIA RCNF_FRETE RCNF_PLACA RCNF_DTSAIDA            RCNF_QTDVOL                             RCNF_ESPECIE         RCNF_MARCA RCNF_NUMERA          RCNF_PESOLIQ                            RCNF_PESOBRT                            RCNF_MENS                                                                                                                                                                                                                                                       RCNF_QTD                                RCNF_VAL                                RCNF_VAL_TIT                            RCNF_VAL_MER                            RCNF_VAL_SER                            RCNF_VAL_FRE                            RCNF_VAL_SEG                            RCNF_VAL_ACE                            RCNF_VAL_DES                            RCNF_VAL_PIS                            RCNF_VAL_COF                            RCNF_VAL_CSS                            RCNF_VAL_INSS                           RCNF_VAL_IRRF                           RCNF_IPI_VAL                            RCNF_IPI_BAS                            RCNF_IPI_OUT                            RCNF_IPI_ISE                            RCNF_ISS_VAL                            RCNF_ISS_BAS                            RCNF_ISS_ISE                            RCNF_ISS_OUT                            RCNF_ICM_VAL                            RCNF_ICM_BAS                            RCNF_ICM_ISE                            RCNF_ICM_OUT                            RCNF_IST_BAS                            RCNF_IST_ALI                            RCNF_IST_VAL                            RCNF_IST_ISE                            RCNF_IST_OUT                            RCNF_IST_IVA                            RCNF_ICP_ALI                            RCNF_ICP_VAL                            RCNF_NLM    RCNF_CLM    RCNF_NLS    RCNF_CLS    RCNF_SIDY RCNF_SISY RCNF_CODY   RCNF_NFE_CHV                                 RCNF_NFE_STA RCNF_NFE_PRO    RCNF_NFE_DTP            RCNF_USC        RCNF_DTC                RCNF_USU        RCNF_DTU                CFBP_SIES   CFBP_SIDO CFBP_SISE CFBP_CFCC   CFBP_SEQ    CFBP_GLCC       CFBP_DAT                CFBP_SIEX   CFBP_SIDX CFBP_SISX CFBP_NUMX   CFBP_SEQX   CFBP_NEXT                      CFBP_STA CFBP_TOP CFBP_VAL                                CFBP_VALM                               CFBP_CXD CFBP_GLHP CFBP_HIS                                                                                                                                                                                                                                                        CFBP_PCC        CFBP_PCR CFBP_CTC        CFBP_CTR CFBP_USC        CFBP_DTC                CFBP_USU        CFBP_DTU

select CHAR(39)