declare
@i int,
@j int

set @i = 10
set @j = 10

While @i <= 9 begin
	select max(year(VDPI_DENT)) ANO, max(month(VDPI_DENT)) MES, VDPI_MTLN LINHA, '', replace(convert(decimal(10,2),sum(VDPI_QTD)),'.',',')QDE, replace(convert(decimal(12,2),sum(VDPI_VAL)),'.',',') VALOR, replace(sum(VDPI_PBRT),'.',',') PESO, max(mtln_nom) LINHA_NOME
	from vdpi, mtln, mtfm
	where vdpi_mtdv = 3500
				and vdpi_sta = 'ok'
				and year(VDPI_DENT) >= 2011
				and month(VDPI_DENT) = @i
				and mtln_mtdv = vdpi_mtdv
				and mtln_cod  = vdpi_mtln
				and mtfm_mtdv = vdpi_mtdv
				and mtfm_mtln = vdpi_mtln
				and mtfm_cod  = vdpi_mtfm
	group by vdpi_mtdv,year(VDPI_DENT), month(VDPI_DENT), VDPI_MTLN
	order by vdpi_mtdv,year(VDPI_DENT), month(VDPI_DENT), VDPI_MTLN

	select max(year(VDPI_DENT)) ANO, max(month(VDPI_DENT)) MES, VDPI_MTLN LINHA, VDPI_MTFM FAMILIA, replace(convert(decimal(10,2),sum(VDPI_QTD)),'.',',')QDE, replace(convert(decimal(12,2),sum(VDPI_VAL)),'.',',') VALOR, replace(sum(VDPI_PBRT),'.',',') PESO, max(mtln_nom) LINHA_NOME, max(mtfm_nom) FAMILIA_NOME
	from vdpi, mtln, mtfm
	where vdpi_mtdv = 3500
				and vdpi_sta = 'ok'
				and year(VDPI_DENT) >= 2011
				and month(VDPI_DENT) = @i
				and mtln_mtdv = vdpi_mtdv
				and mtln_cod  = vdpi_mtln
				and mtfm_mtdv = vdpi_mtdv
				and mtfm_mtln = vdpi_mtln
				and mtfm_cod  = vdpi_mtfm
	group by vdpi_mtdv,year(VDPI_DENT), month(VDPI_DENT), VDPI_MTLN, VDPI_MTFM
	order by vdpi_mtdv,year(VDPI_DENT), month(VDPI_DENT), VDPI_MTLN, VDPI_MTFM
	
	set @i = @i +1
end

select max(year(VDPI_DENT)) ANO, VDPI_MTLN LINHA, '', replace(convert(decimal(10,2),sum(VDPI_QTD)),'.',',')QDE, replace(convert(decimal(12,2),sum(VDPI_VAL)),'.',',') VALOR, replace(sum(VDPI_PBRT),'.',',') PESO, max(mtln_nom) LINHA_NOME
from vdpi, mtln, mtfm
where vdpi_mtdv = 3500
			and vdpi_sta = 'ok'
			and year(VDPI_DENT) >= 2011
			and month(VDPI_DENT) <= @j
			and mtln_mtdv = vdpi_mtdv
			and mtln_cod  = vdpi_mtln
			and mtfm_mtdv = vdpi_mtdv
			and mtfm_mtln = vdpi_mtln
			and mtfm_cod  = vdpi_mtfm
group by vdpi_mtdv,year(VDPI_DENT), VDPI_MTLN
order by vdpi_mtdv,year(VDPI_DENT), VDPI_MTLN

select max(year(VDPI_DENT)) ANO, VDPI_MTLN LINHA, VDPI_MTFM FAMILIA, replace(convert(decimal(10,2),sum(VDPI_QTD)),'.',',')QDE, replace(convert(decimal(12,2),sum(VDPI_VAL)),'.',',') VALOR, replace(sum(VDPI_PBRT),'.',',') PESO, max(mtln_nom) LINHA_NOME, max(mtfm_nom) FAMILIA_NOME
from vdpi, mtln, mtfm
where vdpi_mtdv = 3500
			and vdpi_sta = 'ok'
			and year(VDPI_DENT) >= 2011
			and month(VDPI_DENT) <= @j
			and mtln_mtdv = vdpi_mtdv
			and mtln_cod  = vdpi_mtln
			and mtfm_mtdv = vdpi_mtdv
			and mtfm_mtln = vdpi_mtln
			and mtfm_cod  = vdpi_mtfm
group by vdpi_mtdv,year(VDPI_DENT), VDPI_MTLN, VDPI_MTFM
order by vdpi_mtdv,year(VDPI_DENT), VDPI_MTLN, VDPI_MTFM
