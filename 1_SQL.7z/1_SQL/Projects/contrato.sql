--INSERT INTO VDCX
select 7 VDCX_VDCV, convert(varchar(20),[Codigo MDL]) VDCX_MTPC, 'S' VDCX_ATV , mtpc_nom+'('+convert(varchar(15),replace(Codigo,'a',''))+')' VDCX_MTPC_NOM, 'N' VDCX_PUN_MOD , 0.00 VDCX_PUN_VAL, 'REAL' VDCX_PUN_GLMD , 85.00 VDCX_PUN_PCT, 'N' VDCX_COM_TIPO, 00 VDCX_COM_PCT, 0 VDCX_QTD, 'KINKEL' VDCX_USC        ,getdate() VDCX_DTC                ,null VDCX_USU        ,null VDCX_DTU
from [DOS].[DBO].CONTRATO, mtpc
WHERE convert(varchar(20),[Codigo MDL]) NOT IN (SELECT VDCX_MTPC FROM VDCX WHERE VDCX_VDCV = 7 )
			and convert(varchar(20),[Codigo MDL]) = mtpc_cod
			

SELECT count(*), convert(varchar(20),[Codigo MDL]) 
FROM [DOS].[DBO].CONTRATO
group by convert(varchar(20),[Codigo MDL])
having count(*)>1

--WHERE convert(varchar(20),[Codigo MDL]) not IN (SELECT mtpc_cod from mtpc)

/*
INSERT INTO VDCX
select 5 VDCX_VDCV, MTPC_COD VDCX_MTPC, 'S' VDCX_ATV , MTPC_NOM VDCX_MTPC_NOM, 'N' VDCX_PUN_MOD , 0.00 VDCX_PUN_VAL, 'REAL' VDCX_PUN_GLMD , 85.00 VDCX_PUN_PCT, 'N' VDCX_COM_TIPO, 00 VDCX_COM_PCT, 0 VDCX_QTD, 'KINKEL' VDCX_USC        ,getdate() VDCX_DTC                ,null VDCX_USU        ,null VDCX_DTU
from mtpc
WHERE MTPC_COD LIKE '9-%'
			AND MTPC_COD NOT IN (SELECT VDCX_MTPC FROM VDCX WHERE VDCX_VDCV = 5 )
			
			
SELECT *
--DELETE vdcx
FROM vdcx
where VDCX_VDCV =  7 			
*/

