--select * from GLPA
select * from GLCL, GLPA
where GLCL_GLPA = GLPA_COD

--GLCR_GLCL   GLCR_GLLC GLCR_STA GLCR_MEN                                                                                                                                                                                                                                                       GLCR_PED                                GLCR_TIT                                GLCR_ADT                                GLCR_PRI_VAL                            GLCR_PRI_DAT            GLCR_ULT_VAL                            GLCR_ULT_DAT            GLCR_MAI_VAL                            GLCR_MAI_DAT            GLCR_ACU_VAL                            GLCR_ACU_DAT            GLCR_DP00   GLCR_VP00                               GLCR_DP05   GLCR_VP05                               GLCR_DP15   GLCR_VP15                               GLCR_DP30   GLCR_VP30                               GLCR_DP60   GLCR_VP60                               GLCR_DPAC   GLCR_VPAC                               GLCR_DPNP   GLCR_DPAM   GLCR_USC        GLCR_DTC                GLCR_USU        GLCR_DTU
------------- --------- -------- -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- --------------------------------------- ----------------------- --------------------------------------- ----------------------- --------------------------------------- ----------------------- --------------------------------------- ----------------------- ----------- --------------------------------------- ----------- --------------------------------------- ----------- --------------------------------------- ----------- --------------------------------------- ----------- --------------------------------------- ----------- --------------------------------------- ----------- ----------- --------------- ----------------------- --------------- -----------------------
--2           00        OK                                                                                                                                                                                                                                                                      0.00                                    0.00                                    0.00                                    0.00                                    NULL                    0.00                                    NULL                    0.00                                    NULL                    0.00                                    NULL                    0           0.00                                    0           0.00                                    0           0.00                                    0           0.00                                    0           0.00                                    0           0.00                                    0           0           KINKEL          2011-10-31 14:02:56.113                 NULL

DROP TABLE #GLCRSELECT * INTO #GLCR FROM GLCR WHERE 1 = 0INSERT INTO #GLCRSELECT 		GLCR_GLCL = CONVERT(int,glcl_cod)      --CONVERT(int(6),'') C�digo
	, GLCR_GLLC = CONVERT(varchar(4),'00')      --CONVERT(varchar(4),'') Limite
	, GLCR_STA = CONVERT(varchar(4),'OK')      --CONVERT(varchar(4),'') Status de cr�dito
	, GLCR_MEN = Null      --CONVERT(varchar(254),'') Obs.
	, GLCR_PED = 0      --CONVERT(decimal(12),'') Pedidos
	, GLCR_TIT = 0      --CONVERT(decimal(12),'') T�tulos
	, GLCR_ADT = 0      --CONVERT(decimal(12),'') Adiantamentos
	, GLCR_PRI_VAL = 0      --CONVERT(decimal(12),'') Primeiro Faturamento
	, GLCR_PRI_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_ULT_VAL = 0      --CONVERT(decimal(12),'') �ltimo Faturamento
	, GLCR_ULT_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_MAI_VAL = 0      --CONVERT(decimal(12),'') Maior Faturamento
	, GLCR_MAI_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_ACU_VAL = 0      --CONVERT(decimal(12),'') Maior ac�mulo
	, GLCR_ACU_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_DP00 = 0      --CONVERT(int(3),'') Em dia
	, GLCR_VP00 = 0      --CONVERT(decimal(14),'') Total dos Pagtos.
	, GLCR_DP05 = 0      --CONVERT(int(3),'') At� 5 dias
	, GLCR_VP05 = 0      --CONVERT(decimal(14),'') Valor at� 5 dias
	, GLCR_DP15 = 0      --CONVERT(int(3),'') At� 15 dias
	, GLCR_VP15 = 0      --CONVERT(decimal(14),'') Valor at� 15 dias
	, GLCR_DP30 = 0      --CONVERT(int(3),'') At� 30 dias
	, GLCR_VP30 = 0      --CONVERT(decimal(14),'') Valor at� 30 dias
	, GLCR_DP60 = 0      --CONVERT(int(3),'') At� 60 dias
	, GLCR_VP60 = 0      --CONVERT(decimal(14),'') Valor at� 60 dias
	, GLCR_DPAC = 0      --CONVERT(int(3),'') Acima de 60 dias
	, GLCR_VPAC = 0      --CONVERT(decimal(14),'') Valor acima 60 dias
	, GLCR_DPNP = 0      --CONVERT(int(3),'') N�o pagas
	, GLCR_DPAM = 0      --CONVERT(int(3),'') Atraso m�dio (dias)
	, GLCR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLCR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLCR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLCR_DTU = Null      --CONVERT(datetime(10),'') Em

FROM GLCLINSERT INTO GLCRSELECT *FROM #GLCRWHERE GLCR_GLCL NOT IN (SELECT GLCR_GLCL FROM GLCR)
