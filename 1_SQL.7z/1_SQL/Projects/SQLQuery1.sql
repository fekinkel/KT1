select *
from glfo
where glfo_cod = 32446