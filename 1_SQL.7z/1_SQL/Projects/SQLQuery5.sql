select *
from exli
