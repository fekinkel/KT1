drop table #new

select tipo NEW , SIOI_SIOP
into #new
from [DOS].[dbo].SIOI_New
--where SIOI_SIOP like '%PAISES%' --and SIOI_SIOP_New like '1.2.%'
where tipo <> ''
order by SIOI_SIOP

--select new, rtrim(NEW)+'F'+substring(b.SIOI_SIOP,len(b.SIOI_SIOP),1)+'.'
update [DOS].[dbo].SIOI_New set tipo = rtrim(NEW)+'F'+substring(b.SIOI_SIOP,len(b.SIOI_SIOP),1)+'.'
from #new a, [DOS].[dbo].SIOI_New b
where LEN(new)>=3
			and b.SIOI_SIOP like 'FRM'+substring(a.SIOI_SIOP,4,len(a.SIOI_SIOP)-3)+'F%' 
			and CHARINDEX('rel',a.SIOI_SIOP)<=0
			
			and SUBSTRING(a.SIOI_SIOP,2,1) not in ('.')

select *
from [DOS].[dbo].SIOI_New a
where SUBSTRING(a.SIOI_SIOP_New,2,1) not in ('.')

--select '%'+substring(a.SIOI_SIOP,4,len(a.SIOI_SIOP)-3)+'F%', * from #new a
