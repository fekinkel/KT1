
--exec [DOS].[dbo].opcao_menu 's2r', '8_vendas_geral', '8_vendas_lider'

--exec [DOS].[dbo].opcao_menu 's2r', '8_vendas_lider', ''

exec [DOS].[dbo].cria_menu_todos 'bkp'
--SIOI_SIOP = SIGO_SIOP

if exists (select name 
from [master].[dbo].sysdatabases
where name = 'MDL1') begin
	print 'Existe'
end else begin
	print 'N�O EXISTE'
end


	if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
		 create table [#iae] (par_erro varchar(255) )
	end
	insert into [bkp].[dbo].sigr
	SELECT 			SIGR_COD = UPPER(sigr_cod)      
		, SIGR_NOM = CONVERT(varchar(50),SIGR_NOM)
		, SIGR_ATV = CONVERT(char(1),'S')
		, SIGR_USC = 'KINKEL'     
		, SIGR_DTC = CONVERT(datetime,GETDATE())      
		, SIGR_USU = Null      
		, SIGR_DTU = Null      
	from [DOS].[DBO].sigr_new
	WHERE sigr_cod = '8_VENDAS_GERAL'
				and sigr_cod NOT IN (SELECT SIGR_COD FROM [bkp].[dbo].SIGR)

	insert into [bkp].[dbo].siga
	SELECT 			SIGA_SIGR = CONVERT(varchar(15),UPPER(SIGR_COD))
		, SIGA_SIAP = CONVERT(varchar(6),UPPER('S2R')) 
		, SIGA_NOM = CONVERT(varchar(50),SIGR_NOM+'('+RTRIM(LTRIM(SIGR_COD))+'/'+RTRIM(LTRIM('S2R'))+')')
		, SIGA_USC = CONVERT(varchar(15),'KINKEL') 
		, SIGA_DTC = CONVERT(datetime,GETDATE())      
		, SIGA_USU = Null   
		, SIGA_DTU = Null   
	FROM [dOS].[dbo].sigr_new	WHERE sigr_cod = '8_VENDAS_GERAL'				and RTRIM(LTRIM(SIGR_COD))+'/'+RTRIM(LTRIM('S2R')) NOT IN (SELECT RTRIM(LTRIM(SIGA_SIGR))+'/'+RTRIM(LTRIM(SIGA_SIAP)) FROM [bkp].[dbo].SIGA)
	insert into [bkp].[dbo].SIGM	SELECT 			SIGM_SIGR = CONVERT(varchar(15),SIGO_SIGR) 
		, SIGM_SIAP = CONVERT(varchar(6),SIGO_SIAP)  
		, SIGM_SIMD = CONVERT(varchar(20),SIGO_SIMD) 
		, SIGM_USC = CONVERT(varchar(15),'KINKEL')   
		, SIGM_DTC = CONVERT(datetime,GETDATE())     
		, SIGM_USU = Null      --CONVERT(varchar(15),') Alterado por
		, SIGM_DTU = Null      --CONVERT(datetime(10),') Em
	FROM [DOS].[dbo].sigo_new	WHERE RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD)) NOT IN (SELECT RTRIM(LTRIM(SIGM_SIGR))+'/'+RTRIM(LTRIM(SIGM_SIAP))+'/'+RTRIM(LTRIM(SIGM_SIMD)) FROM [bkp].[dbo].SIGM)	GROUP BY sigo_sigr, SIGO_SIAP, SIGO_SIMD
	delete from [bkp].[dbo].SIGO	insert into [bkp].[dbo].sigo	SELECT 			SIGO_SIGR = CONVERT(varchar(15),SIGO_SIGR)
		, SIGO_SIAP = CONVERT(varchar(6),SIGO_SIAP) 
		, SIGO_SIMD = CONVERT(varchar(20),SIGO_SIMD)
		, SIGO_SIOP = CONVERT(varchar(50),SIGO_SIOP)
		, SIGO_USC = CONVERT(varchar(15),'KINKEL')  
		, SIGO_DTC = CONVERT(datetime,GETDATE())    
		, SIGO_USU = Null
		, SIGO_DTU = Null
	FROM [DOS].[dbo].sigo_new	WHERE RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD))+'/'+RTRIM(LTRIM(SIGO_SIOP)) NOT IN (SELECT RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD))+'/'+RTRIM(LTRIM(SIGO_SIOP)) FROM [bkp].[dbo].SIGO)