if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

insert into sigr
SELECT 		SIGR_COD = UPPER(sigo_sigr)      --CONVERT(varchar(15),'') Grupo
	, SIGR_NOM = CONVERT(varchar(50),SIGR_NOM)      --CONVERT(varchar(50),'') Descri��o
	, SIGR_ATV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Ativo
	, SIGR_USC = 'KINKEL'     --CONVERT(varchar(15),'') Cadastrado por
	, SIGR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIGR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIGR_DTU = Null      --CONVERT(datetime(10),'') Em
from [DOS].[DBO].sigo_new, [DOS].[DBO].sigr_new
WHERE sigr_cod = sigo_sigr
			and sigo_sigr NOT IN (SELECT SIGR_COD FROM SIGR)
GROUP BY sigo_sigr, SIGR_NOM

--select * from [dos].[dbo].sigr_new

insert into siga
SELECT 		SIGA_SIGR = CONVERT(varchar(15),UPPER(SIGO_SIGR))      --CONVERT(varchar(15),'') Grupo
	, SIGA_SIAP = CONVERT(varchar(6),UPPER(SIGO_SIAP))      --CONVERT(varchar(6),'') Aplicativo
	, SIGA_NOM = CONVERT(varchar(50),SIGR_NOM+'('+RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+')')      --CONVERT(varchar(50),'') Nome
	, SIGA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, SIGA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIGA_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIGA_DTU = Null      --CONVERT(datetime(10),'') Em
FROM [dOS].[dbo].sigo_new, [dOS].[dbo].sigr_newWHERE sigr_cod = sigo_sigr			and RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP)) NOT IN (SELECT RTRIM(LTRIM(SIGA_SIGR))+'/'+RTRIM(LTRIM(SIGA_SIAP)) FROM SIGA)GROUP BY sigo_sigr, SIGO_SIAP, SIGR_NOM
insert into SIGMSELECT 		SIGM_SIGR = CONVERT(varchar(15),SIGO_SIGR)      --CONVERT(varchar(15),'') Grupo
	, SIGM_SIAP = CONVERT(varchar(6),SIGO_SIAP)      --CONVERT(varchar(6),'') Aplicativo
	, SIGM_SIMD = CONVERT(varchar(20),SIGO_SIMD)      --CONVERT(varchar(20),'') M�dulo
	, SIGM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, SIGM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIGM_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIGM_DTU = Null      --CONVERT(datetime(10),'') Em
FROM [DOS].[dbo].sigo_newWHERE RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD)) NOT IN (SELECT RTRIM(LTRIM(SIGM_SIGR))+'/'+RTRIM(LTRIM(SIGM_SIAP))+'/'+RTRIM(LTRIM(SIGM_SIMD)) FROM SIGM)GROUP BY sigo_sigr, SIGO_SIAP, SIGO_SIMD
delete from SIGOinsert into sigoSELECT 		SIGO_SIGR = CONVERT(varchar(15),SIGO_SIGR)      --CONVERT(varchar(15),'') Grupo
	, SIGO_SIAP = CONVERT(varchar(6),SIGO_SIAP)      --CONVERT(varchar(6),'') Aplicativo
	, SIGO_SIMD = CONVERT(varchar(20),SIGO_SIMD)      --CONVERT(varchar(20),'') M�dulo
	, SIGO_SIOP = CONVERT(varchar(50),SIGO_SIOP)      --CONVERT(varchar(50),'') Op��o
	, SIGO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, SIGO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, SIGO_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, SIGO_DTU = Null      --CONVERT(datetime(10),'') Em
FROM [DOS].[dbo].sigo_newWHERE RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD))+'/'+RTRIM(LTRIM(SIGO_SIOP)) NOT IN (SELECT RTRIM(LTRIM(SIGO_SIGR))+'/'+RTRIM(LTRIM(SIGO_SIAP))+'/'+RTRIM(LTRIM(SIGO_SIMD))+'/'+RTRIM(LTRIM(SIGO_SIOP)) FROM SIGO)