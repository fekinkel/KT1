
exec [DOS].[dbo].opcao_menu 's2r', '8_vendas_geral', '8_vendas_lider'

exec [DOS].[dbo].opcao_menu 's2r', '8_vendas_lider', ''

exec [DOS].[dbo].cria_menu_todos 'bkp'
--SIOI_SIOP = SIGO_SIOP
use dos
declare 
@s varchar(10)

set @s = 'BKP'
use @s

use (select name
from [master].[dbo].sysdatabases
where name = @s)

select *
from [dos].[dbo].sigo_new

select *
from @s


exec grupo_filhos '8_VENDAS_GERAL', 0

if exists (select name 
from sysdatabases
where name = 'MDL1') begin
	print 'Existe'
end else begin
	print 'N�O EXISTE'
end

