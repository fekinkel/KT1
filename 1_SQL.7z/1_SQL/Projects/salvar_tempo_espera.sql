select top 1 *
from prop

select top 1 *
from prro

select PRRO_PROP, convert(varchar(3),replicate('0',3-len(Opera��o)))+convert(varchar(3),Opera��o), a.*--convert(varchar(3),replicate('0',3-len(Opera��o)))+convert(varchar(3),Opera��o), *
--update prro set PRRO_TESP = [Tempo de Espera padr�o]
from [dos].[dbo].espera a, prro b
where [Tempo de Espera padr�o] is not null
			and PRRO_PROP = convert(varchar(3),replicate('0',3-len(Opera��o)))+convert(varchar(3),Opera��o)