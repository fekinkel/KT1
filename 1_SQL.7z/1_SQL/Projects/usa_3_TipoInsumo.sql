

if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
--MTAL_SIES, MTAL_COD, MTAL_NOM, 
--MTAL_FISI, MTAL_VMRP, MTAL_SALC, MTAL_SUBL, MTAL_LOTC, MTAL_INV, 
--MTAL_STAT, MTAL_CTPC       MTAL_CTCC       MTAL_USC        MTAL_DTC                MTAL_USU        MTAL_DTU
--select * from MTAL
--ALMOXARIFADOS
insert into MTAL
select 1, 'NECESS', 'NECESSITY', 'N', 'N', 'N','N', 'N', 'N', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'OUTSUP', 'OUTSIDE SUPPLIERS', 'N', 'N', 'N','N', 'N', 'N', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'FIXASS', 'FIXED ASSET', 'N', 'N', 'S','N', 'N', 'N', 0, 515650, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'SUPPLI', 'SUPPLIERS', 'N', 'N', 'S','S', 'N', 'N', 0, 111300, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'MSTOCK', 'STOCK', 'S', 'S', 'S','N', 'N', 'S', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'CONPIO', 'CONSIGNATION PIONNER', 'N', 'N', 'S','N', 'N', 'N', 0, 111301, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'CONMFG', 'CONSIGNATION MFG', 'N', 'N', 'S','N', 'N', 'N', 0, 515700, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'BILLIN', 'BILLING', 'S', 'N', 'S','S', 'N', 'S', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'OUTCGS', 'CUSTO SALES', 'N', 'N', 'N','N', 'N', 'N', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, '??????', 'WITHOUT', 'N', 'N', 'N','N', 'N', 'N', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null
insert into MTAL
select 1, 'TRANSF', 'TRANSEFER', 'N', 'N', 'N','N', 'N', 'N', 0, NULL, NULL, 'KINKEL', GETDATE(), null, null

--SELECT * FROM MTTR
--MTTR_SIES, MTTR_COD, MTTR_NOM, MTTR_MTAL_ORI, MTTR_SUBL_ORI, MTTR_MTAL_DES, MTTR_SUBL_DES, MTTR_AUTO, MTTR_TRAN, MTTR_ACAO, 
--MTTR_DIRE, MTTR_VLIN, MTTR_UCIN, MTTR_ATUM, MTTR_SUCA, MTTR_MTAL_AUT, MTTR_GLHP, MTTR_CTPC_ORI, MTTR_CTCC_ORI,   
--MTTR_CTPC_DES, MTTR_CTCC_DES, MTTR_DTC, MTTR_USC, MTTR_DTU, MTTR_USU
--TRANSA��ES
INSERT INTO MTTR
SELECT 1, 'SUPPLI', 'SUPPLIERS', 'OUTSUP', 0, 'SUPPLI', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'RETSUP', 'RETURN SUPPLIERS', 'SUPPLI', 0, 'OUTSUP', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', NULL, NULL,NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL 
INSERT INTO MTTR
SELECT 1, 'RETCGS', 'RETURN SALES', 'OUTCGS', 0, 'MSTOCK', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'MSTPIO', 'CONSIGNATION', 'MSTOCK', 0, 'CONPIO', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'MSTMFG', 'CONSIGNATION', 'MSTOCK', 0, 'CONMFG', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'GIRKIT', 'ORDEM EXPRESS KIT', 'MSTOCK', 0, 'MSTOCK', 0, 'N', 'N', 'N', 'N', 'N','N', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'RECNEC', 'RECEIVING NECESITY', 'MSTOCK', 0, 'BILLIN', 1, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', NULL, NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'INVOUT', 'BILLINN', 'BILLIN', 0, 'OUTCGS', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'OUTPIO', 'OUT CONSIGNATION PIO', 'CONPIO', 0, 'OUTCGS', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'OUTMFG', 'OUT CONSIGNATION MFG', 'CONMFG', 0, 'OUTCGS', 0, 'N', 'N', 'S', 'S', 'S','S', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'AJUENT', 'AJUSTE DE ENTRADA', 'OUTSUP', 0, '??????', 0, 'N', 'N', 'N', 'N', 'N','N', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL
INSERT INTO MTTR
SELECT 1, 'AJUSAI', 'AJUSTE DE SAIDA', '??????', 0, 'OUTSUP', 0, 'N', 'N', 'N', 'N', 'N','N', 'N', 'N', 'NECESS', NULL, NULL,NULL,NULL,NULL, GETDATE(), 'KINKEL',NULL,NULL

select MTTP_COD, MTTP_NOM, MTTP_MS, MTTP_INV, MTTP_ESTR, MTTP_CPTE, MTTP_ORDE, MTTP_CTPC, MTTP_CTCC, MTTP_ATVV, MTTP_CFOV, MTTP_ATVC, MTTP_CFOC, MTTP_CTRI, MTTP_CPO1, MTTP_CPO2, MTTP_CPO3, MTTP_CPO4, null MTTP_SPED, 'KINKEL' MTTP_USC, getdate() MTTP_DTC, null MTTP_USU, null MTTP_DTU
from mttp

--TIPO DE INSUMO
INSERT INTO MTTP
select	'AT/FIXC', 'SUPPLIERS FIXED ASSET',								'M', 'N' , 'N' , 'N' , 'S' , '212032', null , 'N' , NULL ,		 'S' , '1.1651',			'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'FR/CARR', 'FRETES E CARRETOS',										'M', 'N' , 'N' , 'N' , 'S' , '515025', null , 'N' , NULL ,		 'S' , '1.4175',			'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'MP/EMBL', 'MATERIA PRIMA EMBALAGEM COM ESTOQUE', 'M', 'S' , 'N' , 'S' , 'S' , '444552', null , 'N' , NULL ,		 'S' , '1.4550' , 'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'MP/EMBS', 'MATERIA PRIMA EMBALAGEM SEM ESTOQUE', 'M', 'N' , 'N' , 'N' , 'S' , '444552', null , 'N' , NULL ,		 'S' , '1.4550' , 'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'MT/CONS', 'consigna��o',													'M', 'N' , 'V' , 'N' , 'S' , '516175', null , 'S' , '5.4025' , 'S' , '1.4550' , 'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'MT/DIVS', 'MATERIAL DIVERSOS',										'M', 'N' , 'N' , 'S' , 'S' , '516175', null , 'S' , '5.4025' , 'S' , '1.1651' , 'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'PA/COMP', 'PRODUTO ACABADO COMPRADO',						'M', 'S' , 'N' , 'S' , 'S' , '111325', null , 'S' , '5.4025' , 'S' , '1.4550' , 'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 
INSERT INTO MTTP
select	'PI/COMP', 'PRODUTO INTERMEDIARIO',								'M', 'S' , 'S' , 'S' , 'S' , '111325', null , 'S' , '5.4025' , 'S' , '1.4550' , 'N' , 'NA', 0 , NULL , NULL , null , 'KINKEL' , getdate(), null , null 

--SELECT * FROM MTTP


--MTAP_COD   MTAP_NOM  MTAP_MS MTAP_ENEC MTAP_REV MTAP_PCFO MTAP_USC        MTAP_USU        MTAP_DTC                MTAP_DTU
--APLICA��O
INSERT INTO MTAP
SELECT 'ATIVFIX','SUPPLIERS FIXED ASSET', 'M', 2, 'N', NULL, 'KINKEL', NULL, GETDATE(), NULL
INSERT INTO MTAP
SELECT 'DESPESA','DESPESAS', 'M', 2, 'N', NULL, 'KINKEL', NULL, GETDATE(), NULL
INSERT INTO MTAP
SELECT 'SERVICE','SERVICE', 'S', 2, 'N', NULL, 'KINKEL', NULL, GETDATE(), NULL
INSERT INTO MTAP
SELECT 'STOCK', 'STOCK', 'M', 0, 'S', NULL, 'KINKEL', NULL, GETDATE(), NULL
--INSERT INTO MTAP
--SELECT 'ATVFIX', 'SUPPLIERS FIXED ASSET', 'M', 2, 'N', NULL, 'KINKEL', NULL, GETDATE(), NULL
--SELECT * FROM MTAP
--MTTA_MTTP                 MTTA_MTAP  MTTA_DEFA MTTA_USC        MTTA_DTC                MTTA_USU        MTTA_DTU
--APLICA��O POR TIPO
INSERT INTO MTTA
SELECT 'AT/FIXC', 'ATIVFIX','S', 'KINKEL', GETDATE(), NULL, NULL
INSERT INTO MTTA
SELECT 'MT/DIVS','DESPESA', 'S', 'KINKEL', GETDATE(), NULL, NULL
INSERT INTO MTTA
SELECT 'Pi/COMP','SERVICE', 'S', 'KINKEL', GETDATE(), NULL, NULL
INSERT INTO MTTA
SELECT 'PA/COMP', 'STOCK', 'S', 'KINKEL', GETDATE(), NULL, NULL
--INSERT INTO MTAP
--SELECT 'ATVFIX', 'SUPPLIERS FIXED ASSET', 'M', 2, 'N', NULL, 'KINKEL', NULL, GETDATE(), NULL

select *
from MTTA

