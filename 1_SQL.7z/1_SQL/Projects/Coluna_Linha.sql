/*
CREATE TABLE tblClientes (
    IDCliente INT IDENTITY(1,1),
    NomeCliente VARCHAR(80))

CREATE TABLE tblPedidos (
    IDPedido INT IDENTITY(1,1),
    IDCliente INT,
    DataPedido SMALLDATETIME)

--� Cria as constraints
ALTER TABLE tblClientes ADD CONSTRAINT PK_Clientes PRIMARY KEY (IDCliente)
ALTER TABLE tblPedidos ADD CONSTRAINT PK_Pedidos PRIMARY KEY (IDPedido)
ALTER TABLE tblPedidos ADD CONSTRAINT FK_Clientes_Pedidos
FOREIGN KEY (IDCliente) REFERENCES tblClientes (IDCliente)

--� Insere clientes
INSERT INTO tblClientes (NomeCliente) VALUES ('Amanda')
INSERT INTO tblClientes (NomeCliente) VALUES ('Ivone')
INSERT INTO tblClientes (NomeCliente) VALUES ('Regiane')
INSERT INTO tblClientes (NomeCliente) VALUES ('Mariana')

--� Insere pedidos para o cliente 1
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080115')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080328')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080406')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080410')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080523')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080524')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080712')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080812')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080818')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (1,'20080828')

--� Insere pedidos para o cliente 2
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080411')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080417')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080422')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080430')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080711')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080901')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080903')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080907')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (2,'20080914')

--� Insere pedidos para o cliente 3
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080122')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080408')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080502')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080510')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080519')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080702')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080703')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080712')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080713')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080718')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080723')
INSERT INTO tblPedidos (IDCliente, DataPedido) VALUES (3,'20080729') 
*/

SELECT convert(varchar(20),NomeCliente) AS Cliente,
--� Vendas de Janeiro
(SELECT COUNT(*) FROM tblPedidos AS P WHERE C.IdCliente = P.IdCliente
AND YEAR(DataPedido)=2008 AND MONTH(DataPedido)=1) AS [01/2008],
--� Vendas de Fevereiro
(SELECT COUNT(*) FROM tblPedidos AS P WHERE C.IdCliente = P.IdCliente
AND YEAR(DataPedido)=2008 AND MONTH(DataPedido)=2) AS [02/2008],
--� Vendas de Setembro
(SELECT COUNT(*) FROM tblPedidos AS P WHERE C.IdCliente = P.IdCliente
AND YEAR(DataPedido)=2008 AND MONTH(DataPedido)=9) AS [09/2008]
FROM tblClientes AS C 

drop view vPedidos

select * from tblClientes

select * from tblPedidos

CREATE VIEW vPedidos (IDPedido, NomeCliente, Mes, Ano)
AS
SELECT
    IDPedido, NomeCliente, MONTH(DataPedido), YEAR(DataPedido)
FROM tblClientes C LEFT JOIN tblPedidos P
    ON C.IdCliente = P.IdCliente
    
SELECT convert(varchar(20),NomeCliente) AS Cliente, [1], [2], [3], [4]
FROM
(SELECT NomeCliente, IDPedido, Mes
    FROM vPedidos) AS TBO
PIVOT
(COUNT(IDPedido) FOR Mes IN ([1], [2], [3], [4])) AS TPVT

SELECT convert(varchar(20),NomeCliente) AS Cliente, [200801], [200802], [200803], [200804]
FROM
(SELECT NomeCliente, IDPedido [id], Periodo
    FROM vPedidos) AS TBO
PIVOT
--(COUNT(IDPedido) FOR Periodo IN ([200801], [200802], [200803],[200804])) AS TPVT
(COUNT(ID) FOR Periodo IN ([200801], [200802], [200803],[200804])) AS TPVT

ALTER VIEW vPedidos (IDPedido, NomeCliente, Periodo)
AS
SELECT
    IDPedido, NomeCliente, YEAR(DataPedido) * 100 + MONTH(DataPedido)
FROM tblClientes C LEFT JOIN tblPedidos P
    ON C.IdCliente = P.IdCliente
GO
    
SELECT convert(varchar(20),NomeCliente) AS Cliente, [200801], [200802], [200803], [200804]
FROM
(SELECT NomeCliente, IDPedido, Periodo
    FROM vPedidos) AS TBO
PIVOT
(COUNT(IDPedido) FOR Periodo IN ([200801], [200802], [200803],[200804])) AS TPVT
    

DECLARE @menorPeriodo INT, @maiorPeriodo INT, @Periodos VARCHAR(500)

--� Captura os per�odos e inicializa as vari�veis
SELECT @menorPeriodo = MIN(Periodo), @maiorPeriodo = MAX(Periodo),
@Periodos = '' FROM vPedidos

--� Montagem dos per�odos
WHILE @menorPeriodo <= @maiorPeriodo
BEGIN
    SET @Periodos = @Periodos + '[' + CAST(@menorPeriodo AS CHAR(6)) + '],'
    SET @menorPeriodo = @menorPeriodo + 1
END 
    
--� Exibe os per�odos
SET @Periodos = LEFT(@Periodos,LEN(@Periodos)-1)
PRINT @Periodos    

ALTER VIEW vPedidos (IDPedido, NomeCliente, Periodo)
AS
SELECT
    IDPedido, NomeCliente, RIGHT(CONVERT(CHAR(10),DataPedido,103),7)
FROM tblClientes C LEFT JOIN tblPedidos P
    ON C.IdCliente = P.IdCliente
GO

DECLARE @menorPeriodo SMALLDATETIME, @maiorPeriodo SMALLDATETIME, @Periodos VARCHAR(500)

--� Captura os per�odos e inicializa as vari�veis
SELECT @menorPeriodo = MIN(DataPedido), @maiorPeriodo = MAX(DataPedido),
@Periodos = '' FROM tblPedidos

--� Retira os dias das respectivas datas
SET @menorPeriodo = DATEADD(D,-DAY(@menorPeriodo)+1,@menorPeriodo)
SET @maiorPeriodo = DATEADD(D,-DAY(@maiorPeriodo)+1,@maiorPeriodo)

--� Montagem dos per�odos
WHILE @menorPeriodo <= @maiorPeriodo
BEGIN
    --� Captura o m�s e o dia
    SET @Periodos = @Periodos + '[' + RIGHT(CONVERT(CHAR(10),@menorPeriodo,103),7) + '],'

    --� Adiciona um m�s ao menor per�odo
    SET @menorPeriodo = DATEADD(M,1,@menorPeriodo)
END

--� Exibe os per�odos
SET @Periodos = LEFT(@Periodos,LEN(@Periodos)-1)

PRINT @Periodos 



DECLARE @menorPeriodo SMALLDATETIME, @maiorPeriodo SMALLDATETIME,
@Periodos VARCHAR(500), @cmdSQL VARCHAR(1000)

--� Captura os per�odos e inicializa as vari�veis
SELECT @menorPeriodo = MIN(DataPedido), @maiorPeriodo = MAX(DataPedido),
@Periodos = '' FROM tblPedidos

--� Inicializa a vari�vel @cmdSQL com a montagem do PIVOT
--� O caract�r ? ser� substitu�do pelo per�odo obtido dinamicamente
SET @cmdSQL = 'SELECT convert(varchar(20),NomeCliente) [Cliente/Periodo], ?
FROM
(SELECT NomeCliente, IDPedido, Periodo
    FROM vPedidos) AS TBO
PIVOT
(COUNT(IDPedido) FOR Periodo IN (?)) AS TPVT'

--� Retira os dias das respectivas datas
SET @menorPeriodo = DATEADD(D,-DAY(@menorPeriodo)+1,@menorPeriodo)
SET @maiorPeriodo = DATEADD(D,-DAY(@maiorPeriodo)+1,@maiorPeriodo)

--� Montagem dos per�odos
WHILE @menorPeriodo <= @maiorPeriodo
BEGIN
    --� Captura o m�s e o dia
    SET @Periodos = @Periodos + '[' + RIGHT(CONVERT(CHAR(10),@menorPeriodo,103),7) + '],'

    --� Adiciona um m�s ao menor per�odo
    SET @menorPeriodo = DATEADD(M,1,@menorPeriodo)
END

--� Monta os per�odos
SET @Periodos = LEFT(@Periodos,LEN(@Periodos)-1)

--� Substitui o ? pelo per�odo montado dinamicamente
SET @cmdSQL = REPLACE(@cmdSQL,'?',@Periodos)

--� Executa o comando, opcionalmente d� um PRINT
--PRINT @cmdSQL
EXEC (@cmdSQL)
