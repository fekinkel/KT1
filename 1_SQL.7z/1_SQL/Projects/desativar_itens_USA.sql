select SUBSTRING(mtpc_cod,1,3)
--update mtpr set MTPR_ATVV = 'S', mtpr_dtu = getdate(), mtpr_usu = 'KINKEL'
from MTPC, MTPR
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'N'
			and SUBSTRING(mtpc_cod,1,1) > 'a'
			--and SUBSTRING(mtpc_cod,1,1) = 'A'
			--and SUBSTRING(mtpc_cod,1,2) = 'B0'
			--and SUBSTRING(mtpc_cod,1,3) in ('B10', 'B12','b15','b17','b20','b22','b25','b27','b40','b42','b45','b72','ba0','bc5','bm5')
			--and SUBSTRING(mtpc_cod,1,2) = 'C0'
			--and SUBSTRING(mtpc_cod,1,3) in ('c15','c21','c22','c23','ca0','cep','cr5','cr7')
			--and SUBSTRING(mtpc_cod,1,3) in ('eb0','ep0')
			--and SUBSTRING(mtpc_cod,1,3) in ('g61','g65','g72','gb0','gen')
			--and SUBSTRING(mtpc_cod,1,3) in ('hb0','jb0','nb0')
			--and SUBSTRING(mtpc_cod,1,3) in ('p02','p10','p15','p20','p25','p35','pa0','pd5')
			--and SUBSTRING(mtpc_cod,1,3) in ('scf')
			--and SUBSTRING(mtpc_cod,1,3) in ('c21','c22','c23')
			and SUBSTRING(mtpc_cod,1,3) in ('jb0','nb0','hb0')
group by SUBSTRING(mtpc_cod,1,3)
order by SUBSTRING(mtpc_cod,1,3)

