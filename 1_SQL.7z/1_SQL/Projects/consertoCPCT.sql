select convert(decimal(12,2),MTNC_IPI), NFIA_PCT, CPCT_IPI_ALI, CPCT_ICM_ALI, a.*
--update cpct set CPCT_IPI_ALI = convert(decimal(12,2),MTNC_IPI), CPCT_ICM_ALI = NFIA_PCT
from cpct a, mtpr b, mtnc c, nfop d, nfia e
where CPCT_MTPR = mtpr_cod
			and MTPR_MTNC  = mtnc_cod
			and MTPR_CFOC = NFOP_COD
			and NFOP_ICM_TAB = NFIA_NFIC	
			and NFIA_GLUF_ORI = 'SP'
			and NFIA_GLUF_DES = 'SP'
			and cpct_sta  = 'OK'
			and (MTNC_IPI <> CPCT_IPI_ALI
			or NFIA_PCT <> CPCT_ICM_ALI)
			and substring(CPCT_MTPR,1,3) != 'GEN'