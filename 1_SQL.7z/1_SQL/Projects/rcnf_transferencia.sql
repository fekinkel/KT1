drop table #new

select *
into #new
--update rcnf set RCNF_GLXX = 31670, RCNF_GLXX_DIG = 1, RCNF_GLPA = 9861
from rcnf
where RCNF_GLXX = 31082
			and RCNF_SIES = 1
			and RCNF_NFOP like '1.15%'
			
select *
from glfo
where glfo_cod = 31670
			
select a.*
--update rcco set RCCO_CNPJ = '43299791000377', RCCO_IES = '432.024.460.119', RCCO_END = 'AV PRINK, 151 - MAIRINQUE', RCCO_CID = 'MAIRINQUE', RCCO_CEP = '18120000', RCCO_CNPJC = '43299791000377', RCCO_IESC = '432.024.460.119', RCCO_ENDC = 'AV PRINK, 151 - MAIRINQUE', RCCO_CIDC = 'MAIRINQUE', RCCO_CEPC = '18120000', RCCO_CNPJE = '43299791000377', RCCO_IESE = '432.024.460.119', RCCO_ENDE = 'AV PRINK, 151 - MAIRINQUE', RCCO_CIDE = 'MAIRINQUE', RCCO_CEPE = '18120000'
from rcco a, #new b
where RCCO_SIES = RCNF_SIES
			and RCCO_SIDO = RCnf_SIDO
			and RCCO_SISE = RCnf_SISE
			and RCCO_COD  = RCnf_COD