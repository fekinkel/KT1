select *
from [dos].[dbo].[lista_MTPC_20100802] 
where MDL_ref is null 

select *--substring(referencia,1,3)
--update [dos].[dbo].[lista_MTPC_20100802] set MDL_ref = mtpc_cod 
from [dos].[dbo].[lista_MTPC_20100802], mtpc
where (referencia like '%D' and substring(referencia,1,1)= 'S' and substring(referencia,1,len(referencia)-1) = mtpc_cod)
			--or (referencia = mtpc_cod and substring(referencia,1,1)!= 'S')
			or (referencia = replace(mtpc_cod, 'B21', 'B20') and substring(referencia,1,1)!= 'S')
--group by substring(referencia,1,3)