select *
--update cpsc set CPSC_MTAP = 'GASTOSPROD', CPSC_NFOP = '1.556.ZB', CPSC_REV = 'N' 
from cpsc
where cpsc_npai = 45860