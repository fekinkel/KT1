

--http://www.devmedia.com.br/articles/viewcomp.asp?comp=5292
--http://gustavomaiaaguiar.wordpress.com/2008/09/28/transformando-linhas-em-colunas-com-o-sql-server-2005/
drop table #coluna
drop table #linha
drop table ##new
drop table ##new1

declare
@i int,
@j int,
@k int,
@lin int,
@col int,
@aux int,
@cab varchar(100),
@rod varchar(100),
@s varchar(6),
@cod varchar(100),
@v varchar(500)

set @s = 'B21.'

select identity(int,1,1) NUM, substring(mtpr_cod, len(@s)+1, charindex('.', mtpr_cod, 4)-1) [COLUNA]
into #coluna
from mtpr
where substring(mtpr_cod, 1, charindex('.', mtpr_cod)) = @s
group by substring(mtpr_cod, len(@s)+1, charindex('.', mtpr_cod, 4)-1)
order by substring(mtpr_cod, len(@s)+1, charindex('.', mtpr_cod, 4)-1)

select identity(int,1,1) NUM, substring(mtpr_cod, charindex('.', mtpr_cod, 4)+len(@s)+1, 4) [LINHA]
into #linha
from mtpr
where substring(mtpr_cod, 1, charindex('.', mtpr_cod)) = @s
group by substring(mtpr_cod, charindex('.', mtpr_cod, 4)+len(@s)+1, 4)
order by substring(mtpr_cod, charindex('.', mtpr_cod, 4)+len(@s)+1, 4)

select * from #coluna
select @i = min(num), @j=max(num) from #coluna

--CREATE TABLE tblPedidos (IDPedido INT IDENTITY(1,1), IDCliente INT,  DataPedido SMALLDATETIME) 
set @aux = @i


set @v = 'CREATE TABLE ##new ('
While @i <= @j begin
	select @v=@v+char(34)+coluna+char(34) from #coluna where num = @i 
	set @v = @v + ' varchar(3), '
	set @i=@i+1
end
set @v = substring(@v,1,len(@v)-1)
set @v = @v+')'

print @v

exec(@v)

set @i = @aux

set @cab = 'SELECT '
While @i <= @j begin
	@v = @cab
	select @cod=coluna from #coluna where num = @i 
	set @v = @v +char(39)+@cod+char(39) + '['+@cod+'], '
	set @i=@i+1
end
set @v = substring(@v,1,len(@v)-1)
set @v = @v+' into ##new1'

print @v

exec(@v)

select * from [tempdb].[dbo].sysobjects a, [tempdb].[dbo].syscolumns b where a.id = b.id and a.name = '##new1'

--select * #new

select * from #linha

--select '010' [010], '020' [020] into #new

-- insert into ##new select linha, linha, linha, linha, linha, linha, linha, linha, linha, linha, linha, linha from #linha
--select * from ##new

select * from ##new1

select *
from ##new1, #linha