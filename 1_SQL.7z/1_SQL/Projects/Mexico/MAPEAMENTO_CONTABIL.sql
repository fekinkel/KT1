--MAPEAMENTO CONT�BIL CLIENTE--O1745 O2143DROP TABLE #GLMCSELECT * INTO #GLMC FROM GLMC WHERE 1 = 0INSERT INTO #GLMCSELECT 		GLMC_TIPO = CONVERT(char(4),'GLCL')      --CONVERT(char(4),'') Tipo
	, GLMC_COD = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') C�digo
	, GLMC_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLMC_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, GLMC_PCC1 = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR1 = CONVERT(varchar(7),CTPC_NRD)      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC2 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC3 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC4 = CONVERT(varchar(15),'5101090003')      --CONVERT(varchar(15),'') Conta Cont�bil      
	, GLMC_PCR4 = CONVERT(varchar(7),'5903')      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC5 = CONVERT(varchar(15),'4301010002')      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR5 = CONVERT(varchar(7),'4302')      --CONVERT(varchar(7),'') Rdz.      
	, GLMC_CTC1 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR1 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC2 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC3 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC4 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR4 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC5 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR5 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLMC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMC_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from ctpc, GLCL
where substring(CTPC_NRD,1,1) = 'C'
			and substring(CTPC_NRD,2,20) = glcl_cod

--EXCLUIR FORNECEDOR DUPLICADO
--2105011256 (C01256)
--C01429 (C01468)
--C01500 (C01280)

INSERT INTO #GLMCSELECT 		GLMC_TIPO = CONVERT(char(4),'GLFO')      --CONVERT(char(4),'') Tipo
	, GLMC_COD = CONVERT(int,GLFO_COD)      --CONVERT(int(6),'') C�digo
	, GLMC_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLMC_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, GLMC_PCC1 = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR1 = CONVERT(varchar(7),CTPC_NRD)      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC2 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC3 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC4 = CONVERT(varchar(15),'5101090005')      --CONVERT(varchar(15),'') Conta Cont�bil      
	, GLMC_PCR4 = CONVERT(varchar(7),'5905')      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC5 = CONVERT(varchar(15),'4301010003')      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR5 = CONVERT(varchar(7),'4303')      --CONVERT(varchar(7),'') Rdz.      
	, GLMC_CTC1 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR1 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC2 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC3 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC4 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR4 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC5 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR5 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLMC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMC_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
from ctpc, GLFO, GLPA
where GLPA_COD = GLFO_GLPA
			and substring(CTPC_NRD,1,1) = 'P'
			AND CTPC_NOM = GLPA_NOM			
ORDER BY GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM
drop table #dupli
select GLMC_TIPO, GLMC_COD,    GLMC_DIG, count(1) contador
into #dupli
from #glmc
group BY GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM
--ORDER BY count(1), GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM
having count(1) > 1 
select * from #dupli
select a.GLMC_COD, glfo_cod, GLMC_NOM, glpa_nom
from #glmc a, #dupli b, glfo, glpa
where a.GLMC_TIPO = b.GLMC_TIPO
			and a.GLMC_COD = b.GLMC_COD
			and	a.GLMC_DIG = b.GLMC_DIG
			--and substring(GLMC_PCR1,1,1) = 'p'
			and glfo_cod = convert(int,substring(GLMC_PCR1,3,10))
			and glfo_glpa = glpa_cod

INSERT INTO GLMC
SELECT a.*
FROM #GLMC A
WHERE  a.GLMC_TIPO+'/'+CONVERT(VARCHAR(6),a.GLMC_COD)+'/'+CONVERT(VARCHAR(6),a.GLMC_DIG) NOT IN (SELECT GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG) FROM GLMC)
			AND a.GLMC_TIPO+'/'+CONVERT(VARCHAR(6),a.GLMC_COD)+'/'+CONVERT(VARCHAR(6),a.GLMC_DIG) NOT IN (SELECT GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG) FROM #dupli)
			
--ORDER BY GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG)

UPDATE GLCL
SET GLCL_ATV = 'S'
FROM #GLMC, GLCL
WHERE GLMC_TIPO = 'GLCL'
			AND GLMC_COD = GLCL_COD
			AND GLMC_DIG = GLCL_DIG

UPDATE GLFO
SET GLFO_ATV = 'S'
FROM #GLMC a, GLFO
WHERE GLMC_TIPO = 'GLFO'
			AND GLMC_COD = GLFO_COD
			AND GLMC_DIG = GLFO_DIG
			and a.GLMC_TIPO+'/'+CONVERT(VARCHAR(6),a.GLMC_COD)+'/'+CONVERT(VARCHAR(6),a.GLMC_DIG) NOT IN (SELECT GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG) FROM #dupli)

