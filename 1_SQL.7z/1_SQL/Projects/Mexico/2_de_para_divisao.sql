declare
@i int,
@cod varchar(8),
@div char(2),
@lin char(2),
@fam char(2)


set @cod = 'TPB.'; set @div = 7; set @lin = 'EB'; set @fam = 'NC'
set @cod = 'FPB.'; set @div = 7; set @lin = 'EB'; set @fam = 'NC'
set @cod = 'teb.'; set @div = 7; set @lin = 'EB'; set @fam = 'NF'
set @cod = 'feb.'; set @div = 7; set @lin = 'EB'; set @fam = 'NF'
set @cod = 'bhb.'; set @div = 7; set @lin = 'EB'; set @fam = 'NH'
set @cod = 'bLb.'; set @div = 7; set @lin = 'EB'; set @fam = 'NH'
set @cod = 'bLK.'; set @div = 7; set @lin = 'EB'; set @fam = 'NH'
set @cod = 'BHEB.'; set @div = 7; set @lin = 'EB'; set @fam = 'NI'
set @cod = 'BLEB.'; set @div = 7; set @lin = 'EB'; set @fam = 'NI'
set @cod = 'TDW.'; set @div = 7; set @lin = 'HB'; set @fam = 'OB'
set @cod = 'FDW.'; set @div = 7; set @lin = 'HB'; set @fam = 'OC'
set @cod = 'THW.'; set @div = 7; set @lin = 'HB'; set @fam = 'OD'
set @cod = 'FHW.'; set @div = 7; set @lin = 'HB'; set @fam = 'OE'
set @cod = 'BLDW.'; set @div = 7; set @lin = 'HB'; set @fam = 'OH'
set @cod = 'TDC.'; set @div = 7; set @lin = 'HB'; set @fam = 'OJ'
set @cod = 'THC.'; set @div = 7; set @lin = 'HB'; set @fam = 'OJ'
set @cod = 'BLDC.'; set @div = 7; set @lin = 'HB'; set @fam = 'OJ'
set @cod = 'TCPI.'; set @div = 7; set @lin = 'IB'; set @fam = 'IC'
set @cod = 'TAIL.'; set @div = 7; set @lin = 'IB'; set @fam = 'ID'
set @cod = 'TAIH.'; set @div = 7; set @lin = 'IB'; set @fam = 'ID'
set @cod = 'TCI.'; set @div = 7; set @lin = 'IB'; set @fam = 'IC'
set @cod = 'MTB.'; set @div = 8; set @lin = 'EB'; set @fam = 'NC'
set @cod = 'MFB.'; set @div = 8; set @lin = 'EB'; set @fam = 'NC'
set @cod = 'MCB.'; set @div = 8; set @lin = 'EB'; set @fam = 'ND'
set @cod = 'MEB.'; set @div = 8; set @lin = 'EB'; set @fam = 'NF'
set @cod = 'MBLB.'; set @div = 8; set @lin = 'EB'; set @fam = 'NH'
set @cod = 'MBHB.'; set @div = 8; set @lin = 'EB'; set @fam = 'NH'
set @cod = 'MEO'; set @div = 8; set @lin = 'EB'; set @fam = 'NI'
set @cod = 'MFDW.'; set @div = 8; set @lin = 'HB'; set @fam = 'OC'
set @cod = 'MHW.'; set @div = 8; set @lin = 'HB'; set @fam = 'OD'
set @cod = 'MFHW.'; set @div = 8; set @lin = 'HB'; set @fam = 'OE'
set @cod = 'MHC.'; set @div = 8; set @lin = 'HC'; set @fam = 'OJ'
set @cod = 'MDC.'; set @div = 8; set @lin = 'HC'; set @fam = 'OJ'
set @cod = 'MFDO.'; set @div = 8; set @lin = 'HC'; set @fam = 'OJ'
set @cod = 'TABH.'; set @div = 8; set @lin = 'IB'; set @fam = 'ID'

set @i = 0

if @i = 0 begin
	select substring(REF,1,charindex('.',ref)), DIV_REF, LIN_REF, FAM_REF 
	--update [dbfmex]...prod set DIV_REF = @div, LIN_REF = @lin, FAM_REF = @fam
	from [dbfmex]...prod 
	where substring(REF,1,charindex('.',ref)) = @cod
	group by substring(REF,1,charindex('.',ref)), DIV_REF, LIN_REF, FAM_REF 
	order by substring(REF,1,charindex('.',ref)), DIV_REF, LIN_REF, FAM_REF 
end else if @i = 1 begin
	update [dbfmex]...prod set DIV_REF = @div, LIN_REF = @lin, FAM_REF = @fam
	from [dbfmex]...prod 
	where substring(REF,1,charindex('.',ref)) = @cod
	--group by substring(REF,1,charindex('.',ref)), DIV_REF, LIN_REF, FAM_REF 
	--order by substring(REF,1,charindex('.',ref)), DIV_REF, LIN_REF, FAM_REF 
end