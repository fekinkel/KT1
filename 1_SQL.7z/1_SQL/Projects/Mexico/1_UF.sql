
DECLARE
@S varchar(4000),
@v varchar(255),
@c char(2),
@i int
DROP TABLE #GLPSSELECT * INTO #GLPS FROM GLPS WHERE 1 = 0INSERT INTO #GLPSSELECT 		GLPS_COD = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'') Pa�s
	, GLPS_NOM = CONVERT(varchar(50),'M�XICO')      --CONVERT(varchar(50),'') Nome
	, GLPS_SPPS = Null      --CONVERT(varchar(5),'') Pa�s Bacen
	, GLPS_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLPS_DTC = CONVERT(datetime(10),GETDATE())      --CONVERT(datetime(10),'') em
	, GLPS_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLPS_DTU = Null      --CONVERT(datetime(10),'') em
INSERT INTO #GLPSSELECT 		GLPS_COD = CONVERT(varchar(3),'BRA')      --CONVERT(varchar(3),'') Pa�s
	, GLPS_NOM = CONVERT(varchar(50),'BRASIL')      --CONVERT(varchar(50),'') Nome
	, GLPS_SPPS = Null      --CONVERT(varchar(5),'') Pa�s Bacen
	, GLPS_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLPS_DTC = CONVERT(datetime(10),GETDATE())      --CONVERT(datetime(10),'') em
	, GLPS_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLPS_DTU = Null      --CONVERT(datetime(10),'') em
INSERT INTO #GLPSSELECT 		GLPS_COD = CONVERT(varchar(3),'USA')      --CONVERT(varchar(3),'') Pa�s
	, GLPS_NOM = CONVERT(varchar(50),'ESTADOS UNIDOS')      --CONVERT(varchar(50),'') Nome
	, GLPS_SPPS = Null      --CONVERT(varchar(5),'') Pa�s Bacen
	, GLPS_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLPS_DTC = CONVERT(datetime(10),GETDATE())      --CONVERT(datetime(10),'') em
	, GLPS_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLPS_DTU = Null      --CONVERT(datetime(10),'') em
INSERT INTO GLPSSELECT *FROM #GLPSWHERE CONVERT(VARCHAR(6),GLPS_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),GLPS_GLCL)FROM GLPS)

/*
set @S = '1. Aguascalientes 	Aguascalientes;17. Nayarit 	Tepic;2. Baja California 	Mexicali;18. Nuevo Le�n 	Monterrey;3. Baja California Sur 	La Paz;19. Oaxaca 	Oaxaca;4. Campeche 	Campeche;20. Puebla 	Puebla;5. Chiapas 	Tuxtla Guti�rrez;21. Quer�taro de Arteaga 	Quer�taro;6. Chihuahua 	Chihuahua;22. Quintana Roo 	Chetumal;7. Coahuila de Zaragoza 	Saltillo;23. San Luis Potos� 	San Luis Potos�;8. Colima 	Colima;24. Sinaloa 	Culiac�n Rosales;9. Durango 	Durango;25. Sonora 	Hermosillo;10. Guanajuato 	Guanajuato;26. Tabasco 	Villahermosa;11. Guerrero 	Chilpancingo de los Bravo;27. Tamaulipas 	Ciudad Victoria;12. Hidalgo 	Pachuca de Soto;28. Tlaxcala 	Tlaxcala;13. Jalisco 	Guadalajara;29. Veracruz-Llave 	Xalapa;14. Estado do M�xico 	Toluca;30. Yucat�n 	M�rida;15. Michoac�n de Ocampo 	Morelia;31. Zacatecas 	Zacatecas;16. Morelos 	Cuernavaca;32. Distrito Federal 	Cidade do M�xico; '
DROP TABLE #GLUFSELECT * INTO #GLUF FROM GLUF WHERE 1 = 0
while (select CHARINDEX(';',@S))>0 begin
	select @v=ltrim(rtrim((substring(@s,1,charindex(';',@s)))))
	select @i = (charindex('.',@V)-1)
	print (charindex('.',@V))
	select @c = substring(@V, 1, (charindex('.',@V)-1))
	--print convert(varchar(2),substring(@V,1,2-charindex('.',@V)-1))
	PRINT @c+' -- '+@v
	INSERT INTO #GLUF	SELECT 			GLUF_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'') Pa�s
		, GLUF_COD = CONVERT(varchar(2),replicate('0',2-len(@c))+@c)      --CONVERT(varchar(2),'') U.F.
		, GLUF_NOM = rtrim(ltrim(CONVERT(varchar(50),substring(@V,charindex('.',@V)+1, LEN(@V)-@i-2))))      --CONVERT(varchar(50),'') Nome
		, GLUF_IBGE = Null      --CONVERT(varchar(2),'') Tabela IBGE
		, GLUF_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
		, GLUF_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
		, GLUF_USU = Null      --CONVERT(varchar(15),'') Alterado por
		, GLUF_DTU = Null      --CONVERT(datetime(10),'') em
		
	print '-'+@v+'-'
	select @s=(substring(@s,charindex(';',@s)+1,len(@s)))
end
*/

DROP TABLE #GLUFSELECT * INTO #GLUF FROM GLUF WHERE 1 = 0INSERT INTO #GLUFSELECT 		GLUF_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'') Pa�s
	, GLUF_COD = CONVERT(varchar(2),CODIGO_PAR)      --CONVERT(varchar(2),'') U.F.
	, GLUF_NOM = CONVERT(varchar(50),DESCR_PAR)      --CONVERT(varchar(50),'') Nome
	, GLUF_IBGE = Null      --CONVERT(varchar(2),'') Tabela IBGE
	, GLUF_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLUF_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLUF_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLUF_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM [dbfmex]...parWHERE CHAVE_PAR = 'EST'			AND CODIGO_PAR <> '****'
INSERT INTO GLUFSELECT *FROM #GLUFWHERE GLUF_GLPS+'/'+GLUF_COD NOT IN (SELECT GLUF_GLPS+'/'+GLUF_COD FROM GLUF)

/*
--CASO PRECISE EXCLUIR OS ESTADOS
DELETE GLUF--select *FROM #GLUF a, GLUF bWHERE a.GLUF_GLPS+'/'+a.GLUF_COD = b.GLUF_GLPS+'/'+b.GLUF_COD 
*/
