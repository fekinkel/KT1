/*
enabling 'Ad Hoc Distributed Queries'
sp_configure 'show advanced options', 1
RECONFIGURE
GO
sp_configure 'Ad Hoc Distributed Queries', 1
RECONFIGURE
GO
*/

/*EXCLUIR OS REGISTROS
ALTER TABLE MTTP DISABLE TRIGGER ALL
	delete from MTTP
ALTER TABLE MTTP ENABLE TRIGGER ALL
*/

DROP TABLE #MTTPSELECT * INTO #MTTP FROM MTTP WHERE 1 = 0INSERT INTO #MTTPSELECT 		MTTP_COD = CONVERT(varchar(25),CLAVE+'-'+DESCRIPCION)      --CONVERT(varchar(25),'') Tipo Insumo
	, MTTP_NOM = CONVERT(varchar(100),CLAVE+'-'+DESCRIPCION + '   ('+DESCRIPCION1+')')      --CONVERT(varchar(100),'') Descri��o
	, MTTP_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') Aplica-se �
	, MTTP_INV = CONVERT(char(1),[REPORTER INVENTARIO])      --CONVERT(char(1),'') Reg.Inv.
	, MTTP_ESTR = CONVERT(char(1),ESTRUCTURA)      --CONVERT(char(1),'') Estrutura
	, MTTP_CPTE = CONVERT(char(1),COMPONENTE)      --CONVERT(char(1),'') Componente
	, MTTP_ORDE = CONVERT(char(1),PROVIDENCIA)      --CONVERT(char(1),'') Provid�ncia
	, MTTP_CTPC = CONVERT(varchar(15),replace([CUENTA CONTABLE],'.',''))      --CONVERT(varchar(15),'') Conta Cont�bil
	, MTTP_CTCC = Null      --CONVERT(varchar(15),'') Centro de Custo
	, MTTP_ATVV = CONVERT(char(1),VENTAS)      --CONVERT(char(1),'') Vendo
	, MTTP_CFOV = CONVERT(varchar(8),[CFOP VENTAS])      --CONVERT(varchar(8),'') CFOP Venda
	, MTTP_ATVC = CONVERT(char(1),COMPRO)      --CONVERT(char(1),'') Compro
	, MTTP_CFOC = CONVERT(varchar(8),[CFOP COMPRO])      --CONVERT(varchar(8),'') CFOP Compra
	, MTTP_CTRI = CONVERT(char(1),'N')      --CONVERT(char(1),'') Credita Tributos
	, MTTP_CPO1 = CONVERT(varchar(15),'N')      --CONVERT(varchar(15),'') Custo Arbitrado
	, MTTP_CPO2 = CONVERT(varchar(15),STOCK)      --CONVERT(varchar(15),'') Estoque
	, MTTP_CPO3 = Null      --CONVERT(varchar(15),'') Campo 3
	, MTTP_CPO4 = Null      --CONVERT(varchar(15),'') Campo 4
	, MTTP_SPED = CONVERT(varchar(2),'')      --CONVERT(varchar(2),'') Tipo SPED
	, MTTP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTTP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTTP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTTP_DTU = Null      --CONVERT(datetime(10),'') em
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\sistema.XLS',insumos$) 


INSERT INTO MTTPSELECT *FROM #MTTPWHERE MTTP_COD NOT IN (SELECT MTTP_COD FROM MTTP)

--SELECT * FROM MTTP
