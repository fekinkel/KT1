/*
DELETE
FROM MTUN

DELETE
FROM GLMD
WHERE GLMD_COD <> 'MXN'

delete
from glmv

*/
if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end


DROP TABLE #MTUNSELECT * INTO #MTUN FROM MTUN WHERE 1 = 0INSERT INTO #MTUNSELECT 		MTUN_COD = CONVERT(varchar(3),CODIGO_PAR)      --CONVERT(varchar(3),'') Unidade
	, MTUN_NOM = CONVERT(varchar(50),DESCR_PAR)      --CONVERT(varchar(50),'') Nome
	, MTUN_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTUN_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, MTUN_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTUN_DTU = Null      --CONVERT(datetime(10),'') Em
	--SELECT *
FROM [dbfmex]...pARwhere CHAVE_PAR = 'UNI'
			and CHARINDEX('**', CODIGO_PAR) <= 0
INSERT INTO MTUNSELECT *FROM #MTUNWHERE MTUN_COD NOT IN (SELECT MTUN_COD FROM MTUN)

--xxxxxxxxxxxx---MOEDA---------XXXXXXXXXXXXXXXXXXX

DROP TABLE #GLMDSELECT * INTO #GLMD FROM GLMD WHERE 1 = 0INSERT INTO #GLMDSELECT 		GLMD_COD = CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda
	, GLMD_NOM = CONVERT(varchar(50),'DOLLAR')      --CONVERT(varchar(50),'') Nome
	, GLMD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMD_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
INSERT INTO #GLMDSELECT 		GLMD_COD = CONVERT(varchar(8),'USD1')      --CONVERT(varchar(8),'') Moeda
	, GLMD_NOM = CONVERT(varchar(50),'DOLLAR TABLA 1')      --CONVERT(varchar(50),'') Nome
	, GLMD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMD_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
INSERT INTO #GLMDSELECT 		GLMD_COD = CONVERT(varchar(8),'USD2')      --CONVERT(varchar(8),'') Moeda
	, GLMD_NOM = CONVERT(varchar(50),'DOLLAR TABLA 2')      --CONVERT(varchar(50),'') Nome
	, GLMD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMD_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
INSERT INTO #GLMDSELECT 		GLMD_COD = CONVERT(varchar(8),'USD3')      --CONVERT(varchar(8),'') Moeda
	, GLMD_NOM = CONVERT(varchar(50),'DOLLAR TABLA 3')      --CONVERT(varchar(50),'') Nome
	, GLMD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMD_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
INSERT INTO #GLMDSELECT 		GLMD_COD = CONVERT(varchar(8),'BRL')      --CONVERT(varchar(8),'') Moeda
	, GLMD_NOM = CONVERT(varchar(50),'REAL')      --CONVERT(varchar(50),'') Nome
	, GLMD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMD_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
INSERT INTO #GLMDSELECT 		GLMD_COD = CONVERT(varchar(8),'EUR')      --CONVERT(varchar(8),'') Moeda
	, GLMD_NOM = CONVERT(varchar(50),'EURO')      --CONVERT(varchar(50),'') Nome
	, GLMD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMD_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
INSERT INTO GLMDSELECT *FROM #GLMDWHERE GLMD_COD NOT IN (SELECT GLMD_COD FROM GLMD)

--XXXXXXXXXXXXXXXXXXXXXXXXX---VALOR-PARA-A-MOEDA---XXXXXXXXXXXXXXXXXXXXXXXX
DROP TABLE #GLMVSELECT * INTO #GLMV FROM GLMV WHERE 1 = 0INSERT INTO #GLMVSELECT 		GLMV_GLMD = CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda
	, GLMV_COD = CONVERT(datetime,'01/01/2011',103)      --CONVERT(datetime(10),'') Data de
	, GLMV_DAT = CONVERT(datetime,'31/12/2011',103)      --CONVERT(datetime(10),'') Data at�
	, GLMV_VAL = CONVERT(decimal(12,2),13.50)      --CONVERT(decimal(12),'') Valor
	, GLMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMV_DTU = Null      --CONVERT(datetime(10),'') Em
	--SELECT *
INSERT INTO #GLMVSELECT 		GLMV_GLMD = CONVERT(varchar(8),'USD1')      --CONVERT(varchar(8),'') Moeda
	, GLMV_COD = CONVERT(datetime,'01/01/2011',103)      --CONVERT(datetime(10),'') Data de
	, GLMV_DAT = CONVERT(datetime,'31/12/2011',103)      --CONVERT(datetime(10),'') Data at�
	, GLMV_VAL = CONVERT(decimal(12,2),11.5)      --CONVERT(decimal(12),'') Valor
	, GLMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMV_DTU = Null      --CONVERT(datetime(10),'') Em
INSERT INTO #GLMVSELECT 		GLMV_GLMD = CONVERT(varchar(8),'USD2')      --CONVERT(varchar(8),'') Moeda
	, GLMV_COD = CONVERT(datetime,'01/01/2011',103)      --CONVERT(datetime(10),'') Data de
	, GLMV_DAT = CONVERT(datetime,'31/12/2011',103)      --CONVERT(datetime(10),'') Data at�
	, GLMV_VAL = CONVERT(decimal(12,2),16)      --CONVERT(decimal(12),'') Valor
	, GLMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMV_DTU = Null      --CONVERT(datetime(10),'') Em
INSERT INTO #GLMVSELECT 		GLMV_GLMD = CONVERT(varchar(8),'USD3')      --CONVERT(varchar(8),'') Moeda
	, GLMV_COD = CONVERT(datetime,'01/01/2011',103)      --CONVERT(datetime(10),'') Data de
	, GLMV_DAT = CONVERT(datetime,'31/12/2011',103)      --CONVERT(datetime(10),'') Data at�
	, GLMV_VAL = CONVERT(decimal(12,2),14)      --CONVERT(decimal(12),'') Valor
	, GLMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMV_DTU = Null      --CONVERT(datetime(10),'') Em
INSERT INTO #GLMVSELECT 		GLMV_GLMD = CONVERT(varchar(8),'EUR')      --CONVERT(varchar(8),'') Moeda
	, GLMV_COD = CONVERT(datetime,'01/01/2011',103)      --CONVERT(datetime(10),'') Data de
	, GLMV_DAT = CONVERT(datetime,'31/12/2011',103)      --CONVERT(datetime(10),'') Data at�
	, GLMV_VAL = CONVERT(decimal(12,2),20)      --CONVERT(decimal(12),'') Valor
	, GLMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMV_DTU = Null      --CONVERT(datetime(10),'') Em
INSERT INTO #GLMVSELECT 		GLMV_GLMD = CONVERT(varchar(8),'BRL')      --CONVERT(varchar(8),'') Moeda
	, GLMV_COD = CONVERT(datetime,'01/01/2011',103)      --CONVERT(datetime(10),'') Data de
	, GLMV_DAT = CONVERT(datetime,'31/12/2011',103)      --CONVERT(datetime(10),'') Data at�
	, GLMV_VAL = CONVERT(decimal(12,2),7.67)      --CONVERT(decimal(12),'') Valor
	, GLMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMV_DTU = Null      --CONVERT(datetime(10),'') Em
INSERT INTO GLMVSELECT *FROM #GLMVWHERE GLMV_GLMD+'/'+CONVERT(CHAR(10),GLMV_COD,102) NOT IN (SELECT GLMV_GLMD+'/'+CONVERT(CHAR(10),GLMV_COD,102) FROM GLMV)
