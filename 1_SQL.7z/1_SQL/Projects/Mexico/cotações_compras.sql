--DELETE CPCT WHERE CPCT_COD >= 25
if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
DROP TABLE #CPCTSELECT *, IDENTITY(INT,25,1) NUM INTO #CPCT FROM CPCT WHERE 1 = 0INSERT INTO #CPCTSELECT 		CPCT_SIES = CONVERT(int,1)      --CONVERT(int(6),'') E
	, CPCT_SIDO = CONVERT(varchar(4),'CPCT')      --CONVERT(varchar(4),'') Tipo
	, CPCT_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, CPCT_COD = CONVERT(int,0)      --CONVERT(int(3),'') N�mero
	, CPCT_STA = CONVERT(char(2),'OK')      --CONVERT(char(2),'') Status
	, CPCT_CPSC_SIES = CONVERT(int,1)      --CONVERT(int(6),'') E.
	, CPCT_CPSC_SIDO = CONVERT(varchar(4),'CPCT')      --CONVERT(varchar(4),'') Tipo
	, CPCT_CPSC_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, CPCT_CPSC_NPAI = CONVERT(int,0)      --CONVERT(int(6),'') Solicita��o
	, CPCT_CPSC = CONVERT(int,0)      --CONVERT(int(3),'') Item
	, CPCT_MTPR = CONVERT(varchar(20),REPLACE(MTPX_COD,'.',''))      --CONVERT(varchar(20),'') Insumo
	, CPCT_MTPC = CONVERT(varchar(20),REPLACE(MTPX_COD,'.',''))      --CONVERT(varchar(20),'') Refer�ncia
	, CPCT_ESPE = Null      --CONVERT(varchar(6000),'') Especifica��es
	, CPCT_GLTX = CONVERT(varchar(4),'GLFO')      --CONVERT(varchar(4),'') Tipo
	, CPCT_GLXX = CONVERT(int,395)      --CONVERT(int(6),'') Fornecedor
	, CPCT_GLXX_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, CPCT_GLXX_GLPA = CONVERT(int,1045)      --CONVERT(int(6),'') C�d.Parceiro
	, CPCT_GLXX_NRDZ = CONVERT(varchar(15),'SIDOR')      --CONVERT(varchar(15),'') Apelido
	, CPCT_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, CPCT_QTD = CONVERT(decimal(12,2),1)      --CONVERT(decimal(12),'') Quantidade
	, CPCT_QTD_GLFO = CONVERT(decimal(12,2),1)      --CONVERT(decimal(12),'') Qtd.Forn.
	, CPCT_CTO = CONVERT(varchar(25),'ELIANE ROMERO')      --CONVERT(varchar(25),'') Contato
	, CPCT_TEL = Null      --CONVERT(varchar(25),'') Fone
	, CPCT_FAX = Null      --CONVERT(varchar(25),'') Fax
	, CPCT_EMAIL = Null      --CONVERT(varchar(50),'') Email
	, CPCT_GLCP = CONVERT(int,1)      --CONVERT(int(6),'') Comprador
	, CPCT_CPID = CONVERT(varchar(20),MTPX_COD)      --CONVERT(varchar(20),'') Ref. Forn.
	, CPCT_CPUN = CONVERT(varchar(3),'PZ')      --CONVERT(varchar(3),'') Un.Forn.
	, CPCT_CPFT = CONVERT(decimal(10,2),1.00)      --CONVERT(decimal(10),'') Fator Un.
	, CPCT_PUN = CONVERT(decimal(12,2),MTPV_VAL)      --CONVERT(decimal(12),'') Pre�o
	, CPCT_PUN_GLFO = CONVERT(decimal(12,2),MTPV_VAL)      --CONVERT(decimal(12),'') Pre�o Un. Forn.
	, CPCT_PUND = CONVERT(decimal(12,2),MTPV_VAL)      --CONVERT(decimal(12),'') Pre�o c/ Desc.
	, CPCT_PUND_GLFO = CONVERT(decimal(12,2), MTPV_VAL)      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.
	, CPCT_VACT = CONVERT(int,365)      --CONVERT(int(3),'') Validade (dias)
	, CPCT_GLMD = CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda
	, CPCT_IPI_ALI = CONVERT(decimal(5,2),16)      --CONVERT(decimal(5),'') % IPI
	, CPCT_ISS_ALI = Null      --CONVERT(decimal(5),'') % ISS
	, CPCT_ICM_ALI = Null      --CONVERT(decimal(5),'') % ICMS
	, CPCT_VALT = CONVERT(decimal(12,2),MTPV_VAL*116/100)      --CONVERT(decimal(12),'') Total c/ IPI
	, CPCT_GLPG = CONVERT(varchar(6),'PGO30')      --CONVERT(varchar(6),'') Pagamento
	, CPCT_PENT = CONVERT(int,45)      --CONVERT(int(3),'') Entrega (dias �teis)
	, CPCT_DOCF = Null      --CONVERT(varchar(20),'') Doc.Fornec.
	, CPCT_OBS = Null      --CONVERT(varchar(255),'') Obs.
	, CPCT_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, CPCT_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, CPCT_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, CPCT_DTU = Null      --CONVERT(datetime(10),'') em
	, CPCT_CPID_NOM = Null      --CONVERT(varchar(50),'') Nome For.
	--select top 10 *
FROM [192.168.3.39].[sidor].[dbo].mtpv, [192.168.3.39].[sidor].[dbo].mtpxWHERE MTPV_MTTV = 7			and MTPV_MTTV = MTPX_SIEX			and MTPV_MTPU = MTPx_MTPU			and MTPX_COD not like 'A%' --select * from [192.168.3.39].[sidor].[dbo].mtpxINSERT INTO #CPCTSELECT 		CPCT_SIES = CONVERT(int,1)      --CONVERT(int(6),'') E
	, CPCT_SIDO = CONVERT(varchar(4),'CPCT')      --CONVERT(varchar(4),'') Tipo
	, CPCT_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, CPCT_COD = CONVERT(int,0)      --CONVERT(int(3),'') N�mero
	, CPCT_STA = CONVERT(char(2),'EA')      --CONVERT(char(2),'') Status
	, CPCT_CPSC_SIES = CONVERT(int,1)      --CONVERT(int(6),'') E.
	, CPCT_CPSC_SIDO = CONVERT(varchar(4),'CPCT')      --CONVERT(varchar(4),'') Tipo
	, CPCT_CPSC_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, CPCT_CPSC_NPAI = CONVERT(int,0)      --CONVERT(int(6),'') Solicita��o
	, CPCT_CPSC = CONVERT(int,0)      --CONVERT(int(3),'') Item
	, CPCT_MTPR = CONVERT(varchar(20),REPLACE(COD,'.',''))      --CONVERT(varchar(20),'') Insumo
	, CPCT_MTPC = CONVERT(varchar(20),REPLACE(COD,'.',''))      --CONVERT(varchar(20),'') Refer�ncia
	, CPCT_ESPE = Null      --CONVERT(varchar(6000),'') Especifica��es
	, CPCT_GLTX = CONVERT(varchar(4),'GLFO')      --CONVERT(varchar(4),'') Tipo
	, CPCT_GLXX = CONVERT(int,1)      --CONVERT(int(6),'') Fornecedor
	, CPCT_GLXX_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, CPCT_GLXX_GLPA = CONVERT(int,1)      --CONVERT(int(6),'') C�d.Parceiro
	, CPCT_GLXX_NRDZ = CONVERT(varchar(15),'VAZIO')      --CONVERT(varchar(15),'') Apelido
	, CPCT_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, CPCT_QTD = CONVERT(decimal(12,2),1)      --CONVERT(decimal(12),'') Quantidade
	, CPCT_QTD_GLFO = CONVERT(decimal(12,2),1)      --CONVERT(decimal(12),'') Qtd.Forn.
	, CPCT_CTO = CONVERT(varchar(25),'ELIANE ROMERO')      --CONVERT(varchar(25),'') Contato
	, CPCT_TEL = Null      --CONVERT(varchar(25),'') Fone
	, CPCT_FAX = Null      --CONVERT(varchar(25),'') Fax
	, CPCT_EMAIL = Null      --CONVERT(varchar(50),'') Email
	, CPCT_GLCP = CONVERT(int,1)      --CONVERT(int(6),'') Comprador
	, CPCT_CPID = CONVERT(varchar(20),COD)      --CONVERT(varchar(20),'') Ref. Forn.
	, CPCT_CPUN = CONVERT(varchar(3),'PZ')      --CONVERT(varchar(3),'') Un.Forn.
	, CPCT_CPFT = CONVERT(decimal(10,2),1.00)      --CONVERT(decimal(10),'') Fator Un.
	, CPCT_PUN = CONVERT(decimal(12,2),PRE_CMP)      --CONVERT(decimal(12),'') Pre�o
	, CPCT_PUN_GLFO = CONVERT(decimal(12,2),PRE_CMP)      --CONVERT(decimal(12),'') Pre�o Un. Forn.
	, CPCT_PUND = CONVERT(decimal(12,2),PRE_CMP)      --CONVERT(decimal(12),'') Pre�o c/ Desc.
	, CPCT_PUND_GLFO = CONVERT(decimal(12,2), PRE_CMP)      --CONVERT(decimal(12),'') Pre�o c/ Desc. Forn.
	, CPCT_VACT = CONVERT(int,1000)      --CONVERT(int(3),'') Validade (dias)
	, CPCT_GLMD = CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda
	, CPCT_IPI_ALI = CONVERT(decimal(5,2),16)      --CONVERT(decimal(5),'') % IPI
	, CPCT_ISS_ALI = Null      --CONVERT(decimal(5),'') % ISS
	, CPCT_ICM_ALI = Null      --CONVERT(decimal(5),'') % ICMS
	, CPCT_VALT = CONVERT(decimal(12,2),PRE_CMP*116/100)      --CONVERT(decimal(12),'') Total c/ IPI
	, CPCT_GLPG = CONVERT(varchar(6),'NET')      --CONVERT(varchar(6),'') Pagamento
	, CPCT_PENT = CONVERT(int,45)      --CONVERT(int(3),'') Entrega (dias �teis)
	, CPCT_DOCF = Null      --CONVERT(varchar(20),'') Doc.Fornec.
	, CPCT_OBS = Null      --CONVERT(varchar(255),'') Obs.
	, CPCT_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, CPCT_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, CPCT_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, CPCT_DTU = Null      --CONVERT(datetime(10),'') em
	, CPCT_CPID_NOM = Null      --CONVERT(varchar(50),'') Nome For.
	--select  *
FROM [CFG_MDL].[dbo].cpct_mex_usaINSERT INTO CPCTSELECT CPCT_SIES, CPCT_SIDO, CPCT_SISE, NUM CPCT_COD, CPCT_STA, CPCT_CPSC_SIES, CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC   ,CPCT_MTPR            ,CPCT_MTPC            ,CPCT_ESPE                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ,CPCT_GLTX ,CPCT_GLXX   ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ  ,CPCT_REV ,CPCT_QTD                                ,CPCT_QTD_GLFO                           ,CPCT_CTO                  ,CPCT_TEL                  ,CPCT_FAX                  ,CPCT_EMAIL                                         ,CPCT_GLCP   ,CPCT_CPID            ,CPCT_CPUN ,CPCT_CPFT                               ,CPCT_PUN                                ,CPCT_PUN_GLFO                           ,CPCT_PUND                               ,CPCT_PUND_GLFO                          ,CPCT_VACT   ,CPCT_GLMD ,CPCT_IPI_ALI                            ,CPCT_ISS_ALI                            ,CPCT_ICM_ALI                            ,CPCT_VALT                               ,CPCT_GLPG ,CPCT_PENT   ,CPCT_DOCF            ,CPCT_OBS                                                                                                                                                                                                                                                        ,CPCT_USC        ,CPCT_DTC                ,CPCT_USU        ,CPCT_DTU                ,CPCT_CPID_NOMFROM #CPCTWHERE CONVERT(VARCHAR(1),CPCT_SIES)+'/'+CONVERT(varchar(4),CPCT_SIDO)+'/'+CONVERT(varchar(3),CPCT_SISE)+'/'+CONVERT(VARCHAR(6),NUM) NOT IN (SELECT CONVERT(VARCHAR(1),CPCT_SIES)+'/'+CONVERT(varchar(4),CPCT_SIDO)+'/'+CONVERT(varchar(3),CPCT_SISE)+'/'+CONVERT(VARCHAR(6),CPCT_COD)FROM CPCT)
			--AND SUBSTRING(REPLACE(CPCT_MTPR,'.',''),1,20) IN (SELECT MTPR_COD FROM MTPR)			AND SUBSTRING(REPLACE(CPCT_MTPR,'.',''),1,20) IN (SELECT MTES_MTPR FROM MTES)
DROP TABLE #MTFOSELECT * INTO #MTFO FROM MTFO WHERE 1 = 0INSERT INTO #MTFOSELECT 		MTFO_MTPR = CONVERT(varchar(20),CPCT_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTFO_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') Estab.
	, MTFO_GLFO = CONVERT(int,'395')      --CONVERT(int(6),'') Fornecedor
	, MTFO_DEFA = CONVERT(char(1),'S')      --CONVERT(char(1),'') Default
	, MTFO_GLFO_GLPA = CONVERT(int,'1045')      --CONVERT(int(6),'') C�d.Parceiro
	, MTFO_GLFO_NRDZ = CONVERT(varchar(15),'SIDOR')      --CONVERT(varchar(15),'') Apelido
	, MTFO_CPCO = CONVERT(varchar(20),CPCT_CPID)--CONVERT(varchar(20),'') Ref.Fornecedor
	, MTFO_CPUN = CONVERT(varchar(3),CPCT_CPUN)      --CONVERT(varchar(3),'') Un.Fornec.
	, MTFO_NOM = ''      --CONVERT(varchar(50),'') Nome Ref. For.
	, MTFO_CPFT = 1      --CONVERT(decimal(10),'') Fator Un.
	, MTFO_CPCT = ''      --CONVERT(varchar(25),'') �ltima Cota��o
	, MTFO_CPDT = CONVERT(datetime,GETDATE())  --CONVERT(datetime(8),'') Dt Cota��o
	, MTFO_OBS = ''      --CONVERT(varchar(255),'') Obs.
	, MTFO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTFO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTFO_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTFO_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM #CPCTINSERT INTO MTFOSELECT *FROM #MTFOWHERE MTFO_MTPR+'/'+CONVERT(VARCHAR(3),MTFO_SIES)+'/'+CONVERT(VARCHAR(6),MTFO_GLFO) NOT IN (SELECT MTFO_MTPR+'/'+CONVERT(VARCHAR(3),MTFO_SIES)+'/'+CONVERT(VARCHAR(6),MTFO_GLFO) FROM MTFO)
			AND MTFO_MTPR IN (SELECT MTPR_COD FROM MTPR)


--delete from cpct
--SELECT * FROM CPCT WHERE CPCT_COD > 23 AND CPCT_COD < 26