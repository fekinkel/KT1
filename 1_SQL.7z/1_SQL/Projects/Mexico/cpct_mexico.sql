
select * 
into cpct_mexico
from mtpx, mtpv
where MTPX_SIEX = 4
			--and MTPX_COD = 'B10.025.020'
			and MTPV_MTPU = MTPX_MTPU
			and MTPV_MTTV = MTPX_SIEX

 
