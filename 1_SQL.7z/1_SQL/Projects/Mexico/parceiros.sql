/*
delete 
from GLSH

delete 
from GLCL

delete 
from GLFO

delete 
from GLCR

delete 
from GLPA
*/

if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

--select * from [dbfmex]...par

--SELECT * DELETE FROM GLCL WHERE GLCL_COD>1
--SELECT * DELETE FROM GLPA WHERE GLPA_COD>4

--select * from glpa

--GLPA_COD    GLPA_NOM                                           GLPA_NRDZ       GLPA_GLPS GLPA_PJPF GLPA_GLCT GLPA_CNPJ      GLPA_IES             GLPA_IMU             GLPA_CPF    GLPA_RG              GLPA_GLRG GLPA_END                                           GLPA_BAI                                           GLPA_CID                  GLPA_GLUF GLPA_CEP   GLPA_TEL                  GLPA_FAX                  GLPA_CTO                  GLPA_EMAIL                                         GLPA_SITE                                          GLPA_USC        GLPA_USPJ       GLPA_CNAE            GLPA_DTC                GLPA_DTPJ               GLPA_USU        GLPA_DTU                GLPA_REGI GLPA_SKIPE                GLPA_LAT1 GLPA_LAT2   GLPA_LAT3   GLPA_LAT4                               GLPA_LON1 GLPA_LON2   GLPA_LON3   GLPA_LON4                               GLPA_GLMN GLPA_NUME GLPA_COMP
------------- -------------------------------------------------- --------------- --------- --------- --------- -------------- -------------------- -------------------- ----------- -------------------- --------- -------------------------------------------------- -------------------------------------------------- ------------------------- --------- ---------- ------------------------- ------------------------- ------------------------- -------------------------------------------------- -------------------------------------------------- --------------- --------------- -------------------- ----------------------- ----------------------- --------------- ----------------------- --------- ------------------------- --------- ----------- ----------- --------------------------------------- --------- ----------- ----------- --------------------------------------- --------- --------- ----------
--1           MDL DE MEXICO, S.A. DE C.V.                        MDL             MEX       J         CATE      10                                                                                        REGI      ACCESO III NO.52 - BODEGA 19                       .                                                  QUERETARO                 QT        79120      442-3091200                                         ROCIO/IVONNE                                                                                                                    SMRMEX                          0000000              2011-07-06 13:37:40.390 1900-01-01 00:00:00.000                 NULL                    LR                                            0           0           0.0000                                            0           0           0.0000                                  NULL                

--			IDENTITY(INT,1,1),	NOM_CLI,	GUERR_CLI,	'MEX',		'L',			'CLI',		ID_CLI,		null,			null,			null,			null,
--		COD_REG,	END_CLI,	BAI_CLI,	CID_CLI,	EST_CLI,	CEP_CLI,	FONE_CLI,	FAXCT_CLI,	CONTC_CLI,	EMA_CLI,		'',				
--'KINKEL',	NULL,			NULL,			GETDATE(),	NULL,			NULL,			NULL,			NULL,			NULL,				NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL,			NULL
--			GLPA_COD						GLPA_NOM  GLPA_NRDZ   GLPA_GLPS GLPA_PJPF GLPA_GLCT GLPA_CNPJ GLPA_IES  GLPA_IMU  GLPA_CPF  GLPA_RG GLPA_GLRG GLPA_END  GLPA_BAI  GLPA_CID  GLPA_GLUF GLPA_CEP  GLPA_TEL  GLPA_FAX    GLPA_CTO    GLPA_EMAIL  GLPA_SITE GLPA_USC  GLPA_USPJ GLPA_CNAE GLPA_DTC    GLPA_DTPJ GLPA_USU  GLPA_DTU  GLPA_REGI GLPA_SKIPE  GLPA_LAT1 GLPA_LAT2 GLPA_LAT3 GLPA_LAT4 GLPA_LON1 GLPA_LON2 GLPA_LON3 GLPA_LON4 GLPA_GLMN GLPA_NUME GLPA_COMP

DROP TABLE #GLPASELECT 'GLCL' TIPO, GLPA_COD GLCL_COD, 1 GLCL_DIG,  *, IDENTITY(INT,4,1) [NUM] INTO #GLPA FROM GLPA WHERE 1 = 0--select * from #glpaINSERT INTO #GLPASELECT 	TIPO = 'GLCL',	GLCL_COD = CONVERT(int,a.COD_CLI)      --CONVERT(int(6),'')
, GLCL_DIG = CONVERT(int,a.DIGITO)      --CONVERT(int(6),'')
, GLPA_COD = 1      --CONVERT(int(6),'')
, GLPA_NOM = CONVERT(varchar(50),NOM_CLI)      --CONVERT(varchar(50),'')
, GLPA_NRDZ = CONVERT(varchar(15),ISNULL(GUERR_CLI,''))      --CONVERT(varchar(15),'')
, GLPA_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'')
, GLPA_PJPF = CONVERT(char(1),'J')      --CONVERT(char(1),'')
, GLPA_GLCT = CONVERT(varchar(4),'CATE')      --CONVERT(varchar(4),'')
, GLPA_CNPJ = CONVERT(varchar(14),a.ID_CLI)      --CONVERT(varchar(14),'')
, GLPA_IES = Null      --CONVERT(varchar(20),'')
, GLPA_IMU = Null      --CONVERT(varchar(20),'')
, GLPA_CPF = Null      --CONVERT(varchar(11),'')
, GLPA_RG = Null      --CONVERT(varchar(20),'')
, GLPA_GLRG = CONVERT(varchar(4),'REGI')      --CONVERT(varchar(4),'')
, GLPA_END = CONVERT(varchar(50),b.END_CLI)      --CONVERT(varchar(50),'')
, GLPA_BAI = CONVERT(varchar(50),b.BAI_CLI)      --CONVERT(varchar(50),'')
, GLPA_CID = CONVERT(varchar(25),ISNULL(b.CID_CLI,''))      --CONVERT(varchar(25),'')
, GLPA_GLUF = CONVERT(varchar(2),replace(b.EST_CLI,'.','22'))      --CONVERT(varchar(2),'')
, GLPA_CEP = CONVERT(varchar(10),ISNULL(b.CEP_CLI,'00000000'))      --CONVERT(varchar(10),'')
, GLPA_TEL = CONVERT(varchar(25),b.FONE_CLI)      --CONVERT(varchar(25),'')
, GLPA_FAX = CONVERT(varchar(25),FAXCT_CLI)      --CONVERT(varchar(25),'')
, GLPA_CTO = CONVERT(varchar(25),b.CONT_CLI)      --CONVERT(varchar(25),'')
, GLPA_EMAIL = CONVERT(varchar(50),EMA_CLI)      --CONVERT(varchar(50),'')
, GLPA_SITE = Null      --CONVERT(varchar(50),'')
, GLPA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'')
, GLPA_USPJ = Null      --CONVERT(varchar(15),'')
, GLPA_CNAE = Null      --CONVERT(varchar(20),'')
, GLPA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'')
, GLPA_DTPJ = Null      --CONVERT(datetime(10),'')
, GLPA_USU = Null      --CONVERT(varchar(15),'')
, GLPA_DTU = Null      --CONVERT(datetime(10),'')
, GLPA_REGI = CONVERT(char(2),'')      --CONVERT(char(2),'')
, GLPA_SKIPE = Null      --CONVERT(varchar(25),'')
, GLPA_LAT1 = Null      --CONVERT(char(1),'')
, GLPA_LAT2 = Null      --CONVERT(int(3),'')
, GLPA_LAT3 = Null      --CONVERT(int(2),'')
, GLPA_LAT4 = Null      --CONVERT(decimal(7),'')
, GLPA_LON1 = Null      --CONVERT(char(1),'')
, GLPA_LON2 = Null      --CONVERT(int(3),'')
, GLPA_LON3 = Null      --CONVERT(int(2),'')
, GLPA_LON4 = Null      --CONVERT(decimal(7),'')
, GLPA_GLMN = Null      --CONVERT(varchar(7),'')
, GLPA_NUME = Null      --CONVERT(varchar(5),'')
, GLPA_COMP = Null      --CONVERT(varchar(10),'')
--select b.*
from [dbfmex]...cli a, [dbfmex]...ende_cli b
where a.COD_CLI = b.COD_CLI
			and a.DIGITO = b.DIGITO

INSERT INTO #GLPA
select	
	TIPO = 'GLFO'
,	GLCL_COD = CONVERT(int,COD_FOR)      --CONVERT(int(6),'')
,	GLCL_DIG = CONVERT(int,1)      --CONVERT(int(6),'')
, GLPA_COD = 1      --CONVERT(int(6),'')
, GLPA_NOM = CONVERT(varchar(50),NOM_FOR)      --CONVERT(varchar(50),'')
, GLPA_NRDZ = CONVERT(varchar(15),ISNULL(GUE_FOR,''))      --CONVERT(varchar(15),'')
, GLPA_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'')
, GLPA_PJPF = CONVERT(char(1),'J')      --CONVERT(char(1),'')
, GLPA_GLCT = CONVERT(varchar(4),'CATE')      --CONVERT(varchar(4),'')
, GLPA_CNPJ = CONVERT(varchar(14),IDE_FOR)      --CONVERT(varchar(14),'')
, GLPA_IES = Null      --CONVERT(varchar(20),'')
, GLPA_IMU = Null      --CONVERT(varchar(20),'')
, GLPA_CPF = Null      --CONVERT(varchar(11),'')
, GLPA_RG = Null      --CONVERT(varchar(20),'')
, GLPA_GLRG = CONVERT(varchar(4),'REGI')      --CONVERT(varchar(4),'')
, GLPA_END = CONVERT(varchar(50),END_FOR)      --CONVERT(varchar(50),'')
, GLPA_BAI = CONVERT(varchar(50),BAI_FOR)      --CONVERT(varchar(50),'')
, GLPA_CID = CONVERT(varchar(25),ISNULL(CID_FOR,''))      --CONVERT(varchar(25),'')
, GLPA_GLUF = CONVERT(varchar(2),'QT')      --CONVERT(varchar(2),'')
, GLPA_CEP = CONVERT(varchar(10),ISNULL(CEP_FOR,'00000000'))      --CONVERT(varchar(10),'')
, GLPA_TEL = CONVERT(varchar(25),FN1_FOR)      --CONVERT(varchar(25),'')
, GLPA_FAX = CONVERT(varchar(25),FAX_FOR)      --CONVERT(varchar(25),'')
, GLPA_CTO = CONVERT(varchar(25),CON_FOR)      --CONVERT(varchar(25),'')
, GLPA_EMAIL = CONVERT(varchar(50),EMAI)      --CONVERT(varchar(50),'')
, GLPA_SITE = Null      --CONVERT(varchar(50),'')
, GLPA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'')
, GLPA_USPJ = Null      --CONVERT(varchar(15),'')
, GLPA_CNAE = Null      --CONVERT(varchar(20),'')
, GLPA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'')
, GLPA_DTPJ = Null      --CONVERT(datetime(10),'')
, GLPA_USU = Null      --CONVERT(varchar(15),'')
, GLPA_DTU = Null      --CONVERT(datetime(10),'')
, GLPA_REGI = CONVERT(char(2),'')      --CONVERT(char(2),'')
, GLPA_SKIPE = Null      --CONVERT(varchar(25),'')
, GLPA_LAT1 = Null      --CONVERT(char(1),'')
, GLPA_LAT2 = Null      --CONVERT(int(3),'')
, GLPA_LAT3 = Null      --CONVERT(int(2),'')
, GLPA_LAT4 = Null      --CONVERT(decimal(7),'')
, GLPA_LON1 = Null      --CONVERT(char(1),'')
, GLPA_LON2 = Null      --CONVERT(int(3),'')
, GLPA_LON3 = Null      --CONVERT(int(2),'')
, GLPA_LON4 = Null      --CONVERT(decimal(7),'')
, GLPA_GLMN = Null      --CONVERT(varchar(7),'')
, GLPA_NUME = Null      --CONVERT(varchar(5),'')
, GLPA_COMP = Null      --CONVERT(varchar(10),'')
--select *
from [dbfmex]...[FOR]
--where nom_for not in (select glpa_nom from #GLPA)

--select * from [dbfmex]...ende_cli order by cod_cli

--SELECT * FROM #GLPA WHERE TIPO = 'GLFO' ORDER BY GLCL_COD
INSERT INTO GLPA
SELECT NUM, GLPA_NOM, GLPA_NRDZ, GLPA_GLPS, GLPA_PJPF, GLPA_GLCT, GLPA_CNPJ, GLPA_IES, GLPA_IMU, GLPA_CPF, GLPA_RG, GLPA_GLRG, GLPA_END, GLPA_BAI, GLPA_CID, GLPA_GLUF, GLPA_CEP, GLPA_TEL, GLPA_FAX, GLPA_CTO, GLPA_EMAIL, GLPA_SITE   ,GLPA_USC        ,GLPA_USPJ   ,GLPA_CNAE   ,GLPA_DTC                ,GLPA_DTPJ   ,GLPA_USU    ,GLPA_DTU    ,GLPA_REGI ,GLPA_SKIPE  ,GLPA_LAT1   ,GLPA_LAT2   ,GLPA_LAT3   ,GLPA_LAT4   ,GLPA_LON1   ,GLPA_LON2   ,GLPA_LON3   ,GLPA_LON4   ,GLPA_GLMN   ,GLPA_NUME   ,GLPA_COMP
FROM #GLPA
WHERE GLPA_COD NOT IN (SELECT GLPA_COD FROM GLPA)

DROP TABLE #GLCLSELECT * INTO #GLCL FROM GLCL WHERE 1 = 0INSERT INTO #GLCL
SELECT 
		GLCL_COD = CONVERT(int,COD_CLI)      --CONVERT(int(6),'') C�digo
	, GLCL_DIG = CONVERT(int,DIGITO)      --CONVERT(int(3),'') Digito
	, GLCL_GLPA = CONVERT(int,glpa_cod)      --CONVERT(int(6),'') C�d.Parceiro
	, GLCL_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, GLCL_GLVD = CONVERT(int,COD_VEND)      --CONVERT(int(6),'') Vendedor
	, GLCL_GLVD_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLCL_REV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Destina��o
	, GLCL_GLCC = Null      --CONVERT(varchar(15),'') Portador
	, GLCL_CART = Null      --CONVERT(varchar(3),'') Carteira
	, GLCL_GLPG = CONVERT(varchar(6),'NET30')      --CONVERT(varchar(6),'') Pagamento
	, GLCL_GLMD = CONVERT(varchar(8),'PESO')      --CONVERT(varchar(8),'') Moeda
	, GLCL_FPV = CONVERT(decimal(7),'0.00')      --CONVERT(decimal(7),'') Fator pre�o
	, GLCL_VIA = CONVERT(char(1),'1')      --CONVERT(char(1),'') Via Transporte
	, GLCL_GLTR = NULL 
	, GLCL_INST = NULL
	, GLCL_MTLP = NULL
	, GLCL_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLCL_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLCL_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLCL_DTU = Null      --CONVERT(datetime(10),'') Em
from [dbfmex]...cli, #GLPA
WHERE TIPO = 'GLCL'
			AND GLPA_CNPJ = CONVERT(varchar(14),ID_CLI)


INSERT INTO #GLCLSELECT GLCL_COD    ,GLCL_DIG    ,GLCL_GLPA   ,GLCL_ATV ,GLCL_GLVD   ,GLCL_GLVD_DIG ,GLCL_REV ,GLCL_GLCC       ,GLCL_CART ,GLCL_GLPG ,GLCL_GLMD ,GLCL_FPV                                ,GLCL_VIA ,GLCL_GLTR   ,GLCL_INST                                          ,GLCL_MTLP ,GLCL_USC        ,GLCL_DTC                ,GLCL_USU        ,GLCL_DTU
FROM #GLCL
WHERE CONVERT(VARCHAR(6),GLCL_COD)+'/'+CONVERT(VARCHAR(3),GLCL_DIG) NOT IN (SELECT CONVERT(VARCHAR(6),GLCL_COD)+'/'+CONVERT(VARCHAR(3),GLCL_DIG) FROM GLCL)

DROP TABLE #GLCRSELECT * INTO #GLCR FROM GLCR WHERE 1 = 0INSERT INTO #GLCRSELECT 
	  GLCR_GLCL = CONVERT(int,cod_cli)      --CONVERT(int(6),'') C�digo
	, GLCR_GLLC = CONVERT(varchar(4),'00')      --CONVERT(varchar(4),'') Limite
	, GLCR_STA = CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Status de cr�dito
	, GLCR_MEN = Null      --CONVERT(varchar(254),'') Obs.
	, GLCR_PED = 0.00      --CONVERT(decimal(12),'') Pedidos
	, GLCR_TIT = 0.00      --CONVERT(decimal(12),'') T�tulos
	, GLCR_ADT = 0.00      --CONVERT(decimal(12),'') Adiantamentos
	, GLCR_PRI_VAL = 0.00      --CONVERT(decimal(12),'') Primeiro Faturamento
	, GLCR_PRI_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_ULT_VAL = 0.00      --CONVERT(decimal(12),'') �ltimo Faturamento
	, GLCR_ULT_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_MAI_VAL = 0.00      --CONVERT(decimal(12),'') Maior Faturamento
	, GLCR_MAI_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_ACU_VAL = 0.00      --CONVERT(decimal(12),'') Maior ac�mulo
	, GLCR_ACU_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_DP00 = 0      --CONVERT(int(3),'') Em dia
	, GLCR_VP00 = 0.00      --CONVERT(decimal(14),'') Total dos Pagtos.
	, GLCR_DP05 = 0      --CONVERT(int(3),'') At� 5 dias
	, GLCR_VP05 = 0.00      --CONVERT(decimal(14),'') Valor at� 5 dias
	, GLCR_DP15 = 0      --CONVERT(int(3),'') At� 15 dias
	, GLCR_VP15 = 0.00      --CONVERT(decimal(14),'') Valor at� 15 dias
	, GLCR_DP30 = 0      --CONVERT(int(3),'') At� 30 dias
	, GLCR_VP30 = 0.00      --CONVERT(decimal(14),'') Valor at� 30 dias
	, GLCR_DP60 = 0      --CONVERT(int(3),'') At� 60 dias
	, GLCR_VP60 = 0.00      --CONVERT(decimal(14),'') Valor at� 60 dias
	, GLCR_DPAC = 0      --CONVERT(int(3),'') Acima de 60 dias
	, GLCR_VPAC = 0.00      --CONVERT(decimal(14),'') Valor acima 60 dias
	, GLCR_DPNP = 0      --CONVERT(int(3),'') N�o pagas
	, GLCR_DPAM = 0.00      --CONVERT(int(3),'') Atraso m�dio (dias)
	, GLCR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLCR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLCR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLCR_DTU = Null      --CONVERT(datetime(10),'') Em
from [dbfmex]...cli, #GLPA
WHERE GLPA_CNPJ = CONVERT(varchar(14),ID_CLI)

INSERT INTO GLCR
SELECT *
FROM #GLCR
WHERE CONVERT(VARCHAR(6),GLCR_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),GLCR_GLCL)FROM GLCR)

DROP TABLE #GLSHSELECT * INTO #GLSH FROM GLSH WHERE 1 = 0INSERT INTO #GLSHSELECT		GLSH_GLCL = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') Cliente
	, GLSH_GLCL_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLSH_COD = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') Cliente Destino
	, GLSH_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLSH_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLSH_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Inclus�o
	, GLSH_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLSH_DTU = Null      --CONVERT(datetime(10),'') Altera��o
FROM #GLCLINSERT INTO GLSHSELECT *FROM #GLSHWHERE CONVERT(VARCHAR(6),GLSH_GLCL)+'/'+CONVERT(VARCHAR(6),GLSH_GLCL_DIG) NOT IN (SELECT CONVERT(VARCHAR(6),GLSH_GLCL)+'/'+CONVERT(VARCHAR(6),GLSH_GLCL_DIG)FROM GLSH)

--XXXXXXXXXXXXXXXXXXXXXXX----------------X----------XXXXXXXXXXXXXXXXXXXXXXXXX-------------
/*
select * from glfo 
UPDATE GLFO SET GLFO_GLPA = NUM
FROM #GLPA_FOR a, GLFO b
WHERE a.GLCL_COD = b.GLFO_COD
			and a.GLCL_DIG = b.GLFO_DIG
			and NUM IN (SELECT GLPA_COD FROM GLPA)
			--AND GLPA_CNPJ NOT IN (SELECT GLPA_CNPJ FROM #GLPA)
*/


DROP TABLE #GLFOSELECT * INTO #GLFO FROM GLFO WHERE 1 = 0INSERT INTO #GLFOSELECT
		GLFO_COD = CONVERT(int,COD_FOR)      --CONVERT(int(6),'') C�digo
	, GLFO_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLFO_GLPA = CONVERT(int,NUM)      --CONVERT(int(6),'') C�d.Parceiro
	, GLFO_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, GLFO_GLCP = 1      --CONVERT(int(6),'') Comprador
	, GLFO_GLCP_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLFO_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, GLFO_GLCC = Null      --CONVERT(varchar(15),'') Portador
	, GLFO_GLPG = Null      --CONVERT(varchar(6),'') Pagamento
	, GLFO_GLMD = CONVERT(varchar(8),'MXN')      --CONVERT(varchar(8),'') Moeda
	, GLFO_FPV = CONVERT(decimal,1.0)      --CONVERT(decimal(7),'') Fator pre�o
	, GLFO_VIA = CONVERT(char(1),'')      --CONVERT(char(1),'') Via Transporte
	, GLFO_BCO = Null      --CONVERT(varchar(3),'') Banco
	, GLFO_AGE = Null      --CONVERT(varchar(6),'') Ag�ncia
	, GLFO_AGE_DIG = Null      --CONVERT(char(1),'') Digito
	, GLFO_CTA = Null      --CONVERT(varchar(15),'') Conta corrente
	, GLFO_CTA_DIG = Null      --CONVERT(char(1),'') Digito
	, GLFO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLFO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLFO_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLFO_DTU = Null      --CONVERT(datetime(10),'') Em
from [dbfmex]...[FOR], #GLPA
WHERE TIPO = 'GLFO'
			AND COD_FOR = GLCL_COD
			AND 1 = GLCL_DIG
--			AND nom_for+'/'+GUE_FOR = glpa_nom+'/'+GLPA_NRDZ
			--GLPA_CNPJ = CONVERT(varchar(14),IDE_FOR)
INSERT INTO GLFOSELECT distinct *FROM #GLFOWHERE CONVERT(VARCHAR(6),GLFO_COD)+'/'+CONVERT(VARCHAR(6),GLFO_DIG) NOT IN (SELECT CONVERT(VARCHAR(6),GLFO_COD)+'/'+CONVERT(VARCHAR(6),GLFO_DIG)FROM GLFO)

select *
update glfo set GLFO_GLPA = a.GLFO_GLPA
from #glfo a, glfo b
where a.GLFO_COD = b.GLFO_COD
			and a.GLFO_DIG = b.GLFO_DIG
			and a.GLFO_GLPA <> b.GLFO_GLPA


--SELECT GLFO_COD, count(1) FROM #GLFO group by GLFO_COD order by count(1),GLFO_COD
--SELECT nom_for, GUE_FOR, count(1) FROM [dbfmex]...[FOR] group by nom_for, GUE_FOR order by count(1) desc  WHERE COD_FOR = 68
--select * from [dbfmex]...[for] where cod_for = 728 --678, 728
--select * from #glpa_for where glpa_nom like '%CIA SHERWIN WILLIAMS SA DE CV%'

select *
from GLPA
