select PRCT_COD, 000.00 PRCT_CVAR
from PRCT
where PRCT_COD like '%PU%'
group by PRCT_COD
order by PRCT_COD

drop table #new

select PROR_SIES, PROR_SIDO, PROR_SISE, PROR_COD
into #new
from PROR
where PROR_COD >= 543
			and PROR_SIES = 7
			and PROR_SIDO = 'pror'
			and PROR_ORDE = 'N'

select *
from PROT, #new
where PROT_SIES = pror_sies
			and PROT_SIDO = pror_sido
			and PROT_SISE = PROR_sise
			and PROT_PROR = pror_cod

