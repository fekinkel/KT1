/*
DELETE
FROM GLLC

delete
from gltr

delete from mtfo

delete 
from GLFO

delete
from glcp

delete 
from GLSH

delete 
from GLCL


delete 
from GLCR

delete
from glvd

delete 
from GLPA
*/

--EXCLUS�O DE DUPLICADO (dos)
--SELECT TOP 1 * INTO #NEW FROM [DBFMEX]...[ENDE_CLI] WHERE COD_CLI = 125
--DELETE FROM [DBFMEX]...[ENDE_CLI] WHERE COD_CLI = 125
--INSERT INTO [DBFMEX]...[ENDE_CLI] SELECT * FROM #NEW
--SELECT * FROM GLPA WHERE GLPA_NOM = 'HELVEX, S.A. DE C.V.'
if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end

--LIMITE DE CR�DITO

DROP TABLE #GLLCSELECT * INTO #GLLC FROM GLLC WHERE 1 = 0INSERT INTO #GLLCSELECT 		GLLC_COD = CONVERT(varchar(4),CODIGO_PAR)      --CONVERT(varchar(4),'') C�digo
	, GLLC_VAL = CONVERT(decimal,REPLACE(SUBSTRING(DESCR_PAR,1,CHARINDEX('(',DESCR_PAR+'(')-2),'SIN CREDIT',00))      --CONVERT(decimal(12),'') Valor
	, GLLC_GLMD = CONVERT(varchar(8),'MXN')      --CONVERT(varchar(8),'') Moeda
	, GLLC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLLC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLLC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLLC_DTU = Null      --CONVERT(datetime(10),'') Em
	--SELECT SUBSTRING(DESCR_PAR,1,CHARINDEX('(',(DESCR_PAR+'('))-2), *
FROM [dbfmex]...parWHERE CHAVE_PAR = 'LCR'INSERT INTO GLLCSELECT *FROM #GLLCWHERE GLLC_COD NOT IN (SELECT GLLC_COD FROM GLLC)

--EXCLUIR A TABELA DE PARCEIROS 
DROP TABLE #GLPASELECT distinct 'XXXX' TIPO, GLPA_COD GLCL_COD, 1 GLCL_DIG,  *, IDENTITY(INT,1,1) [NUM] INTO #GLPA FROM GLPA WHERE 1 = 0
go
--CRIAR COMPRADOR
INSERT INTO #GLPASELECT 	TIPO = 'GLCP',	GLCL_COD = CONVERT(int,1)      --CONVERT(int(6),'')
, GLCL_DIG = CONVERT(int,1)      --CONVERT(int(6),'')
, GLPA_COD = 1      --CONVERT(int(6),'')
, GLPA_NOM = CONVERT(varchar(50),'MARIA LUIZA QUIROGA')      --CONVERT(varchar(50),'')
, GLPA_NRDZ = CONVERT(varchar(15),'MLQUIROGA')      --CONVERT(varchar(15),'')
, GLPA_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'')
, GLPA_PJPF = CONVERT(char(1),'L')      --CONVERT(char(1),'')
, GLPA_GLCT = CONVERT(varchar(4),'CATE')      --CONVERT(varchar(4),'')
, GLPA_CNPJ = CONVERT(varchar(14),'MLQ')      --CONVERT(varchar(14),'')
, GLPA_IES = Null      --CONVERT(varchar(20),'')
, GLPA_IMU = Null      --CONVERT(varchar(20),'')
, GLPA_CPF = Null      --CONVERT(varchar(11),'')
, GLPA_RG = Null      --CONVERT(varchar(20),'')
, GLPA_GLRG = CONVERT(varchar(4),'REGI')      --CONVERT(varchar(4),'')
, GLPA_END = CONVERT(varchar(50),'REVISAR...')      --CONVERT(varchar(50),'')
, GLPA_BAI = CONVERT(varchar(50),'REVISAR...')      --CONVERT(varchar(50),'')
, GLPA_CID = CONVERT(varchar(25),'QUERETARO')      --CONVERT(varchar(25),'')
, GLPA_GLUF = CONVERT(varchar(2),'22')      --CONVERT(varchar(2),'')
, GLPA_CEP = CONVERT(varchar(10),'00000000')      --CONVERT(varchar(10),'')
, GLPA_TEL = CONVERT(varchar(25),'')      --CONVERT(varchar(25),'')
, GLPA_FAX = CONVERT(varchar(25),'')      --CONVERT(varchar(25),'')
, GLPA_CTO = CONVERT(varchar(25),'')      --CONVERT(varchar(25),'')
, GLPA_EMAIL = CONVERT(varchar(50),'gerencia@mdlmexico.com.br')      --CONVERT(varchar(50),'')
, GLPA_SITE = Null      --CONVERT(varchar(50),'')
, GLPA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'')
, GLPA_USPJ = Null      --CONVERT(varchar(15),'')
, GLPA_CNAE = Null      --CONVERT(varchar(20),'')
, GLPA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'')
, GLPA_DTPJ = Null      --CONVERT(datetime(10),'')
, GLPA_USU = Null      --CONVERT(varchar(15),'')
, GLPA_DTU = Null      --CONVERT(datetime(10),'')
, GLPA_REGI = CONVERT(char(2),'LR')      --CONVERT(char(2),'')
, GLPA_SKIPE = Null      --CONVERT(varchar(25),'')
, GLPA_LAT1 = Null      --CONVERT(char(1),'')
, GLPA_LAT2 = Null      --CONVERT(int(3),'')
, GLPA_LAT3 = Null      --CONVERT(int(2),'')
, GLPA_LAT4 = Null      --CONVERT(decimal(7),'')
, GLPA_LON1 = Null      --CONVERT(char(1),'')
, GLPA_LON2 = Null      --CONVERT(int(3),'')
, GLPA_LON3 = Null      --CONVERT(int(2),'')
, GLPA_LON4 = Null      --CONVERT(decimal(7),'')
, GLPA_GLMN = Null      --CONVERT(varchar(7),'')
, GLPA_NUME = Null      --CONVERT(varchar(5),'')
, GLPA_COMP = Null      --CONVERT(varchar(10),'')
--select b.*
go
--select * from #glpaINSERT INTO #GLPASELECT 	TIPO = 'GLCL',	GLCL_COD = CONVERT(int,a.COD_CLI)      --CONVERT(int(6),'')
, GLCL_DIG = CONVERT(int,a.DIGITO)      --CONVERT(int(6),'')
, GLPA_COD = 1      --CONVERT(int(6),'')
, GLPA_NOM = CONVERT(varchar(50),NOM_CLI)      --CONVERT(varchar(50),'')
, GLPA_NRDZ = CONVERT(varchar(15),ISNULL(GUERR_CLI,''))      --CONVERT(varchar(15),'')
, GLPA_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'')
, GLPA_PJPF = CONVERT(char(1),'L')      --CONVERT(char(1),'')
, GLPA_GLCT = CONVERT(varchar(4),'CATE')      --CONVERT(varchar(4),'')
, GLPA_CNPJ = CONVERT(varchar(14),a.ID_CLI)      --CONVERT(varchar(14),'')
, GLPA_IES = Null      --CONVERT(varchar(20),'')
, GLPA_IMU = Null      --CONVERT(varchar(20),'')
, GLPA_CPF = Null      --CONVERT(varchar(11),'')
, GLPA_RG = Null      --CONVERT(varchar(20),'')
, GLPA_GLRG = CONVERT(varchar(4),'REGI')      --CONVERT(varchar(4),'')
, GLPA_END = CONVERT(varchar(50),b.END_CLI)      --CONVERT(varchar(50),'')
, GLPA_BAI = CONVERT(varchar(50),b.BAI_CLI)      --CONVERT(varchar(50),'')
, GLPA_CID = CONVERT(varchar(25),ISNULL(b.CID_CLI,''))      --CONVERT(varchar(25),'')
, GLPA_GLUF = CONVERT(varchar(2),replace(b.EST_CLI,'.','22'))      --CONVERT(varchar(2),'')
, GLPA_CEP = CONVERT(varchar(10),ISNULL(b.CEP_CLI,'00000000'))      --CONVERT(varchar(10),'')
, GLPA_TEL = CONVERT(varchar(25),b.FONE_CLI)      --CONVERT(varchar(25),'')
, GLPA_FAX = CONVERT(varchar(25),FAXCT_CLI)      --CONVERT(varchar(25),'')
, GLPA_CTO = CONVERT(varchar(25),b.CONT_CLI)      --CONVERT(varchar(25),'')
, GLPA_EMAIL = CONVERT(varchar(50),EMA_CLI)      --CONVERT(varchar(50),'')
, GLPA_SITE = Null      --CONVERT(varchar(50),'')
, GLPA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'')
, GLPA_USPJ = Null      --CONVERT(varchar(15),'')
, GLPA_CNAE = Null      --CONVERT(varchar(20),'')
, GLPA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'')
, GLPA_DTPJ = Null      --CONVERT(datetime(10),'')
, GLPA_USU = Null      --CONVERT(varchar(15),'')
, GLPA_DTU = Null      --CONVERT(datetime(10),'')
, GLPA_REGI = CONVERT(char(2),'LR')      --CONVERT(char(2),'')
, GLPA_SKIPE = Null      --CONVERT(varchar(25),'')
, GLPA_LAT1 = Null      --CONVERT(char(1),'')
, GLPA_LAT2 = Null      --CONVERT(int(3),'')
, GLPA_LAT3 = Null      --CONVERT(int(2),'')
, GLPA_LAT4 = Null      --CONVERT(decimal(7),'')
, GLPA_LON1 = Null      --CONVERT(char(1),'')
, GLPA_LON2 = Null      --CONVERT(int(3),'')
, GLPA_LON3 = Null      --CONVERT(int(2),'')
, GLPA_LON4 = Null      --CONVERT(decimal(7),'')
, GLPA_GLMN = Null      --CONVERT(varchar(7),'')
, GLPA_NUME = Null      --CONVERT(varchar(5),'')
, GLPA_COMP = Null      --CONVERT(varchar(10),'')
--select b.*
from [dbfmex]...cli a, [dbfmex]...ende_cli b
where a.COD_CLI = b.COD_CLI
			and a.DIGITO = b.DIGITO
go

INSERT INTO #GLPA
select	
	TIPO = 'GLFO'
,	GLCL_COD = CONVERT(int,COD_FOR)      --CONVERT(int(6),'')
,	GLCL_DIG = CONVERT(int,1)      --CONVERT(int(6),'')
, GLPA_COD = 1      --CONVERT(int(6),'')
, GLPA_NOM = CONVERT(varchar(50),NOM_FOR)      --CONVERT(varchar(50),'')
, GLPA_NRDZ = CONVERT(varchar(15),ISNULL(GUE_FOR,''))      --CONVERT(varchar(15),'')
, GLPA_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'')
, GLPA_PJPF = CONVERT(char(1),'J')      --CONVERT(char(1),'')
, GLPA_GLCT = CONVERT(varchar(4),'CATE')      --CONVERT(varchar(4),'')
, GLPA_CNPJ = CONVERT(varchar(14),IDE_FOR)      --CONVERT(varchar(14),'')
, GLPA_IES = Null      --CONVERT(varchar(20),'')
, GLPA_IMU = Null      --CONVERT(varchar(20),'')
, GLPA_CPF = Null      --CONVERT(varchar(11),'')
, GLPA_RG = Null      --CONVERT(varchar(20),'')
, GLPA_GLRG = CONVERT(varchar(4),'REGI')      --CONVERT(varchar(4),'')
, GLPA_END = CONVERT(varchar(50),END_FOR)      --CONVERT(varchar(50),'')
, GLPA_BAI = CONVERT(varchar(50),BAI_FOR)      --CONVERT(varchar(50),'')
, GLPA_CID = CONVERT(varchar(25),ISNULL(CID_FOR,''))      --CONVERT(varchar(25),'')
, GLPA_GLUF = CONVERT(varchar(2),replace(EST_FOR,'.','22'))      --CONVERT(varchar(2),'')
, GLPA_CEP = CONVERT(varchar(10),ISNULL(CEP_FOR,'00000000'))      --CONVERT(varchar(10),'')
, GLPA_TEL = CONVERT(varchar(25),FN1_FOR)      --CONVERT(varchar(25),'')
, GLPA_FAX = CONVERT(varchar(25),FAX_FOR)      --CONVERT(varchar(25),'')
, GLPA_CTO = CONVERT(varchar(25),CON_FOR)      --CONVERT(varchar(25),'')
, GLPA_EMAIL = CONVERT(varchar(50),EMAI)      --CONVERT(varchar(50),'')
, GLPA_SITE = Null      --CONVERT(varchar(50),'')
, GLPA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'')
, GLPA_USPJ = Null      --CONVERT(varchar(15),'')
, GLPA_CNAE = Null      --CONVERT(varchar(20),'')
, GLPA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'')
, GLPA_DTPJ = Null      --CONVERT(datetime(10),'')
, GLPA_USU = Null      --CONVERT(varchar(15),'')
, GLPA_DTU = Null      --CONVERT(datetime(10),'')
, GLPA_REGI = CONVERT(char(2),'')      --CONVERT(char(2),'')
, GLPA_SKIPE = Null      --CONVERT(varchar(25),'')
, GLPA_LAT1 = Null      --CONVERT(char(1),'')
, GLPA_LAT2 = Null      --CONVERT(int(3),'')
, GLPA_LAT3 = Null      --CONVERT(int(2),'')
, GLPA_LAT4 = Null      --CONVERT(decimal(7),'')
, GLPA_LON1 = Null      --CONVERT(char(1),'')
, GLPA_LON2 = Null      --CONVERT(int(3),'')
, GLPA_LON3 = Null      --CONVERT(int(2),'')
, GLPA_LON4 = Null      --CONVERT(decimal(7),'')
, GLPA_GLMN = Null      --CONVERT(varchar(7),'')
, GLPA_NUME = Null      --CONVERT(varchar(5),'')
, GLPA_COMP = Null      --CONVERT(varchar(10),'')
--select *
from [dbfmex]...[FOR]

go

INSERT INTO #GLPA
select	
	TIPO = 'GLVD'--VENDEDORES
,	GLCL_COD = CONVERT(int,COD_VEND)      --CONVERT(int(6),'')
,	GLCL_DIG = CONVERT(int,1)      --CONVERT(int(6),'')
, GLPA_COD = 1      --CONVERT(int(6),'')
, GLPA_NOM = CONVERT(varchar(50),NOM_VEND)      --CONVERT(varchar(50),'')
, GLPA_NRDZ = CONVERT(varchar(15),ISNULL(GUE_VEND,''))      --CONVERT(varchar(15),'')
, GLPA_GLPS = CONVERT(varchar(3),'MEX')      --CONVERT(varchar(3),'')
, GLPA_PJPF = CONVERT(char(1),'L')      --CONVERT(char(1),'')
, GLPA_GLCT = CONVERT(varchar(4),'CATE')      --CONVERT(varchar(4),'')
, GLPA_CNPJ = CONVERT(varchar(14),ID_VEND)      --CONVERT(varchar(14),'')
, GLPA_IES = Null      --CONVERT(varchar(20),'')
, GLPA_IMU = Null      --CONVERT(varchar(20),'')
, GLPA_CPF = Null      --CONVERT(varchar(11),'')
, GLPA_RG = Null      --CONVERT(varchar(20),'')
, GLPA_GLRG = CONVERT(varchar(4),'REGI')      --CONVERT(varchar(4),'')
, GLPA_END = CONVERT(varchar(50),END_VEND)      --CONVERT(varchar(50),'')
, GLPA_BAI = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'')
, GLPA_CID = CONVERT(varchar(25),ISNULL(CID_VEND,'REVISAR...'))      --CONVERT(varchar(25),'')
, GLPA_GLUF = CONVERT(varchar(2),replace(EST_VEND,'.','22'))      --CONVERT(varchar(2),'')
, GLPA_CEP = CONVERT(varchar(10),ISNULL(CEP_VEND,'00000000'))      --CONVERT(varchar(10),'')
, GLPA_TEL = CONVERT(varchar(25),FONE_VEND)      --CONVERT(varchar(25),'')
, GLPA_FAX = CONVERT(varchar(25),FAX_VEND)      --CONVERT(varchar(25),'')
, GLPA_CTO = CONVERT(varchar(25),GUE_VEND)      --CONVERT(varchar(25),'')
, GLPA_EMAIL = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'')
, GLPA_SITE = Null      --CONVERT(varchar(50),'')
, GLPA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'')
, GLPA_USPJ = Null      --CONVERT(varchar(15),'')
, GLPA_CNAE = Null      --CONVERT(varchar(20),'')
, GLPA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'')
, GLPA_DTPJ = Null      --CONVERT(datetime(10),'')
, GLPA_USU = Null      --CONVERT(varchar(15),'')
, GLPA_DTU = Null      --CONVERT(datetime(10),'')
, GLPA_REGI = CONVERT(char(2),'LR')      --CONVERT(char(2),'')
, GLPA_SKIPE = Null      --CONVERT(varchar(25),'')
, GLPA_LAT1 = Null      --CONVERT(char(1),'')
, GLPA_LAT2 = Null      --CONVERT(int(3),'')
, GLPA_LAT3 = Null      --CONVERT(int(2),'')
, GLPA_LAT4 = Null      --CONVERT(decimal(7),'')
, GLPA_LON1 = Null      --CONVERT(char(1),'')
, GLPA_LON2 = Null      --CONVERT(int(3),'')
, GLPA_LON3 = Null      --CONVERT(int(2),'')
, GLPA_LON4 = Null      --CONVERT(decimal(7),'')
, GLPA_GLMN = Null      --CONVERT(varchar(7),'')
, GLPA_NUME = Null      --CONVERT(varchar(5),'')
, GLPA_COMP = Null      --CONVERT(varchar(10),'')
--select *
from [dbfmex]...[arvend]
where id_vend is not null

update #glpa set glpa_gluf = 22 from #glpa where GLPA_GLUF NOT in (select gluf_cod from gluf where gluf_glps = 'mex')

--select GLPA_GLUF from #glpa where GLPA_GLUF not in (select gluf_cod from gluf) group by GLPA_GLUF
INSERT INTO GLPA
SELECT NUM, GLPA_NOM, GLPA_NRDZ, GLPA_GLPS, GLPA_PJPF, GLPA_GLCT, GLPA_CNPJ, GLPA_IES, GLPA_IMU, GLPA_CPF, GLPA_RG, GLPA_GLRG, GLPA_END, GLPA_BAI, GLPA_CID, GLPA_GLUF, GLPA_CEP, GLPA_TEL, GLPA_FAX, GLPA_CTO, GLPA_EMAIL, GLPA_SITE   ,GLPA_USC        ,GLPA_USPJ   ,GLPA_CNAE   ,GLPA_DTC                ,GLPA_DTPJ   ,GLPA_USU    ,GLPA_DTU    ,GLPA_REGI ,GLPA_SKIPE  ,GLPA_LAT1   ,GLPA_LAT2   ,GLPA_LAT3   ,GLPA_LAT4   ,GLPA_LON1   ,GLPA_LON2   ,GLPA_LON3   ,GLPA_LON4   ,GLPA_GLMN   ,GLPA_NUME   ,GLPA_COMP
FROM #GLPA
WHERE GLPA_COD NOT IN (SELECT GLPA_COD FROM GLPA)

--			and GLPA_GLUF in (select gluf_cod from gluf where gluf_glps = 'mex')
GO
--print 'GLPA'
--nao incluir os parceiros com UF BR OT 50 SL SO QR PU AA NL JA AG		
--XXXXXXXXXXXXXXXXXXXXXXX---------VENDEDORES--------XXXXXXXXXXXXXXXXXXXXXXXXX-------------

DROP TABLE #GLVDSELECT * INTO #GLVD FROM GLVD WHERE 1 = 0INSERT INTO #GLVDSELECT 		GLVD_COD = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') C�digo
	, GLVD_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLVD_GLPA = CONVERT(int,NUM)      --CONVERT(int(6),'') C�d.Parceiro
	, GLVD_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, GLVD_COM_COM = CONVERT(char(1),'S')      --CONVERT(char(1),'') Comiss�o
	, GLVD_COM_PCT = CONVERT(decimal,REPLACE(REPLACE(REPLACE(COD_COM,'DAY',5),'MDL',10),'SIN',0))      --CONVERT(decimal(6),'') Valor %
	, GLVD_COM_DES = CONVERT(decimal,0)      --CONVERT(decimal(6),'') Desconto %
	, GLVD_COM_MIN = CONVERT(decimal,0)      --CONVERT(decimal(6),'') M�nima %
	, GLVD_COM_EVE = CONVERT(char(1),'R')      --CONVERT(char(1),'') Evento Com.
	, GLVD_COM_LIQ = CONVERT(char(1),'S')      --CONVERT(char(1),'') Base L�quida
	, GLVD_COM_IPI = CONVERT(char(1),'S')      --CONVERT(char(1),'') Deduz IPI
	, GLVD_COM_ICM = CONVERT(char(1),'N')      --CONVERT(char(1),'') Deduz ICM
	, GLVD_COM_PIS = CONVERT(char(1),'N')      --CONVERT(char(1),'') Deduz PIS
	, GLVD_COM_COF = CONVERT(char(1),'N')      --CONVERT(char(1),'') Deduz COFINS
	, GLVD_COM_ISS = CONVERT(char(1),'N')      --CONVERT(char(1),'') Deduz ISS
	, GLVD_COM_ATR = CONVERT(int,1)      --CONVERT(int(6),'') Cut Off (dias)
	, GLVD_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLVD_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLVD_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLVD_DTU = Null      --CONVERT(datetime(10),'') Em
	--SELECT *
FROM [dbfmex]...[arvend], #GLPAWHERE TIPO = 'GLVD'			and GLCL_COD in (5,9)			AND GLCL_COD = COD_VEND			AND GLCL_DIG = 1INSERT INTO GLVDSELECT *FROM #GLVDWHERE CONVERT(VARCHAR(6),GLVD_COD) NOT IN (SELECT CONVERT(VARCHAR(6),GLVD_COD)FROM GLVD)

go
--PRINT 'GLVD'
--XXXXXXXXXXXXXXXXXXXXXXX-------------COMPRADOR-----XXXXXXXXXXXXXXXXXXXXXXXXX-------------

DROP TABLE #GLCPSELECT * INTO #GLCP FROM GLCP WHERE 1 = 0INSERT INTO #GLCPSELECT 		GLCP_COD = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') C�digo
	, GLCP_DIG = CONVERT(int,'1')      --CONVERT(int(3),'') Digito
	, GLCP_GLPA = CONVERT(int,num)      --CONVERT(int(6),'') C�d.Parceiro
	, GLCP_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, GLCP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLCP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLCP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLCP_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
from #GLPA
where TIPO = 'GLCP'
			
INSERT INTO GLCPSELECT *FROM #GLCPWHERE CONVERT(VARCHAR(6),GLCP_COD) NOT IN (SELECT CONVERT(VARCHAR(6),GLCP_COD)FROM GLCP)
go--PRINT 'GLCP'--XXXXXXXXXXXXXXXXXXXXXXX-------------CLIENTE-------XXXXXXXXXXXXXXXXXXXXXXXXX-------------

DROP TABLE #GLCLSELECT * INTO #GLCL FROM GLCL WHERE 1 = 0INSERT INTO #GLCL
SELECT 
		GLCL_COD = CONVERT(int,COD_CLI)      --CONVERT(int(6),'') C�digo
	, GLCL_DIG = CONVERT(int,DIGITO)      --CONVERT(int(3),'') Digito
	, GLCL_GLPA = CONVERT(int,num)      --CONVERT(int(6),'') C�d.Parceiro
	, GLCL_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, GLCL_GLVD = CONVERT(int,COD_VEND)      --CONVERT(int(6),'') Vendedor
	, GLCL_GLVD_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLCL_REV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Destina��o
	, GLCL_GLCC = Null      --CONVERT(varchar(15),'') Portador
	, GLCL_CART = Null      --CONVERT(varchar(3),'') Carteira
	, GLCL_GLPG = CONVERT(varchar(6),'NET30')      --CONVERT(varchar(6),'') Pagamento
	, GLCL_GLMD = CONVERT(varchar(8),'MXN')      --CONVERT(varchar(8),'') Moeda
	, GLCL_FPV = CONVERT(decimal(7),'0.00')      --CONVERT(decimal(7),'') Fator pre�o
	, GLCL_VIA = CONVERT(char(1),'1')      --CONVERT(char(1),'') Via Transporte
	, GLCL_GLTR = NULL 
	, GLCL_INST = NULL
	, GLCL_MTLP = NULL
	, GLCL_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLCL_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLCL_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLCL_DTU = Null      --CONVERT(datetime(10),'') Em
	--select *
from [dbfmex]...cli, #GLPA
WHERE TIPO = 'GLCL'
			and COD_CLI = GLCL_COD
			and digito  = GLCL_DIG
			AND GLPA_CNPJ = CONVERT(varchar(14),ID_CLI)

update #glcl set glcl_glvd = 9 from #glcl where glcl_glvd <> 5

INSERT INTO GLCLSELECT distinct GLCL_COD    ,GLCL_DIG    ,GLCL_GLPA   ,GLCL_ATV ,GLCL_GLVD   ,GLCL_GLVD_DIG ,GLCL_REV ,GLCL_GLCC       ,GLCL_CART ,GLCL_GLPG ,GLCL_GLMD ,GLCL_FPV                                ,GLCL_VIA ,GLCL_GLTR   ,GLCL_INST                                          ,GLCL_MTLP ,GLCL_USC        ,GLCL_DTC                ,GLCL_USU        ,GLCL_DTU
FROM #GLCL
WHERE CONVERT(VARCHAR(6),GLCL_COD)+'/'+CONVERT(VARCHAR(3),GLCL_DIG) NOT IN (SELECT CONVERT(VARCHAR(6),GLCL_COD)+'/'+CONVERT(VARCHAR(3),GLCL_DIG) FROM GLCL)
--			and glcl_glvd not in (select glvd_cod from glvd)

go
--PRINT 'GLCL'
--XXXXXXXXXXXXXXXXXXXXXXX----------------X----------XXXXXXXXXXXXXXXXXXXXXXXXX-------------

DROP TABLE #GLCRSELECT * INTO #GLCR FROM GLCR WHERE 1 = 0INSERT INTO #GLCRSELECT 
	  GLCR_GLCL = CONVERT(int,cod_cli)      --CONVERT(int(6),'') C�digo
	, GLCR_GLLC = CONVERT(varchar(4),'00')      --CONVERT(varchar(4),'') Limite
	, GLCR_STA = CONVERT(varchar(4),'OK')      --CONVERT(varchar(4),'') Status de cr�dito
	, GLCR_MEN = CONVERT(varchar(254),'')      --CONVERT(varchar(254),'') Obs.
	, GLCR_PED = 0.00      --CONVERT(decimal(12),'') Pedidos
	, GLCR_TIT = 0.00      --CONVERT(decimal(12),'') T�tulos
	, GLCR_ADT = 0.00      --CONVERT(decimal(12),'') Adiantamentos
	, GLCR_PRI_VAL = 0.00      --CONVERT(decimal(12),'') Primeiro Faturamento
	, GLCR_PRI_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_ULT_VAL = 0.00      --CONVERT(decimal(12),'') �ltimo Faturamento
	, GLCR_ULT_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_MAI_VAL = 0.00      --CONVERT(decimal(12),'') Maior Faturamento
	, GLCR_MAI_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_ACU_VAL = 0.00      --CONVERT(decimal(12),'') Maior ac�mulo
	, GLCR_ACU_DAT = Null      --CONVERT(datetime(8),'') Em
	, GLCR_DP00 = 0      --CONVERT(int(3),'') Em dia
	, GLCR_VP00 = 0.00      --CONVERT(decimal(14),'') Total dos Pagtos.
	, GLCR_DP05 = 0      --CONVERT(int(3),'') At� 5 dias
	, GLCR_VP05 = 0.00      --CONVERT(decimal(14),'') Valor at� 5 dias
	, GLCR_DP15 = 0      --CONVERT(int(3),'') At� 15 dias
	, GLCR_VP15 = 0.00      --CONVERT(decimal(14),'') Valor at� 15 dias
	, GLCR_DP30 = 0      --CONVERT(int(3),'') At� 30 dias
	, GLCR_VP30 = 0.00      --CONVERT(decimal(14),'') Valor at� 30 dias
	, GLCR_DP60 = 0      --CONVERT(int(3),'') At� 60 dias
	, GLCR_VP60 = 0.00      --CONVERT(decimal(14),'') Valor at� 60 dias
	, GLCR_DPAC = 0      --CONVERT(int(3),'') Acima de 60 dias
	, GLCR_VPAC = 0.00      --CONVERT(decimal(14),'') Valor acima 60 dias
	, GLCR_DPNP = 0      --CONVERT(int(3),'') N�o pagas
	, GLCR_DPAM = 0.00      --CONVERT(int(3),'') Atraso m�dio (dias)
	, GLCR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLCR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLCR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLCR_DTU = Null      --CONVERT(datetime(10),'') Em
from [dbfmex]...cli, #GLPA
WHERE tipo = 'GLCL'
			and GLPA_CNPJ = CONVERT(varchar(14),ID_CLI)

INSERT INTO GLCR
SELECT distinct *
FROM #GLCR
WHERE GLCR_GLCL NOT IN (SELECT GLCR_GLCL FROM GLCR)

go
--PRINT 'GLCR'
--delete from glcr
--XXXXXXXXXXXXXXXXXXXXXXX----------------X----------XXXXXXXXXXXXXXXXXXXXXXXXX-------------

DROP TABLE #GLSHSELECT * INTO #GLSH FROM GLSH WHERE 1 = 0INSERT INTO #GLSHSELECT		GLSH_GLCL = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') Cliente
	, GLSH_GLCL_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLSH_COD = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') Cliente Destino
	, GLSH_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLSH_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLSH_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Inclus�o
	, GLSH_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLSH_DTU = Null      --CONVERT(datetime(10),'') Altera��o
FROM #GLCLINSERT INTO GLSHSELECT distinct *FROM #GLSHWHERE CONVERT(VARCHAR(6),GLSH_GLCL)+'/'+CONVERT(VARCHAR(6),GLSH_GLCL_DIG) NOT IN (SELECT CONVERT(VARCHAR(6),GLSH_GLCL)+'/'+CONVERT(VARCHAR(6),GLSH_GLCL_DIG)FROM GLSH)

go
--PRINT 'GLSH'
--XXXXXXXXXXXXXXXXXXXXXXX---------FORNECEDOR--------XXXXXXXXXXXXXXXXXXXXXXXXX-------------

DROP TABLE #GLFOSELECT * INTO #GLFO FROM GLFO WHERE 1 = 0INSERT INTO #GLFOSELECT
		GLFO_COD = CONVERT(int,COD_FOR)      --CONVERT(int(6),'') C�digo
	, GLFO_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLFO_GLPA = CONVERT(int,NUM)      --CONVERT(int(6),'') C�d.Parceiro
	, GLFO_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, GLFO_GLCP = 1      --CONVERT(int(6),'') Comprador
	, GLFO_GLCP_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLFO_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, GLFO_GLCC = Null      --CONVERT(varchar(15),'') Portador
	, GLFO_GLPG = Null      --CONVERT(varchar(6),'') Pagamento
	, GLFO_GLMD = CONVERT(varchar(8),'MXN')      --CONVERT(varchar(8),'') Moeda
	, GLFO_FPV = CONVERT(decimal,1.0)      --CONVERT(decimal(7),'') Fator pre�o
	, GLFO_VIA = CONVERT(char(1),'')      --CONVERT(char(1),'') Via Transporte
	, GLFO_BCO = Null      --CONVERT(varchar(3),'') Banco
	, GLFO_AGE = Null      --CONVERT(varchar(6),'') Ag�ncia
	, GLFO_AGE_DIG = Null      --CONVERT(char(1),'') Digito
	, GLFO_CTA = Null      --CONVERT(varchar(15),'') Conta corrente
	, GLFO_CTA_DIG = Null      --CONVERT(char(1),'') Digito
	, GLFO_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLFO_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, GLFO_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLFO_DTU = Null      --CONVERT(datetime(10),'') Em
from [dbfmex]...[FOR], #GLPA
WHERE TIPO = 'GLFO'
			AND COD_FOR = GLCL_COD
			AND 1 = GLCL_DIG
--			AND nom_for+'/'+GUE_FOR = glpa_nom+'/'+GLPA_NRDZ
			--GLPA_CNPJ = CONVERT(varchar(14),IDE_FOR)
--SELECT * FROM #GLPAINSERT INTO GLFOSELECT distinct *FROM #GLFOWHERE CONVERT(VARCHAR(6),GLFO_COD)+'/'+CONVERT(VARCHAR(6),GLFO_DIG) NOT IN (SELECT CONVERT(VARCHAR(6),GLFO_COD)+'/'+CONVERT(VARCHAR(6),GLFO_DIG)FROM GLFO)

go
--PRINT 'GLFO'
--XXXXXXXXXXXXXXXXXXXXXXX------MAPEAMENTO-CONTABIL--XXXXXXXXXXXXXXXXXXXXXXXXX-------------

--MAPEAMENTO CONT�BIL CLIENTE--O1745 O2143DROP TABLE #GLMCSELECT * INTO #GLMC FROM GLMC WHERE 1 = 0INSERT INTO #GLMCSELECT 		GLMC_TIPO = CONVERT(char(4),'GLCL')      --CONVERT(char(4),'') Tipo
	, GLMC_COD = CONVERT(int,GLCL_COD)      --CONVERT(int(6),'') C�digo
	, GLMC_DIG = CONVERT(int,GLCL_DIG)      --CONVERT(int(3),'') Digito
	, GLMC_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, GLMC_PCC1 = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR1 = CONVERT(varchar(7),CTPC_NRD)      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC2 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC3 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC4 = CONVERT(varchar(15),'5101090003')      --CONVERT(varchar(15),'') Conta Cont�bil      
	, GLMC_PCR4 = CONVERT(varchar(7),'5903')      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC5 = CONVERT(varchar(15),'4301010002')      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR5 = CONVERT(varchar(7),'4302')      --CONVERT(varchar(7),'') Rdz.      
	, GLMC_CTC1 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR1 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC2 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC3 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC4 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR4 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC5 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR5 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLMC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMC_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from ctpc, GLCL
where substring(CTPC_NRD,1,1) = 'C'
			and substring(CTPC_NRD,2,20) = glcl_cod

--EXCLUIR FORNECEDOR DUPLICADO
--2105011256 (C01256)
--C01429 (C01468)
--C01500 (C01280)

INSERT INTO #GLMCSELECT 		GLMC_TIPO = CONVERT(char(4),'GLFO')      --CONVERT(char(4),'') Tipo
	, GLMC_COD = CONVERT(int,GLFO_COD)      --CONVERT(int(6),'') C�digo
	, GLMC_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLMC_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, GLMC_PCC1 = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR1 = CONVERT(varchar(7),CTPC_NRD)      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC2 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC3 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC4 = CONVERT(varchar(15),'5101090005')      --CONVERT(varchar(15),'') Conta Cont�bil      
	, GLMC_PCR4 = CONVERT(varchar(7),'5905')      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC5 = CONVERT(varchar(15),'4301010003')      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR5 = CONVERT(varchar(7),'4303')      --CONVERT(varchar(7),'') Rdz.      
	, GLMC_CTC1 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR1 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC2 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC3 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC4 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR4 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC5 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR5 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLMC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMC_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
from ctpc, GLFO, GLPA
where GLPA_COD = GLFO_GLPA
			and substring(CTPC_NRD,1,1) = 'P'
			AND CTPC_NOM = GLPA_NOM			
ORDER BY GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM

GO
--PRINT 'GLMC'
/*
INSERT INTO #GLMCSELECT 		GLMC_TIPO = CONVERT(char(4),'GLVD')      --CONVERT(char(4),'') Tipo
	, GLMC_COD = CONVERT(int,GLVD_COD)      --CONVERT(int(6),'') C�digo
	, GLMC_DIG = CONVERT(int,1)      --CONVERT(int(3),'') Digito
	, GLMC_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, GLMC_PCC1 = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR1 = CONVERT(varchar(7),CTPC_NRD)      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC2 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC3 = Null      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC4 = CONVERT(varchar(15),'5101090005')      --CONVERT(varchar(15),'') Conta Cont�bil      
	, GLMC_PCR4 = CONVERT(varchar(7),'5905')      --CONVERT(varchar(7),'') Rdz.
	, GLMC_PCC5 = CONVERT(varchar(15),'4301010003')      --CONVERT(varchar(15),'') Conta Cont�bil
	, GLMC_PCR5 = CONVERT(varchar(7),'4303')      --CONVERT(varchar(7),'') Rdz.      
	, GLMC_CTC1 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR1 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC2 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR2 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC3 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR3 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC4 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR4 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_CTC5 = Null      --CONVERT(varchar(15),'') Centro de Custo
	, GLMC_CTR5 = Null      --CONVERT(varchar(7),'') Rdz.
	, GLMC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLMC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLMC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLMC_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
from ctpc, GLVD, GLPA
where GLPA_COD = GLVD_GLPA
			and substring(CTPC_NRD,1,1) = 'P'
			AND CTPC_NOM = GLPA_NOM			
ORDER BY GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM

GO
*/

drop table #dupli
select GLMC_TIPO, GLMC_COD,    GLMC_DIG, count(1) contador
into #dupli
from #glmc
group BY GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM
--ORDER BY count(1), GLMC_TIPO, GLMC_COD,    GLMC_DIG--GLMC_NOM
having count(1) > 1 
select * from #dupli
select a.GLMC_COD, glfo_cod, GLMC_NOM, glpa_nom
from #glmc a, #dupli b, glfo, glpa
where a.GLMC_TIPO = b.GLMC_TIPO
			and a.GLMC_COD = b.GLMC_COD
			and	a.GLMC_DIG = b.GLMC_DIG
			--and substring(GLMC_PCR1,1,1) = 'p'
			and glfo_cod = convert(int,substring(GLMC_PCR1,3,10))
			and glfo_glpa = glpa_cod

INSERT INTO GLMC
SELECT a.*
FROM #GLMC A
WHERE  a.GLMC_TIPO+'/'+CONVERT(VARCHAR(6),a.GLMC_COD)+'/'+CONVERT(VARCHAR(6),a.GLMC_DIG) NOT IN (SELECT GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG) FROM GLMC)
			AND a.GLMC_TIPO+'/'+CONVERT(VARCHAR(6),a.GLMC_COD)+'/'+CONVERT(VARCHAR(6),a.GLMC_DIG) NOT IN (SELECT GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG) FROM #dupli)

GO			
--ORDER BY GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG)

UPDATE GLCL
SET GLCL_ATV = 'S'
FROM #GLMC, GLCL
WHERE GLMC_TIPO = 'GLCL'
			AND GLMC_COD = GLCL_COD
			AND GLMC_DIG = GLCL_DIG

GO

UPDATE GLFO
SET GLFO_ATV = 'S'
FROM #GLMC a, GLFO
WHERE GLMC_TIPO = 'GLFO'
			AND GLMC_COD = GLFO_COD
			AND GLMC_DIG = GLFO_DIG
			and a.GLMC_TIPO+'/'+CONVERT(VARCHAR(6),a.GLMC_COD)+'/'+CONVERT(VARCHAR(6),a.GLMC_DIG) NOT IN (SELECT GLMC_TIPO+'/'+CONVERT(VARCHAR(6),GLMC_COD)+'/'+CONVERT(VARCHAR(6),GLMC_DIG) FROM #dupli)

GO

