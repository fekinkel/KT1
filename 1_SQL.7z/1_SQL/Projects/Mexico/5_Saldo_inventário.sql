
--Corrigir a base de Dados em DOS (Clipper)
--
	if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
		 create table [#iae] (par_erro varchar(255) )
	end
--(1487 linha(s) afetadas)
DROP TABLE #MTMVSELECT *, IDENTITY(int,1,1) NUM INTO #MTMV FROM MTMV WHERE 1 = 0INSERT INTO #MTMVSELECT 		MTMV_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') Estab.
	, MTMV_SIDO = CONVERT(varchar(4),'MTMV')      --CONVERT(varchar(4),'') Tip.Doc.
	, MTMV_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, MTMV_COD = CONVERT(int,'1')      --CONVERT(int(6),'') N�mero
	, MTMV_SEQ = CONVERT(int,'1')      --CONVERT(int(3),'') Seq.
	, MTMV_DAT = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Data
	, MTMV_MTES = CONVERT(varchar(20),REPLACE(REF,'.',''))      --CONVERT(varchar(20),'') Insumo
	, MTMV_MTTR = CONVERT(varchar(6),'AJUENT')      --CONVERT(varchar(6),'') Transa��o
	, MTMV_AUTO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Nec.Auto
	, MTMV_TRAN = CONVERT(char(1),'N')      --CONVERT(char(1),'') Transforma��o
	, MTMV_ACAO = CONVERT(char(1),'S')      --CONVERT(char(1),'') C�lculo
	, MTMV_DIRE = CONVERT(char(1),'S')      --CONVERT(char(1),'') Opera��o
	, MTMV_VLIN = CONVERT(char(1),'S')      --CONVERT(char(1),'') Inf. Valor
	, MTMV_UCIN = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ult. compra
	, MTMV_ATUM = CONVERT(char(1),'N')      --CONVERT(char(1),'') Atualiza Consumo
	, MTMV_SUCA = CONVERT(char(1),'N')      --CONVERT(char(1),'') Sucata
	, MTMV_SIDX = CONVERT(varchar(4),'INVE')      --CONVERT(varchar(4),'') Doc.Externo
	, MTMV_SISX = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�r.Ext.
	, MTMV_CODX = CONVERT(int,'201112')      --CONVERT(int(6),'') N�m.Ext.
	, MTMV_SEQX = CONVERT(int,'1')      --CONVERT(int(8),'') Seq.Ext.
	, MTMV_MTAL_ORI = CONVERT(varchar(6),'EXTCPV')      --CONVERT(varchar(6),'') Almox.Origem
	, MTMV_SUBL_ORI = CONVERT(char(1),'1')      --CONVERT(char(1),'') Sub-local O
	, MTMV_TABE_ORI = CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Tabela Origem
	, MTMV_SIDO_ORI = CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Doc.Ori.
	, MTMV_SISE_ORI = CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�r.Ori
	, MTMV_COD_ORI = 0      --CONVERT(int(6),'') N�mero Ori
	, MTMV_SEQ_ORI = 0      --CONVERT(int(3),'') Seq.Ori
	, MTMV_LOTE_ORI = CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Lote Origem
	, MTMV_CTPC_ORI = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Conta origem
	, MTMV_CTCC_ORI = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') C.Custo origem
	, MTMV_MTAL_DES = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Destino
	, MTMV_SUBL_DES = CONVERT(char(1),'1')      --CONVERT(char(1),'') Sub-local D
	, MTMV_TABE_DES = CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Tabela Destino
	, MTMV_SIDO_DES = CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Doc Des
	, MTMV_SISE_DES = CONVERT(varchar(3),'')      --CONVERT(varchar(3),'') S�r.Des
	, MTMV_COD_DES = 0      --CONVERT(int(6),'') N�mero Des
	, MTMV_SEQ_DES = 0      --CONVERT(int(3),'') Seq.Des
	, MTMV_LOTE_DES = CONVERT(varchar(20),'')      --CONVERT(varchar(20),'') Lote Destino
	, MTMV_CTPC_DES = CONVERT(varchar(15),MTTP_CTPC)      --CONVERT(varchar(15),'') Conta destino
	, MTMV_CTCC_DES = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') C.Custo destino
	, MTMV_MTAL_AUT = Null      --CONVERT(varchar(6),'') Almox.Auto
	, MTMV_QTD = ((QMER-QMSR)+SIQR)     --CONVERT(decimal(14),'') Quantidade
	, MTMV_VAL = ((VMER-VMSR)+SIVR)/GLMV_VAL      --CONVERT(decimal(14),'') Valor Total
	, MTMV_VALM = ((VMEM-VMSM)+SIVM)      --CONVERT(decimal(14),'') Valor Total M
	, MTMV_VALP = 0      --CONVERT(decimal(14),'') Valor Padr�o
	, MTMV_VALA = 0      --CONVERT(decimal(14),'') Valor Arbitrado
	, MTMV_GLHP = CONVERT(varchar(5),'021')      --CONVERT(varchar(5),'') Hist�rico
	, MTMV_MEN = UPPER(CONVERT(varchar(256),'Manual Rotaci�n de Inventarios'))      --CONVERT(varchar(256),'') Texto
	, MTMV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTMV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTMV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTMV_DTU = Null      --CONVERT(datetime(10),'') em
FROM [dbfSCD]...toq_est a, MTPR, MTTP, GLMVWHERE MTPR_COD collate SQL_Latin1_General_CP1_CI_AS = CONVERT(varchar(20),REPLACE(REF,'.',''))			AND MTPR_MTTP = MTTP_COD			AND ((QMER-QMSR)+SIQR)<>0			AND glmv_glmd = 'USD'insert into MTMVSELECT		MTMV_SIES
	, MTMV_SIDO
	, MTMV_SISE
	, MTMV_COD 
	, num 
	, MTMV_DAT 
	, MTMV_MTES
	, MTMV_MTTR
	, MTMV_AUTO
	, MTMV_TRAN
	, MTMV_ACAO
	, MTMV_DIRE
	, MTMV_VLIN
	, MTMV_UCIN
	, MTMV_ATUM
	, MTMV_SUCA
	, MTMV_SIDX
	, MTMV_SISX
	, MTMV_CODX
	, MTMV_SEQX
	, MTMV_MTAL_ORI
	, MTMV_SUBL_ORI
	, MTMV_TABE_ORI
	, MTMV_SIDO_ORI
	, MTMV_SISE_ORI
	, MTMV_COD_ORI 
	, MTMV_SEQ_ORI 
	, MTMV_LOTE_ORI
	, MTMV_CTPC_ORI
	, MTMV_CTCC_ORI
	, MTMV_MTAL_DES
	, MTMV_SUBL_DES
	, MTMV_TABE_DES
	, MTMV_SIDO_DES
	, MTMV_SISE_DES
	, MTMV_COD_DES 
	, MTMV_SEQ_DES 
	, MTMV_LOTE_DES
	, MTMV_CTPC_DES
	, MTMV_CTCC_DES
	, MTMV_MTAL_AUT
	, MTMV_QTD 
	, MTMV_VAL 
	, MTMV_VALM 
	, MTMV_VALP 
	, MTMV_VALA 
	, MTMV_GLHP 
	, MTMV_MEN 
	, MTMV_USC 
	, MTMV_DTC 
	, MTMV_USU 
	, MTMV_DTU 
from #mtmv--DELETE FROM MTMVSELECT *FROM #MTMV/*INSERT INTO MTMVSELECT *FROM #MTMVWHERE CONVERT(VARCHAR(6),MTMV_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),MTMV_GLCL)FROM MTMV)


UPDATE MTIV
SET		MTIV_QTD1 = CONVERT(decimal(12,2),(QMER-QMSR)+SIQR)      --CONVERT(decimal(14),'') Qtde 1
	, MTIV_MTA1 = MTIV_MTAL      --CONVERT(varchar(6),'') Almox. C1
	, MTIV_USU1 = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Resp. 1
	, MTIV_DAT1 = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Data 1
	, MTIV_EMI1 = CONVERT(char(1),'N')      --CONVERT(char(1),'') Cont.1 Emitida
	, MTIV_CTG2 = MTIV_CTG2      --CONVERT(char(1),'') Contagem
	, MTIV_QTD2 = CONVERT(decimal(12,2),(QMER-QMSR)+SIQR)      --CONVERT(decimal(14),'') Qtde 2
	, MTIV_MTA2 = MTIV_MTAL      --CONVERT(varchar(6),'') Almox. C2
	, MTIV_USU2 = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Resp. 2
	, MTIV_DAT2 = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Data 2
	, MTIV_EMI2 = CONVERT(char(1),'N')      --CONVERT(char(1),'') Cont.2 Emitida
FROM [dbfmex]...toq_est a, MTPR, MTIVWHERE REPLACE(REF,'.','') = MTPR_COD			AND MTPR_COD = MTIV_MTPR			AND MTIV_COD = '201110'UPDATE MTMV
SET		MTMV_VLIN = 'S'      --CONVERT(decimal(14),'') Qtde 1
	, MTMV_VAL = (VMER-VMSR)+SIVR      --CONVERT(varchar(6),'') Almox. C1
	, MTMV_VALM = (VMEM-VMSM)+SIVM      --CONVERT(varchar(15),'') Resp. 1
FROM [dbfmex]...toq_est a, MTPR, MTMVWHERE REPLACE(REF,'.','') = MTPR_COD			AND MTPR_COD = MTMV_MTESselect *FROM [dbfmex]...mtepselect (QMER-QMSR)+SIQR , (VMEM-VMSM)+SIVM, *FROM [dbfmex]...toq_estselect *from [MDL-MEX].[dbo].mttpselect *from [MDL-MEX].[dbo].mtmv*/