DROP TABLE #GLPGSELECT * INTO #GLPG FROM GLPG WHERE 1 = 0INSERT INTO #GLPGSELECT 		GLPG_COD = CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') C�digo
	, GLPG_NOM = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Nome
	, GLPG_NPAR = CONVERT(int,'1')      --CONVERT(int(3),'') N� de parcelas
	, GLPG_NPCT = CONVERT(decimal(10,2),'100')      --CONVERT(decimal(10),'') Soma do % parcelas
	, GLPG_UTIL = CONVERT(char(1),'')      --CONVERT(char(1),'') Vctos em dia �til
	, GLPG_ATVC = CONVERT(char(1),'')      --CONVERT(char(1),'') Ativa para Compras
	, GLPG_ATVV = CONVERT(char(1),'')      --CONVERT(char(1),'') Ativa para Vendas
	, GLPG_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLPG_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLPG_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLPG_DTU = Null      --CONVERT(datetime(10),'') em
INSERT INTO GLPGSELECT *FROM #GLPGWHERE GLPG_COD NOT IN (SELECT GLPG_COD FROM GLPG)




DROP TABLE #GLPPSELECT * INTO #GLPP FROM GLPP WHERE 1 = 0INSERT INTO #GLPPSELECT 		GLPP_GLPG = CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') C�digo
	, GLPP_COD = CONVERT(int,'1')      --CONVERT(int(3),'') N� Parcela
	, GLPP_DIAS = CONVERT(int,'0')      --CONVERT(int(3),'') Prazo em dias
	, GLPP_DFIX = CONVERT(int,'0')      --CONVERT(int(2),'') Vcto fixo no dia
	, GLPP_PCT = CONVERT(decimal(10,2),'0')      --CONVERT(decimal(10),'') % Parcela
	, GLPP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, GLPP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, GLPP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, GLPP_DTU = Null      --CONVERT(datetime(10),'') em
INSERT INTO GLPPSELECT *FROM #GLPPWHERE GLPP_GLPG+'/'+CONVERT(VARCHAR(6),GLPP_COD) NOT IN (SELECT GLPP_GLPG+'/'+CONVERT(VARCHAR(6),GLPP_COD) FROM GLPP)
