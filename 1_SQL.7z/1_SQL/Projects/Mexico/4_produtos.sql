--Configuration option 'Ad Hoc Distributed Queries' changed from 0 to 1. Run the RECONFIGURE statement to install.
/*
sp_configure 'show advanced options', 1;
RECONFIGURE;

sp_configure 'Ad Hoc Distributed Queries', 1;
RECONFIGURE;
*/

--Corrigir a base de Dados em DOS (Clipper)
--
	if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
		 create table [#iae] (par_erro varchar(255) )
	end

--NCM

--insert into MTNC
--select * from [dbfscd]...mtnc
--where mtnc_cod not in (select mtnc_cod from mtnc)




--delete from [DOS].[dbo].depadivi where [PRE_C�DIGO] = 'wwwww'
--REPLICATE('0',4-LEN(CONVERT(varchar(4),MAX(divisao_nova))))
drop table #div
SELECT *
--into #div
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\DLFMEX.XLS',div_lin_fam$) 
where Div is not null
			and [Div-Nome] is not null
			AND FAM IS NOT NULL

--select * from #div

DROP TABLE #MTDVSELECT * INTO #MTDV FROM MTDV WHERE 1 = 0INSERT INTO #MTDV SELECT		MTDV_COD = UPPER(CONVERT(varchar(4),div))      --CONVERT(varchar(4),'') Divis�o
	, MTDV_NOM = UPPER(CONVERT(varchar(50),[Div-Nome]))      --CONVERT(varchar(50),'') Nome
	, MTDV_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTDV_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, MTDV_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTDV_DTU = Null      --CONVERT(datetime(10),'') Em
	--select div, [Div-Nome]FROM #divGROUP BY 	Div, [Div-Nome]INSERT INTO MTDVSELECT *FROM #MTDVWHERE CONVERT(VARCHAR(6),MTDV_COD) NOT IN (SELECT CONVERT(VARCHAR(6),MTDV_COD)FROM MTDV)

GO

DROP TABLE #MTLNSELECT * INTO #MTLN FROM MTLN WHERE 1 = 0INSERT INTO #MTLNSELECT	  MTLN_MTDV = UPPER(CONVERT(varchar(4),DIV))      --CONVERT(varchar(4),'') Divis�o
	, MTLN_COD = UPPER(CONVERT(varchar(4),LIN))      --CONVERT(varchar(4),'') Linha
	, MTLN_NOM = UPPER(CONVERT(varchar(50),[LIN-NOME]))      --CONVERT(varchar(50),'') Nome
	, MTLN_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTLN_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, MTLN_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTLN_DTU = Null      --CONVERT(datetime(10),'') Em
	--SELECT Div, [Div-Nome], Lin, [Lin-Nome]		
FROM #DIVGROUP BY 	Div, [Div-Nome], Lin, [Lin-Nome]		INSERT INTO MTLNSELECT *FROM #MTLNWHERE CONVERT(VARCHAR(6),MTLN_mtdv)+'/'+CONVERT(VARCHAR(6),MTLN_cod) NOT IN (SELECT CONVERT(VARCHAR(6),MTLN_mtdv)+'/'+CONVERT(VARCHAR(6),MTLN_cod) FROM MTLN)

GO

DROP TABLE #MTFMSELECT * INTO #MTFM FROM MTFM WHERE 1 = 0INSERT INTO #MTFMSELECT DISTINCT	  MTFM_MTDV = upper(CONVERT(varchar(4),DIV))      --CONVERT(varchar(4),'') Divis�o
	, MTFM_MTLN = upper(CONVERT(varchar(4),LIN))      --CONVERT(varchar(4),'') Linha
	, MTFM_COD = UPPER(CONVERT(varchar(4),FAM))    --CONVERT(varchar(4),'') Fam�lia
	, MTFM_NOM = UPPER(CONVERT(varchar(50),ISNULL(max([FAM-NOME]),'REVISAR...')))      --CONVERT(varchar(50),'') Nome
	, MTFM_MEDI = 180      --CONVERT(int(3),'') Dias p/ M�dia
	, MTFM_EPRE = CONVERT(char(1),[EDITA_PRE�O])      --CONVERT(char(1),'') Edita pre�o
	, MTFM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTFM_DTC = CONVERT(datetime,getdate())      --CONVERT(datetime(10),'') Em
	, MTFM_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTFM_DTU = Null      --CONVERT(datetime(10),'') Em
	--SELECT Div, [Div-Nome], Lin, [Lin-Nome], FAM, [FAM-NOME], [EDITA_PRE�O]
FROM #DIVGROUP BY 	Div, [Div-Nome], Lin, [Lin-Nome], FAM, [EDITA_PRE�O]INSERT INTO MTFMSELECT *FROM #MTfmWHERE MTFM_mtdv+'/'+MTFM_MTLN+'/'+MTFM_cod NOT IN (SELECT MTFM_mtdv+'/'+MTFM_MTLN+'/'+MTFM_cod FROM MTFM)

GO
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
select *from #div--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxDROP TABLE #MTPRSELECT *, IDENTITY(INT,1,1) NUM INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT DISTINCT 
		MTPR_COD = CONVERT(varchar(20),REPLACE(REF,'.',''))      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = CONVERT(varchar(25),REPLACE(REPLACE(TIPO,'PA-Produto Acab Pinos','PA-Produto AcabADO Pinos'),'??-???','MP-MAT�RIA PRIMA'))      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = CONVERT(varchar(80),NOM_REF)      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = CONVERT(varchar(4),DIVISAO_NOVA)      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = CONVERT(varchar(4),LINHA_NOVA)      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),FAMILIA_NOVA)      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = CONVERT(varchar(3),UN_REF)      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = CONVERT(varchar(8),replace(REPLACE(NBM_REF,'.',''),'000000','00000000'))      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = CONVERT(char(1),1)      --CONVERT(char(1),'') Origem
	, MTPR_PES = CONVERT(decimal(13,2),PLQ_REF)--PLQ_REF)      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = CONVERT(varchar(240),'')      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = Null      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = CONVERT(varchar(3),UN_REF)       --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = CONVERT(decimal(10,2),1.0)     --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = CONVERT(varchar(3),UN_REF)       --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = CONVERT(decimal(10,2),1.0)      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = CONVERT(varchar(8),'5.4101')  --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = CONVERT(varchar(8),'1.5102')    --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = CONVERT(decimal(12,2),5.00)      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') Em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') Em	--SELECT *--substring(ref,1,charindex('.',(ref+'.'))-1), CONVERT(varchar(4),divisao_old), CONVERT(varchar(4),DIV_REF)FROM [dbfmex]...prod, [DOS].[DBO].[DEPADIVI]WHERE CONVERT(varchar(2), rtrim(ltrim(divisao_old))) = CONVERT(varchar(2),rtrim(ltrim(DIV_REF)))			AND CONVERT(varchar(2),rtrim(ltrim(linha_old))) = CONVERT(varchar(2),rtrim(ltrim(LIN_REF)))			and CONVERT(varchar(2),rtrim(ltrim(familia_old))) = CONVERT(varchar(2),rtrim(ltrim(FAM_REF)))			--AND SUBSTRING(REF,1,1) = 'M'			and SUBSTRING(REF,1,CHARINDEX('.',(REF+'.'))-1) = [PRE_C�DIGO]--SELECT * FROM MTESINSERT INTO MTPRSELECT MTPR_COD, MTPR_MTTP, MTPR_MS, MTPR_ATV, MTPR_NOM, MTPR_MTDV, MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES                                ,MTPR_DES                                                                                                                                                                                                                                         ,MTPR_NIV    ,MTPR_ESUN ,MTPR_ESFT                               ,MTPR_CPUN ,MTPR_CPFT                               ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE                               ,MTPR_USC        ,MTPR_DTC                ,MTPR_USU        ,MTPR_DTUFROM #MTPRWHERE CONVERT(VARCHAR(6),MTPR_cod) NOT IN (SELECT CONVERT(VARCHAR(6),MTPR_cod)FROM MTPR)
			--AND MTPR_MTNC NOT IN (SELECT MTNC_COD FROM MTNC)			--AND MTPR_MTTP NOT IN (SELECT MTTP_COD FROM MTTP)GO--B4669410 BB5012026
--}4669410 C25010008
--5786S410 P26010013

SELECT *--DELETE--UPDATE MTPR SET MTPR_ATV = 'N'FROM MTPRWHERE CONVERT(VARCHAR(6),MTPR_cod) IN (SELECT CONVERT(VARCHAR(6),MTPR_cod)FROM #MTPR)

DELETE FROM MTPC

--SELECT * FROM MTPR
--update mtpr set MTPR_MTTP = 'MP-MAT�RIA PRIMA'
--select * from [DBFMEX]...[PROD] WHERE SUBSTRING(REF,1,1) = 'B'

DROP TABLE #MTPCSELECT * INTO #MTPC FROM MTPC WHERE 1 = 0INSERT INTO #MTPCSELECT distinct		MTPC_COD = CONVERT(varchar(20),REPLACE(REF,'.',''))      --CONVERT(varchar(20),'') Refer�ncia
	, MTPC_MTPR = CONVERT(varchar(20),REPLACE(REF,'.',''))      --CONVERT(varchar(20),'') Insumo
	, MTPC_NOM = CONVERT(varchar(80),NOM_REF)      --CONVERT(varchar(80),'') Nome
	, MTPC_GLMD = CONVERT(varchar(8),'USD')      --CONVERT(varchar(8),'') Moeda
	, MTPC_PRE = CONVERT(decimal(12,2),PUN_REF)      --CONVERT(decimal(12),'') Pre�o
	, MTPC_PRE_USU = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Alterado por
	, MTPC_PRE_DTU = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPC_PREC = CONVERT(decimal(12,2),PUN_REF)      --CONVERT(decimal(12),'') Pre�o C
	, MTPC_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPC_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPC_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPC_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM [dbfmex]...prodWHERE CONVERT(varchar(20),REPLACE(REF,'.','')) in (select mtpr_cod from mtpr)			AND CONVERT(varchar(20),REPLACE(REF,'.','')) NOT IN (SELECT MTPC_COD FROM MTPC)--select MOE_REF from [dbfmex]...prod group by MOE_REFINSERT INTO MTPCSELECT *FROM #MTPCWHERE MTPC_COD NOT IN (SELECT MTPC_COD FROM MTPC)

GO

			

--select top 1 * FROM [dbfmex]...prod


DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT distinct 		MTES_MTPR = CONVERT(varchar(20),REPLACE(REF,'.',''))      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES = CONVERT(int,1)      --CONVERT(int(6),'') Estab.
	, MTES_MTAL = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP = CONVERT(varchar(6),'PROCES')      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE = CONVERT(char(1),'N')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD = CONVERT(varchar(8),'PESO')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU = 0      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU = 0      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM = 0      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS = 0      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC = 0      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO = 0      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME = 0      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR = 0      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN = 0      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ = 0      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM = 0      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI = 0      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM = 0      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL = 0      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC = 0      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO = 0      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD = 0      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM = 0      --CONVERT(int(3),'') LT Urg�ncia (dias)
	, MTES_EXPL = CONVERT(char(1),'N')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP = CONVERT(char(1),'S')      --CONVERT(char(1),'') Pol�tica
	, MTES_CREP = 0      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR = 0      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF = 0      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT = CONVERT(int,1)      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT = 0      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 = Null      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 = Null      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 = Null      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 = Null      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT = Null      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em
FROM [dbfmex]...prodWHERE CONVERT(varchar(20),REPLACE(REF,'.','')) in (select mtpr_cod from mtpr)INSERT INTO MTESSELECT *FROM #MTESWHERE MTES_MTPR+'/'+convert(varchar(1),MTES_SIES) NOT IN (SELECT MTES_MTPR+'/'+convert(varchar(1),MTES_SIES) FROM MTES)

SELECT *--DELETEFROM MTESWHERE MTES_MTPR+'/'+convert(varchar(1),MTES_SIES) IN (SELECT MTES_MTPR+'/'+convert(varchar(1),MTES_SIES) FROM #MTES)

SELECT *
FROM MTES
WHERE MTES_MTPR NOT IN (SELECT MTPR_COD FROM MTPR)


--SELECT *
UPDATE MTPR SET MTPR_ATVV = 'S', MTPR_ATV = 'S', MTPR_ATVC = 'S'
FROM MTPR
WHERE MTPR_COD IN (SELECT MTPR_COD FROM #MTPR)

UPDATE MTPR SET MTPR_MTTP = stuff(tipo,3,1,'-')
--select *
FROM MTPR, [dos].[dbo].depadivi
WHERE mtpr_mtdv = DIVISAO_NOVA 
			and mtpr_mtln = LINHA_NOVA
			and mtpr_mtfm = FAMILIA_NOVA
			AND TIPO <> '??????'
			and mtpr_cod in (select mtes_mtpr from MTES)
			


DROP TABLE #MTEPSELECT * INTO #MTEP FROM MTEP WHERE 1 = 0INSERT INTO #MTEPSELECT 		MTEP_PAI = CONVERT(varchar(20),MTPR_COD)      --CONVERT(varchar(20),'') C�digo (Pai)
	, MTEP_FIL = CONVERT(varchar(20),'A05005012')      --CONVERT(varchar(20),'') C�digo (Filho)
	, MTEP_SEQ = CONVERT(int,1)      --CONVERT(int(4),'') Sequ�ncia
	, MTEP_QTD = Null      --CONVERT(decimal(12),'') Quantidade
	, MTEP_PCT = 0.00      --CONVERT(decimal(10),'') Perda %
	, MTEP_GNEC = CONVERT(char(1),'N')      --CONVERT(char(1),'') Gera Nec.
	, MTEP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTEP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTEP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTEP_DTU = Null      --CONVERT(datetime(10),'') em
FROM MTPR, MTTP
WHERE MTPR_MTTP = MTTP_COD
			AND MTTP_ESTR = 'V'

INSERT INTO MTEPSELECT top 1 *FROM #MTEPWHERE mtep_pai+'/'+mtep_fil NOT IN (SELECT mtep_pai+'/'+mtep_fil FROM MTEP)


SELECT MTEP_PAI, MTEP_FIL, COUNT(1)FROM #MTEPgroup by MTEP_PAI, MTEP_FIL
order by COUNT(1)



--SELECT * FROM MTTP

UPDATE MTPR SET MTPR_ATV = 'S'
from MTPR
WHERE mtpr_cod in (select mtes_mtpr from MTES)

select *
FROM [dos].[dbo].depadivi
WHERE stuff(tipo,3,1,'-') not in (select mttp_cod from mttp)
			AND TIPO <> '??????'
 
*/ 

--select * from [dbfmex]...prod where ref like 'v%'
/*
drop table #new

select *, identity(int,1,1)NUM
into #new
from [dbfmex]...prod

declare
@i int

set @i = 1

while (select MAX(num) from #new) >= @i begin
	
	select * from #new where num = @i
	
	set @i = @i + 1
end 

*/

--select * from mtpr

--SELECT * FROM [DBFMEX]...[PAR] WHERE CHAVE_PAR = 'DIV'
--14348
/*
--C�DIGO DUPLICADO DOS
SELECT *--INTO #PRODFROM [DBFMEX]...[PROD]WHERE REF = 'MFR.200.050'select *from #prodDELETEFROM [DBFMEX]...[PROD]WHERE REF = 'MFR.200.050'INSERT INTO [DBFMEX]...[PROD]SELECT *FROM #PRODGROUP BY REFORDER BY COUNT(1) DESC*//*SELECT NBM_REF--UPDATE [dbfmex]...prod SET NBM_REF = '84.6694.10'FROM [dbfmex]...prodWHERE NBM_REF LIKE '%}%'			OR NBM_REF LIKE '%S%'*/


