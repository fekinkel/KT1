select *
--update mtpr set mtpr_mttp = upper(rtrim(ltrim(mtpr_mttp)))
from MTPR
where MTPR_COD like 'S11%'

select *
--update mtpr set MTPR_CFOV = '5.4101'
from MTPR
where MTPR_ATVV = 's'

select *
--update mtpr set MTPR_CFOC = '1.5102'
from MTPR
where MTPR_ATVC = 's'


SELECT substring(PRE_C�DIGO,2,15), substring(DIVISAO_OLD,2,2), substring(LINHA_OLD,2,2) , substring(FAMILIA_OLD,2,2), REPLICATE('0',4-len(substring(DIVISAO_NOVA,2,4)))+rtrim(ltrim(substring(DIVISAO_NOVA,2,4))), REPLICATE('0',4-LEN(substring(LINHA_NOVA,2,4)))+RTRIM(ltrim(substring(LINHA_NOVA,2,4))), REPLICATE('0',4-LEN(substring(FAMILIA_NOVA,2,4)))+LTRIM(rtrim(substring(FAMILIA_NOVA,2,4))), substring(stuff(F8,4,1,'-'),2,30) MTTP_NEW
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=c:\bkp\divisao_mex.XLS',sheet3$), mttp
where [PRE_C�DIGO] <> 'wwwwww'
			and substring(stuff(F8,4,1,'-'),2,30) = MTTP_cod
