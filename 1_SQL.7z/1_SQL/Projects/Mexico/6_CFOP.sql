DROP TABLE #NFOPSELECT * INTO #NFOP FROM NFOP WHERE 1 = 0INSERT INTO #NFOPSELECT 		NFOP_COD = CONVERT(varchar(8),'1.'+CTPC_NRD)      --CONVERT(varchar(8),'') C�digo
	, NFOP_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, NFOP_CODF = CONVERT(varchar(8),'1.'+CTPC_NRD)      --CONVERT(varchar(8),'') CFOP
	, NFOP_NOMF = CONVERT(varchar(150),CTPC_NOM)      --CONVERT(varchar(150),'') Nome Fiscal
	, NFOP_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, NFOP_TIT = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera t�tulos
	, NFOP_MTTR = CONVERT(varchar(6),'NA')      --CONVERT(varchar(6),'') Transa��o
	, NFOP_IPI_INC = CONVERT(char(1),'3')      --CONVERT(char(1),'') Incid�ncia IPI
	, NFOP_ISS_INC = CONVERT(char(1),'3')      --CONVERT(char(1),'') Incid�ncia ISS
	, NFOP_ISS_PCT = 0.00      --CONVERT(numeric(6),'') % ISS
	, NFOP_ICM_TBB = CONVERT(varchar(2),'00')      --CONVERT(varchar(2),'') Tabela B
	, NFOP_ICM_INC = CONVERT(char(1),'1')      --CONVERT(char(1),'') Incid�ncia ICM
	, NFOP_ICM_TAB = CONVERT(varchar(4),'A')      --CONVERT(varchar(4),'') Tabela ICM
	, NFOP_ICM_BAS = 100.00      --CONVERT(numeric(5),'') Base de ICM
	, NFOP_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, NFOP_MEN = CONVERT(varchar(255),'')      --CONVERT(varchar(255),'') Mensagem
	, NFOP_PIS_INC = CONVERT(char(1),'N')      --CONVERT(char(1),'') Incid�ncia PIS
	, NFOP_COF_INC = CONVERT(char(1),'N')      --CONVERT(char(1),'') Incid�ncia COFINS
	, NFOP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, NFOP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, NFOP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, NFOP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM CTPCWHERE (CTPC_NRD >= '5523'			AND CTPC_NRD <= '5527')			OR(CTPC_NRD >= '5531'			AND CTPC_NRD <= '5598')			OR(CTPC_NRD >= '5623'			AND CTPC_NRD <= '5650')			OR(CTPC_NRD >= '1301'			AND CTPC_NRD <= '1306')			OR(CTPC_NRD >= '1600'			AND CTPC_NRD <= '1600')			OR(CTPC_NRD >= '1500'			AND CTPC_NRD <= '1500')INSERT INTO #NFOPSELECT 		NFOP_COD = CONVERT(varchar(8),'2.'+CTPC_NRD)      --CONVERT(varchar(8),'') C�digo
	, NFOP_NOM = CONVERT(varchar(50),CTPC_NOM)      --CONVERT(varchar(50),'') Nome
	, NFOP_CODF = CONVERT(varchar(8),'1.'+CTPC_NRD)      --CONVERT(varchar(8),'') CFOP
	, NFOP_NOMF = CONVERT(varchar(150),CTPC_NOM)      --CONVERT(varchar(150),'') Nome Fiscal
	, NFOP_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, NFOP_TIT = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera t�tulos
	, NFOP_MTTR = CONVERT(varchar(6),'NA')      --CONVERT(varchar(6),'') Transa��o
	, NFOP_IPI_INC = CONVERT(char(1),'3')      --CONVERT(char(1),'') Incid�ncia IPI
	, NFOP_ISS_INC = CONVERT(char(1),'3')      --CONVERT(char(1),'') Incid�ncia ISS
	, NFOP_ISS_PCT = 0.00      --CONVERT(numeric(6),'') % ISS
	, NFOP_ICM_TBB = CONVERT(varchar(2),'00')      --CONVERT(varchar(2),'') Tabela B
	, NFOP_ICM_INC = CONVERT(char(1),'1')      --CONVERT(char(1),'') Incid�ncia ICM
	, NFOP_ICM_TAB = CONVERT(varchar(4),'A')      --CONVERT(varchar(4),'') Tabela ICM
	, NFOP_ICM_BAS = 100.00      --CONVERT(numeric(5),'') Base de ICM
	, NFOP_REV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Destina��o
	, NFOP_MEN = CONVERT(varchar(255),'')      --CONVERT(varchar(255),'') Mensagem
	, NFOP_PIS_INC = CONVERT(char(1),'N')      --CONVERT(char(1),'') Incid�ncia PIS
	, NFOP_COF_INC = CONVERT(char(1),'N')      --CONVERT(char(1),'') Incid�ncia COFINS
	, NFOP_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, NFOP_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, NFOP_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, NFOP_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM CTPCWHERE (CTPC_NRD >= '5523'			AND CTPC_NRD <= '5527')			OR(CTPC_NRD >= '5531'			AND CTPC_NRD <= '5598')			OR(CTPC_NRD >= '5623'			AND CTPC_NRD <= '5650')			OR(CTPC_NRD >= '1301'			AND CTPC_NRD <= '1306')			OR(CTPC_NRD >= '1600'			AND CTPC_NRD <= '1600')			OR(CTPC_NRD >= '1500'			AND CTPC_NRD <= '1500')INSERT INTO NFOPSELECT *FROM #NFOPWHERE CONVERT(VARCHAR(6),NFOP_COD) NOT IN (SELECT CONVERT(VARCHAR(6),NFOP_COD)FROM NFOP)


DROP TABLE #NFOMSELECT * INTO #NFOM FROM NFOM WHERE 1 = 0INSERT INTO #NFOMSELECT 		NFOM_NFOP = CONVERT(varchar(8),nfop_cod)      --CONVERT(varchar(8),'') Opera��o
	, NFOM_COD = CONVERT(varchar(20),'PRINCIPAL')      --CONVERT(varchar(20),'') Express�o
	, NFOM_GLHP = Null      --CONVERT(varchar(5),'') Hist�rico
	, NFOM_MAC1 = Null      --CONVERT(varchar(15),'') Macro 1
	, NFOM_MAC2 = Null      --CONVERT(varchar(15),'') Macro 2
	, NFOM_MAC3 = Null      --CONVERT(varchar(15),'') Macro 3
	, NFOM_PCCD = CONVERT(varchar(15),CTPC_COD)      --CONVERT(varchar(15),'') Conta d�bito
	, NFOM_PCRD = CONVERT(varchar(7),SUBSTRING(nfop_cod,3,4))      --CONVERT(varchar(7),'') Rdz
	, NFOM_CTCD = Null      --CONVERT(varchar(15),'') CC d�bito
	, NFOM_CTRD = Null      --CONVERT(varchar(7),'') Rdz
	, NFOM_PCCC = Null      --CONVERT(varchar(15),'') Conta cr�dito
	, NFOM_PCRC = Null      --CONVERT(varchar(7),'') Rdz
	, NFOM_CTCC = Null      --CONVERT(varchar(15),'') CC cr�dito
	, NFOM_CTRC = Null      --CONVERT(varchar(7),'') Rdz
	, NFOM_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, NFOM_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, NFOM_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, NFOM_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM #NFOP, CTPCWHERE '1.'+CTPC_NRD = nfop_cod			or '2.'+CTPC_NRD = nfop_codINSERT INTO NFOMSELECT *FROM #NFOMWHERE NFOM_NFOP+'/'+NFOM_COD NOT IN (SELECT NFOM_NFOP+'/'+NFOM_COD FROM NFOM)--DELETE NFOP FROM NFOP A, #NFOP B WHERE 


DROP TABLE #MTPRSELECT * INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD = CONVERT(varchar(20),'GEN'+SUBSTRING(nfop_cod,3,4))      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = CONVERT(varchar(25),'DE-DESPESAS')      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = CONVERT(varchar(80),nfop_NOM)      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = CONVERT(varchar(4),'9999')      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = CONVERT(varchar(4),'9999')      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),'9999')      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = CONVERT(varchar(3),'PZ')      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = CONVERT(varchar(8),'99999999')      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, MTPR_PES = CONVERT(decimal,'0')      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = CONVERT(varchar(240),'')      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = 0      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = CONVERT(varchar(3),'PZ')      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = 1.00      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = CONVERT(varchar(3),'PZ')      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = 1.00      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = NULL--CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = CONVERT(varchar(8),nfop_cod)      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = CONVERT(decimal,5)      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM #NFOPINSERT INTO MTPRSELECT *FROM #MTPRWHERE MTPR_COD NOT IN (SELECT MTPR_COD FROM MTPR)

--DELETE MTPR FROM #MTPR A, MTPR B WHERE A.MTPR_COD = B.MTPR_COD

DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = CONVERT(varchar(20),'GEN'+SUBSTRING(nfop_cod,3,4))      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') Estab.
	, MTES_MTAL = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN = CONVERT(varchar(6),'ALMO01')      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP = CONVERT(varchar(6),'PROCES')      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE = CONVERT(char(1),'N')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD = CONVERT(varchar(8),'MXN')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU = 0      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU = 0      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM = 0      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS = 0      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC = 0      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO = 0      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME = 0      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR = 0      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN = 0      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ = 0      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM = 0      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI = 0      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM = 0      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL = 0      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC = 0      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO = CONVERT(varchar(25),'')      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD = 0      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM = 0      --CONVERT(int(3),'') LT Urg�ncia (dias)
	, MTES_EXPL = CONVERT(char(1),'N')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP = CONVERT(char(1),'N')      --CONVERT(char(1),'') Pol�tica
	, MTES_CREP = 0      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR = 0      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF = 0      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT = CONVERT(int,'1')      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT = 0      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 = CONVERT(varchar(50),'')      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT = CONVERT(varchar(50),'')      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em

FROM #NFOPINSERT INTO MTESSELECT *FROM #MTESWHERE MTES_MTPR+'/'+CONVERT(VARCHAR(2),MTES_SIES) NOT IN (SELECT MTES_MTPR+'/'+CONVERT(VARCHAR(2),MTES_SIES) FROM MTES)

--DELETE MTes FROM #MTes A, MTes B WHERE A.mtes_MTPR = B.mtes_MTPR


UPDATE MTPR SET MTPR_ATV = 'S'
FROM #MTPR A, MTPR B 
WHERE A.MTPR_COD = B.MTPR_COD


DROP TABLE #NFIASELECT * INTO #NFIA FROM NFIA WHERE 1 = 0INSERT INTO #NFIASELECT 		NFIA_NFIC = CONVERT(varchar(4),'A')      --CONVERT(varchar(4),'') ICMS
	, NFIA_GLPS_ORI = CONVERT(varchar(3),a.GLUF_GLPS)      --CONVERT(varchar(3),'') Pa�s Origem
	, NFIA_GLUF_ORI = CONVERT(varchar(2),a.GLUF_COD)      --CONVERT(varchar(2),'') U.F. origem
	, NFIA_GLPS_DES = CONVERT(varchar(3),b.GLUF_GLPS)      --CONVERT(varchar(3),'') Pa�s destino
	, NFIA_GLUF_DES = CONVERT(varchar(2),b.GLUF_COD)      --CONVERT(varchar(2),'') U.F. destino
	, NFIA_PCT = Null      --CONVERT(decimal(6),'') Al�quota
	, NFIA_PCTC = Null      --CONVERT(decimal(6),'') %ICMS Complem.
	, NFIA_MEN = Null      --CONVERT(varchar(80),'') Mensagem fiscal
	, NFIA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, NFIA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, NFIA_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, NFIA_DTU = Null      --CONVERT(datetime(10),'') em
--select *
FROM GLUF a, GLUF bWHERE a.GLUF_GLPS = 'MEX'			and b.GLUF_GLPS = 'MEX'INSERT INTO NFIASELECT *FROM #NFIAWHERE NFIA_NFIC+'/'+NFIA_GLPS_ORI+'/'+NFIA_GLUF_ORI+'/'+NFIA_GLPS_DES+'/'+NFIA_GLUF_DES NOT IN (SELECT NFIA_NFIC+'/'+NFIA_GLPS_ORI+'/'+NFIA_GLUF_ORI+'/'+NFIA_GLPS_DES+'/'+NFIA_GLUF_DES FROM NFIA)
