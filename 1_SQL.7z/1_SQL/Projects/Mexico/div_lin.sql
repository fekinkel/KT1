--select * from divlinfam_bra
--Divis�o linha e Familia Pun��o

drop table #new
drop table #linfam



select IDENTITY(int,1,1) num,*
into #new
from divlinfam_bra
where [Divis�o 3500 = Pun��es e Matrizes(Futuro)] is not null


declare
@i int,
@div char(4),
@lin char(4),
@lin_old char(4),
@fam char(4),
@tipo varchar(12),
@nome varchar(150)
set @i = 1
set @lin_old = 'wwww'
set @lin = 'qqqq'

select @lin [lin], @fam [fam], 'wwwwwwww' [desc], 'ww' [lin_old], 'ww' [fam_old]
into #linfam
where 1 = 0

while (select max(num) from #new) > @i begin

	if (@lin <> @lin_old) or (select charindex('linha',[Divis�o 3500 = Pun��es e Matrizes(Futuro)],1) from #new where num =@i)> 0 begin
	
		select @lin=substring([Divis�o 3500 = Pun��es e Matrizes(Futuro)], charindex('Linha',[Divis�o 3500 = Pun��es e Matrizes(Futuro)],1)+6,4) 
		from #new 
		where num =@i
		-- from #new		where num = @i
		set @lin_old = @lin
		set @fam=''
		set @nome=''
	end else if (select charindex('familia',[Divis�o 3500 = Pun��es e Matrizes(Futuro)],1) from #new where num =@i)> 0 begin
		select	@fam=substring([Divis�o 3500 = Pun��es e Matrizes(Futuro)], charindex('familia',[Divis�o 3500 = Pun��es e Matrizes(Futuro)],1)+8,4),
						@nome=substring([Divis�o 3500 = Pun��es e Matrizes(Futuro)], charindex('.',[Divis�o 3500 = Pun��es e Matrizes(Futuro)],1)-4,150)
		from #new 
		where num =@i
		if CHARINDEX('.',@nome,1)=0 begin
			set @tipo = reverse(@nome)
			if charindex(' ',@tipo) > 0 begin
				set @tipo = reverse(SUBSTRING(@tipo,1,charindex(' ',@tipo)-1))
			end else set @tipo = REVERSE(@tipo)
			insert into #linfam
			select @lin, @fam, @tipo, '',''
		end
		
		while CHARINDEX('.',@nome,1)>0 begin
			if CHARINDEX('.',@nome)>0 begin
				print 'indice '+convert(varchar(3),CHARINDEX('.',@nome))
				set @tipo = rtrim((substring(@nome,1,CHARINDEX('.',@nome)-1)))
				print 'Tipo '+@tipo
			end else set @tipo = @nome
			print 'Inicio '+@tipo+' nome:='+@nome
			set @tipo = REVERSE(@tipo)
			if charindex(' ',@tipo) > 0 begin
				set @tipo = reverse(SUBSTRING(@tipo,1,charindex(' ',@tipo)-1))
			end else set @tipo = REVERSE(@tipo)
			set @nome = substring(@nome,CHARINDEX('.',@nome)+1,100)
			
			insert into #linfam
			select @lin, @fam, @tipo,'',''
		
		end 
		--select @lin, @fam, @tipo
		print '------------------------------------- fim --------------------------------------------------'
		-- from #new		where num = @i
		set @lin_old = @lin	
	end
	print 'Linha := '+@lin
	print 'Fam�lia:= '+@fam
	print 'Desc:= '+@nome
	set @i = @i + 1
end

select *
from [dbfmex]...prod b
where ref like 'PSMB%'


select distinct convert(char(4),replace(replace(DIV_REF,'7','3500'),'8','3600')) [div], a.*, DIV_REF, LIN_REF, FAM_REF
into depara_divlinfan
from #linfam a, [dbfmex]...prod b
where substring(ref,1,charindex('.',ref+'.')-1) like [desc]
			--and ref like 'PSMB%'
