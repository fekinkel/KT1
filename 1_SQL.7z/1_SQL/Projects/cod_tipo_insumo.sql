
drop table #cod
select convert(varchar(6),substring(f1,1,charindex('.',f1)-1)) Cod, 'PI-PRODUCTO INTERMEDIO' tipointo #codFROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\kits_M�xico.XLS',kitsgrampos$) 
where f1 is not null and f3 is not null
group by substring(f1,1,charindex('.',f1)-1)

insert into #cod
select substring([C�digo do Kit Tipo-1 MM],1,charindex('.',[C�digo do Kit Tipo-1 MM])-1), 'PI-PRODUCTO INTERMEDIO'FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\kits_M�xico.XLS',kitsColares$) 
where [C�digo do Kit Tipo-1 MM] is not null and f3 is not null
group by substring([C�digo do Kit Tipo-1 MM],1,charindex('.',[C�digo do Kit Tipo-1 MM])-1)

insert into #cod
select substring([C�digo],1,charindex('.',[C�digo])-1), 'PI-PRODUCTO INTERMEDIO'FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\kits_M�xico.XLS',cjpb$) 
where [C�digo] is not null and f4 is not null
group by substring([C�digo],1,charindex('.',[C�digo])-1)

insert into #cod
select substring([C�digo],1,charindex('.',[C�digo])-1), 'PI-PRODUCTO INTERMEDIO'FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\kits_M�xico.XLS',cjce$) 
where [C�digo] is not null and f4 is not null
group by substring([C�digo],1,charindex('.',[C�digo])-1)

insert into #cod
select [tipo], 'PI-PRODUCTO INTERMEDIO'FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\kits_M�xico.XLS',ResumoKitsPol$) 
where [Tipo] is not null and [Di�metros (pol)] is not null and [tipo] <> 'tipo'
group by [tipo]--substring([Tipo],1,charindex('.',[Tipo])-1)

insert into #cod
select [tipo], 'PI-PRODUCTO INTERMEDIO'FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\kits_M�xico.XLS',ResumoKitsmm$) 
where [Tipo] is not null and [Di�metros (mm)] is not null and [tipo] <> 'tipo'
group by [tipo]--substring([Tipo],1,charindex('.',[Tipo])-1)


select convert(varchar(10),Pref), convert(varchar(20),[Fam-Nome]), isnull(tipo, 'PA-PRODUCTO ACABADO')FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0',
'EXCEL 8.0;Database=D:\disco_j\Excel\dlfmex.XLS',Div_lin_fam$) a left outer join #cod b on a.Pref = b.cod
where Div is not null and Lin is not null
			

