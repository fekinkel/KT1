print 'BALL BEARING COMPONENTS'


select MTPC_COD [Part#], convert(char(50),MTPC_NOM) [descri��o], convert(char(16),replace(MTPC_PRE,'.',',')) [pre�o de vendas], MTPR_MTDV [Divis�o], MTPR_MTLN [Linha], MTPR_MTFM [Fam�lia]
from mtpc, mtpr
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'S'
			and (substring(MTPC_COD,7,20) not like ('%c%')
			and substring(MTPC_COD,7,20) not like ('%s%')
			and substring(MTPC_COD,7,20) not like ('%u%')
			and substring(MTPC_COD,7,20) not like ('%n%')
			and substring(MTPC_COD,7,20) not like ('%-1%'))
			and SUBSTRING(mtpc_cod,1,3) in('P17', 'P26', 'B35', 'B46', 'C25', 'C26')

--select * from MTPR where MTPR_COD = 'p16010020'

print 'PLAIN BEARING COMPONENTS'

select MTPC_COD [Part#], convert(char(50),MTPC_NOM) [descri��o], convert(char(16),replace(MTPC_PRE,'.',',')) [pre�o de vendas], MTPR_MTDV [Divis�o], MTPR_MTLN [Linha], MTPR_MTFM [Fam�lia]
from mtpc, mtpr
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'S'
			and (substring(MTPC_COD,7,20) not like ('%c%')
			and substring(MTPC_COD,7,20) not like ('%s%')
			and substring(MTPC_COD,7,20) not like ('%u%')
			and substring(MTPC_COD,7,20) not like ('%n%')
			and substring(MTPC_COD,7,20) not like ('%-1%'))
			and SUBSTRING(mtpc_cod,1,3) in('P16','P36','B16','B26','B18','B28','X15','X16','X18')

print 'METRIC COMPONENTS'

select MTPC_COD [Part#], convert(char(50),MTPC_NOM) [descri��o], convert(char(16),replace(MTPC_PRE,'.',',')) [pre�o de vendas], MTPR_MTDV [Divis�o], MTPR_MTLN [Linha], MTPR_MTFM [Fam�lia]
from mtpc, mtpr
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'S'
			and (substring(MTPC_COD,7,20) not like ('%c%')
			and substring(MTPC_COD,7,20) not like ('%s%')
			and substring(MTPC_COD,7,20) not like ('%u%')
			and substring(MTPC_COD,7,20) not like ('%n%')
			and substring(MTPC_COD,7,20) not like ('%-1%'))
			and SUBSTRING(mtpc_cod,1,3) in('P11','P21','P22','B11','B21','B13','B23','B30','B41','B43','C11','C12','C13','X05','X06','X07','X08')			

print 'BALL BEARING COMPONENTS "L" STYLE'

select MTPC_COD [Part#], convert(char(50),MTPC_NOM) [descri��o], convert(char(16),replace(MTPC_PRE,'.',',')) [pre�o de vendas], MTPR_MTDV [Divis�o], MTPR_MTLN [Linha], MTPR_MTFM [Fam�lia]
from mtpc, mtpr
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'S'
			and (substring(MTPC_COD,7,20) not like ('%c%')
			and substring(MTPC_COD,7,20) not like ('%s%')
			and substring(MTPC_COD,7,20) not like ('%u%')
			and substring(MTPC_COD,7,20) not like ('%n%')
			and substring(MTPC_COD,7,20) not like ('%-1%'))
			and SUBSTRING(mtpc_cod,1,3) in('PP5','PD6','BB5','BC6','CR6')

print 'SPRING'

select MTPC_COD [Part#], convert(char(50),MTPC_NOM) [descri��o], convert(char(16),replace(MTPC_PRE,'.',',')) [pre�o de vendas], MTPR_MTDV [Divis�o], MTPR_MTLN [Linha], MTPR_MTFM [Fam�lia]
from mtpc, mtpr
where MTPC_MTPR = MTPR_COD
			and MTPR_ATVV = 'S'
			and (substring(MTPC_COD,7,20) not like ('%c%')
			and substring(MTPC_COD,7,20) not like ('%s%')
			and substring(MTPC_COD,7,20) not like ('%u%')
			and substring(MTPC_COD,7,20) not like ('%n%')
			and substring(MTPC_COD,7,20) not like ('%-1%'))
			and SUBSTRING(mtpc_cod,1,3) in('SSR','SSG','SSY','SSB')

