select *
--delete
from mtpv
where convert(char(10), MTPV_DTC, 102) = '2011.03.25'
			
select convert(varchar(2),MTPV_MTPU)+'/'+rtrim(ltrim(MTPV_MTTV)) 
from mtpv
where convert(varchar(2),MTPV_MTPU)+'/'+rtrim(ltrim(MTPV_MTTV)) = '3/00004470'