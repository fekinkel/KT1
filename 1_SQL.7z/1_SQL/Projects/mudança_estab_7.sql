insert into mttr
select 7 MTTR_SIES   ,MTTR_COD ,MTTR_NOM                                                                         ,MTTR_MTAL_ORI ,MTTR_SUBL_ORI ,MTTR_MTAL_DES ,MTTR_SUBL_DES ,MTTR_AUTO ,MTTR_TRAN ,MTTR_ACAO ,MTTR_DIRE ,MTTR_VLIN ,MTTR_UCIN ,MTTR_ATUM ,MTTR_SUCA ,MTTR_MTAL_AUT ,MTTR_GLHP ,MTTR_CTPC_ORI   ,MTTR_CTCC_ORI   ,MTTR_CTPC_DES   ,MTTR_CTCC_DES   ,MTTR_DTC                ,MTTR_USC        ,MTTR_DTU                ,MTTR_USU
from mttr
where mttr_sies  = 1
			and MTTR_MTAL_ORI in (select mtal_cod from mtal where mtal_sies  = 7)

insert into mtal
select 7 MTAL_SIES   ,MTAL_COD ,MTAL_NOM                                           ,MTAL_FISI ,MTAL_VMRP ,MTAL_SALC ,MTAL_SUBL ,MTAL_LOTC ,MTAL_INV ,MTAL_STAT ,MTAL_CTPC       ,MTAL_CTCC       ,MTAL_USC        ,MTAL_DTC                ,MTAL_USU        ,MTAL_DTU
from mtal
where mtal_sies = 1


insert into mtes
select MTES_MTPR            , 7 MTES_SIES   ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU                               ,MTES_VATU                               ,MTES_VATM                               ,MTES_QVIS                               ,MTES_QNEC                               ,MTES_QPRO                               ,MTES_PCME                               ,MTES_PCMR                               ,MTES_PMIN   ,MTES_POBJ   ,MTES_PPMI                               ,MTES_PLEM                               ,MTES_PMUL                               ,MTES_PLEC                               ,MTES_UCDO                 ,MTES_LEAD   ,MTES_EXPL ,MTES_MRP ,MTES_CREP                               ,MTES_CPDR                               ,MTES_FGGF                               ,MTES_FRAT   ,MTES_CTGT                               ,MTES_CPO1                                          ,MTES_CPO2                                          ,MTES_CPO3                                          ,MTES_CPO4                                          ,MTES_PRAT            ,MTES_USC        ,MTES_DTC                ,MTES_USU        ,MTES_DTU
from mtes
where mtes_sies = 1

insert into prgt
select 7 PRGT_SIES   ,PRGT_COD ,PRGT_NOM                                           ,PRGT_GLDP       ,PRGT_CTCC       ,PRGT_CTCR ,PRGT_USC        ,PRGT_DTC                ,PRGT_USU        ,PRGT_DTU
from prgt
where prgt_sies  = 1

insert into prjo
select PRJO_COD , 7 PRJO_SIES   ,PRJO_NOM                                           ,PRJO_DIA1                               ,PRJO_DIA2                               ,PRJO_DIA3                               ,PRJO_DIA4                               ,PRJO_DIA5                               ,PRJO_DIA6                               ,PRJO_DIA7                               ,PRJO_USC        ,PRJO_DTC                ,PRJO_USU        ,PRJO_DTU
from prjo
where prjo_sies = 1

insert into prct
select 7 PRCT_SIES   ,PRCT_COD ,PRCT_NOM                                           ,PRCT_PRGT ,PRCT_TIPO ,PRCT_TMAX                               ,PRCT_TNOR                               ,PRCT_VMAX                               ,PRCT_PMAX                               ,PRCT_POT                                ,PRCT_UNCT ,PRCT_CFIX       ,PRCT_CVAR       ,PRCT_MEMO                                                                                                                                                                                                                                                        ,PRCT_USC        ,PRCT_DTC                ,PRCT_USU        ,PRCT_DTU                ,PRCT_PRJO
from prct
where prct_sies  = 1

insert into prop
select 7 PROP_SIES   ,PROP_COD ,PROP_NOM                                           ,PROP_TIPO ,PROP_ORDE ,PROP_USC        ,PROP_DTC                ,PROP_USU        ,PROP_DTU
from prop
where prop_sies  = 1

insert into prra
select PRRA_MTPR            , 7 PRRA_SIES   ,PRRA_COD    ,PRRA_DEFA ,PRRA_TTOT                               ,PRRA_MEMO                                                                                                                                                                                                                                                        ,PRRA_USC        ,PRRA_DTC                ,PRRA_USU        ,PRRA_DTU
from prra
where prra_sies = 1
