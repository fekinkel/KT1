select substring(b.tipo,2,1), *
--into sioi_new
--update sioi set SIOI_NOM = convert(varchar(50),rtrim(tipo)+rtrim(b.SIOI_NOM))
--update sioi set SIOI_NOM = convert(varchar(50),b.SIOI_NOM)
from sioi a, [dos].[dbo].SIOI_New b
where a.SIOI_SIOP = b.SIOI_SIOP
			and substring(b.tipo,2,1) = '.'
			
select *
from [dos].[dbo].SIOI_New
--2096

--					SIOI_SIOP_New        SIOI_NOM_New
--insert into [dos].[dbo].SIOI_New
select	*,	space(16)
from SIOI
where  SIOI_SIOP not in (select SIOI_SIOP from [dos].[dbo].SIOI_New)
--2135

--select * from sioi where sioi_nom like 'pa�ses'