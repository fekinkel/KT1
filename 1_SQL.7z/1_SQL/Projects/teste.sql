declare
@msg varchar(4000),
@campos varchar(4000),
@tabela varchar(20)

set @tabela = 'glpr'

set @campos=' '

--select @campos = @campos+b.name +', ' 
select @campos = @campos+replace(replace(replace(replace(b.name, '_DTU', ', null '+b.name),'_USU', ' null '+b.name), '_USC', ''' SISTEMA '''+b.name), '_DTC', ' getdate() '+b.name) +', ' 
--select @campos = @campos+b.name +', ' 
from sysobjects a, syscolumns b
where a.name = @tabela
			and a.id = b.id

set @campos = SUBSTRING(@campos,1,len(@campos)-1)
print 'Campos:='+@campos
set @msg = 
'select ' +char(39)+ 'INSERT INTO'+CHAR(39)+' + '+char(39)+' '+upper(@tabela)+CHAR(39)+@campos+CHAR(10)+
'from '+ @tabela

print @msg

exec (@msg)

--insert into SIES
--select 77, 'NOVO', '', '', 'Endere�o novo', 100, '', 'N�o sei', '', 'in', 'USA', '11111111', null, null, null, null, 'LR', 'MDL_NOVA', null, null, null, 0, 'N', '', null, null, '00', 'KINKEL', GETDATE(), null, null

--USE [MDL-USA]
select 'INSERT INTO' + ' SIES'
from SIES

select SIES_COD ,','--+ SIES_NOM+ SIES_CNPJ+ SIES_IE+ SIES_END+ SIES_NUME+ SIES_COMP+ SIES_BAI+ SIES_CID+ SIES_GLUF+ SIES_GLPS+ SIES_CEP+ SIES_TEL+ SIES_FAX+ SIES_SITE+ SIES_EMAIL+ SIES_REGI+ SIES_NRDZ+ SIES_GLMN+ SIES_SUFR+ SIES_IMU+ SIES_ATIV+ SIES_ESP+ SIES_NIRE+ SIES_NIRE_DAT+ SIES_CNAE+ SIES_NATPJ+ SIES_USC+ SIES_DTC+ SIES_USU+ SIES_DTU
from SIES

--INSERT INTO GLPR select(B2              *************** Unidade de Comando Unilog B2                                                                                                                                                                                                                                    0.0000                                  B2                                                 MAURY           2005-06-08 00:00:00.000                 2005-06-09 00:00:00.000