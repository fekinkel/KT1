select *, identity(int,1,1) num
into #n
from cpct
--where CPCT_GLXX in (3383,4436,4826,2630,3209,326)
where CPCT_GLXX in (5038)
			and CPCT_STA  = 'OK'
			and cpct_sies = 1

insert into cpct
select 7 CPCT_SIES   ,CPCT_SIDO ,CPCT_SISE , 62+num CPCT_COD    ,CPCT_STA ,CPCT_CPSC_SIES ,CPCT_CPSC_SIDO ,CPCT_CPSC_SISE ,CPCT_CPSC_NPAI ,CPCT_CPSC   ,CPCT_MTPR            ,CPCT_MTPC            ,CPCT_ESPE                                                                                                                                                                                                                                                        ,CPCT_GLTX ,CPCT_GLXX   ,CPCT_GLXX_DIG ,CPCT_GLXX_GLPA ,CPCT_GLXX_NRDZ  ,CPCT_REV ,CPCT_QTD                                ,CPCT_QTD_GLFO                           ,CPCT_CTO                  ,CPCT_TEL                  ,CPCT_FAX                  ,CPCT_EMAIL                                         ,CPCT_GLCP   ,CPCT_CPID            ,CPCT_CPUN ,CPCT_CPFT                               ,CPCT_PUN                                ,CPCT_PUN_GLFO                           ,CPCT_PUND                               ,CPCT_PUND_GLFO                          ,CPCT_VACT   ,CPCT_GLMD ,CPCT_IPI_ALI                            ,CPCT_ISS_ALI                            ,CPCT_ICM_ALI                            ,CPCT_VALT                               ,CPCT_GLPG ,CPCT_PENT   ,CPCT_DOCF            ,CPCT_OBS                                                                                                                                                                                                                                                        ,CPCT_USC        ,CPCT_DTC                ,CPCT_USU        ,CPCT_DTU                ,CPCT_CPID_NOM
from #n
			
drop table #n
