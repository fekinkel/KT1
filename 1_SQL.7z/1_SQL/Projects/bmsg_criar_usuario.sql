declare @i int

select 'teste', convert(bit,'false')

exec @i = bmsg_cria_usua 2, 'kinkel', '192.168.2.85', 5225, 'notecpd', 'fernando kinkel serejo', 'gsistemas', 'mq'

select @i