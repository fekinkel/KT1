SELECT *
--update mtiv set MTIV_STA = 'EC'
--update mtiv set MTIV_EMI3 = 'N'
FROM MTIV
WHERE MTIV_COD = '201012'
			and mtiv_sies = 1
			--and MTIV_STA != 'C1'
			and MTIV_MTMV_COD is null
			MTIV_EMI3 is null
			