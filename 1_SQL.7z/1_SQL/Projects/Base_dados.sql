select *
from sysdatabases
where cmptlevel = 80