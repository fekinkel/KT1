if not exists (select 1 from [tempdb].[dbo].sysobjects where id = object_id(N'[tempdb].[dbo].#iae')) begin
   create table [#iae] (par_erro varchar(255) )
end
select *
--update vdpi set VDPI_MTPC = 'OM', VDPI_MTPR = 'OM'
from vdpi
where vdpi_vdpd  = 122891

select *
--update prnc set PRNC_MTPR = 'OM'
from prnc
where prnc_npai = 122891

select *
--update pror set PROR_MTPR = 'OM'
from pror
where PROR_PROJ like '%122891%'

