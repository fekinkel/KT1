

drop table #kinp
--select MTPC_COD [VENDAS_COD], MTPR_COD [ESTOQUE_COD], CPCT_CPID [COMPRAS_COD], cpct_glxx_glpa [FORNECEDOR], mtpc_pre [PRECO_VENDAS], cpct_pun [PRECO_COMPRAS], mtpr_mtdv [DIVISAO], mtpr_mtln [LINHA], mtpr_mtfm [FAMILIA], mtpc_pre [PRECO_VENDAS_NOVO], cpct_pun [PRECO_COMPRAS_NOVO], 0.00 [FATOR_AUMENTO_VENDAS], 0.00 [FATOR_AUMENTO_COMPRAS], 3 [DIGITOS_SIGNIFICATIVOS]
select identity(int,1,1) num, mtpc_cod, mtpr_cod, CPCT_CPID [cpct_cod], cpct_glxx_glpa [glpa_cod], mtpc_pre , cpct_pun [cpct_pre], mtpr_mtdv , mtpr_mtln , mtpr_mtfm , mtpc_pre [mtpc_pre_new], cpct_pun [cpct_pre_new], 999.99 [mtpc_fator], 999.99 [cpct_fator], 3 [num_sig]
into #KINP
from mtpr, mtpc, cpct--, glpa
where mtpr_cod = mtpc_mtpr
			and mtpr_cod  = cpct_mtpr
			and mtpc_mtpr = cpct_mtpr
			and cpct_sta  = 'OK'
			and MTPR_ATVV = 'S' --Produto ativo para venda
			and substring(MTPR_COD,1,3) not in ('GEN')
			and substring(MTPR_COD,1,1) not in ('+','Z','o')

order by mtpc_cod

drop table #new
select mtpc_cod, count(1) num
into #new
from #kinp
group by mtpc_cod
having count(1) > 1

drop table #new_0
select mtpc_cod, count(1) num
into #new_0
from #kinp
group by mtpc_cod
having count(1) = 1

drop table #new_1
--select a.num [contador], a.MTPC_COD [VENDAS_COD], a.MTPR_COD [ESTOQUE_COD], a.CPCT_cod [COMPRAS_COD], a.glpa_cod [FORNECEDOR], a.mtpc_pre [PRECO_VENDAS], a.cpct_pre [PRECO_COMPRAS], a.mtpr_mtdv [DIVISAO], a.mtpr_mtln [LINHA], a.mtpr_mtfm [FAMILIA], a.mtpc_pre [PRECO_VENDAS_NOVO], a.cpct_pre [PRECO_COMPRAS_NOVO], a.mtpc_fator [FATOR_AUMENTO_VENDAS], a.cpct_fator [FATOR_AUMENTO_COMPRAS], a.num_sig [DIGITOS_SIGNIFICATIVOS]
select distinct min(a.num) [contador], a.MTPC_COD--, a.MTPR_COD [ESTOQUE_COD], a.CPCT_cod [COMPRAS_COD], a.mtpc_pre [PRECO_VENDAS], a.mtpr_mtdv [DIVISAO], a.mtpr_mtln [LINHA], a.mtpr_mtfm [FAMILIA], a.mtpc_pre [PRECO_VENDAS_NOVO], a.mtpc_fator [FATOR_AUMENTO_VENDAS], a.cpct_fator [FATOR_AUMENTO_COMPRAS], a.num_sig [DIGITOS_SIGNIFICATIVOS]
into #new_1
from #kinp a, #new b
where a.mtpc_cod = b.mtpc_cod
group by a.MTPC_COD--, a.MTPR_COD [ESTOQUE_COD], a.CPCT_cod [COMPRAS_COD], a.mtpc_pre [PRECO_VENDAS], a.mtpr_mtdv [DIVISAO], a.mtpr_mtln [LINHA], a.mtpr_mtfm [FAMILIA], a.mtpc_pre [PRECO_VENDAS_NOVO], a.mtpc_fator [FATOR_AUMENTO_VENDAS], a.cpct_fator [FATOR_AUMENTO_COMPRAS], a.num_sig [DIGITOS_SIGNIFICATIVOS]

drop table kinp

--select *--a.num [contador], a.MTPC_COD [VENDAS_COD], a.MTPR_COD [ESTOQUE_COD], a.CPCT_cod [COMPRAS_COD], a.glpa_cod [FORNECEDOR], a.mtpc_pre [PRECO_VENDAS], a.cpct_pre [PRECO_COMPRAS], a.mtpr_mtdv [DIVISAO], a.mtpr_mtln [LINHA], a.mtpr_mtfm [FAMILIA], a.mtpc_pre [PRECO_VENDAS_NOVO], a.cpct_pre [PRECO_COMPRAS_NOVO], a.mtpc_fator [FATOR_AUMENTO_VENDAS], a.cpct_fator [FATOR_AUMENTO_COMPRAS], a.num_sig [DIGITOS_SIGNIFICATIVOS]
select a.mtpc_cod, a.mtpr_cod, a.cpct_cod, a.glpa_cod, mtpc_pre , a.cpct_pre, mtpr_mtdv , mtpr_mtln , mtpr_mtfm , a.mtpc_pre_new, a.cpct_pre_new, a.mtpc_fator, a.cpct_fator, a.num_sig
into kinp
from #kinp a, #new_1 b--, #new_0 c
where a.num = b.contador
			--and a.mtpc_cod = b.mtpc_cod
insert into kinp
select a.mtpc_cod, a.mtpr_cod, a.cpct_cod, a.glpa_cod, mtpc_pre , a.cpct_pre, mtpr_mtdv , mtpr_mtln , mtpr_mtfm , a.mtpc_pre_new, a.cpct_pre_new, a.mtpc_fator, a.cpct_fator, a.num_sig
from #kinp a, #new_0 b
where a.mtpc_cod = b.mtpc_cod

--group by mtpc_cod
--having count(1) = 1

go
CREATE TRIGGER tri_KINP_UPDATE ON KINP
FOR UPDATE 
AS
BEGIN
  IF update(mtpc_fator) BEGIN
  --print 'Entrou aqui ' 
		if (select max(mtpc_fator) from inserted) > 0 begin 
		  --select 'Entrou aqui, pre�o �: ' + convert(varchar(10),kinp.mtpc_pre)+ ' e o novo valor �: '+ convert(varchar(100),round((inserted.mtpc_pre*(1+(inserted.mtpc_fator/100))),(inserted.num_sig-len(convert(int,(inserted.mtpc_pre*(1+(inserted.mtpc_fator/100)))))))) from KINP, inserted where KINP.mtpc_cod = inserted.mtpc_cod
			update KINP
			set KINP.mtpc_pre_new =  round((inserted.mtpc_pre*(1+(inserted.mtpc_fator/100))),(inserted.num_sig-len(convert(int,(inserted.mtpc_pre*(1+(inserted.mtpc_fator/100)))))))
--			,KINP.cpct_pre_new =  round((inserted.cpct_pre*(1+(inserted.cpct_fator/100))),(inserted.num_sig-len(convert(int,(inserted.cpct_pre*(1+(inserted.cpct_fator/100)))))))
			from inserted
			where KINP.mtpc_cod = inserted.mtpc_cod
		END else if (select max(mtpc_fator) from inserted) < 0 begin
		  --select mtpc_cod + ' Entrou aqui, pre�o �: ZERO' from inserted 
			update KINP set KINP.mtpc_pre_new =  0.00
			from inserted
			where KINP.mtpc_cod = inserted.mtpc_cod		
		END else begin
			update KINP set KINP.mtpc_pre_new =  KINP.mtpc_pre
			from inserted
			where KINP.mtpc_cod = inserted.mtpc_cod		
		END
  END
  IF update(cpct_fator) BEGIN
  --print 'Entrou aqui ' 
		if (select max(cpct_fator) from inserted) > 0 begin 
			update KINP
			set KINP.cpct_pre_new =  round((inserted.cpct_pre*(1+(inserted.cpct_fator/100))),(inserted.num_sig-len(convert(int,(inserted.cpct_pre*(1+(inserted.cpct_fator/100)))))))
			from inserted
			where KINP.mtpc_cod = inserted.mtpc_cod
		END else if (select max(cpct_fator) from inserted) < 0 begin
			update KINP set KINP.cpct_pre_new =  0.00
			from inserted
			where KINP.mtpc_cod = inserted.mtpc_cod		
		END else begin
			update KINP set KINP.cpct_pre_new =  KINP.cpct_pre
			from inserted
			where KINP.mtpc_cod = inserted.mtpc_cod		
		END
  END
END

go

select a.MTPC_COD [VENDAS_COD], a.MTPR_COD [ESTOQUE_COD], a.CPCT_cod [COMPRAS_COD], a.glpa_cod [FORNECEDOR], a.mtpc_pre [PRECO_VENDAS], a.cpct_pre [PRECO_COMPRAS], a.mtpr_mtdv [DIVISAO], a.mtpr_mtln [LINHA], a.mtpr_mtfm [FAMILIA], a.mtpc_pre [PRECO_VENDAS_NOVO], a.cpct_pre [PRECO_COMPRAS_NOVO], a.mtpc_fator [FATOR_AUMENTO_VENDAS], a.cpct_fator [FATOR_AUMENTO_COMPRAS], a.num_sig [DIGITOS_SIGNIFICATIVOS]
from kinp a
order by mtpc_cod
