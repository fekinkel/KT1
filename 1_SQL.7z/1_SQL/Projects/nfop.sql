--NFOP_COD NFOP_NOM       NFOP_CODF NFOP_NOMF NFOP_MS NFOP_TIT																							NFOP_MTTR NFOP_IPI_INC NFOP_ISS_INC NFOP_ISS_PCT                            NFOP_ICM_TBB NFOP_ICM_INC NFOP_ICM_TAB NFOP_ICM_BAS                            NFOP_REV NFOP_MEN                                                                                                                                                                                                                                                        NFOP_PIS_INC NFOP_COF_INC NFOP_USC        NFOP_DTC                NFOP_USU        NFOP_DTU
INSERT INTO NFOP
select CFOP, [DESCRI��O], CFOP, [DESCRI��O], 'M', 'S', REPLACE(REPLACE(SUBSTRING(cfop,1,1),'1','SUPPLI'),'5','INVOUT'), 3, 3, 0.00, '00', 1, 'A', 100.00, 'N', NULL, 'N', 'N', 'KINKEL', GETDATE(), NULL, NULL
from [dos].[dbo].CFOPUSA
WHERE CFOP IS NOT NULL
--group by CFOP
