--EXEC sp_dropserver 'dbf2'
EXEC sp_dropserver 'dbf4'
--N�O ESQUECER DA BARRA NO FINAL DO CAMINHO
EXEC sp_addlinkedserver 'DBF4', 'Jet 4.0', 'Microsoft.Jet.OLEDB.4.0', 'c:\mexico\scdmex\dados\', NULL, 'dBase III'
--exec sp_addlinkedsrvlogin 'DBF4', true, 'mdl\KINKEL', 'sa', 'mdlmdl'
exec sp_addlinkedsrvlogin 'DBF4', false, NULL, 'admin', NULL

--exec sp_addlinkedserver  'dbf2', '', 'MSDASQL', Null, Null, 'Driver={Microsoft dBASE Driver (*.dbf)};DriverID=277;DBQ=c:\mexico\SCDMEX\DADOS',null
--exec sp_addlinkedsrvlogin 'DBF2', false, 'mdl\KINKEL', 'Admin', NULL

--select * from dbf2...prod

select * into [mex].[dbo].PED from dbf4...ped where 1 = 2
select * into [mex].[dbo].ITEM from dbf4...item where 1 = 2

select * into [mex].[dbo].NFNF0000 from dbf4...nfnf0000 where 1 = 2
select * into [mex].[dbo].NFIT0000 from dbf4...nfit0000 where 1 = 2

select * into [mex].[dbo].MOV from dbf4...mov where 1 = 2

select * into [mex].[dbo].APTITU from dbf4...aptitu where 1 = 2

select * from dbf4...item WHERE NUM_PED = 19914 order by num_ped
select top 1 * from dbf4...prod
select top 1 * from dbf4...cli
select top 10 * from dbf4...nfnf0000 where num_nf > 30349
select top 1 * from dbf4...prod
select top 5 * from dbf4...nfit0000 where num_nf > 30349
select top 1 * from dbf4...CLI
select top 5 * from dbf4...nfco0000 where num_nf > 30349



