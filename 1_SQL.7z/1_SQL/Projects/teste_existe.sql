--,FILHO,Engraxadeira,KIT,Grampo,Parafuso
select substring(FILHO,1,3)
from [dos].[dbo].NEW_KIT a
where FILHO not in (select b.mtpr_cod from MTPR b)
group by substring(FILHO,1,3)

select substring(Engraxadeira,1,3)
from [dos].[dbo].NEW_KIT a
where Engraxadeira not in (select b.mtpr_cod from MTPR b)
group by substring(Engraxadeira,1,3)

select substring(KIT,1,3)
from [dos].[dbo].NEW_KIT a
where KIT not in (select b.mtpr_cod from MTPR b)
group by substring(KIT,1,3)

select substring(Grampo,1,3)
from [dos].[dbo].NEW_KIT a
where Grampo not in (select b.mtpr_cod from MTPR b)
group by substring(Grampo,1,3)

select substring(Parafuso,1,3)
from [dos].[dbo].NEW_KIT a
where Parafuso not in (select b.mtpr_cod from MTPR b)
group by substring(Parafuso,1,3)



