select *, SIGR_COD SIGR_PAI
into SIGR_NEW
from [MDL_Menus].[dbo].sigr
where 1 = 0

select replace(SIOI_SIOP_New,SIOI_SIOP,'')+';'+ SIOI_NOM+';'+'1'
from [dos].[dbo].sioi_new
where replace(SIOI_SIOP_New,SIOI_SIOP,'') <> ''
			and SIOI_USC = 's2ri' 
order by replace(SIOI_SIOP_New,SIOI_SIOP,'')


select * from [DOS].[dbo].sigr_new

insert into [dos].[dbo].sioi_new upper('novo'), upper('novissimo'), 'S', 'GRUPO_S2R', GETDATE(), null, null, 'Velho'  

'insert into [dos].[dbo].sioi_new select upper('novo'), upper('novissimo'), 'S', 'GRUPO_S2R', GETDATE(), null, null, 'velho''

insert into [dos].[dbo].sigr_new select upper('novo'), upper('novissimo'), 'S', 'GRUPO_S2R', GETDATE(), null, null, 'velho'
