drop table #new
--select * from kit


select CONVERT(char(3),tipo) TIPO, convert(char(30),Di�metros) DIA, IDENTITY(int,1,1) NUM
into #new
from [DOS].[DBO].kit

--SELECT * FROM #NEW
drop table #kit

declare
@i int,
@s varchar(30),
@d char(2)
set @i = 1

select CONVERT(char(3),a.tipo) TIPO, @d DIA, 1 QDE_0, convert(varchar(20),'                    ')FILHO, 1 QDE_1, convert(varchar(20),[KIT Engraxadeira]) Engraxadeira, 1 QDE_2, convert(varchar(20),[C�digo do Kit]) KIT, convert(int,[Qt#]) QDE_A, convert(varchar(20),Grampo)Grampo, convert(int,[Qt#1]) QDE_B, convert(varchar(20),Parafuso)Parafuso,  CONVERT(char(3),a.tipo)+'.0'+@d+'.' PRE_COD
into #KIT
from [DOS].[DBO].KIT a
where 1 =0

select * from #kit

while @i<= (select MAX(num) from #new) begin
	select @s = DIA from #new where num =@i
	print @s
	if CHARINDEX(',',@s) >0 begin
		while CHARINDEX(',',@s)> 0 begin
			set @d = LTRIM(substring(@s,1,charindex(',',@s)-1))
				insert into #kit
				--			TIPO,													DIA,		QDE_0    FILHO																				QDE_1    Engraxadeira																						QDE_2			KIT																				QDE_A											Grampo															QDE_B												Parafuso																PRE_COD
				select	CONVERT(char(3),a.tipo) TIPO, @d DIA, 1 QDE_0, CONVERT(char(3),a.filho)+'.0'+@d+'.' FILHO,	1 QDE_1, convert(varchar(20),[KIT Engraxadeira]) Engraxadeira,	1 QDE_2,	convert(varchar(20),[C�digo do Kit]) KIT, convert(int,[Qt#]) QDE_A, convert(varchar(20),Grampo)Grampo,	convert(int,[Qt#1]) QDE_B,	convert(varchar(20),Parafuso)Parafuso,  CONVERT(char(3),a.tipo)+'.0'+@d+'.'
				from [DOS].[DBO].KIT a, #new b
				where NUM = @i
							and a.Tipo = b.Tipo	
							and [Di�metros] = DIA
			set @s = SUBSTRING(@s,charindex(',',@s)+1,len(@s))			
			print @d

		end
		set @d = rtrim(LTRIM(@s))
		insert into #kit
		select	CONVERT(char(3),a.tipo) TIPO, @d DIA, 1 QDE_0, CONVERT(char(3),a.filho)+'.0'+@d+'.' FILHO,	1 QDE_1, convert(varchar(20),[KIT Engraxadeira]) Engraxadeira,	1 QDE_2,	convert(varchar(20),[C�digo do Kit]) KIT, convert(int,[Qt#]) QDE_A, convert(varchar(20),Grampo)Grampo,	convert(int,[Qt#1]) QDE_B,	convert(varchar(20),Parafuso)Parafuso,  CONVERT(char(3),a.tipo)+'.0'+@d+'.'
		from [DOS].[DBO].KIT a, #new b
		where NUM = @i
					and a.Tipo = b.Tipo	
					and [Di�metros] = DIA
	end
	set @i = @i + 1
end

select mtpr_cod, TIPO, DIA,  QDE_0, convert(varchar(20),replace(mtpr_cod,PRE_COD, FILHO )) FILHO, QDE_1, Engraxadeira, QDE_2, KIT, QDE_A, Grampo, QDE_B, Parafuso, PRE_COD, 0 semestral, 0 anual
into [DOS].[DBO].NEW_KIT
from #kit a, mtpr b
where PRE_COD = SUBSTRING(mtpr_cod,1,8)
			and CHARINDEX('*',mtpr_cod) =0

SELECT * FROM [DOS].[dbo].NEW_KIT

drop table #semestral
drop table #anual

select VDPI_MTPC, sum(VDPI_QTD) QTD
into #semestral
--update [dos].[dbo].new_kit set semestral = count(VDPI_QTD)
from VDPI a, VDPD b, [DOS].[dbo].new_kit
where VDPI_SIES = VDPD_SIES
			and VDPI_SIDO = VDPD_SIDO
			and VDPI_SISE = VDPD_SISE
			and VDPI_VDPD = VDPD_COD
			and VDPD_STA  = 'OK'
			--and vdpi_vdpd = 139144
			and CONVERT(char(10),vdpi_dtc,102) >= '2011.02.01'
			and VDPI_MTPc = mtpr_cod
group by VDPI_MTPC


select VDPI_MTPC, sum(VDPI_QTD) QTD
into #anual
--update [dos].[dbo].new_kit set semestral = count(VDPI_QTD)
from VDPI a, VDPD b, [DOS].[dbo].new_kit
where VDPI_SIES = VDPD_SIES
			and VDPI_SIDO = VDPD_SIDO
			and VDPI_SISE = VDPD_SISE
			and VDPI_VDPD = VDPD_COD
			and VDPD_STA  = 'OK'
			--and vdpi_vdpd = 139144
			and CONVERT(char(10),vdpi_dtc,102) >= '2010.07.01'
			and VDPI_MTPc = mtpr_cod
group by VDPI_MTPC


--select *
update [dos].[dbo].new_kit set semestral = QTD
from #semestral, [dos].[dbo].new_kit
where vdpi_mtpc = mtpr_cod

--select *
update [dos].[dbo].new_kit set anual = QTD
from #anual, [dos].[dbo].new_kit
where vdpi_mtpc = mtpr_cod

SELECT KIT, SUM(semestral) semestral,   SUM(anual) anual
FROM [DOS].[dbo].NEW_KIT
GROUP BY KIT

SELECT *
FROM [DOS].[dbo].NEW_KIT

