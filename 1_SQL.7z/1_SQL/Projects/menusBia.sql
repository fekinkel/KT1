--select *, SPACE(16) [TIPO] into [dos].[dbo].SIOI_New from SIOI_novo

declare
@v varchar(50),
@t varchar(50),
@h varchar(50),
@n varchar(12)

set @v = '%ativa/%'; set @n = '1.6.X1.'; set @h = '%MNUESTABATIVA%'

/*
*/


set @t = '%'


--select tipo, SIOI_NOM, * from [dos].[dbo].SIOI_New where SIOI_NOM like '%INTEGRA��O%'
print @t

if (select COUNT(1)
from [dos].[dbo].SIOI_New
where SIOI_NOM like @v
			and SIOI_SIOP like @h
			and SIOI_SIOP like @t)=1 begin
	update [dos].[dbo].SIOI_New set TIPO = @n
	from [dos].[dbo].SIOI_New
	where SIOI_NOM like @v
				and SIOI_SIOP like @h
				and SIOI_SIOP like @t

	update sioi set SIOI_NOM = rtrim(tipo)+rtrim(b.SIOI_NOM)
	--update sioi set SIOI_NOM = b.SIOI_NOM
	from sioi a, [dos].[dbo].SIOI_New b
	where a.SIOI_SIOP = b.SIOI_SIOP
				and substring(b.tipo,2,1) = '.'

end 
			
select TIPO, *
from [dos].[dbo].SIOI_New
where SIOI_NOM like @v
				and SIOI_SIOP like @h
			--SIOI_NOM like substring(@v,1,6)+'%'
			and SIOI_SIOP like @t

/*
drop table #new

select tipo NEW , SIOI_SIOP
into #new
from [DOS].[dbo].SIOI_New
--where SIOI_SIOP like '%PAISES%' --and SIOI_SIOP_New like '1.2.%'
where tipo <> ''
order by tipo

select rtrim(new)+'F'+substring(b.SIOI_SIOP,len(b.SIOI_SIOP),1)+'.', *
--update [DOS].[dbo].SIOI_New set tipo = rtrim(new)+'F'+substring(b.SIOI_SIOP,len(b.SIOI_SIOP),1)+'.'
from #new a, [DOS].[dbo].SIOI_New b
where LEN(new)>=3
			and (b.SIOI_SIOP like 'FRM'+substring(a.SIOI_SIOP,4,len(a.SIOI_SIOP)-3)+'F%' 
				or b.SIOI_SIOP like ''+substring(a.SIOI_SIOP,4,len(a.SIOI_SIOP)-3)+'F%' 
			)
			and CHARINDEX('rel',a.SIOI_SIOP)<=0
			and SUBSTRING(a.new,2,1) not in ('.')

select *
from [DOS].[dbo].SIOI_New a
where SUBSTRING(a.tipo,2,1) not in ('.')

--select '%'+substring(a.SIOI_SIOP,4,len(a.SIOI_SIOP)-3)+'F%', * from #new a

*/

