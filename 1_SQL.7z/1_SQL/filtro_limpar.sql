select *
--delete
from SICC
where SICC_SIUS like 'jayapandianp'
and SICC_CAMP like 'VDCO%'--_ICM_VAL
--and SICC_CAMP like 'mtmv%' --OP��O TABELA
			and SICC_SIOP like  '%Cota��es de Venda%'



select *
--delete
from SICC
where SICC_SIUS = 'claudior'
			and SICC_SIOP = 'Clientes'

select *
--delete
from SICC
where SICC_SIUS = 'RENATAc'
			and SICC_SIOP = 'Nota de Recebimento'

select *
--delete
from SICC
where SICC_SIUS = 'cristinap'
			and SICC_SIOP = 'Nota de Recebimento'

select *
--delete
from SICC
where SICC_SIUS = 'carolinap'
			and SICC_SIOP = 'Nota de Recebimento'
			
select *
--delete
from SICC
where SICC_SIUS = 'lucasm'
			and SICC_SIOP = 'Nota de Recebimento'

select *
--delete
from SICC
where SICC_SIUS = 'rafaelh'
			and SICC_CAMP like 'PRAH%'
