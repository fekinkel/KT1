--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 13/03/2018--DEPARTAMENTO : SISTEMA--ASSUNTO      : FINALIZAR OS PROCESSOS DIFERENTE DE MDL--CASO SEJA MDL, SOMENTE SE FOR PRAH ------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #new
SELECT
	num = identity(int,1,1)
	,Processo      = spid
	,Computador   = hostname
	,Usuario      = loginame
	,Status       = a.status
	,BloqueadoPor = blocked
	,TipoComando  = cmd
	,Aplicativo   = program_name
	,Nome = b.name
	,Han = a.sql_handle
	,proce = '                              ' 
	into #new
	--select *
FROM
	master..sysprocesses a, master..sysdatabases b
WHERE
	a.dbid = b.dbid
	and program_name <> 'dllhost.exe'
	and (b.name = 'CFG_MDL' or
	 b.name = 'MDL' or
	 b.name = 'BKP' or
	 b.name = 'SITIO' or
	 b.name = 'VND')
--	status in ('runnable', 'suspended')
ORDER BY
	blocked desc, status, spid



declare
@i int,
@j int,
@k int,
@s varchar(255),
@h varbinary(64),
@t varchar(100),
@m varchar(4000),
@n varchar(50)

set @i = 1

while (select max(num) from #new) >= @i begin

	select @t = Nome, @j = processo, @h = han from #new where num = @i
	if @t = 'MDL' begin
		set @n = ''
		SELECT @k= count(1), @n = 'PRAH_ia_ATV_SMR' 
		FROM ::fn_get_sql(@h)
		where text like '%PRAH_ia_ATV_SMR%'

		if @k = 1 begin
			set @s = 'KILL '+convert(varchar(6),@j)
			update #new set proce = @n where num = @i
		end else begin
		  set @s = ''
		end
	end else begin
		set @s = 'KILL '+convert(varchar(6),@j)
		set @n = ''
	end
	if @s <> '' begin
		select @s, @k, 'OK', @n
		--exec (@s)
	end else begin
		select 'false'
	end
	--exec (@s)
	--select * from #new where num = @i	
	set @i = @i + 1
end

select * from #new

--SELECT * FROM ::fn_get_sql(0x030007002C690B33876FE6007EA8000001000000)
