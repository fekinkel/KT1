declare
@i int,
@j int,
@k INT,
@d INT,
@datade varchar(10),
@dataat varchar(10),
@dd date,
@da date

SET @i = 0
SET @j = 1
SET @d = 0

set @datade = '18/03/2016'
set @dataat = '04/04/2016'

select @dd = convert(date,@datade,103)
select @da = convert(date,@dataat,103)

if @dd < @da begin

	--SELECT @k = datepart(day,@dd)
	--print convert(varchar(10), @dd, 103)
	WHILE DATEDIFF(DD,@dd,@da)>=0  BEGIN
		IF (SELECT (DATEPART(DW,@dD))) IN (2,3,4,5,6) BEGIN
			IF (SELECT COUNT(1) FROM [MDL].[DBO].GLCA WHERE CONVERT(DATE,GLCA_COD) = @DD AND GLCA_UTIL = 'N')=0 BEGIN
				SET @d = @d + 1 
				--print convert(varchar(10), @dd, 103)
			END
		END

	
		SELECT @dd = DATEADD(DD,1,@dd)
	END 
	PRINT 'Dias '+convert(varchar(10),@D)
end else begin
	print 'Verificar datas'
end



