
IF OBJECT_ID('TempDB.dbo.#new') IS NOT NULL DROP TABLE #new
Select SUBSTRING(MTPR_COD,1,LEN(MTPR_COD)-1)+'B' MTPR_COD_NEW,*
INTO #NEW
from mtpr
where ((substring(mtpr_cod,1,3) = 'MB.' and substring(mtpr_cod,len(mtpr_cod),1) = 'A')
or (substring(mtpr_cod,1,4) = 'MBS.' and substring(mtpr_cod,len(mtpr_cod),1) = 'A') 
or (substring(mtpr_cod,1,4) = 'MSB.' and substring(mtpr_cod,len(mtpr_cod),1) = 'A') 
or (substring(mtpr_cod,1,5) = 'MSBS.' and substring(mtpr_cod,len(mtpr_cod),1) = 'A'))
AND MTPR_ATV = 'N' 

--20+12+15+9 = 56

IF OBJECT_ID('TempDB.dbo.#MTPC') IS NOT NULL DROP TABLE #MTPC
SELECT IDENTITY(INT,1,1) NUM, *
INTO #MTPC
FROM #NEW
WHERE substring(mtpr_cod,charindex('.',mtpr_cod)+1,3)/10 <= 13

SELECT *
FROM #MTPC


DECLARE@i INT,@j1 int,@j2 int,@qtd decimal(12,2),@cod varchar(20),@cod_new varchar(20),@erro varchar(4000),@modo char(1),@DATA Datetime,@ano int,@mes intset @i = 1set @erro = ''set @data = GETDATE()--select * from #mtpcWHILE @i <= (SELECT MAX(NUM) FROM #MTPC) BEGIN	select @ano = year(getdate()), @mes = month(getdate())	select @cod = MTPR_COD, @cod_new = MTPR_COD_NEW from #mtpc where num = @i 	exec MT_MTSW_SALDO @cod, 5, @ano, @mes, 'ALMO01', '', '', @qtd output, 0, 0, 0	--exec MT_MTSO_SALDO @cod, 5, @ano, @mes, 'ALMO01', '', @qtd output, 0, 0, 0	--exec MT_MTSY_SALDO @cod, 5, 'ALMO01', @ano, @mes, @qtd output, 0, 0, 0		--PRINT @I		--PRINT @ANO		--PRINT @MES		--PRINT @COD
		--PRINT @QTD
	if (select @qtd)>0 begin 		print 'NUM ='+convert(varchar(10),@i)+' - O C�digo � = '+@cod+ ' e seu saldo � '+convert(varchar(20),@qtd)+'  tranferir o saldo para o c�digo = '+@cod_new		set @modo = 'I'		Exec MTTD_iae   @modo output  ,@erro output  ,5  ,'MTTD', '001', 0 , @DATA,'GIRMAT' ,@COD			,'ALMO01', @QTD, @COD_NEW	,'ALMO01', @QTD,'','KINKEL'  ,@DATA  ,NULL  ,NULL
		--print @modo + '/'+@erro
		--PRINT @COD_NEW
		--PRINT @QTD
	end	set @i = @i + 1END