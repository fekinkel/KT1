--------------------------------------------------------------------------------------------------------------------------AUTOR        : FERNANDO KINKEL SEREJO--DATA         : 21/02/2018--DEPARTAMENTO : 21/02/2018--ASSUNTO      : 21/02/2018------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('TempDB.dbo.#ATAT') IS NOT NULL DROP TABLE #ATATSELECT * INTO #ATAT FROM ATAT WHERE 1 = 0INSERT INTO #ATATSELECT */*		ATAT_COD = CONVERT(int(6),'')      --CONVERT(int(6),'') C�digo(C�digo da atividade)
	, ATAT_NOM = CONVERT(varchar(1000),'')      --CONVERT(varchar(1000),'') Atividade(Descri��o resumida da atividades)
	, ATAT_STA = CONVERT(varchar(2),'')      --CONVERT(varchar(2),'') Status(Status da Atividade)
	, ATAT_DTA = CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') Em(Data do Status)
	, ATAT_DES = Null      --CONVERT(varchar(8000),'') Descri��o(Descri��o complementar da atividade)
	, ATAT_TIP = CONVERT(varchar(4),'')      --CONVERT(varchar(4),'') Tipo(Tipo de atividade)
	, ATAT_PRI = CONVERT(char(1),'')      --CONVERT(char(1),'') Prioridade(Prioridade da atividade)
	, ATAT_GLFU = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Respons�vel(Nome do usu�rio respons�vel)
	, ATAT_GLCL = CONVERT(varchar(6),'')      --CONVERT(varchar(6),'') Cliente(Reduzido do Cliente)
	, ATAT_GLCO = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Tipo(Projetos/Ocorr�ncias)
	, ATAT_DTS = CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') Solicitado em(Data de solicita��o da atividade)
	, ATAT_DTP = CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') Ent. Prometida(Data de entrega prometida da atividade)
	, ATAT_DTC = CONVERT(datetime(10),'')      --CONVERT(datetime(10),'') Em(Data de cadastro do registro)
	, ATAT_USC = CONVERT(varchar(15),'')      --CONVERT(varchar(15),'') Cadastrado por(Usu�rio que efetuou o cadastro do registro)
	, ATAT_PRZ = CONVERT(int(6),'')      --CONVERT(int(6),'') Prazo (horas)(N�mero de horas para realiza��o da atividade)
	, ATAT_USU = Null      --CONVERT(varchar(15),'') Alterado por(Usu�rio que efetuou a �ltima altera��o no registro)
	, ATAT_DTU = Null      --CONVERT(datetime(10),'') Em(Data da �ltima atualiza��o do registro)
	, ATAT_AREA = Null      --CONVERT(varchar(15),'') �rea(�rea de atua��o do sistema)
	, ATAT_SIAP = Null      --CONVERT(varchar(6),'') Aplicativo(C�digo do aplicativo)
	, ATAT_EMAI = Null      --CONVERT(varchar(80),'') E-Mail(E-mail do Solicitante)
	, ATAT_ASLA = Null      --CONVERT(int(8),'') SLA(Valor de SLA)
	, ATAT_DTE = Null      --CONVERT(datetime(10),'') Envio(Data do envio para terceiros)
	, ATAT_GLFO = Null      --CONVERT(int(8),'') Fornecedor(C�digo Fornecedor)
	, ATAT_DCO = Null      --CONVERT(datetime(10),'') Conclus�o(Data de conclus�o da atividade)
	, ATAT_MGID = Null      --CONVERT(varchar(255),'') ID(ID da mensagem)
	*/
	--select *
from atat
where convert(varchar(10),ATAT_DTA,102) between '2018.01.01' and '2018.01.31'
declare@i intSELECT @i = count(1)FROM #ATATSELECT @i TOTAL, ATAT_GLFU FUNCIONARIO, count(1) TOTAL_FUNFROM #ATATgroup by ATAT_GLFUSELECT @i TOTAL, ATAT_GLCL CLIENTE, count(1) TOTAL_CLIFROM #ATATgroup by ATAT_GLCL
order by count(1) descSELECT @i TOTAL, ATAT_AREA AREA, count(1) TOTAL_CLIFROM #ATATwhere ATAT_GLCL = 'MDL-BRASIL'group by ATAT_AREA
order by count(1) descselect ATAT_COD ,ATAT_NOM ,ATAT_STA ,ATAT_DTA ,ATAT_TIP ,ATAT_PRI ,ATAT_GLFU ,ATAT_GLCL ,ATAT_GLCO ,ATAT_DTS ,ATAT_DTP ,ATAT_DTC ,ATAT_USC ,ATAT_PRZ ,ATAT_USU ,ATAT_DTU ,ATAT_AREA ,ATAT_SIAP ,ATAT_EMAI ,ATAT_ASLA ,ATAT_DTE ,ATAT_GLFO ,ATAT_DCOFROM #ATAT--ATAT_COD ,ATAT_NOM ,ATAT_STA ,ATAT_DTA ,ATAT_DES ,ATAT_TIP ,ATAT_PRI ,ATAT_GLFU ,ATAT_GLCL ,ATAT_GLCO ,ATAT_DTS ,ATAT_DTP ,ATAT_DTC ,ATAT_USC ,ATAT_PRZ ,ATAT_USU ,ATAT_DTU ,ATAT_AREA ,ATAT_SIAP ,ATAT_EMAI ,ATAT_ASLA ,ATAT_DTE ,ATAT_GLFO ,ATAT_DCO ,ATAT_MGID ,

