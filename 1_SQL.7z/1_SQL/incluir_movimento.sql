insert into [mdl-usa].[dbo].[MTMV]
select *
from mtmv
where convert(varchar(6),mtmv_cod)+'/'+convert(varchar(6),mtmv_seq) in ('109114/1','109110/1','109107/1','109113/3','109109/3','109106/3','109111/4','109112/4','109108/4','109105/4', '110436/4', '110479/1')
			and convert(varchar(6),mtmv_cod)+'/'+convert(varchar(6),mtmv_seq) not in (select convert(varchar(6),mtmv_cod)+'/'+convert(varchar(6),mtmv_seq) from [mdl-usa].[dbo].[MTMV])