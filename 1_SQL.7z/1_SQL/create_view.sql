
create view GLVDM
as
select GLVD_COD GLVD_ID,	GLPA_NOM GLVD_NOM, GLPA_NRDZ GLVD_NRDZ, GLPA_BAI GLVD_BAI,	GLPA_CID GLVD_CID, GLPA_END GLVD_END, GLPA_TEL GLVD_TEL, GLPA_CTO GLVD_CTO, GLPA_EMAIL GLVD_EMAIL 
from [MDL].[dbo].glvd, [MDL].[dbo].glpa
where glvd_glpa = glpa_cod
and glvd_atv = 'S'
and glvd_cod not between 90 and 99
