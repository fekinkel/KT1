
--			VDC1_SIES   VDC1_SIDO VDC1_SISE VDC1_VDCO   VDC1_COD    VDC1_SUB    VDC1_TIPO VDC1_MTPC            VDC1_MTPC_NOM                                                                                                                                                                                                                                                  VDC1_ORC     VDC1_REV VDC1_QTDE                               VDC1_PUNI                               VDC1_DESC                               VDC1_PUNID                              VDC1_PENT   VDC1_IPI_BAS                            VDC1_IPI_ALI                            VDC1_IPI_VAL                            VDC1_ICMS_ST                            VDC1_SMDO VDC1_OBS                                                                                                                                                                                                                                                         VDC1_CMDO                               VDC1_CMAT                               VDC1_FATR                               VDC1_FMAT                               VDC1_FMDO                               VDC1_ESPE VDC1_MTPR            VDC1_PESO                               VDC1_PBRT                               VDC1_VDCV   VDC1_USC        VDC1_DTC                VDC1_USU        VDC1_DTU
select	VDC1_SIES, VDC1_SIDO, VDC1_SISE, 
				VDC1_VDCO = 
				case MTPR_MTLN 
					when 3800 then 245908
					when 3900 then 245969
					when 4000 then 245970
					when 4100 then 245971
				end
				, identity(int,1,1) VDC1_COD, VDC1_SUB, VDC1_TIPO, mtpc_cod VDC1_MTPC, mtpc_nom VDC1_MTPC_NOM, VDC1_ORC, VDC1_REV, VDC1_QTDE, mtpc_pre VDC1_PUNI, VDC1_DESC, mtpc_pre VDC1_PUNID, VDC1_PENT, mtpc_pre VDC1_IPI_BAS, VDC1_IPI_ALI, VDC1_IPI_VAL, VDC1_ICMS_ST, VDC1_SMDO, VDC1_OBS, VDC1_CMDO, mtpc_pre VDC1_CMAT, VDC1_FATR, VDC1_FMAT, VDC1_FMDO, VDC1_ESPE, mtpc_mtpr VDC1_MTPR, mtpr_pes VDC1_PESO, VDC1_PBRT, VDC1_VDCV, VDC1_USC, VDC1_DTC, VDC1_USU, VDC1_DTU
into #new1
from VDC1, MTPC, MTPR, MTLN
where VDC1_VDCO = 245908
			and MTPC_MTPR = MTPR_COD
			and MTPR_MTDV = 3500
			and MTPR_ATVV = 'S'
			and MTPC_PRE > 0
			and MTPR_MTDV = MTLN_MTDV
			and MTPR_MTLN = MTLN_COD
			and MTPR_MTLN < 4150
			and MTPR_MTLN = 3800
			
select	VDC1_SIES, VDC1_SIDO, VDC1_SISE, 
				VDC1_VDCO = 
				case MTPR_MTLN 
					when 3800 then 245908
					when 3900 then 245969
					when 4000 then 245970
					when 4100 then 245971
				end
				, identity(int,1,1) VDC1_COD, VDC1_SUB, VDC1_TIPO, mtpc_cod VDC1_MTPC, mtpc_nom VDC1_MTPC_NOM, VDC1_ORC, VDC1_REV, VDC1_QTDE, mtpc_pre VDC1_PUNI, VDC1_DESC, mtpc_pre VDC1_PUNID, VDC1_PENT, mtpc_pre VDC1_IPI_BAS, VDC1_IPI_ALI, VDC1_IPI_VAL, VDC1_ICMS_ST, VDC1_SMDO, VDC1_OBS, VDC1_CMDO, mtpc_pre VDC1_CMAT, VDC1_FATR, VDC1_FMAT, VDC1_FMDO, VDC1_ESPE, mtpc_mtpr VDC1_MTPR, mtpr_pes VDC1_PESO, VDC1_PBRT, VDC1_VDCV, VDC1_USC, VDC1_DTC, VDC1_USU, VDC1_DTU
into #new2
from VDC1, MTPC, MTPR, MTLN
where VDC1_VDCO = 245908
			and MTPC_MTPR = MTPR_COD
			and MTPR_MTDV = 3500
			and MTPR_ATVV = 'S'
			and MTPC_PRE > 0
			and MTPR_MTDV = MTLN_MTDV
			and MTPR_MTLN = MTLN_COD
			and MTPR_MTLN < 4150
			and MTPR_MTLN = 3900
			
select	VDC1_SIES, VDC1_SIDO, VDC1_SISE, 
				VDC1_VDCO = 
				case MTPR_MTLN 
					when 3800 then 245908
					when 3900 then 245969
					when 4000 then 245970
					when 4100 then 245971
				end
				, identity(int,1,1) VDC1_COD, VDC1_SUB, VDC1_TIPO, mtpc_cod VDC1_MTPC, mtpc_nom VDC1_MTPC_NOM, VDC1_ORC, VDC1_REV, VDC1_QTDE, mtpc_pre VDC1_PUNI, VDC1_DESC, mtpc_pre VDC1_PUNID, VDC1_PENT, mtpc_pre VDC1_IPI_BAS, VDC1_IPI_ALI, VDC1_IPI_VAL, VDC1_ICMS_ST, VDC1_SMDO, VDC1_OBS, VDC1_CMDO, mtpc_pre VDC1_CMAT, VDC1_FATR, VDC1_FMAT, VDC1_FMDO, VDC1_ESPE, mtpc_mtpr VDC1_MTPR, mtpr_pes VDC1_PESO, VDC1_PBRT, VDC1_VDCV, VDC1_USC, VDC1_DTC, VDC1_USU, VDC1_DTU
into #new3
from VDC1, MTPC, MTPR, MTLN
where VDC1_VDCO = 245908
			and MTPC_MTPR = MTPR_COD
			and MTPR_MTDV = 3500
			and MTPR_ATVV = 'S'
			and MTPC_PRE > 0
			and MTPR_MTDV = MTLN_MTDV
			and MTPR_MTLN = MTLN_COD
			and MTPR_MTLN < 4150
			and MTPR_MTLN = 4000
					
select	VDC1_SIES, VDC1_SIDO, VDC1_SISE, 
				VDC1_VDCO = 
				case MTPR_MTLN 
					when 3800 then 245908
					when 3900 then 245969
					when 4000 then 245970
					when 4100 then 245971
				end
				, identity(int,1,1) VDC1_COD, VDC1_SUB, VDC1_TIPO, mtpc_cod VDC1_MTPC, mtpc_nom VDC1_MTPC_NOM, VDC1_ORC, VDC1_REV, VDC1_QTDE, mtpc_pre VDC1_PUNI, VDC1_DESC, mtpc_pre VDC1_PUNID, VDC1_PENT, mtpc_pre VDC1_IPI_BAS, VDC1_IPI_ALI, VDC1_IPI_VAL, VDC1_ICMS_ST, VDC1_SMDO, VDC1_OBS, VDC1_CMDO, mtpc_pre VDC1_CMAT, VDC1_FATR, VDC1_FMAT, VDC1_FMDO, VDC1_ESPE, mtpc_mtpr VDC1_MTPR, mtpr_pes VDC1_PESO, VDC1_PBRT, VDC1_VDCV, VDC1_USC, VDC1_DTC, VDC1_USU, VDC1_DTU
into #new4
from VDC1, MTPC, MTPR, MTLN
where VDC1_VDCO = 245908
			and MTPC_MTPR = MTPR_COD
			and MTPR_MTDV = 3500
			and MTPR_ATVV = 'S'
			and MTPC_PRE > 0
			and MTPR_MTDV = MTLN_MTDV
			and MTPR_MTLN = MTLN_COD
			and MTPR_MTLN < 4150
			and MTPR_MTLN = 4100


insert into VDC1
select *
from #new1
where CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC not in (select CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC from VDC1 where VDC1_VDCO = 245908)
insert into VDC1
select *
from #new2
where CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC not in (select CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC from VDC1 where VDC1_VDCO = 245908)
insert into VDC1
select *
from #new3
where CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC not in (select CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC from VDC1 where VDC1_VDCO = 245908)
insert into VDC1
select *
from #new4
where CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC not in (select CONVERT(varchar(3),vdc1_sies)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+convert(varchar(6),VDC1_VDCO)+'/'+VDC1_MTPC from VDC1 where VDC1_VDCO = 245908)

/*
select Mtpr_cod, MTPR_MTDV Divis�o, MTPR_MTLN Linha, MTLN_NOM Descri��o
from MTPC, MTPR, MTLN
where MTPC_MTPR = MTPR_COD
			and MTPR_MTDV = 3500
			and MTPR_ATVV = 'S'
			and MTPC_PRE > 0
			and MTPR_MTDV = MTLN_MTDV
			and MTPR_MTLN = MTLN_COD
			and MTPR_MTLN < 4150
--group by MTPR_MTDV, MTPR_MTLN, MTLN_NOM
*/
