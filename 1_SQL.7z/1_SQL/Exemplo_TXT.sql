SELECT substring(doc, charindex('(',doc)+1,6) OLD, substring(doc, 1,6) NEW, *
FROM OPENROWSET ('MSDASQL', 'Driver={Microsoft Text Driver (*.txt; *.csv)};DBQ=C:\0_Docs;', 'SELECT * from vdpd.txt') a
--28
SELECT PRNC_NUMX, *, substring(doc, charindex('(',doc)+1,6) OLD, substring(doc, 1,6) NEW 
--UPDATE [192.168.2.39].[mdl].[dbo].tmpRlri set Rlri_nec_new = convert(varchar(6),substring(doc, 1,6))+'/'+convert(varchar(6),prnc_cod) 
FROM OPENROWSET ('MSDASQL', 'Driver={Microsoft Text Driver (*.txt; *.csv)};DBQ=C:\0_Docs;', 'SELECT * from vdpd.txt') a
, [192.168.2.39].[mdl].[dbo].prnc b, [192.168.2.39].[mdl].[dbo].tmpRlri c
where prnc_sies = 7
			and prnc_sido = 'VDPD'
			and prnc_sise = '001'
			and prnc_npai = substring(doc, charindex('(',doc)+1,6)
			and Rlri_orde = convert(varchar(6),PRNC_SIEX)+'/'+PRNC_SIDX+'/'+PRNC_SISX+'/'+convert(varchar(6),PRNC_NUMX)
			--and Rlri_subl = convert(varchar(6),PRNC_SIEX)+'/'+PRNC_SIDX+'/'+PRNC_SISX+'/'+convert(varchar(6),PRNC_NUMX+'/'+convert(varchar(6),PRNC_SEQX))
order by DOC

select *
from [192.168.2.39].[mdl].[dbo].tmpRlri 
where Rlri_nec_new <> 0
