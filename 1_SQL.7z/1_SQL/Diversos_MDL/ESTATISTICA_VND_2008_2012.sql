drop table #new
select *
into #new
from FTNF a, FTIT b, MTPR
where FTNF_SIES = FTIT_SIES
			and FTNF_SIDO = FTIT_SIDO
			and FTNF_SISE = FTIT_SISE
			and FTNF_COD  = FTIT_FTNF
			and FTIT_MTPR = MTPR_COD
			and CONVERT(varchar(10), ftnf_dat,102) between '2008.01.01' and '2012.12.31'
			and FTIT_MTDV in ('0500', '1000', '1500', '2500', '3000', '3500')
			and FTNF_ES = 'S'
			--and FTIT_MTTR = 'SAIFAT'
			and FTNF_STA <> 'CA'
			and FTNF_GLXX NOT IN (5381,1)
			and FTIT_MTLN not in ('0300','0400')
			and FTIT_MTFM not in ('0150')

select top 10 *
from #new
group by FTIT_NFOP

SELECT FTIT_MTDV
FROM #new
GROUP BY FTIT_MTDV

select FTIT_MTDV 'DIVIS�O', FTIT_MTLN 'LINHA', FTIT_MTFM 'FAMILIA', sum(MTPR_PES)'PESO', CONVERT(DECIMAL(12,0),SUM(FTIT_QTD)) 'QTD'
from #new
where FTIT_MTDV = '0500'
			AND FTNF_SIES = 5
group BY FTIT_MTDV, FTIT_MTLN, FTIT_MTFM
order by FTIT_MTDV, FTIT_MTLN, FTIT_MTFM

select SUBSTRING(MTPR_COD,1,CHARINDEX('.',MTPR_COD)) 'SUB',year(ftnf_dat) 'ANO',FTIT_MTDV 'DIVIS�O', FTIT_MTLN 'LINHA', FTIT_MTFM 'FAMILIA', REPLACE(sum(MTPR_PES*FTIT_QTD),'.',',')'PESO', REPLACE(CONVERT(DECIMAL(12,0),SUM(FTIT_QTD)),'.',',') 'QTD', REPLACE(SUM(FTIT_VAL-(FTIT_VAL_COF + FTIT_VAL_PIS + FTIT_ICM_VAL)),'.',',') VALOR
from #new
where FTIT_MTDV = '3500'
			--AND FTNF_SIES = 5
--			and year(ftnf_dat) = 2012
group by SUBSTRING(MTPR_COD,1,CHARINDEX('.',MTPR_COD)) ,year(ftnf_dat), FTIT_MTDV, FTIT_MTLN, FTIT_MTFM
order by SUBSTRING(MTPR_COD,1,CHARINDEX('.',MTPR_COD)) ,year(ftnf_dat), FTIT_MTDV, FTIT_MTLN, FTIT_MTFM

/*
select MTPR_COD, REPLACE(FTIT_QTD,'.',','), REPLACE(MTPR_PES,'.',','), FTIT_VAL, FTIT_VAL_COF, FTIT_VAL_PIS, FTIT_ICM_VAL, FTIT_VAL-(FTIT_VAL_COF+ FTIT_VAL_PIS+ FTIT_ICM_VAL)
from #new
where FTIT_MTDV = '1000'
			AND SUBSTRING(MTPR_COD,1,CHARINDEX('.',MTPR_COD)) = 'B30.'
			--AND FTNF_SIES = 5
*/
