drop table #new
--VDPD_SIES, VDPD_SIDO, VDPD_SISE, VDPD_COD ,vdps_mtpc, vdps_mtpr, mtpr_cod,vdpi_mtpr, vdpd_dent, vdps_qtd, vdps_val, 
--SELECT * FROM VDPD WHERE VDPD_VAL = 0 AND VDPD_STA = 'OK' AND VDPD_DTC > '01/01/2008'
 
select convert(char(1),VDPD_SIES)+'/'+ VDPD_SIDO+'/'+ VDPD_SISE+'/'+convert(varchar(6), VDPD_COD) [COD], VDPD_SIES, VDPD_SIDO, VDPD_SISE, VDPD_COD ,vdps_mtpc, vdps_mtpr, mtpr_cod,vdpi_mtpr, VDPD_DTC vdpd_dent, vdps_qtd, vdps_val,vdpi_mtdv, MTPR_MTUN, mtpr_pes, vdpi_cod, VDPD_VDCO_COD, VDPD_VDCO_SIES, vdps_cod, ((VDPD_VALD*100/VDPD_VAL) )VDPI_DESC ,VDPD_VAL,VDPD_VALD,IDENTITY(int,1,1) NUM
--select top 100 *
into #new
from VDPD a, VDPI b, VDPS c, MTPR d
where VDPD_SIES = VDPI_SIES
			and VDPD_SIDO = VDPI_SIDO
			and VDPD_SISE = VDPI_SISE
			and VDPD_COD  = VDPI_VDPD
			and VDPD_SIES = VDPS_SIES
			and VDPD_SIDO = VDPS_SIDO
			and VDPD_SISE = VDPD_SISE
			and VDPD_COD  = VDPS_VDPD
			and VDPS_MTPR = MTPR_COD
			and VDPI_SIES = VDPS_SIES
			and VDPI_SIDO = VDPS_SIDO
			and VDPI_SISE = VDPS_SISE
			and VDPI_VDPD = VDPS_VDPD
			and VDPI_COD  = VDPS_VDPI
			and CONVERT(varchar(10), VDPD_DTC,102) between '2008.01.01' and '2012.12.31'
			and VDPI_MTDV in ('2000')
			and VDPD_STA = 'OK'
			--and VDPS_MTPC not in ('FURO','CAVI')
			--and FTIT_MTTR = 'SAIFAT'
			and VDPD_GLCL NOT IN (5381,1)
			and substring(VDPI_MTPR,1,1) = 'O'
			AND VDPD_VAL <> 0

--select top 1 * from vdpi

--select * from #new where COD = '1/vdpd/001/60003'

--Caso tenha furo ou cavidade transformar em ++ que � m�o de obra
update #new set vdps_mtpc = '++', vdps_mtpr = '++', mtpr_cod = '++'
from #new
where VDPS_MTPC in ('FURO','CAVI', 'RECURSOS','+')

drop table #MO
select COD, VDPI_COD, vdps_cod, IDENTITY(int,1,1) NUM_A
into #MO
from #new
where VDPI_MTDV = '2000'
			AND (MTPR_MTUN = 'KG' or (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)>20))
group by COD, VDPI_COD, vdps_cod
order by COD, VDPI_COD, vdps_cod


--select * from vdpi where vdpi_vdpd = 62739
delete
from #MO
where COD+'/'+convert(varchar(6),VDPI_COD) in (select COD+'/'+convert(varchar(6),VDPI_COD) from #new where VDPS_MTPC = '++' )

--select * from #MO a, #new b where a.cod = b.cod and a.cod = '1/vdpd/001/62739'
drop table #custo

select sum(VDCS_QTDE *VDCS_VUNI) VAL, a.COD, a.VDPI_COD, a.VDPS_COD --, a.VDPD_SIES   ,VDPD_SIDO ,VDPD_SISE ,VDPD_COD    ,vdps_mtpc            ,vdps_mtpr            ,mtpr_cod             ,vdpi_mtpr            ,vdpd_dent               ,vdps_qtd                                ,vdps_val                                ,vdpi_mtdv ,MTPR_MTUN ,mtpr_pes                                ,a.vdpi_cod    ,VDPD_VDCO_COD ,VDPD_VDCO_SIES ,NUM
into #custo
--select c.*, a.COD, a.VDPD_SIES   ,VDPD_SIDO ,VDPD_SISE ,VDPD_COD    ,vdps_mtpc            ,vdps_mtpr            ,mtpr_cod             ,vdpi_mtpr            ,vdpd_dent               ,vdps_qtd                                ,vdps_val                                ,vdpi_mtdv ,MTPR_MTUN ,mtpr_pes                                ,a.vdpi_cod    ,VDPD_VDCO_COD ,VDPD_VDCO_SIES ,NUM
from #new a, #MO b, VDCS c
where a.COD = b.COD
			and a.MTPR_MTUN = 'KG'--c.MTPR_COD
			and a.VDPD_VDCO_COD = VDCS_VDCO
			and a.VDPD_SIES = VDCS_SIES
			--and a.VDPD_SIDO =  VDC1_SIDO
			--and VDC1_SISE
			and a.VDPI_COD =  VDCS_VDC1
			and a.VDPS_COD = VDCS_SUB
			and a.COD = b.COD
--			and a.COD = '1/vdpd/001/60003'
			and a.VDPI_COD = b.VDPI_COD
			and a.VDPS_COD = b.VDPS_COD

group by a.COD, a.VDPI_COD, a.VDPS_COD
order by a.COD, a.VDPI_COD, a.VDPS_COD


update #new set vdps_val = vdps_val-val
--select vdps_val = vdps_val-val, vdps_val,val, *
from #new a, #custo b
where a.COD = b.COD
			and a.VDPI_COD = b.VDPI_COD
			and a.VDPS_COD = b.VDPS_COD
			AND (MTPR_MTUN = 'KG' or (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)>20))			

--select * from #new where MTPR_COD = '++'

insert into #new
--			 COD    VDPD_SIES    VDPD_SIDO  VDPD_SISE  VDPD_COD          vdps_mtpc                  vdps_mtpr                  mtpr_cod              vdpi_mtpr             vdpd_dent                vdps_qtd                                 vdps_val                                     vdpi_mtdv       MTPR_MTUN  mtpr_pes                                   vdpi_cod     VDPD_VDCO_COD  VDPD_VDCO_SIES    vdps_cod  VDPI_DESC  VDPD_VAL  VDPD_VALD  NUM
select a.COD, a.VDPD_SIES   ,VDPD_SIDO ,VDPD_SISE ,VDPD_COD    ,'++' vdps_mtpc            ,'++' vdps_mtpr            ,'++' mtpr_cod             ,vdpi_mtpr            ,vdpd_dent               ,vdps_qtd                                ,val vdps_val                                ,vdpi_mtdv ,'UN' MTPR_MTUN ,mtpr_pes                                ,a.vdpi_cod    ,VDPD_VDCO_COD ,VDPD_VDCO_SIES, a.vdps_cod, VDPI_DESC ,VDPD_VAL, VDPD_VALD
from #new a, #custo b
where a.COD = b.COD
			and a.VDPI_COD = b.VDPI_COD
			and a.VDPS_COD = b.VDPS_COD
			AND (MTPR_MTUN = 'KG' or (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)>20))			
		
--select * from vdcs where vdcs_vdco = 80867 


drop table #nova
declare 
@n int
--set @n = 145758
--set @n = 59587
set @n = 62739
--select vdpi_mtpr, year(VDPD_DENT) 'ANO',MTPR_MTDV 'DIVIS�O', MTPR_MTLN 'LINHA', MTPR_MTFM 'FAMILIA', REPLACE(sum(MTPR_PES*VDPS_QTD),'.',',')'PESO', REPLACE(CONVERT(DECIMAL(12,0),SUM(VDPS_QTD)),'.',',') 'QTD', REPLACE(SUM(VDPS_VAL-(0 + 1 + 2)),'.',',') VALOR
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '1_M.O.      ' 'PRE', sum(0) [PESO], CONVERT(DECIMAL(12,0),SUM(0)) [QTD], SUM(VDPS_QTD-(0 + 0 + 0)) [VALOR], SUM(VDPS_QTD*VDPI_DESC/100) [VALOR_DESCONTO]
into #nova
from #new
where VDPI_MTDV = '2000'
			AND VDPS_MTPR = '++'
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
--			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))


insert into #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '1_M.O.      ' 'PRE', sum(0)[PESO], CONVERT(DECIMAL(12,0),SUM(0)) [QTD], SUM(VDPS_VAL-((VDPS_QTD*MTPL_PESN*3.61)*.7275*1.489)) [VALOR], SUM((VDPS_VAL-((VDPS_QTD*MTPL_PESN*3.61)*.7275*1.489))*VDPI_DESC/100) [VALOR_DESCONTO]
from #new, MTPL
where VDPI_MTDV = '2000'
			--AND VDPS_MTPR = '++'
			and MTPR_COD = MTPL_MTPR
			AND (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('D','U','V','Y','Z'))			
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
--			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))


insert into #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '2_M.P.' 'PRE', sum(VDPS_QTD) [PESO], CONVERT(DECIMAL(12,0),SUM(0))[QTD], SUM(VDPS_VAL-(0 + 0 + 0))[VALOR], SUM((VDPS_VAL-(0 + 0 + 0))*VDPI_DESC/100)[VALOR_DESCONTO]
from #new
where VDPI_MTDV = '2000'
			AND (MTPR_MTUN = 'KG' or (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)>20))
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
--			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))

--select top 1 * from mtpl where mtpl_cod = '2520-cc1'

insert into #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '2_M.P.' 'PRE', sum(VDPS_QTD*MTPL_PESN) [PESO], CONVERT(DECIMAL(12,0),SUM(VDPS_QTD)) [QTD], SUM(VDPS_QTD*MTPL_PESN*3.61*.7275*1.489) [VALOR], SUM((VDPS_QTD*MTPL_PESN*3.61*.7275*1.489)*VDPI_DESC/100) [VALOR_DESCONTO]
from #new, MTPL
where VDPI_MTDV = '2000'
			AND (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('D','U','V','Y','Z'))
			and MTPR_COD = MTPL_MTPR
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
--			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))

insert into #nova
--select * from #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '3_'+substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.')) 'PRE', sum(VDPS_QTD*MTPR_PES) [PESO], CONVERT(DECIMAL(12,0),SUM(VDPS_QTD)) [QTD], SUM(VDPS_VAL-(0 + 0 + 0)) [VALOR], SUM((VDPS_VAL-(0 + 0 + 0))*VDPI_DESC/100) [VALOR_DESCONTO]
from #new
where VDPI_MTDV = '2000'
			AND MTPR_MTUN = 'pc' 
			AND (SUBSTRING(MTPR_COD,1,1) NOT in ('D','U','V','Y','Z') or SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)<20)
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
--			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))

--select top 10 * from #nova

select vdpi_mtpr, ANO, PRE, sum(PESO) [PESO], SUM(QTD) [QTD], replace(SUM(VALOR),'.',',') [VALOR], replace(SUM(VALOR_DESCONTO),'.',',') [VALOR_DESCONTO]
from #nova
--where PRE like '3_%'
GROUP BY vdpi_mtpr, ANO, PRE
order by vdpi_mtpr, ANO, PRE
--compute  sum(VALOR)


--select * from #new where VDPD_COD = 62739

