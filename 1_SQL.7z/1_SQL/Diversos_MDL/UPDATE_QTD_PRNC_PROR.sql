select PROR_QTDO, *
ALTER TABLE PROR DISABLE TRIGGER ALL
update pror set pror_qtdo = 201
from PROR
where PROR_SIES = 5
			and PROR_COD in (58557)
update pror set pror_qtdo = 200
from PROR
where PROR_SIES = 5
			and PROR_COD in (58640)
update pror set pror_qtdo = 225
from PROR
where PROR_SIES = 5
			and PROR_COD in (59005)
update pror set pror_qtdo = 216
from PROR
where PROR_SIES = 5
			and PROR_COD in (59014)

ALTER TABLE PROR ENABLE TRIGGER ALL

ALTER TABLE PRNC DISABLE TRIGGER ALL
update PRNC set prnc_qtd = 201
--select top 2 *
from PRNC, PROR
where PRNC_SIES = 5
			and PROR_COD in (58557)
			and PRNC_NPAI = PROR_NPAX
			and PRNC_SIDO = PROR_SIDX
			
update PRNC set prnc_qtd = 200
from PRNC, PROR
where PROR_SIES = 5
			and PROR_COD in (58640)
			and PRNC_NPAI = PROR_NPAX
			and PRNC_SIDO = PROR_SIDX

update PRNC set PRNC_QTD = 225
from PRNC, PROR
where PROR_SIES = 5
			and PROR_COD in (59005)
			and PRNC_NPAI = PROR_NPAX
			and PRNC_SIDO = PROR_SIDX

update PRNC set PRNC_QTD = 216
from PRNC, PROR
where PROR_SIES = 5
			and PROR_COD in (59014)
			and PRNC_NPAI = PROR_NPAX
			and PRNC_SIDO = PROR_SIDX

ALTER TABLE PRNC ENABLE TRIGGER ALL
