drop table #cod
select replace(MTPX_COD,'R','S') COD, MTPX_COD COD_NEW 
into #cod
from MTPX
where MTPX_SIEX = 3
			and MTPX_COD like 'R%'
			and MTPX_NOM like '%spring%'
			
			
select *
--update mtpx set mtpx_cod = cod_new
from MTPX, #cod
where MTPX_SIEX = 5
			and MTPX_COD = COD


select *
--update EXMI set exmi_mtpe = cod_new
from EXMI, #cod
where EXMI_EXMP = 6635
			and EXMI_MTPE = COD
			
insert into [192.168.3.39].[bkp].[dbo].COD
select *
from #cod

select *
--update EXPI set EXPI_MTPE = cod_new
from EXPI, #cod
where EXPI_EXMP = 6635
			and EXPI_EXPV = 3
			and EXPI_MTPE = COD

ALTER TABLE [192.168.3.39].[bkp].[dbo].[vdpi] DISABLE TRIGGER ALL
select *
--update [192.168.3.39].[bkp].[dbo].[vdpi] set vdpi_mtpc = cod_new, vdpi_mtpr = cod_new
from [192.168.3.39].[bkp].[dbo].[vdpi], #cod
where vdpi_vdpd = 36870
			and vdpi_mtpc = COD

ALTER TABLE [192.168.3.39].[bkp].[dbo].[vdpi] ENABLE TRIGGER ALL
