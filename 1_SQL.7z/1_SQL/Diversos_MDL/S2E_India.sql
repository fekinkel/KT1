--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Autor                : Rodrigo Dias
--Data                : 02/02/2015
--Solicitante    : Sr(a). Eliane(Sidor)
--Objetivo 01    : ATUALIZAR Lista de pre�o S2E (LISTA 19 E 20)
--Campos            :
--Restries        :
--Observaes        :
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-----------------------------------------
-- TABELA VAZIA PARA OS NOVOS PRECOS INDIA
-----------------------------------------
-- drop table [192.168.3.39].[bkp].[dbo].[lista_19_20]
drop table #INSUMO
SELECT [Part #],   [Base part #] INSUMO , [Base part #] INSUMO2
            , [INSUMO_INT] = MTPX_MTPU
            ,   [SIDOR -> PE] PRECO_19    , [PE -> IN] PRECO_20,    [US -> IN]
            ,'999999/99' [Contrato_US_IN], 	'999999/99' [Cotacao_IN_BR]
            ,'999999/99' [Cotacao_IN_US]
        -- select [Part #],    INSUMO, INSUMO2 , [INSUMO_INT], PRECO_19    , PRECO_20,    [US -> IN],    F6,    [PE situation],    F8,    [Todos valores em USD]         -- select * 
INTO #INSUMO
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\INDIA_2016.XLS',HOJA1$),  MTPX 
where 1 = 0
-----------------------------------------
-- TABELA DADOS NOVOS PRECOS INDIA
-----------------------------------------
insert into #INSUMO
select MAX([Part #]),    [Base part #]
            , INSUMO2 = SUBSTRING([Base part #], 1, 3) + N'.' + SUBSTRING([Base part #], 4, 3) + N'.' + SUBSTRING([Base part #], 7, 3)
            , [INSUMO_INT] = N' '        -- N'aaaaaaaaaaaa'
            ,    max([SIDOR -> PE])    , max([PE -> IN]),    max([US -> IN])
            , ''
            , ''
            , ''
--select *--nome--, identity(int,1,1) NUM
FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\INDIA_2016.XLS',HOJA1$) --from [192.168.3.39].[bkp].[dbo].[lista_19_20_2]
group by [Base part #]

-----------------------------------------
-- ATUALIZAR CODIGO INTERNACIONAL
-----------------------------------------
update #insumo set
-- SELECT *,
            [INSUMO_INT] = MTPX_MTPU
FROM #INSUMO             LEFT JOIN MTPX                     ON MTPX_COD = INSUMO2 AND MTPX_SIEX = 3 

--SELECT * FROM #INSUMO
-----------------------------------------
-- ATUALIZAR PRE�O BRASIL PORT ELLEN
-----------------------------------------
select MTPV_VAL , REPLACE(PRECO_19, N',', N'.') , [Part #],    INSUMO    ,INSUMO2    ,INSUMO_INT, b.*
--UPDATE MTPV SET MTPV_VAL = REPLACE(PRECO_19, N',', N'.'), MTPV_USU = N'KINKEL', MTPV_DTU = GETDATE()
from #INSUMO a, mtpv b
where INSUMO_INT =	MTPV_MTPU 
and MTPV_MTTV = 19

-----------------------------------------
-- ATUALIZAR PRE�O PORT ELLEN BRASIL
-----------------------------------------
select MTPV_VAL , REPLACE(PRECO_20, N',', N'.') , [Part #],    INSUMO    ,INSUMO2    ,INSUMO_INT, b.*
--UPDATE MTPV SET MTPV_VAL = REPLACE(PRECO_20, N',', N'.'), MTPV_USU = N'KINKEL', MTPV_DTU = GETDATE()
from #INSUMO a, mtpv b
where INSUMO_INT =	MTPV_MTPU 
and MTPV_MTTV = 20
--341
----
-----------------------------------------
-- CONTRATO VENDA USA PARA INDIA
-----------------------------------------
select REPLACE(PRECO_20, N',', N'.'), VDCX_PUN_VAL, *
--UPDATE MTPV SET MTPV_VAL = REPLACE(PRECO_20, N',', N'.'), MTPV_USU = N'KINKEL', MTPV_DTU = GETDATE()
from #INSUMO a, [192.168.6.2\sqlexpress].[MDL-USA].[dbo].[vdcx] b
where VDCX_VDCV = 61013
and VDCX_MTPC = INSUMO
-----------------------------------------
-- ATUALIZAR PLANILHA COM O NUMERO CONTRADO USA
-----------------------------------------
select *--REPLACE(PRECO_20, N',', N'.'), VDCX_PUN_VAL, *
--UPDATE OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\INDIA_2016.XLS',HOJA1$) SET [Contrato_US_IN] = '61013'
from #INSUMO a, OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\INDIA_2016.XLS',HOJA1$) c, [192.168.6.2\sqlexpress].[MDL-USA].[dbo].[vdcx] b
where a.[Part #] = c.[Part #]
and VDCX_VDCV = 61013
and VDCX_MTPC = INSUMO
and INSUMO = 'P20080500'

-----------------------------------------
-- ATUALIZAR COTA��O DE COMPRAS INDIA PARA BRASIL
-----------------------------------------
select REPLACE(PRECO_20, N',', N'.'), CPCT_PUN_GLFO, * 
--UPDATE MTPV SET MTPV_VAL = REPLACE(PRECO_20, N',', N'.'), MTPV_USU = N'KINKEL', MTPV_DTU = GETDATE()
from #INSUMO a, [192.168.5.1\sqlexpress].[INDIA].[dbo].[cpct] b
where CPCT_STA = 'OK'
and CPCT_MTPC = INSUMO
and CPCT_GLXX = 200137

drop table #EXCEL
select * 
--UPDATE OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\INDIA_2016.XLS',HOJA1$) SET [Cotacao_IN_BR] = CPCT_COD
from #INSUMO a, [192.168.5.1\sqlexpress].[INDIA].[dbo].[cpct] b--, OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=C:\Temp\INDIA_2016.XLS',HOJA1$) c
where a.[Part #] = c.[Part #]
and CPCT_STA = 'OK'
and CPCT_MTPC = INSUMO
and CPCT_GLXX = 200137

-----------------------------------------
-- ATUALIZAR COTA��O INDIA USA
-----------------------------------------
select REPLACE(PRECO_20, N',', N'.'), CPCT_PUN_GLFO, *
--UPDATE MTPV SET MTPV_VAL = REPLACE(PRECO_20, N',', N'.'), MTPV_USU = N'KINKEL', MTPV_DTU = GETDATE()
from #INSUMO a, [192.168.5.1\sqlexpress].[INDIA].[dbo].[cpct] b
where CPCT_STA = 'OK'
and CPCT_MTPC = INSUMO
and CPCT_GLXX = 200001
