insert into [india].[dbo].[MTDV]
select *
from MTDV
where MTDV_COD not in (select MTDV_COD from [india].[dbo].[MTDV])

insert into [india].[dbo].[MTLN]
select *
from MTLN
where MTLN_MTDV+'/'+MTLN_COD not in (select MTLN_MTDV+'/'+MTLN_COD from [india].[dbo].[MTLN])

insert into [india].[dbo].[MTTP]
select *
from MTTP
where MTTP_COD not in (select MTTP_COD from [india].[dbo].[MTTP])

insert into [india].[dbo].[MTTP]
select *
from MTTP
where MTfm_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD not in (select MTfm_MTDV+'/'+MTFM_MTLN+'/'+MTFM_COD from [india].[dbo].[MTFM])


insert into [india].[dbo].[MTPR]
select MTPR_COD ,MTPR_MTTP ,MTPR_MS ,'N' MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU
from MTPR
where MTPR_COD not in (select MTPR_COD from [india].[dbo].MTPR)


insert into [india].[dbo].[mtes]
select *
from MTES
where MTES_MTPR+'/'+CONVERT(varchar(6), mtes_sies) not in (select MTES_MTPR+'/'+CONVERT(varchar(6), mtes_sies) from [india].[dbo].[mtes])

select *
from PRGT
where CONVERT(varchar(6),prgt_sies)+'/'+PRGT_COD not in (select CONVERT(varchar(6),prgt_sies)+'/'+PRGT_COD from [india].[dbo].PRGT)

insert into [india].[dbo].PRCT
select *
from PRCT
where CONVERT(varchar(6),PRCT_SIES)+'/'+PRCT_COD not in (select CONVERT(varchar(6),PRCT_SIES)+'/'+PRCT_COD from [india].[dbo].PRCT)

insert into [india].[dbo].PROP
select *
from PROP
where convert(varchar(6),PROP_SIES)+'/'+PROP_COD not in (select convert(varchar(6),PROP_SIES)+'/'+PROP_COD from [india].[dbo].prop)

insert into [india].dbo.prra
select *
from prra
where PRRA_MTPR+'/'+CONVERT(varchar(6),prra_sies)+'/'+CONVERT(varchar(6),prra_cod) not in (select PRRA_MTPR+'/'+CONVERT(varchar(6),prra_sies)+'/'+CONVERT(varchar(6),prra_cod) from [india].dbo.PRRA)


insert into [india].[dbo].PRRO
select *
from PRRO
where PRRO_MTPR+'/'+CONVERT(varchar(6),PRRO_SIES)+'/'+CONVERT(varchar(6),prro_prra)+'/'+CONVERT(varchar(6),prro_cod)not in (select PRRO_MTPR+'/'+CONVERT(varchar(6),PRRO_SIES)+'/'+CONVERT(varchar(6),prro_prra)+'/'+CONVERT(varchar(6),prro_cod) from [INDIA].[dbo].PRRO)
