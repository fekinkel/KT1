
ALTER TABLE vdpi DISABLE TRIGGER ALL
select *
--update vdpi set vdpi_mtpc = cod_new, vdpi_mtpr = cod_new
from vdpi, cod
where vdpi_vdpd = 36870
			and vdpi_mtpc = COD


ALTER TABLE vdpi ENABLE TRIGGER ALL