/*
IF OBJECT_ID('TempDB.dbo.#VDC1') IS NOT NULL DROP TABLE #VDC1SELECT IDENTITY(INT,1,1) NUM, * INTO #VDC1 FROM VDC1 WHERE 1 = 0INSERT INTO #VDC1SELECT 		VDC1_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, VDC1_SIDO = CONVERT(varchar(4),'VDCO')      --CONVERT(varchar(4),'') Tipo
	, VDC1_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, VDC1_VDCO = CONVERT(int,314229)      --CONVERT(int(6),'') N�mero
	, VDC1_COD = CONVERT(int,'1')      --CONVERT(int(3),'') Item
	, VDC1_SUB = CONVERT(int,'1')      --CONVERT(int(3),'') Sub_item
	, VDC1_TIPO = CONVERT(varchar(4),'OSPL')      --CONVERT(varchar(4),'') Tipo
	, VDC1_MTPC = CONVERT(varchar(20),'OSPL')      --CONVERT(varchar(20),'') Refer�ncia
	, VDC1_MTPC_NOM = Null      --CONVERT(varchar(254),'') Nome
	, VDC1_ORC = Null      --CONVERT(varchar(12),'') Or�amento
	, VDC1_REV = CONVERT(varchar(1),'I')      --CONVERT(varchar(1),'') Destina��o
	, VDC1_QTDE = 1--Null      --CONVERT(decimal(12),'') Quantidade
	, VDC1_PUNI = 0--Null      --CONVERT(decimal(12),'') Pre�o
	, VDC1_DESC = 0--Null      --CONVERT(decimal(9),'') Desconto %
	, VDC1_PUNID = 0--Null      --CONVERT(decimal(12),'') Pre�o c/ desc.
	, VDC1_PENT = 0--CONVERT(int(3),'')      --CONVERT(int(3),'') Entrega (dias)
	, VDC1_VAL = 0--Null      --CONVERT(decimal(12),'') Total Item
	, VDC1_SMDO = CONVERT(char(1),'N')      --CONVERT(char(1),'') S� MDO
	, VDC1_OBS = Null      --CONVERT(varchar(4000),'') Obs.
	, VDC1_CMDO = 0--Null      --CONVERT(decimal(12),'') Recursos
	, VDC1_CMAT = 0--Null      --CONVERT(decimal(12),'') Material
	, VDC1_FATR = 0--Null      --CONVERT(decimal(9),'') Fator
	, VDC1_FMAT = 0--Null      --CONVERT(decimal(9),'') Fator MAT
	, VDC1_FMDO = 0--Null      --CONVERT(decimal(9),'') Fator MDO
	, VDC1_ESPE = CONVERT(char(1),'N')      --CONVERT(char(1),'') Especial
	, VDC1_MTPR = CONVERT(varchar(20),'X01.028.575')-- Insumo
	, VDC1_PBRU = 0--Null      --CONVERT(decimal(12),'') Peso br. un.
	, VDC1_PESO = 0--Null      --CONVERT(decimal(12),'') Peso
	, VDC1_PLQT = 0--Null      --CONVERT(decimal(13),'') Peso Tot.
	, VDC1_PBRT = 0--Null      --CONVERT(decimal(12),'') Peso bruto
	, VDC1_VDCV = 0--Null      --CONVERT(int(6),'') Contrato
	, VDC1_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, VDC1_MTUN = CONVERT(varchar(3),'PC')      --CONVERT(varchar(3),'') Unidade
	, VDC1_MTNC = CONVERT(varchar(8),'84669410')      --CONVERT(varchar(8),'') NCM
	, VDC1_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, VDC1_MTDV = CONVERT(varchar(4),'2000')      --CONVERT(varchar(4),'') Divis�o
	, VDC1_MTLN = CONVERT(varchar(4),'2600')      --CONVERT(varchar(4),'') Linha
	, VDC1_MTFM = CONVERT(varchar(4),'3270')      --CONVERT(varchar(4),'') Fam�lia
	, VDC1_COMPO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Composto
	, VDC1_EST = CONVERT(char(1),'S')      --CONVERT(char(1),'') Estoque
	, VDC1_NFOP = CONVERT(varchar(8),'5.101.B')      --CONVERT(varchar(8),'') Oper.
	, VDC1_CFOP = CONVERT(varchar(6),'5.101')-- CFOP
	, VDC1_TIT = CONVERT(char(1),'S')      --CONVERT(char(1),'') Gera t�tulos
	, VDC1_TBB = '20'--Null      --CONVERT(varchar(2),'') Tabela B
	, VDC1_MEN = Null      --CONVERT(varchar(255),'') Mensagem
	, VDC1_IPI_BAS = 0--Null      --CONVERT(decimal(12),'') Base IPI
	, VDC1_IPI_ALI = 0--Null      --CONVERT(decimal(6),'') % IPI
	, VDC1_IPI_VAL = 0--Null      --CONVERT(decimal(12),'') Valor IPI
	, VDC1_IPI_ISE = 0--Null      --CONVERT(decimal(12),'') IPI Isento
	, VDC1_IPI_OUT = 0--Null      --CONVERT(decimal(12),'') IPI Outros
	, VDC1_ISS_BAS = 0--Null      --CONVERT(decimal(12),'') Base de ISS
	, VDC1_ISS_ALI = 0--Null      --CONVERT(decimal(5),'') % ISS
	, VDC1_ISS_VAL = 0--Null      --CONVERT(decimal(12),'') Valor do ISS
	, VDC1_ISS_ISE = 0--Null      --CONVERT(decimal(12),'') ISS Isento
	, VDC1_ISS_OUT = 0--Null      --CONVERT(decimal(12),'') ISS Isento
	, VDC1_ICM_BAS = 0--Null      --CONVERT(decimal(12),'') Base ICMS
	, VDC1_ICM_ALI = 0--Null      --CONVERT(decimal(5),'') % ICMS
	, VDC1_ICM_VAL = 0--Null      --CONVERT(decimal(12),'') Valor do ICMS
	, VDC1_ICM_ISE = 0--Null      --CONVERT(decimal(12),'') ICMS Isento
	, VDC1_ICM_OUT = 0--Null      --CONVERT(decimal(12),'') ICMS Outros
	, VDC1_IST_BAS = 0--Null      --CONVERT(decimal(12),'') Base ICMS - ST
	, VDC1_IST_ALI = 0--Null      --CONVERT(decimal(5),'') % ICMS - ST
	, VDC1_IST_VAL = 0--Null      --CONVERT(decimal(12),'') Valor do ICMS - ST
	, VDC1_IST_ISE = 0--Null      --CONVERT(decimal(12),'') ICMS Isento - ST
	, VDC1_IST_OUT = 0--Null      --CONVERT(decimal(12),'') ICMS Outros - ST
	, VDC1_IST_IVA = 0--Null      --CONVERT(decimal(12),'') ST- IVA %
	, VDC1_ICP_ALI = 0--Null      --CONVERT(decimal(6),'') %ICMS Complem.
	, VDC1_ICP_VAL = 0--Null      --CONVERT(decimal(12),'') Valor ICMS Complem.
	, VDC1_PIS_CST = '00'--Null      --CONVERT(varchar(2),'') CST PIS
	, VDC1_PIS_NAT = '01'--Null      --CONVERT(varchar(2),'') Nat BC PIS
	, VDC1_PIS_BAS = 0--Null      --CONVERT(decimal(12),'') Base PIS
	, VDC1_PIS_ALI = 0--Null      --CONVERT(decimal(5),'') % PIS
	, VDC1_PIS_VAL = 0--Null      --CONVERT(decimal(12),'') Valor PIS
	, VDC1_PIS_ISE = 0--Null      --CONVERT(decimal(12),'') PIS Isento
	, VDC1_PIS_OUT = 0--Null      --CONVERT(decimal(12),'') PIS Outros
	, VDC1_COF_CST = '01'--Null      --CONVERT(varchar(2),'') CST COF
	, VDC1_COF_NAT = '00'--Null      --CONVERT(varchar(2),'') Nat BC COF
	, VDC1_COF_BAS = 0--Null      --CONVERT(decimal(12),'') Base COF
	, VDC1_COF_ALI = 0--Null      --CONVERT(decimal(5),'') % COF
	, VDC1_COF_VAL = 0--Null      --CONVERT(decimal(12),'') Valor COFINS
	, VDC1_COF_ISE = 0--Null      --CONVERT(decimal(12),'') c Isento
	, VDC1_COF_OUT = 0--Null      --CONVERT(decimal(12),'') COFINS Outros
	, VDC1_VAL_FRE = 0--Null      --CONVERT(decimal(12),'') Frete
	, VDC1_VAL_SEG = 0--Null      --CONVERT(decimal(12),'') Seguro
	, VDC1_VAL_ACE = 0--Null      --CONVERT(decimal(12),'') Desp. Aces.
	, VDC1_VAL_DES = 0--Null      --CONVERT(decimal(12),'') Descontos
	, VDC1_ICMS_ST = 0--Null      --CONVERT(decimal(12),'') ICMS ST
	, VDC1_VAL_TRC = 0--Null      --CONVERT(decimal(12),'') Tributos
	, VDC1_VAL_TRN = 0--Null      --CONVERT(decimal(12),'') Tributos N
	, VDC1_MTTR = 'SAIFAT'--Null      --CONVERT(varchar(6),'') Transa��o
	, VDC1_CTPC = '4101010001'--Null      --CONVERT(varchar(15),'') Cont�bil
	, VDC1_RDPC = ''--Null      --CONVERT(varchar(7),'') Rdz.
	, VDC1_CTCC = '210199'--Null      --CONVERT(varchar(15),'') C.C.
	, VDC1_RDCC = Null      --CONVERT(varchar(7),'') Rdz.
	, VDC1_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDC1_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDC1_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDC1_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM VDOP a--, VDOP b--, VDOP c
WHERE a.VDOP_VDOM = 'a36'
and VDOP_ESPM <= 110.00
--and a.VDOP_VDOM = b.VDOP_VDOM
--and a.VDOP_ESPM = b.VDOP_ESPM
--and b.VDOP_ESPM <= a.VDOP_ESPM - 0.01


--and b.VDOP_VDOM = 'a36'
--and c.VDOP_VDOM = 'a36'

--SELECT * FROM VDC1 WHERE VDC1_VDCO = 314229
--ALTER TABLE VDC1 DISABLE TRIGGER ALL--ALTER INDEX ALL ON VDC1 DISABLE;INSERT INTO VDC1SELECT VDC1_SIES ,VDC1_SIDO ,VDC1_SISE ,VDC1_VDCO ,VDC1_COD ,NUM VDC1_SUB ,VDC1_TIPO ,VDC1_MTPC ,VDC1_MTPC_NOM ,VDC1_ORC ,VDC1_REV ,VDC1_QTDE ,VDC1_PUNI ,VDC1_DESC ,VDC1_PUNID ,VDC1_PENT ,VDC1_VAL ,VDC1_SMDO ,VDC1_OBS ,VDC1_CMDO ,VDC1_CMAT ,VDC1_FATR ,VDC1_FMAT ,VDC1_FMDO ,VDC1_ESPE ,VDC1_MTPR ,VDC1_PBRU ,VDC1_PESO ,VDC1_PLQT ,VDC1_PBRT ,VDC1_VDCV ,VDC1_MS ,VDC1_MTUN ,VDC1_MTNC ,VDC1_ORI ,VDC1_MTDV ,VDC1_MTLN ,VDC1_MTFM ,VDC1_COMPO ,VDC1_EST ,VDC1_NFOP ,VDC1_CFOP ,VDC1_TIT ,VDC1_TBB ,VDC1_MEN ,VDC1_IPI_BAS ,VDC1_IPI_ALI ,VDC1_IPI_VAL ,VDC1_IPI_ISE ,VDC1_IPI_OUT ,VDC1_ISS_BAS ,VDC1_ISS_ALI ,VDC1_ISS_VAL ,VDC1_ISS_ISE ,VDC1_ISS_OUT ,VDC1_ICM_BAS ,VDC1_ICM_ALI ,VDC1_ICM_VAL ,VDC1_ICM_ISE ,VDC1_ICM_OUT ,VDC1_IST_BAS ,VDC1_IST_ALI ,VDC1_IST_VAL ,VDC1_IST_ISE ,VDC1_IST_OUT ,VDC1_IST_IVA ,VDC1_ICP_ALI ,VDC1_ICP_VAL ,VDC1_PIS_CST ,VDC1_PIS_NAT ,VDC1_PIS_BAS ,VDC1_PIS_ALI ,VDC1_PIS_VAL ,VDC1_PIS_ISE ,VDC1_PIS_OUT ,VDC1_COF_CST ,VDC1_COF_NAT ,VDC1_COF_BAS ,VDC1_COF_ALI ,VDC1_COF_VAL ,VDC1_COF_ISE ,VDC1_COF_OUT ,VDC1_VAL_FRE ,VDC1_VAL_SEG ,VDC1_VAL_ACE ,VDC1_VAL_DES ,VDC1_ICMS_ST ,VDC1_VAL_TRC ,VDC1_VAL_TRN ,VDC1_MTTR ,VDC1_CTPC ,VDC1_RDPC ,VDC1_CTCC ,VDC1_RDCC ,VDC1_USC ,VDC1_DTC ,VDC1_USU ,VDC1_DTUFROM #VDC1WHERE CONVERT(VARCHAR(6),VDC1_SIES)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+CONVERT(VARCHAR(6),VDC1_VDCO)+'/'+CONVERT(VARCHAR(6),VDC1_COD)+'/'+CONVERT(VARCHAR(6),NUM) NOT IN (SELECT CONVERT(VARCHAR(6),VDC1_SIES)+'/'+VDC1_SIDO+'/'+VDC1_SISE+'/'+CONVERT(VARCHAR(6),VDC1_VDCO)+'/'+CONVERT(VARCHAR(6),VDC1_COD)+'/'+CONVERT(VARCHAR(6),VDC1_SUB) FROM VDC1)
--ALTER INDEX ALL ON VDC1 REBUILD;--ALTER TABLE VDC1 ENABLE TRIGGER ALL--VDC1_SIES ,VDC1_SIDO ,VDC1_SISE ,VDC1_VDCO ,VDC1_COD ,VDC1_SUB ,VDC1_TIPO ,VDC1_MTPC ,VDC1_MTPC_NOM ,VDC1_ORC ,VDC1_REV ,VDC1_QTDE ,VDC1_PUNI ,VDC1_DESC ,VDC1_PUNID ,VDC1_PENT ,VDC1_VAL ,VDC1_SMDO ,VDC1_OBS ,VDC1_CMDO ,VDC1_CMAT ,VDC1_FATR ,VDC1_FMAT ,VDC1_FMDO ,VDC1_ESPE ,VDC1_MTPR ,VDC1_PBRU ,VDC1_PESO ,VDC1_PLQT ,VDC1_PBRT ,VDC1_VDCV ,VDC1_MS ,VDC1_MTUN ,VDC1_MTNC ,VDC1_ORI ,VDC1_MTDV ,VDC1_MTLN ,VDC1_MTFM ,VDC1_COMPO ,VDC1_EST ,VDC1_NFOP ,VDC1_CFOP ,VDC1_TIT ,VDC1_TBB ,VDC1_MEN ,VDC1_IPI_BAS ,VDC1_IPI_ALI ,VDC1_IPI_VAL ,VDC1_IPI_ISE ,VDC1_IPI_OUT ,VDC1_ISS_BAS ,VDC1_ISS_ALI ,VDC1_ISS_VAL ,VDC1_ISS_ISE ,VDC1_ISS_OUT ,VDC1_ICM_BAS ,VDC1_ICM_ALI ,VDC1_ICM_VAL ,VDC1_ICM_ISE ,VDC1_ICM_OUT ,VDC1_IST_BAS ,VDC1_IST_ALI ,VDC1_IST_VAL ,VDC1_IST_ISE ,VDC1_IST_OUT ,VDC1_IST_IVA ,VDC1_ICP_ALI ,VDC1_ICP_VAL ,VDC1_PIS_CST ,VDC1_PIS_NAT ,VDC1_PIS_BAS ,VDC1_PIS_ALI ,VDC1_PIS_VAL ,VDC1_PIS_ISE ,VDC1_PIS_OUT ,VDC1_COF_CST ,VDC1_COF_NAT ,VDC1_COF_BAS ,VDC1_COF_ALI ,VDC1_COF_VAL ,VDC1_COF_ISE ,VDC1_COF_OUT ,VDC1_VAL_FRE ,VDC1_VAL_SEG ,VDC1_VAL_ACE ,VDC1_VAL_DES ,VDC1_ICMS_ST ,VDC1_VAL_TRC ,VDC1_VAL_TRN ,VDC1_MTTR ,VDC1_CTPC ,VDC1_RDPC ,VDC1_CTCC ,VDC1_RDCC ,VDC1_USC ,VDC1_DTC ,VDC1_USU ,VDC1_DTU ,
*/

declare
@x decimal(8,2),
@y decimal(8,2),
@p varchar(3)

Set @x = 1000.00; set @y = 800.00; set @p = 'P1'
--Set @x = 800.00; set @y = 300.00; set @p = 'P1'
--Set @x = 600.00; set @y = 250.00; set @p = 'P1'
--Set @x = 1000.00; set @y = 800.00; set @p = 'P7'
--Set @x = 800.00; set @y = 300.00; set @p = 'P7'
--Set @x = 600.00; set @y = 250.00; set @p = 'P7'

delete from vdca where vdca_vdco = 314229

IF OBJECT_ID('TempDB.dbo.#VDCA') IS NOT NULL DROP TABLE #VDCASELECT IDENTITY(INT,1,3) NUM, * INTO #VDCA FROM VDCA WHERE 1 = 0INSERT INTO #VDCASELECT 		VDCA_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, VDCA_SIDO = CONVERT(varchar(4),'VDCO')      --CONVERT(varchar(4),'') Tipo
	, VDCA_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, VDCA_VDCO = CONVERT(int,'314229')      --CONVERT(int(6),'') N�mero
	, VDCA_COD = CONVERT(int,'1')      --CONVERT(int(3),'') Item
	, VDCA_SUB = CONVERT(int,'1')      --CONVERT(int(3),'') Sub_item
	, VDCA_GLPR_MONT = CONVERT(varchar(6),'ORMTPL')      --CONVERT(varchar(6),'') ORMTPL
	, VDCA_MONT = CONVERT(varchar(6),'C1')      --CONVERT(varchar(6),'') Placa
	, VDCA_COMP = CONVERT(decimal(8,2),@x)      --CONVERT(decimal(8),'') Comprimento
	, VDCA_ACTP = CONVERT(varchar(6),@p)      --CONVERT(varchar(6),'') Acabamento
	, VDCA_LARG = CONVERT(decimal(8,2),@y)      --CONVERT(decimal(8),'') Largura
	, VDCA_VDOM = CONVERT(varchar(6),'A36')      --CONVERT(varchar(6),'') Material
	, VDCA_ESPE = CONVERT(decimal(6,2),VDOP_ESPM-0.1)      --CONVERT(decimal(6),'') Espessura
	, VDCA_ACCH = CONVERT(char(1),'N')      --CONVERT(char(1),'') Chanfro Lateral
	, VDCA_GLPR_ACTP = CONVERT(varchar(6),'ORACTP')      --CONVERT(varchar(6),'') ORACTP
	, VDCA_DTOX = CONVERT(char(1),'S')      --CONVERT(char(1),'') Oxicorte
	, VDCA_GLPR_ICRC = CONVERT(varchar(6),'ORICRC')      --CONVERT(varchar(6),'') ORICRC
	, VDCA_ICQT = 0--Null      --CONVERT(int(8),'') Furos de I�amento
	, VDCA_ICRC = CONVERT(varchar(6),'M08')      --CONVERT(varchar(6),'') Rosca
	, VDCA_COMF = CONVERT(char(1),'S')      --CONVERT(char(1),'') Com furos
	, VDCA_FAIX = 'N'--Null      --CONVERT(char(1),'') Faixa Ref.:
	, VDCA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDCA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDCA_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDCA_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM VDOP
WHERE VDOP_VDOM = 'a36'and VDOP_ESPM <= 110.00
INSERT INTO #VDCASELECT 		VDCA_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, VDCA_SIDO = CONVERT(varchar(4),'VDCO')      --CONVERT(varchar(4),'') Tipo
	, VDCA_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, VDCA_VDCO = CONVERT(int,'314229')      --CONVERT(int(6),'') N�mero
	, VDCA_COD = CONVERT(int,'1')      --CONVERT(int(3),'') Item
	, VDCA_SUB = CONVERT(int,'1')      --CONVERT(int(3),'') Sub_item
	, VDCA_GLPR_MONT = CONVERT(varchar(6),'ORMTPL')      --CONVERT(varchar(6),'') ORMTPL
	, VDCA_MONT = CONVERT(varchar(6),'C1')      --CONVERT(varchar(6),'') Placa
	, VDCA_COMP = CONVERT(decimal(8,2),@x)      --CONVERT(decimal(8),'') Comprimento
	, VDCA_ACTP = CONVERT(varchar(6),@p)      --CONVERT(varchar(6),'') Acabamento
	, VDCA_LARG = CONVERT(decimal(8,2),@y)      --CONVERT(decimal(8),'') Largura
	, VDCA_VDOM = CONVERT(varchar(6),'A36')      --CONVERT(varchar(6),'') Material
	, VDCA_ESPE = CONVERT(decimal(6,2),VDOP_ESPM)      --CONVERT(decimal(6),'') Espessura
	, VDCA_ACCH = CONVERT(char(1),'N')      --CONVERT(char(1),'') Chanfro Lateral
	, VDCA_GLPR_ACTP = CONVERT(varchar(6),'ORACTP')      --CONVERT(varchar(6),'') ORACTP
	, VDCA_DTOX = CONVERT(char(1),'S')      --CONVERT(char(1),'') Oxicorte
	, VDCA_GLPR_ICRC = CONVERT(varchar(6),'ORICRC')      --CONVERT(varchar(6),'') ORICRC
	, VDCA_ICQT = 0--Null      --CONVERT(int(8),'') Furos de I�amento
	, VDCA_ICRC = CONVERT(varchar(6),'M08')      --CONVERT(varchar(6),'') Rosca
	, VDCA_COMF = CONVERT(char(1),'S')      --CONVERT(char(1),'') Com furos
	, VDCA_FAIX = 'N'--Null      --CONVERT(char(1),'') Faixa Ref.:
	, VDCA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDCA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDCA_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDCA_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM VDOP
WHERE VDOP_VDOM = 'a36'and VDOP_ESPM <= 110.00
INSERT INTO #VDCASELECT 		VDCA_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, VDCA_SIDO = CONVERT(varchar(4),'VDCO')      --CONVERT(varchar(4),'') Tipo
	, VDCA_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, VDCA_VDCO = CONVERT(int,'314229')      --CONVERT(int(6),'') N�mero
	, VDCA_COD = CONVERT(int,'1')      --CONVERT(int(3),'') Item
	, VDCA_SUB = CONVERT(int,'1')      --CONVERT(int(3),'') Sub_item
	, VDCA_GLPR_MONT = CONVERT(varchar(6),'ORMTPL')      --CONVERT(varchar(6),'') ORMTPL
	, VDCA_MONT = CONVERT(varchar(6),'C1')      --CONVERT(varchar(6),'') Placa
	, VDCA_COMP = CONVERT(decimal(8,2),@x)      --CONVERT(decimal(8),'') Comprimento
	, VDCA_ACTP = CONVERT(varchar(6),@p)      --CONVERT(varchar(6),'') Acabamento
	, VDCA_LARG = CONVERT(decimal(8,2),@y)      --CONVERT(decimal(8),'') Largura
	, VDCA_VDOM = CONVERT(varchar(6),'A36')      --CONVERT(varchar(6),'') Material
	, VDCA_ESPE = CONVERT(decimal(6,2),VDOP_ESPM+0.1)      --CONVERT(decimal(6),'') Espessura
	, VDCA_ACCH = CONVERT(char(1),'N')      --CONVERT(char(1),'') Chanfro Lateral
	, VDCA_GLPR_ACTP = CONVERT(varchar(6),'ORACTP')      --CONVERT(varchar(6),'') ORACTP
	, VDCA_DTOX = CONVERT(char(1),'S')      --CONVERT(char(1),'') Oxicorte
	, VDCA_GLPR_ICRC = CONVERT(varchar(6),'ORICRC')      --CONVERT(varchar(6),'') ORICRC
	, VDCA_ICQT = 0--Null      --CONVERT(int(8),'') Furos de I�amento
	, VDCA_ICRC = CONVERT(varchar(6),'M08')      --CONVERT(varchar(6),'') Rosca
	, VDCA_COMF = CONVERT(char(1),'S')      --CONVERT(char(1),'') Com furos
	, VDCA_FAIX = 'N'--Null      --CONVERT(char(1),'') Faixa Ref.:
	, VDCA_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDCA_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDCA_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDCA_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM VDOP
WHERE VDOP_VDOM = 'a36'and VDOP_ESPM <= 110.00
--ALTER TABLE PRNC DISABLE TRIGGER ALLINSERT INTO VDCASELECT VDCA_SIES ,VDCA_SIDO ,VDCA_SISE ,VDCA_VDCO ,VDCA_COD ,NUM VDCA_SUB ,VDCA_GLPR_MONT ,VDCA_MONT ,VDCA_COMP ,VDCA_ACTP ,VDCA_LARG ,VDCA_VDOM ,VDCA_ESPE ,VDCA_ACCH ,VDCA_GLPR_ACTP ,VDCA_DTOX ,VDCA_GLPR_ICRC ,VDCA_ICQT ,VDCA_ICRC ,VDCA_COMF ,VDCA_FAIX ,VDCA_USC ,VDCA_DTC ,VDCA_USU ,VDCA_DTUFROM #VDCAWHERE CONVERT(VARCHAR(6),VDCA_SIES)+'/'+VDCA_SIDO+'/'+VDCA_SISE+'/'+CONVERT(VARCHAR(6),VDCA_VDCO)+'/'+CONVERT(VARCHAR(6),VDCA_COD)+'/'+CONVERT(VARCHAR(6),NUM) NOT IN (SELECT CONVERT(VARCHAR(6),VDCA_SIES)+'/'+VDCA_SIDO+'/'+VDCA_SISE+'/'+CONVERT(VARCHAR(6),VDCA_VDCO)+'/'+CONVERT(VARCHAR(6),VDCA_COD)+'/'+CONVERT(VARCHAR(6),VDCA_SUB) FROM VDCA)
and num <= 73INSERT INTO VDCASELECT VDCA_SIES ,VDCA_SIDO ,VDCA_SISE ,VDCA_VDCO ,VDCA_COD ,(NUM-74) VDCA_SUB ,VDCA_GLPR_MONT ,VDCA_MONT ,VDCA_COMP ,VDCA_ACTP ,VDCA_LARG ,VDCA_VDOM ,VDCA_ESPE ,VDCA_ACCH ,VDCA_GLPR_ACTP ,VDCA_DTOX ,VDCA_GLPR_ICRC ,VDCA_ICQT ,VDCA_ICRC ,VDCA_COMF ,VDCA_FAIX ,VDCA_USC ,VDCA_DTC ,VDCA_USU ,VDCA_DTUFROM #VDCAWHERE CONVERT(VARCHAR(6),VDCA_SIES)+'/'+VDCA_SIDO+'/'+VDCA_SISE+'/'+CONVERT(VARCHAR(6),VDCA_VDCO)+'/'+CONVERT(VARCHAR(6),VDCA_COD)+'/'+CONVERT(VARCHAR(6),NUM) NOT IN (SELECT CONVERT(VARCHAR(6),VDCA_SIES)+'/'+VDCA_SIDO+'/'+VDCA_SISE+'/'+CONVERT(VARCHAR(6),VDCA_VDCO)+'/'+CONVERT(VARCHAR(6),VDCA_COD)+'/'+CONVERT(VARCHAR(6),VDCA_SUB) FROM VDCA)
and num between 76 and 148INSERT INTO VDCASELECT VDCA_SIES ,VDCA_SIDO ,VDCA_SISE ,VDCA_VDCO ,VDCA_COD ,(NUM-148) VDCA_SUB ,VDCA_GLPR_MONT ,VDCA_MONT ,VDCA_COMP ,VDCA_ACTP ,VDCA_LARG ,VDCA_VDOM ,VDCA_ESPE ,VDCA_ACCH ,VDCA_GLPR_ACTP ,VDCA_DTOX ,VDCA_GLPR_ICRC ,VDCA_ICQT ,VDCA_ICRC ,VDCA_COMF ,VDCA_FAIX ,VDCA_USC ,VDCA_DTC ,VDCA_USU ,VDCA_DTUFROM #VDCAWHERE CONVERT(VARCHAR(6),VDCA_SIES)+'/'+VDCA_SIDO+'/'+VDCA_SISE+'/'+CONVERT(VARCHAR(6),VDCA_VDCO)+'/'+CONVERT(VARCHAR(6),VDCA_COD)+'/'+CONVERT(VARCHAR(6),NUM) NOT IN (SELECT CONVERT(VARCHAR(6),VDCA_SIES)+'/'+VDCA_SIDO+'/'+VDCA_SISE+'/'+CONVERT(VARCHAR(6),VDCA_VDCO)+'/'+CONVERT(VARCHAR(6),VDCA_COD)+'/'+CONVERT(VARCHAR(6),VDCA_SUB) FROM VDCA)
and num between 151 and 223--VDCA_SIES ,VDCA_SIDO ,VDCA_SISE ,VDCA_VDCO ,VDCA_COD ,VDCA_SUB ,VDCA_GLPR_MONT ,VDCA_MONT ,VDCA_COMP ,VDCA_ACTP ,VDCA_LARG ,VDCA_VDOM ,VDCA_ESPE ,VDCA_ACCH ,VDCA_GLPR_ACTP ,VDCA_DTOX ,VDCA_GLPR_ICRC ,VDCA_ICQT ,VDCA_ICRC ,VDCA_COMF ,VDCA_FAIX ,VDCA_USC ,VDCA_DTC ,VDCA_USU ,VDCA_DTU ,

--SELECT * FROM [BKP].[dbo].[VDCA] WHERE VDCA_VDCO = 314229

--delete from vdca where vdca_vdco = 314229