drop table #new
--VDPD_SIES, VDPD_SIDO, VDPD_SISE, VDPD_COD ,vdps_mtpc, vdps_mtpr, mtpr_cod,vdpi_mtpr, vdpd_dent, vdps_qtd, vdps_val, 

select *, IDENTITY(int,1,1) NUM
into #new
from VDPD a, VDPI b, VDPS c, MTPR d, VDC1
where VDPD_SIES = VDPI_SIES
			and VDPD_SIDO = VDPI_SIDO
			and VDPD_SISE = VDPI_SISE
			and VDPD_COD  = VDPI_VDPD
			and VDPD_SIES = VDPS_SIES
			and VDPD_SIDO = VDPS_SIDO
			and VDPD_SISE = VDPD_SISE
			and VDPD_COD  = VDPS_VDPD
			and VDPS_MTPR = MTPR_COD
			and VDPI_SIES = VDPS_SIES
			and VDPI_SIDO = VDPS_SIDO
			and VDPI_SISE = VDPS_SISE
			and VDPI_VDPD = VDPS_VDPD
			and VDPI_COD  = VDPS_VDPI
			and CONVERT(varchar(10), VDPD_DTC,102) between '2008.01.01' and '2012.12.31'
			and VDPI_MTDV in ('2000')
			and VDPD_STA = 'OK'
			--and VDPS_MTPC not in ('FURO','CAVI')
			--and FTIT_MTTR = 'SAIFAT'
			and VDPD_GLCL NOT IN (5381,1)
			and substring(VDPI_MTPR,1,1) = 'O'
--select * from #new where vdpd_cod = 145758
--select sum(vdcs_qtde*vdcs_vuni) from vdcs where vdcs_vdco = 211178
--select * from vdcs where vdcs_vdco = 211178
update #new set vdps_mtpc = '++', vdps_mtpr = '++', mtpr_cod = '++'
from #new
where VDPS_MTPC in ('FURO','CAVI')

select VDPD_SIES, VDPD_SIDO, VDPD_SISE, VDPD_COD 
into #roteiro
from #new 
where vdpi_mtpr = 'osba'
group by VDPD_SIES, VDPD_SIDO, VDPD_SISE, VDPD_COD

select VDPS_MTPR, *
from #new a, #roteiro b
where a.VDPD_SIES = b.VDPD_SIES
			and a.VDPD_SIDO = b.VDPD_SIDO
			and a.VDPD_SISE = b.VDPD_SISE
			and a.VDPD_COD  = b.VDPD_COD
			and VDPS_MTPR <> '++'

--6357 linhas
select NUM, sum(MTEP_QTD*PRCC_VALP*(PRRO_TFIX+PRRO_TVAR))--, b.*, c.*, d.*
--update #new set vdps_mtpc = '++', vdps_mtpr = '++', mtpr_cod = '++'
from #new a, MTEP b, PRRO c, PRCC d
where SUBSTRING(MTPR_COD,1,1) in ('D')
			and VDPS_MTPR = MTEP_PAI
			and MTEP_FIL = PRRO_MTPR
			and PRRO_PRRA = 1
			and PRRO_PRCT = PRCC_PRCT
			and PRRO_CRTL = 'S'
			and PRCC_ANO = 2012
			and PRCC_MES = 12
group by NUM
order by NUM

--10759       151.7524000000000000
select top 1 * from #new

SELECT *
FROM #new
where NUM = 10759

select top 10 *
from VDPS

select SUBSTRING(MTPR_COD,1,1), MTPR_COD, *
from #new
where --VDPI_MTPR = 'opba'
			SUBSTRING(MTPR_COD,1,1) in ('D')
order by MTPR_COD


drop table #nova
declare 
@n int
--set @n = 145758
set @n = 59587
--select vdpi_mtpr, year(VDPD_DENT) 'ANO',MTPR_MTDV 'DIVIS�O', MTPR_MTLN 'LINHA', MTPR_MTFM 'FAMILIA', REPLACE(sum(MTPR_PES*VDPS_QTD),'.',',')'PESO', REPLACE(CONVERT(DECIMAL(12,0),SUM(VDPS_QTD)),'.',',') 'QTD', REPLACE(SUM(VDPS_VAL-(0 + 1 + 2)),'.',',') VALOR
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '1_M.O.      ' 'PRE', sum(0) [PESO], CONVERT(DECIMAL(12,0),SUM(0)) [QTD], SUM(VDPS_QTD-(0 + 0 + 0)) [VALOR]
into #nova
from #new
where VDPI_MTDV = '2000'
			AND VDPS_MTPR = '++'
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))


insert into #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '1_M.O.      ' 'PRE', sum(0)[PESO], CONVERT(DECIMAL(12,0),SUM(0)) [QTD], SUM(VDPS_VAL-((VDPS_QTD*MTPL_PESN*3.61)*.7275*1.489)) [VALOR]
from #new, MTPL
where VDPI_MTDV = '2000'
			--AND VDPS_MTPR = '++'
			and MTPR_COD = MTPL_MTPR
			AND (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('D','U','V','Y','Z'))			
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))


insert into #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '2_M.P.' 'PRE', sum(VDPS_QTD) [PESO], CONVERT(DECIMAL(12,0),SUM(0))[QTD], SUM(VDPS_VAL-(0 + 0 + 0))[VALOR]
from #new
where VDPI_MTDV = '2000'
			AND (MTPR_MTUN = 'KG' or (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)>20))
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))

--select top 1 * from mtpl where mtpl_cod = '2520-cc1'

insert into #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '2_M.P.' 'PRE', sum(VDPS_QTD*MTPL_PESN) [PESO], CONVERT(DECIMAL(12,0),SUM(VDPS_QTD)) [QTD], SUM(VDPS_QTD*MTPL_PESN*3.61*.7275*1.489) [VALOR]
from #new, MTPL
where VDPI_MTDV = '2000'
			AND (MTPR_MTUN = 'pc' and SUBSTRING(MTPR_COD,1,1) in ('D','U','V','Y','Z'))
			and MTPR_COD = MTPL_MTPR
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))

insert into #nova
--select * from #nova
select vdpi_mtpr, year(VDPD_DENT) 'ANO', '3_'+substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.')) 'PRE', sum(VDPS_QTD*MTPR_PES) [PESO], CONVERT(DECIMAL(12,0),SUM(VDPS_QTD)) [QTD], SUM(VDPS_VAL-(0 + 0 + 0)) [VALOR]
from #new
where VDPI_MTDV = '2000'
			AND MTPR_MTUN = 'pc' 
			AND (SUBSTRING(MTPR_COD,1,1) NOT in ('D','U','V','Y','Z') or SUBSTRING(MTPR_COD,1,1) in ('X') and SUBSTRING(MTPR_COD,2,2)<20)
--			and VDPD_COD = 84230
--			and VDPD_COD = 164600
			and VDPD_COD = @n
group by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))
order by VDPI_MTPR,year(VDPD_DENT), substring(VDPS_MTPR+'.',1,charindex('.',VDPS_MTPR+'.'))

select top 10 * from #nova

select vdpi_mtpr, ANO, PRE, sum(PESO) [PESO], SUM(QTD) [QTD], SUM(VALOR) [VALOR]
from #nova
--where PRE like '3_%'
GROUP BY vdpi_mtpr, ANO, PRE
order by vdpi_mtpr, ANO, PRE



select *
from #new, MTPL
where VDPD_COD = 81948
			and MTPR_COD = MTPL_MTPR

