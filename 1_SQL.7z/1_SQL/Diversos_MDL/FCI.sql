--ESTAB. 5 ---------------------------------------------------------------------------------------------DROP TABLE #MTCISELECT *, '0' CST INTO #MTCI FROM [192.168.2.39].[mdl].[dbo].MTCI WHERE 1 = 0INSERT INTO #MTCISELECT 		MTCI_MTES = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTCI_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, MTCI_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, MTCI_ANO = CONVERT(int,'2013')      --CONVERT(int(4),'') Ano
	, MTCI_MES = CONVERT(int,'9')      --CONVERT(int(2),'') M�s
	, MTCI_GTIN = Null      --CONVERT(varchar(20),'') GTIN
	, MTCI_VALI = CONVERT(decimal(12,2),round([CUSTO MP],2))      --CONVERT(decimal(12),'') Vr Importada
	, MTCI_VALT = CONVERT(decimal(12,2),round([S/ICMS],2))      --CONVERT(decimal(12),'') Valor do Item
	, MTCI_CI = CONVERT(decimal(5,2),Round(100*round([CUSTO MP],2)/round([S/ICMS],2),2))      --CONVERT(decimal(5),'') CI %
	, MTCI_DTG = Null      --CONVERT(datetime(10),'') Gera��o do Arquivo
	, MTCI_USG = Null      --CONVERT(varchar(15),'') ->
	, MTCI_FCI_COD = null      --CONVERT(varchar(36),'') FCI #
	, MTCI_FCI_IND = Null      --CONVERT(varchar(20),'') Indicador Valida��o
	, MTCI_FCI_DAT = Null      --CONVERT(datetime(10),'') Atualiza��o da FCI
	, MTCI_FCI_ARQ = Null      --CONVERT(varchar(100),'') Arquivo Retorno
	, MTCI_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTCI_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTCI_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTCI_DTU = Null      --CONVERT(datetime(10),'') em
	, CST
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\0_SQL\FCI_PUN.xls',TFB$), [192.168.2.39].[mdl].[dbo].mtpcWHERE CST <> 0			AND [C�DIGO] IS NOT NULL			and [C�DIGO] collate SQL_Latin1_General_CP1_CI_AS = MTPC_COD--928INSERT INTO #MTCISELECT 		MTCI_MTES = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTCI_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, MTCI_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, MTCI_ANO = CONVERT(int,'2013')      --CONVERT(int(4),'') Ano
	, MTCI_MES = CONVERT(int,'9')      --CONVERT(int(2),'') M�s
	, MTCI_GTIN = Null      --CONVERT(varchar(20),'') GTIN
	, MTCI_VALI = CONVERT(decimal(12,2),round([MP],2))      --CONVERT(decimal(12),'') Vr Importada
	, MTCI_VALT = CONVERT(decimal(12,2),round([S/ICMS],2))      --CONVERT(decimal(12),'') Valor do Item
	, MTCI_CI = CONVERT(decimal(5,2),Round(100*round([MP],2)/round([S/ICMS],2),2))      --CONVERT(decimal(5),'') CI %
	, MTCI_DTG = Null      --CONVERT(datetime(10),'') Gera��o do Arquivo
	, MTCI_USG = Null      --CONVERT(varchar(15),'') ->
	, MTCI_FCI_COD = null      --CONVERT(varchar(36),'') FCI #
	, MTCI_FCI_IND = Null      --CONVERT(varchar(20),'') Indicador Valida��o
	, MTCI_FCI_DAT = Null      --CONVERT(datetime(10),'') Atualiza��o da FCI
	, MTCI_FCI_ARQ = Null      --CONVERT(varchar(100),'') Arquivo Retorno
	, MTCI_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTCI_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTCI_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTCI_DTU = Null      --CONVERT(datetime(10),'') em
	, CST
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\0_SQL\FCI_PUN.xls',PPB$) , [192.168.2.39].[mdl].[dbo].mtpcWHERE CST <> 0			AND [CODIGO] IS NOT NULL			and [CODIGO] collate SQL_Latin1_General_CP1_CI_AS = MTPC_CODINSERT INTO #MTCISELECT 		MTCI_MTES = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTCI_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, MTCI_SIES = CONVERT(int,'5')      --CONVERT(int(6),'') Estab.
	, MTCI_ANO = CONVERT(int,'2013')      --CONVERT(int(4),'') Ano
	, MTCI_MES = CONVERT(int,'9')      --CONVERT(int(2),'') M�s
	, MTCI_GTIN = Null      --CONVERT(varchar(20),'') GTIN
	, MTCI_VALI = CONVERT(decimal(12,2),round([MP],2))      --CONVERT(decimal(12),'') Vr Importada
	, MTCI_VALT = CONVERT(decimal(12,2),round([S/ICMS],2))      --CONVERT(decimal(12),'') Valor do Item
	, MTCI_CI = CONVERT(decimal(5,2),Round(100*round([MP],2)/round([S/ICMS],2),2))      --CONVERT(decimal(5),'') CI %
	, MTCI_DTG = Null      --CONVERT(datetime(10),'') Gera��o do Arquivo
	, MTCI_USG = Null      --CONVERT(varchar(15),'') ->
	, MTCI_FCI_COD = null      --CONVERT(varchar(36),'') FCI #
	, MTCI_FCI_IND = Null      --CONVERT(varchar(20),'') Indicador Valida��o
	, MTCI_FCI_DAT = Null      --CONVERT(datetime(10),'') Atualiza��o da FCI
	, MTCI_FCI_ARQ = Null      --CONVERT(varchar(100),'') Arquivo Retorno
	, MTCI_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTCI_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTCI_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTCI_DTU = Null      --CONVERT(datetime(10),'') em
	, CST
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\0_SQL\FCI_PUN.xls',DVS$) , [192.168.2.39].[mdl].[dbo].mtpcWHERE CST <> 0			AND [CODIGO] IS NOT NULL			AND [S/ICMS] <> 0			and [CODIGO] collate SQL_Latin1_General_CP1_CI_AS = MTPC_COD--ESTAB. 7 ---------------------------------------------------------------------------------------------INSERT INTO #MTCISELECT 		MTCI_MTES = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTCI_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, MTCI_SIES = CONVERT(int,'7')      --CONVERT(int(6),'') Estab.
	, MTCI_ANO = CONVERT(int,'2013')      --CONVERT(int(4),'') Ano
	, MTCI_MES = CONVERT(int,'9')      --CONVERT(int(2),'') M�s
	, MTCI_GTIN = Null      --CONVERT(varchar(20),'') GTIN
	, MTCI_VALI = CONVERT(decimal(12,2),round([CUSTO MP],2))      --CONVERT(decimal(12),'') Vr Importada
	, MTCI_VALT = CONVERT(decimal(12,2),round([S/ICMS],2))      --CONVERT(decimal(12),'') Valor do Item
	, MTCI_CI = CONVERT(decimal(5,2),Round(100*round([CUSTO MP],2)/round([S/ICMS],2),2))      --CONVERT(decimal(5),'') CI %
	, MTCI_DTG = Null      --CONVERT(datetime(10),'') Gera��o do Arquivo
	, MTCI_USG = Null      --CONVERT(varchar(15),'') ->
	, MTCI_FCI_COD = null      --CONVERT(varchar(36),'') FCI #
	, MTCI_FCI_IND = Null      --CONVERT(varchar(20),'') Indicador Valida��o
	, MTCI_FCI_DAT = Null      --CONVERT(datetime(10),'') Atualiza��o da FCI
	, MTCI_FCI_ARQ = Null      --CONVERT(varchar(100),'') Arquivo Retorno
	, MTCI_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTCI_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTCI_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTCI_DTU = Null      --CONVERT(datetime(10),'') em
	, CST
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\0_SQL\FCI_PUN.xls',TFB$) , [192.168.2.39].[mdl].[dbo].mtpcWHERE CST <> 0			AND [C�DIGO] IS NOT NULL			and [C�DIGO] collate SQL_Latin1_General_CP1_CI_AS = MTPC_CODINSERT INTO #MTCISELECT 		MTCI_MTES = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTCI_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, MTCI_SIES = CONVERT(int,'7')      --CONVERT(int(6),'') Estab.
	, MTCI_ANO = CONVERT(int,'2013')      --CONVERT(int(4),'') Ano
	, MTCI_MES = CONVERT(int,'9')      --CONVERT(int(2),'') M�s
	, MTCI_GTIN = Null      --CONVERT(varchar(20),'') GTIN
	, MTCI_VALI = CONVERT(decimal(12,2),round([MP],2))      --CONVERT(decimal(12),'') Vr Importada
	, MTCI_VALT = CONVERT(decimal(12,2),round([S/ICMS],2))      --CONVERT(decimal(12),'') Valor do Item
	, MTCI_CI = CONVERT(decimal(5,2),Round(100*round([MP],2)/round([S/ICMS],2),2))      --CONVERT(decimal(5),'') CI %
	, MTCI_DTG = Null      --CONVERT(datetime(10),'') Gera��o do Arquivo
	, MTCI_USG = Null      --CONVERT(varchar(15),'') ->
	, MTCI_FCI_COD = null      --CONVERT(varchar(36),'') FCI #
	, MTCI_FCI_IND = Null      --CONVERT(varchar(20),'') Indicador Valida��o
	, MTCI_FCI_DAT = Null      --CONVERT(datetime(10),'') Atualiza��o da FCI
	, MTCI_FCI_ARQ = Null      --CONVERT(varchar(100),'') Arquivo Retorno
	, MTCI_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTCI_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTCI_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTCI_DTU = Null      --CONVERT(datetime(10),'') em
	, CST
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\0_SQL\FCI_PUN.xls',PPB$) , [192.168.2.39].[mdl].[dbo].mtpcWHERE CST <> 0			AND [CODIGO] IS NOT NULL			and [CODIGO] collate SQL_Latin1_General_CP1_CI_AS = MTPC_CODINSERT INTO #MTCISELECT 		MTCI_MTES = CONVERT(varchar(20),MTPC_MTPR)      --CONVERT(varchar(20),'') Insumo
	, MTCI_MTPC = CONVERT(varchar(20),MTPC_COD)      --CONVERT(varchar(20),'') Refer�ncia
	, MTCI_SIES = CONVERT(int,'7')      --CONVERT(int(6),'') Estab.
	, MTCI_ANO = CONVERT(int,'2013')      --CONVERT(int(4),'') Ano
	, MTCI_MES = CONVERT(int,'9')      --CONVERT(int(2),'') M�s
	, MTCI_GTIN = Null      --CONVERT(varchar(20),'') GTIN
	, MTCI_VALI = CONVERT(decimal(12,2),round([MP],2))      --CONVERT(decimal(12),'') Vr Importada
	, MTCI_VALT = CONVERT(decimal(12,2),round([S/ICMS],2))      --CONVERT(decimal(12),'') Valor do Item
	, MTCI_CI = CONVERT(decimal(5,2),Round(100*round([MP],2)/round([S/ICMS],2),2))      --CONVERT(decimal(5),'') CI %
	, MTCI_DTG = Null      --CONVERT(datetime(10),'') Gera��o do Arquivo
	, MTCI_USG = Null      --CONVERT(varchar(15),'') ->
	, MTCI_FCI_COD = null      --CONVERT(varchar(36),'') FCI #
	, MTCI_FCI_IND = Null      --CONVERT(varchar(20),'') Indicador Valida��o
	, MTCI_FCI_DAT = Null      --CONVERT(datetime(10),'') Atualiza��o da FCI
	, MTCI_FCI_ARQ = Null      --CONVERT(varchar(100),'') Arquivo Retorno
	, MTCI_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTCI_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTCI_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTCI_DTU = Null      --CONVERT(datetime(10),'') em
	, CST
	--select *FROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\0_SQL\FCI_PUN.xls',DVS$) , [192.168.2.39].[mdl].[dbo].mtpcWHERE CST <> 0			AND [CODIGO] IS NOT NULL			AND [S/ICMS] <> 0			and [CODIGO] collate SQL_Latin1_General_CP1_CI_AS = MTPC_CODSELECT MTPR_ORI--UPDATE [192.168.2.39].[mdl].[dbo].MTPR SET MTPR_ORI = CSTFROM #MTCI a, [192.168.2.39].[mdl].[dbo].MTPRWHERE MTPR_COD = MTCI_MTES			AND MTCI_SIES = 7order by MTPR_ORI--[192.168.2.39].[bkp].[dbo].MTCIINSERT INTO [192.168.2.39].[mdl].[dbo].MTCISELECT MTCI_MTES ,MTCI_MTPC ,MTCI_SIES ,MTCI_ANO ,MTCI_MES ,MTCI_GTIN ,MTCI_VALI ,MTCI_VALT ,MTCI_CI ,MTCI_DTG ,MTCI_USG ,MTCI_FCI_COD ,MTCI_FCI_IND ,MTCI_FCI_DAT ,MTCI_FCI_ARQ ,MTCI_USC ,MTCI_DTC ,MTCI_USU ,MTCI_DTUFROM #MTCIWHERE CONVERT(VARCHAR(6),MTCI_sies)+'/'+MTCI_MTES+'/'+MTCI_MTPC  NOT IN (SELECT CONVERT(VARCHAR(6),MTCI_sies)+'/'+MTCI_MTES+'/'+MTCI_MTPC FROM [192.168.2.39].[mdl].[dbo].MTCI)
			and CONVERT(VARCHAR(6),MTCI_sies)+'/'+MTCI_MTES IN (SELECT CONVERT(VARCHAR(6),mtes_sies)+'/'+MTES_mtpr FROM [192.168.2.39].[mdl].[dbo].MTES)
			and MTCI_VALI > 0			--and mtes_sies = mtci_siesSELECT CONVERT(VARCHAR(6),MTCI_sies)+'/'+MTCI_MTESFROM #MTCIWHERE CONVERT(VARCHAR(6),MTCI_sies)+'/'+MTCI_MTES NOT IN (SELECT CONVERT(VARCHAR(6),mtes_sies)+'/'+MTES_mtpr FROM [192.168.2.39].[mdl].[dbo].MTES)
--MTCI_MTES ,MTCI_SIES ,MTCI_ANO ,MTCI_MES ,MTCI_GTIN ,MTCI_VALI ,MTCI_VALT ,MTCI_CI ,MTCI_DTG ,MTCI_USG ,MTCI_FCI_COD ,MTCI_FCI_IND ,MTCI_FCI_DAT ,MTCI_FCI_ARQ ,MTCI_USC ,MTCI_DTC ,MTCI_USU ,MTCI_DTU ,

-- delete  from [192.168.2.39].[mdl].[dbo].MTCI where MTCI_USC = 'KINKEL'--delete  from #mtciSELECT *FROM #MTCIwhere MTCI_VALI = 0 mtci_mtpc = '9-0604-36R'SELECT *--UPDATE [192.168.2.39].[mdl].[dbo].MTPR SET MTPR_ORI = 5--deleteFROM [192.168.2.39].[mdl].[dbo].MTCI, [192.168.2.39].[mdl].[dbo].MTpcWHERE MTCI_MTPC = mtpc_cod and mtci_usg is nullorder by MTPR_ORI
