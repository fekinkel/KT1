DECLARE
@t varchar(12),
@s varchar(4000),
@c varchar(1000),
@r varchar(4000),
@q varchar(4000)

set nocount on
set @s= ''

set @t = upper('mtPC')

--DROP TABLE #MTDV--SELECT * INTO #MTDV FROM MTDV WHERE 1 = 0--INSERT INTO #MTDV 
set @c=+'DROP TABLE #'+@t+CHAR(13)+
		'SELECT * INTO #'+@t+' FROM '+@t+' WHERE 1 = 0'+CHAR(13)+
		'INSERT INTO #'+@t+CHAR(13)+
		'SELECT '+CHAR(13)
print @c
SELECT '	, '+SIDC_COD+' = '+replace(REPLACE(SIDC_NULO,'N', 'CONVERT('+SIDC_TIPO+'('+CONVERT(VARCHAR(6),SIDC_COMP)+'),'''')'),'S','Null')+ '      --CONVERT('+SIDC_TIPO+'('+CONVERT(VARCHAR(6),SIDC_COMP)+'),'''') '+SIDI_TEXT
FROM SIDC, sidi
WHERE SIDC_SITB = @t
			and SIDC_COD  = SIDI_SIDC
			and SIDC_SITB = SIDI_SITB
			and SIDI_COD  = '01'
			AND SIDC_FISI = 'S'
order by SIDC_SEQU

set @r='FROM [dbfmex]...prod'+CHAR(13)+
'WHERE '+@t+'_cod = CONVERT(int,)'+CHAR(13)+
'			and '+@t+'_dig = CONVERT(int,)'+CHAR(13)+CHAR(13)+

'INSERT INTO '+@t+CHAR(13)+
'SELECT *'+CHAR(13)+
'FROM #'+@T+CHAR(13)+
'WHERE CONVERT(VARCHAR(6),'+@t+'_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),'+@t+'_GLCL)FROM '+@t+')'

print @r

set @q =char(13)+'--'
SELECT @q=@q+SIDC_COD+' ,'
FROM SIDC, sidi
WHERE SIDC_SITB = @t
			and SIDC_COD  = SIDI_SIDC
			and SIDC_SITB = SIDI_SITB
			and SIDI_COD  = '01'
			AND SIDC_FISI = 'S'
order by SIDC_SEQU

print @q
