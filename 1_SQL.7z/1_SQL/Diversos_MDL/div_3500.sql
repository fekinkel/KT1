--Quantidade de pedidos no periodo de 
--Abril 2010
select VDPI_SIES [Estab.],   VDPI_SIDO [Tipo], VDPI_SISE [Serie], VDPI_VDPD [C�digo], vdpi_mtdv [DIVIS�O]--, datepart(weekday,getdate())
from vdpi
where convert(char(10), VDPi_DTC, 102) >= '2010.07.01'
			and convert(char(10), VDPi_DTC, 102) <= '2010.07.31'		
			and VDPI_MTDV = '0500'
			and vdpi_sta = 'OK'
--			and vdpi_sies = 5
group by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD, vdpi_mtdv
order by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD

select VDPI_SIES [Estab.],   VDPI_SIDO [Tipo], VDPI_SISE [Serie], VDPI_VDPD [C�digo], vdpi_mtdv [DIVIS�O]--, datepart(weekday,getdate())
from vdpi
where convert(char(10), VDPi_DTC, 102) >= '2010.07.01'
			and convert(char(10), VDPi_DTC, 102) <= '2010.07.31'		
			and VDPI_MTDV = '1000'
			and vdpi_sta = 'OK'
--			and vdpi_sies = 5
group by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD, vdpi_mtdv
order by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD

select VDPI_SIES [Estab.],   VDPI_SIDO [Tipo], VDPI_SISE [Serie], VDPI_VDPD [C�digo], vdpi_mtdv [DIVIS�O]--, datepart(weekday,getdate())
from vdpi
where convert(char(10), VDPi_DTC, 102) >= '2013.07.01'
			and convert(char(10), VDPi_DTC, 102) <= '2013.07.31'		
			and VDPI_MTDV = '1500'
			and vdpi_sta = 'OK'
--			and vdpi_sies = 5
group by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD, vdpi_mtdv
order by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD

select VDPI_SIES [Estab.],   VDPI_SIDO [Tipo], VDPI_SISE [Serie], VDPI_VDPD [C�digo], vdpi_mtdv [DIVIS�O]--, datepart(weekday,getdate())
from vdpi
where convert(char(10), VDPi_DTC, 102) >= '2010.06.01'
			and convert(char(10), VDPi_DTC, 102) <= '2010.06.30'		
			and VDPI_MTDV = '2000'
			and vdpi_sta = 'OK'
--			and vdpi_sies = 5
group by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD, vdpi_mtdv
order by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD

select VDPI_SIES [Estab.],   VDPI_SIDO [Tipo], VDPI_SISE [Serie], VDPI_VDPD [C�digo], vdpi_mtdv [DIVIS�O]--, datepart(weekday,getdate())
from vdpi
where convert(char(10), VDPi_DTC, 102) >= '2013.07.01'
			and convert(char(10), VDPi_DTC, 102) <= '2013.07.30'		
			and VDPI_MTDV = '3500'
			and vdpi_sta = 'OK'
			and vdpi_sies = 7
group by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD, vdpi_mtdv
order by VDPI_SIES,   VDPI_SIDO, VDPI_SISE, VDPI_VDPD
