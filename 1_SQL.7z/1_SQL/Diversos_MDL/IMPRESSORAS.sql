declare
@ano int,
@mes int

select *--max(convert(varchar(4),MDPI_ANO)+replicate('0',2-(len(mdpi_mes)))+convert(varchar(2),MDPI_MES)) 
from mdpi
where MDPI_ANO = 2016
and MDPI_MES = 9


select MDPR_EMPR, MDPR_ID,	MDPR_DEPT, MDPI_ANO,	MDPI_MES, MDPI_CONT, MDPR_NOME, MDPR_PATH, MDPR_FUNC_VAL
from MDPI a, MDPR b 
where MDPI_ANO = 2016
and MDPI_MES = 8 
and mdpr_id = mdpi_id 
and mdpr_atv = 'S'
order by b.MDPR_EMPR

