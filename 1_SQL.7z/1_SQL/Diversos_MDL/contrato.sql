/*drop table #newselect mtpc_cod COD, mtpc_nom NOM, 1 tipo, 'Molas                                         ' Nomeinto #newfrom mtpc, mtprwhere mtpc_mtpr = mtpr_cod			and MTPR_MTDV = '0500'			and mtpc_cod like '9%'			and mtpc_pre > 0.00 insert into #newselect mtpc_cod COD, mtpc_nom NOM, 2 tipo, 'Pinos, Bucha e Camisa'from mtpc, mtprwhere mtpc_mtpr = mtpr_cod			and MTPR_MTLN in('0500','0700','1900','2000','2100','2200')			and mtpc_cod not like '%*' 			and mtpc_pre > 0.00 insert into #newselect mtpc_cod COD, mtpc_nom NOM, 3 tipo, 'Pun��o e Matriz'from mtpc, mtpr, mttpwhere mtpc_mtpr = mtpr_cod			and MTPR_MTLN in('3800','4000')			and mtpc_cod not like '%*'			and MTTP_COD = MTPR_MTTP			and MTTP_ESTR = 'N'			and mtpc_pre > 0.00 --insert into #newselect mtpc_cod COD, mtpc_nom NOM, 4 tipo, 'S� Pun��o'from mtpc, mtpr, mttpwhere mtpc_mtpr = mtpr_cod			and MTPR_MTLN in('3800')			and mtpc_cod not like '%*' 			and MTTP_COD = MTPR_MTTP			and MTTP_ESTR = 'N'			and mtpc_pre > 0.00 select * from #new*/declare@cod int,@vmol decimal(12,2),@vcom decimal(12,2),@vpun decimal(12,2),@vspun decimal(12,2),@tipo varchar(100)set @cod = 10; set @vmol = 0; set @vcom = 20; set @vpun = 20; set @vspun = 0DROP TABLE #VDCXSELECT * INTO #VDCX FROM VDCX WHERE 1 = 0INSERT INTO #VDCXSELECT 		VDCX_VDCV = CONVERT(int,@cod)      --CONVERT(int(3),'') Contrato
	, VDCX_MTPC = CONVERT(varchar(20), cod)      --CONVERT(varchar(20),'') Refer�ncia
	, VDCX_ATV = CONVERT(char(1),'S')      --CONVERT(char(1),'') Ativo
	, VDCX_MTPC_NOM = nom      --CONVERT(varchar(254),'') Nome
	, VDCX_PUN_MOD = CONVERT(char(1),'N')      --CONVERT(char(1),'') Pre�o espec�fico
	, VDCX_PUN_VAL = CONVERT(decimal(12),'0')      --CONVERT(decimal(12),'') Pre�o
	, VDCX_PUN_GLMD = 'MXN'      --CONVERT(varchar(8),'') Moeda
	, VDCX_PUN_PCT = CASE 
		WHEN TIPO = 1 THEN  100-@vmol      --CONVERT(decimal(6),'') % Sobre Padr�o
		WHEN TIPO = 2 THEN  100-@vcom      --CONVERT(decimal(6),'') % Sobre Padr�o
		WHEN TIPO = 3 THEN  100-@vpun      --CONVERT(decimal(6),'') % Sobre Padr�o
		WHEN TIPO = 4 THEN  100-@vspun      --CONVERT(decimal(6),'') % Sobre Padr�o
		END
	, VDCX_COM_TIPO = CONVERT(char(1),'N')      --CONVERT(char(1),'') Comiss�o Negociada
	, VDCX_COM_PCT = 0.00      --CONVERT(decimal(6),'') Comiss�o %
	, VDCX_QTD = 0.00      --CONVERT(decimal(14),'') Expectativa/Ano
	, VDCX_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, VDCX_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, VDCX_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, VDCX_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM #newWHERE (@vmol > 0.00 and tipo = 1) 			or (@vcom > 0.00 and tipo = 2)			or (@vpun > 0.00 and tipo = 3)			or (@vspun > 0.00 and tipo = 4)DELETEFROM VDCXWHERE VDCX_VDCV = @codINSERT INTO VDCXSELECT *FROM #VDCXorder by vdcx_mtpc--WHERE CONVERT(VARCHAR(6),VDCX_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),VDCX_GLCL)FROM VDCX)
--VDCX_VDCV ,VDCX_MTPC ,VDCX_ATV ,VDCX_MTPC_NOM ,VDCX_PUN_MOD ,VDCX_PUN_VAL ,VDCX_PUN_GLMD ,VDCX_PUN_PCT ,VDCX_COM_TIPO ,VDCX_COM_PCT ,VDCX_QTD ,VDCX_USC ,VDCX_DTC ,VDCX_USU ,VDCX_DTU ,

select cod, COUNT(1) qtd 
from #new 
GROUP by cod  
having COUNT(1) > 1

