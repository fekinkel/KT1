--CONTRATOR
select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N'
from VDCX
where VDCX_VDCV = 7
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and MTPR_MTDV = '0500')


select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N'
--delete
from VDCX
where VDCX_VDCV = 9
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))


select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-16)
--delete
from VDCX
where VDCX_VDCV in (11,12,13,14)
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-12)
--delete
from VDCX
where VDCX_VDCV in (16)
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-17)
--delete
from VDCX
where VDCX_VDCV in (24)
			and VDCX_MTPC  in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-5)
--delete
from VDCX
where VDCX_VDCV in (24)
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-19)
--delete
from VDCX
where VDCX_VDCV in (26)
			--and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))
			and VDCX_MTPC  in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-7)
--delete
from VDCX
where VDCX_VDCV in (26)
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-18)
--delete
from VDCX
where VDCX_VDCV in (29,30)
			--and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))
			and VDCX_MTPC  in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-13)
--delete
from VDCX
where VDCX_VDCV in (29,30)
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))
			
--VDCX_VDCV ,VDCX_MTPC ,VDCX_ATV ,VDCX_MTPC_NOM ,VDCX_PUN_MOD ,VDCX_PUN_VAL ,VDCX_PUN_GLMD ,VDCX_PUN_PCT ,VDCX_COM_TIPO ,VDCX_COM_PCT ,VDCX_QTD ,VDCX_USC ,VDCX_DTC ,VDCX_USU ,VDCX_DTU

select * 
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-18)
--delete
from VDCX
where VDCX_VDCV in (62)
			--and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))
			and VDCX_MTPC  in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))


select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-15)
--delete
from VDCX
where VDCX_VDCV in (32)
			--and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' or (MTPR_MTLN in('0500','0700','2000','2100','2200') )))
			and VDCX_MTPC  in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))

select *
--update vdcx set vdcx_pun_val = 0, vdcx_pun_mod = 'N', vdcx_pun_pct = (100-10)
--delete
from VDCX
where VDCX_VDCV in (32)
			and VDCX_MTPC not in (select mtpc_cod from MTPC, MTPR where MTPC_MTPR = MTPR_COD and (MTPR_MTDV = '0500' ))


select *
from mt