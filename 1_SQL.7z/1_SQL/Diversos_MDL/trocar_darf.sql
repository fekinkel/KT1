select *
--update cfrp set cfrp_darf = '8045'
from cfrp
where CFRP_COD in (35999, 36000, 36001,36002,36003,36004,36005,36092,36006,36007,36008,36009,36010)
			and cfrp_darf <> '8045'