drop table #new

select year(ftnf_dat) ANO, month(ftnf_dat) MES, mtdv_cod DIVISAO
into #new
from ftnf, mtdv
where convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and mtdv_cod in ('0500','1000','1500','3500')
--order by year(ftnf_dat), month(ftnf_dat)
group by year(ftnf_dat), month(ftnf_dat), mtdv_cod
order by year(ftnf_dat), month(ftnf_dat), mtdv_cod

------------------BALC�O---------------------------------------------------------
----TOTAL-------------
select sum(ftit_val) VALOR
from ftnf a,ftit b
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_glxx = 1
			and ftnf_glxx_dig = 6
			and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
			
--TOTAL ANO E MES
select year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(ftit_val) VALOR
from ftnf a,ftit b
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_glxx = 1
			and ftnf_glxx_dig = 6
			and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by  month(ftnf_dat), year(ftnf_dat)

--TOTAL ANO, DIVIS�O, MES
select year(ftnf_dat) ANO, ftit_mtdv DIVISAO, month(ftnf_dat) MES, sum(ftit_val) VALOR
from ftnf a,ftit b
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_glxx = 1
			and ftnf_glxx_dig = 6
			and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by  year(ftnf_dat), ftit_mtdv, month(ftnf_dat)



------------------------POSS�VEL VENDAS BALC�O------------------------
select sum(ftit_val) VALOR, sum(ftit_plqt) PESO
from ftnf a,ftit b
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and ftnf_glxx <> 5381
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500')--('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 

select year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(ftit_val) VALOR, sum(ftit_plqt) PESO
from ftnf a,ftit b
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and ftnf_glxx <> 5381
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by  month(ftnf_dat), year(ftnf_dat)

select ftit_mtdv DIVISAO, year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(ftit_val) VALOR, sum(ftit_plqt) PESO
from ftit b, ftnf a right join #new on year(ftnf_dat) = ANO and month(ftnf_dat) = MES-- and ftit_mtdv = DIVISAO
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and ftnf_glxx <> 5381
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by  year(ftnf_dat), ftit_mtdv, month(ftnf_dat)
order by  ftit_mtdv, year(ftnf_dat), month(ftnf_dat)


-----PESO POR Fatura
select ftit_ftnf FATURA, year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(ftit_val) VALOR, sum(ftit_plqt) PESO, max(ftnf_pesobrt) PESO, max(ftnf_qtdvol) VOLUME, max(ftnf_pesobrt)/max(ftnf_qtdvol)
from ftco, ftit b, ftnf a right join #new on year(ftnf_dat) = ANO and month(ftnf_dat) = MES-- and ftit_mtdv = DIVISAO
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftco_sies = ftnf_sies
			and ftco_sido = ftnf_sido
			and ftco_sise = ftnf_sise
			and ftco_cod = ftnf_cod
			and ftnf_sta = 'OK'
			and ftnf_glxx <> 5381
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by  year(ftnf_dat), ftit_ftnf, month(ftnf_dat)
having sum(ftit_plqt) > 30
order by  max(ftnf_pesobrt)/max(ftnf_qtdvol) desc,ftit_ftnf, year(ftnf_dat), month(ftnf_dat)

-----PESO POR Fatura
select ftnf_cod FATURA, year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(ftnf_val) VALOR, sum(ftnf_pesobrt) PESO, sum(ftnf_qtdvol) VOLUME, sum(ftnf_pesobrt)/sum(ftnf_qtdvol)
from ftnf a right join #new on year(ftnf_dat) = ANO and month(ftnf_dat) = MES-- and ftit_mtdv = DIVISAO
where ftnf_sta = 'OK'
			and ftnf_glxx <> 5381
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			--and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			--and ftnf_pesobrt = 0
			--and substring(ftit_mtpr,1,1) <> 'O' 
group by  year(ftnf_dat), ftnf_cod, month(ftnf_dat)
having sum(ftnf_pesobrt) > 30
order by  sum(ftnf_pesobrt)/sum(ftnf_qtdvol),ftnf_cod, year(ftnf_dat), month(ftnf_dat)

-----PESO POR Pedido
select ftit_ftnf FATURA, year(ftnf_dat) ANO, month(ftnf_dat) MES, sum(ftit_val) VALOR, sum(ftit_plqt) PESO
from vdit b, vdpd a right join #new on year(ftnf_dat) = ANO and month(ftnf_dat) = MES-- and ftit_mtdv = DIVISAO
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and ftnf_glxx <> 5381
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by  year(ftnf_dat), ftit_ftnf, month(ftnf_dat)
having sum(ftit_plqt) > 30
order by  ftit_ftnf, year(ftnf_dat), month(ftnf_dat)

-----------------  QUANTIDADE   EM 6 MESES --------------
select ftit_mtdv DIVISAO, ftit_mtpc PRODUTO, '1' SEMESTRE, sum(ftit_qtd) QDE
from ftit b, ftnf a 
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2013.11.30'
			and ftnf_glxx = 1
			and ftnf_glxx_dig = 6
			and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by ftit_mtdv, ftit_mtpc
order by ftit_mtdv, ftit_mtpc

select ftit_mtdv DIVISAO, ftit_mtpc PRODUTO, '2' SEMESTRE, sum(ftit_qtd) QDE
from ftit b, ftnf a 
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.12.01' and  '2014.05.31'
			and ftnf_glxx = 1
			and ftnf_glxx_dig = 6
			and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by ftit_mtdv, ftit_mtpc
order by ftit_mtdv, ftit_mtpc



-----------------  QUANTIDADE   EM 6 MESES --------------
select ftit_mtdv DIVISAO, ftit_mtpc PRODUTO, '1' SEMESTRE, sum(ftit_qtd) QDE
from ftit b, ftnf a 
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.06.01' and  '2013.11.30'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by ftit_mtdv, ftit_mtpc
order by ftit_mtdv, ftit_mtpc

select ftit_mtdv DIVISAO, ftit_mtpc PRODUTO, '2' SEMESTRE, sum(ftit_qtd) QDE
from ftit b, ftnf a 
where ftit_sies = ftnf_sies
			and ftit_sido = ftnf_sido
			and ftit_sise = ftnf_sise
			and ftit_ftnf = ftnf_cod
			and ftnf_sta = 'OK'
			and convert(varchar(10),ftnf_dat,102) between '2013.12.01' and  '2014.05.31'
			and ftnf_gltr = 10
			and ftnf_cfop like '%.101%'
			and ftit_mtdv in ('0500', '1000','1500','3500')
			--and ftnf_sies = 7
			and ftnf_es = 'S'
			and ftnf_sta = 'OK'
			and substring(ftit_mtpr,1,1) <> 'O' 
group by ftit_mtdv, ftit_mtpc
order by ftit_mtdv, ftit_mtpc
