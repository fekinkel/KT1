DROP TABLE #MTPRSELECT * INTO #MTPR FROM MTPR WHERE 1 = 0INSERT INTO #MTPRSELECT 		MTPR_COD = replace(mtpr_cod,'PRJ','PRA')      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = CONVERT(varchar(25),'MT/DIVS')      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM = REPLACE(MTPR_NOM,'PASTILHAS', 'CARBIDE INSERTS')      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = CONVERT(varchar(4),'N')      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = CONVERT(varchar(4),'10')      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),'950')      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = CONVERT(varchar(3),'UN')      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = CONVERT(varchar(8),'99999999')      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, MTPR_PES = CONVERT(decimal(13,3),'0.00')      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = Null      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = Null      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = Null      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = Null      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = Null      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = CONVERT(varchar(8),'1.PUR000')      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = CONVERT(decimal(12),'5')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM mtprWHERE substring(MTPR_cod,1,3) = 'prj'INSERT INTO #MTPRSELECT 		MTPR_COD = replace(mtpr_cod,'PRO','PRO')      --CONVERT(varchar(20),'') Insumo
	, MTPR_MTTP = CONVERT(varchar(25),'MT/DIVS')      --CONVERT(varchar(25),'') Tipo
	, MTPR_MS = CONVERT(char(1),'M')      --CONVERT(char(1),'') M/S
	, MTPR_ATV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Ativo
	, MTPR_NOM --= REPLACE(MTPR_NOM,'PASTILHAS', 'CARBIDE INSERTS')      --CONVERT(varchar(80),'') Nome
	, MTPR_MTDV = CONVERT(varchar(4),'N')      --CONVERT(varchar(4),'') Divis�o
	, MTPR_MTLN = CONVERT(varchar(4),'10')      --CONVERT(varchar(4),'') Linha
	, MTPR_MTFM = CONVERT(varchar(4),'951')      --CONVERT(varchar(4),'') Fam�lia
	, MTPR_MTUN = CONVERT(varchar(3),'UN')      --CONVERT(varchar(3),'') Unidade
	, MTPR_MTNC = CONVERT(varchar(8),'99999999')      --CONVERT(varchar(8),'') NCM
	, MTPR_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, MTPR_PES = CONVERT(decimal(13,3),'0.00')      --CONVERT(decimal(13),'') Peso em Kg
	, MTPR_DES = Null      --CONVERT(varchar(240),'') Descri��o
	, MTPR_NIV = Null      --CONVERT(int(6),'') N�vel
	, MTPR_ESUN = Null      --CONVERT(varchar(3),'') Un.Estrutura
	, MTPR_ESFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_CPUN = Null      --CONVERT(varchar(3),'') Un.Compra
	, MTPR_CPFT = Null      --CONVERT(decimal(10),'') Fator Un.
	, MTPR_ATVV = CONVERT(char(1),'N')      --CONVERT(char(1),'') Vendo
	, MTPR_CFOV = Null      --CONVERT(varchar(8),'') CFOP Venda
	, MTPR_ATVC = CONVERT(char(1),'S')      --CONVERT(char(1),'') Compro
	, MTPR_CFOC = CONVERT(varchar(8),'1.PUR000')      --CONVERT(varchar(8),'') CFOP Compra
	, MTPR_TOLE = CONVERT(decimal(12),'5')      --CONVERT(decimal(12),'') Varia��o%
	, MTPR_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTPR_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTPR_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTPR_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
FROM mtprWHERE substring(MTPR_cod,1,3) = 'prO'INSERT INTO [192.168.5.1\sqlexpress].[india].[dbo].MTPRSELECT *FROM #MTPRWHERE CONVERT(VARCHAR(6),MTPR_COD) NOT IN (SELECT CONVERT(VARCHAR(6),MTPR_COD)FROM [192.168.5.1\sqlexpress].[india].[dbo].MTPR)--[192.168.5.1\sqlexpress].[india].[dbo]
--MTPR_COD ,MTPR_MTTP ,MTPR_MS ,MTPR_ATV ,MTPR_NOM ,MTPR_MTDV ,MTPR_MTLN ,MTPR_MTFM ,MTPR_MTUN ,MTPR_MTNC ,MTPR_ORI ,MTPR_PES ,MTPR_DES ,MTPR_NIV ,MTPR_ESUN ,MTPR_ESFT ,MTPR_CPUN ,MTPR_CPFT ,MTPR_ATVV ,MTPR_CFOV ,MTPR_ATVC ,MTPR_CFOC ,MTPR_TOLE ,MTPR_USC ,MTPR_DTC ,MTPR_USU ,MTPR_DTU ,

DROP TABLE #MTESSELECT * INTO #MTES FROM MTES WHERE 1 = 0INSERT INTO #MTESSELECT 		MTES_MTPR = CONVERT(varchar(20),mtpr_cod)      --CONVERT(varchar(20),'') Insumo
	, MTES_SIES = CONVERT(int,'1')      --CONVERT(int(6),'') Estab.
	, MTES_MTAL = CONVERT(varchar(6),'MSTOCK')      --CONVERT(varchar(6),'') Almox.Padr�o
	, MTES_MTAN = CONVERT(varchar(6),'MSTOCK')      --CONVERT(varchar(6),'') Almox.Necessidade
	, MTES_MTAP = CONVERT(varchar(6),'PROCES')      --CONVERT(varchar(6),'') Almox.Fabrica��o
	, MTES_LOTE = CONVERT(char(1),'')      --CONVERT(char(1),'') Lote Controlado
	, MTES_GLMD = CONVERT(varchar(8),'')      --CONVERT(varchar(8),'') Moeda Forte
	, MTES_QATU = Null      --CONVERT(decimal(14),'') Saldo Atual
	, MTES_VATU = Null      --CONVERT(decimal(14),'') Valor Atual
	, MTES_VATM = Null      --CONVERT(decimal(14),'') Valor M Atual
	, MTES_QVIS = Null      --CONVERT(decimal(14),'') Saldo Vis�vel
	, MTES_QNEC = Null      --CONVERT(decimal(14),'') Necessidades
	, MTES_QPRO = Null      --CONVERT(decimal(14),'') Provid�ncias
	, MTES_PCME = Null      --CONVERT(decimal(14),'') Consumo Estimado
	, MTES_PCMR = Null      --CONVERT(decimal(14),'') Consumo Real
	, MTES_PMIN = Null      --CONVERT(int(8),'') Dispara compra com
	, MTES_POBJ = Null      --CONVERT(int(8),'') Nec. para suprir
	, MTES_POEM = Null      --CONVERT(int(8),'') Nec. para urg�ncia
	, MTES_PPMI = Null      --CONVERT(decimal(14),'') Estoque m�nimo
	, MTES_PLEM = Null      --CONVERT(decimal(14),'') Nec. m�nima
	, MTES_PMUL = Null      --CONVERT(decimal(14),'') M�ltiplos
	, MTES_PLEC = Null      --CONVERT(decimal(14),'') Lote econ�mico
	, MTES_UCDO = Null      --CONVERT(varchar(25),'') �ltima Compra
	, MTES_LEAD = Null      --CONVERT(int(3),'') Lead Time (dias)
	, MTES_LEEM = Null      --CONVERT(int(8),'') LT Urg�ncia (dias)
	, MTES_EXPL = CONVERT(char(1),'N')      --CONVERT(char(1),'') Explode em estrutura
	, MTES_MRP = CASE 
		WHEN SUBSTRING(MTPR_COD,1,3) = 'PRA' THEN 'S'      --CONVERT(char(1),'') Pol�tica
		WHEN SUBSTRING(MTPR_COD,1,3) = 'PRO' THEN 'N'      --CONVERT(char(1),'') Pol�tica
	END
	, MTES_CREP = Null      --CONVERT(decimal(18),'') Custo Reposi��o
	, MTES_CPDR = Null      --CONVERT(decimal(18),'') Custo Padr�o
	, MTES_FGGF = Null      --CONVERT(decimal(18),'') Fator GGF
	, MTES_FRAT = CONVERT(int,'0')      --CONVERT(int(8),'') M�todo de rateio
	, MTES_CTGT = Null      --CONVERT(decimal(18),'') Custo Target
	, MTES_CPO1 = Null      --CONVERT(varchar(50),'') Campo 1
	, MTES_CPO2 = Null      --CONVERT(varchar(50),'') Campo 2
	, MTES_CPO3 = Null      --CONVERT(varchar(50),'') Campo 3
	, MTES_CPO4 = Null      --CONVERT(varchar(50),'') Campo 4
	, MTES_PRAT = Null      --CONVERT(varchar(20),'') Prateleira
	, MTES_USC = CONVERT(varchar(15),'KINKEL')      --CONVERT(varchar(15),'') Cadastrado por
	, MTES_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, MTES_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, MTES_DTU = Null      --CONVERT(datetime(10),'') em
	--SELECT *
FROM #MTPRINSERT INTO [192.168.5.1\sqlexpress].[india].[dbo].MTESSELECT *FROM #MTESWHERE CONVERT(VARCHAR(6),MTES_SIES)+'/'+mtes_mtpr NOT IN (SELECT CONVERT(VARCHAR(6),MTES_SIES)+'/'+mtes_mtpr FROM [192.168.5.1\sqlexpress].[india].[dbo].MTES)
--MTES_MTPR ,MTES_SIES ,MTES_MTAL ,MTES_MTAN ,MTES_MTAP ,MTES_LOTE ,MTES_GLMD ,MTES_QATU ,MTES_VATU ,MTES_VATM ,MTES_QVIS ,MTES_QNEC ,MTES_QPRO ,MTES_PCME ,MTES_PCMR ,MTES_PMIN ,MTES_POBJ ,MTES_POEM ,MTES_PPMI ,MTES_PLEM ,MTES_PMUL ,MTES_PLEC ,MTES_UCDO ,MTES_LEAD ,MTES_LEEM ,MTES_EXPL ,MTES_MRP ,MTES_CREP ,MTES_CPDR ,MTES_FGGF ,MTES_FRAT ,MTES_CTGT ,MTES_CPO1 ,MTES_CPO2 ,MTES_CPO3 ,MTES_CPO4 ,MTES_PRAT ,MTES_USC ,MTES_DTC ,MTES_USU ,MTES_DTU ,

