drop table #new

select identity(int,1,1) num, 99999999.999 Valor, 99999999.999 Resultado into #new where 1 = 0

insert into #new select 0.1			,0
insert into #new select 0.456		,0
insert into #new select 1.456		,0
insert into #new select 10.50		,0
insert into #new select 101.456	,0
insert into #new select 1109.456	,0

select *, (Valor*(1000)), 3-(len(Valor*1000)-( len(Valor*1000)-charindex('.',valor*1000)))--*, len(Valor) TAMANHO, len(Valor)-charindex('.',valor) CASAS_DECIMAIS, round(valor,-1), (len(Valor)-charindex('.',valor))-(sign(100-round(valor*100,0))), (charindex('.',valor)+len(Valor)-(len(Valor)-charindex('.',valor))-(sign(100-round(valor*100,0)))), 3-((len(Valor))-(len(Valor)-charindex('.',valor))-1) N, (sign(100-round(valor*100,0))) M, 3-((len(Valor))-(len(Valor)-charindex('.',valor))-1) + (sign(100-round(valor*100,0))) P

from #new

drop table #new1
select identity(int,1,1) num, 99999999.99 Valor, 99999999.99 Resultado into #new1 where 1 = 0

insert into #new1 select 0.1			,0
insert into #new1 select 0.456		,0
insert into #new1 select 1.456		,0
insert into #new1 select 10.50		,0
insert into #new1 select 101.456	,0

select *, len(Valor), charindex('.',valor), len(Valor)-charindex('.',valor), round(valor,3) 
from #new1

--0,456 -> 0,456
--1,456 _> 1,46
--10,456 -> 10,50
--101,456 -> 101,00