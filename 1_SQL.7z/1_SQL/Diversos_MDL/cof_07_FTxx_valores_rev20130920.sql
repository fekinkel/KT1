ALTER TABLE FTIT DISABLE TRIGGER ALL
ALTER TABLE FTNF DISABLE TRIGGER ALL


-- PASSO N : In�cio  do c�digo de atualiza��o de dados aqui ---------- Bof() --------
-- PASSO N : In�cio  do c�digo de atualiza��o de dados aqui ---------- Bof() --------
set implicit_transactions off
set nocount on
-- Vari�veis auxiliares
declare @PIS_inc char(1), @PIS_cst varchar(2), @PIS_nat varchar(2), @PIS_bas decimal(12,2), @PIS_ali decimal(12,2), @PIS_val decimal(12,2), @PIS_ise decimal(12,2), @PIS_out decimal(12,2)
declare @COF_inc char(1), @COF_cst varchar(2), @COF_nat varchar(2), @COF_bas decimal(12,2), @COF_ali decimal(12,2), @COF_val decimal(12,2), @COF_ise decimal(12,2), @COF_out decimal(12,2)
declare @regi varchar(10), @cnpj varchar(20), @bas_PISCOF decimal(12,2)
declare @acu_pis_bas decimal(12,2), @acu_pis_val decimal(12,2), @acu_pis_ise decimal(12,2), @acu_pis_out decimal(12,2)
      , @acu_cof_bas decimal(12,2), @acu_cof_val decimal(12,2), @acu_cof_ise decimal(12,2), @acu_cof_out decimal(12,2)

declare cCABE cursor local static for
select FTNF_SIES, FTNF_SIDO, FTNF_SISE, FTNF_COD, FTNF_DAT
     , FTIT_COD, FTIT_NFOP, FTIT_CFOP, FTIT_MTNC, FTIT_VAL_PIS, FTIT_VAL_COF, (isnull(FTIT_val,0)+isnull(FTIT_val_fre,0)+isnull(FTIT_val_seg,0)+isnull(FTIT_val_ace,0))
     , isnull(FTIT_ipi_bas,0.00), isnull(FTIT_ipi_val,0.00), isnull(FTIT_ipi_out,0.00)
from FTNF, FTIT
where FTIT_sies=FTNF_sies and FTIT_sido=FTNF_sido and FTIT_FTNF=FTNF_cod
--- Selecionar per�odo aqui !!!
and year(FTNF_DAT)=2011
and month(FTNF_DAT)=1

open cCABE
if Cursor_Status('local','cCABE')>0 begin
   declare @sies int, @sido varchar(4), @sise varchar(3), @cod int, @dat datetime
   declare @sies_atu int, @sido_atu varchar(4), @sise_atu varchar(3), @cod_atu int, @dat_atu datetime
   declare @codi int, @nfop varchar(20), @cfop varchar(20),  @mtnc varchar(20), @val_pis decimal(12,2), @val_cof decimal(12,2), @val_ms decimal(12,2), @ipi_bas decimal(12,2), @ipi_val decimal(12,2), @ipi_out decimal(12,2)
   fetch next from cCABE into @sies, @sido, @sise, @cod, @dat
   , @codi, @nfop, @cfop, @mtnc, @val_pis, @val_cof, @val_ms, @ipi_bas, @ipi_val, @ipi_out
   while @@fetch_status=0 begin
      set @sies_atu=@sies
      set @sido_atu=@sido
      set @sise_atu=@sise
      set @cod_atu =@cod
      set @dat_atu =@dat
--      while @@fetch_status=0
--      -- Cria cursor dos itens
--      declare cITEM cursor local for
--      select FTIT_COD, FTIT_NFOP, FTIT_CFOP, FTIT_MTNC, FTIT_VAL_PIS, FTIT_VAL_COF, (isnull(FTIT_val,0)+isnull(FTIT_val_fre,0)+isnull(FTIT_val_seg,0)+isnull(FTIT_val_ace,0))
--      , isnull(FTIT_ipi_bas,0.00), isnull(FTIT_ipi_val,0.00), isnull(FTIT_ipi_out,0.00)
--      from FTIT where FTIT_SIES=@sies and FTIT_SIDO=@sido and FTIT_SISE=@sise and FTIT_FTNF=@cod
--      open cITEM
      -- Inicializa acumulados do pai
      set @acu_pis_bas=0.00
      set @acu_pis_val=0.00
      set @acu_pis_ise=0.00
      set @acu_pis_out=0.00
      set @acu_cof_bas=0.00
      set @acu_cof_val=0.00
      set @acu_cof_ise=0.00
      set @acu_cof_out=0.00
      BEGIN transaction CABE
      SAVE transaction CABE
      while @@fetch_status=0
         and @sies_atu=@sies
         and @sido_atu=@sido
         and @sise_atu=@sise
         and @cod_atu =@cod
      begin
--      if Cursor_status('local','cITEM')>0 begin
--         fetch next from cITEM into @codi, @nfop, @cfop, @mtnc, @val_pis, @val_cof, @val_ms, @ipi_bas, @ipi_val, @ipi_out
--         while @@fetch_status=0 begin
            if exists(select 1 from nfop where nfop_cod=@nfop) begin
               select @pis_inc=nfop_pis_inc, @pis_cst=nfop_pis_cst, @pis_nat=nfop_pis_natbc, @pis_ali=nfop_pis_ali
               ,      @cof_inc=nfop_cof_inc, @cof_cst=nfop_cof_cst, @cof_nat=nfop_cof_natbc, @cof_ali=nfop_cof_ali
               from nfop where nfop_cod=@nfop
            end else begin
               select @pis_cst='99', @pis_nat='00', @pis_ali=1.65
               ,      @cof_cst='99', @cof_nat='00', @cof_ali=7.60
               if exists (select 1 from SIES where sies_cod=@sies) begin
                  select @cnpj=isnull(sies_cnpj,'99999999999999'), @regi=isnull(sies_regi,'') from SIES where sies_cod=@sies
                  -- A al�quota poder� vir da opera��o futuramente
                  if @Regi='LR' begin
                     set @Pis_Ali= 1.65
                     set @Cof_Ali= 7.60
                  end else if @Regi='LP' begin
                     set @Pis_Ali= 0.65
                     set @Cof_Ali= 3.00
                  end else begin
                     set @Pis_Ali= 0.00
                     set @Cof_Ali= 0.00
                  end
               end else begin
                  set @cnpj='99999999999999'
               end
            end
            -- Respeitando o passado
            set @PIS_val=@val_PIS
            set @COF_val=@val_COF
            if @PIS_val>0 set @pis_inc='S' else set @pis_inc='N'
            if @COF_val>0 set @cof_inc='S' else set @cof_inc='N'
            -- complementando campos
            if (substring(@CFOP,1,1)<>'3') begin
-- GDGDGDGDGDGDGD  BOF===================================================================================
               -- GD ---
               if  (substring(@cnpj,1,8)='45402385')
               and (@ipi_VAL)<>0.00
               begin
                  set @bas_PISCOF=@Val_ms
                  if (@pis_inc='S') or (@cof_inc='S') begin
                     -- Realizar c�lculo do valor do IPI quando entrada e base 1 est� zerada p/ n�o contabilizar cr�dito, por�m total da NF
                     if ((substring(@CFOP,1,1)='1') or (substring(@CFOP,1,1)='2')) begin
      -- 05/04/2012 08:29 -- SCIED -- Meire da GD :  Caso exista IPI destacado e n�o me credito do IPI, o mesmo deve fazer parte da base de c�lculo do PIS/COF
                        if (@IPI_BAS=0.00) begin
                           set @BAS_PISCOF=@BAS_PISCOF+@IPI_VAL
                        end else
      -- 02/05/2012 17:41 -- SCIED -- Meire da GD :  Caso do IPI presumido sobre base de 50%: Deve ser deduzido da base do PISCOF
                        if (Abs(Round(@IPI_BAS-@IPI_OUT,2))<=0.01) begin
                           set @BAS_PISCOF=@BAS_PISCOF-@IPI_VAL
                        end
                     end
                  end
                  set @Val_ms=@bas_PISCOF
               end -- cnpj GD
-- GDGDGDGDGDGDGD  EOF===================================================================================
               -- PIS
               if @pis_inc='S' begin
                  set @pis_bas=@Val_ms
                  set @pis_ise=0.00
                  set @pis_out=0.00
               end else begin
                  set @pis_bas=0.00
                  if @pis_cst='07' or @pis_cst='71' begin
                     set @pis_ise=@Val_ms
                     set @pis_out=0.00
                  end else begin
                     set @pis_ise=0.00
                     set @pis_out=@Val_ms
                  end
               end
               -- COFINS
               if @COF_inc='S' begin
                  set @COF_bas=@Val_ms
                  set @COF_ise=0.00
                  set @COF_out=0.00
               end else begin
                  set @COF_bas=0.00
                  if @cof_cst='07' or @cof_cst='71' begin
                     set @cof_ise=@Val_ms
                     set @cof_out=0.00
                  end else begin
                     set @cof_ise=0.00
                     set @cof_out=@Val_ms
                  end
               end
            end else begin
               --- Importa��es
               -- PIS
               -- Base ser� c/ c�lculo reverso
               if @pis_inc='S' begin -- (@pis_val>0)
                   set @pis_ise=0.00
                   set @pis_out=0.00
                  if @pis_ali<>0 begin
                     set @pis_bas=round(@pis_val*100/@pis_ali,2)
                  end else begin
                     set @pis_bas=@Val_ms
                  end
               end else begin
                  set @pis_bas=0.00
                  if @pis_cst='07' or @pis_cst='71' begin
                     set @pis_ise=@Val_ms
                     set @pis_out=0.00
                  end else begin
                     set @pis_ise=0.00
                     set @pis_out=@Val_ms
                  end
               end
               -- COFINS
               -- Reve al�quota espec�fica de COFINS Se � IMPORTA��O
               -- MP 563 a partir de AGO/2012
               if (year(@dat)=2012 and month(@dat)>=8) or (year(@dat)>2012)  begin
                  if exists(select 1 from MTNC where MTNC_COD=@mtnc and isnull(MTNC_COF_ALI,0)<>0) begin
                     select @cof_ali=MTNC_COF_ALI from MTNC where MTNC_COD=@mtnc and isnull(MTNC_COF_ALI,0)<>0
                  end
               end
               -- Base ser� c/ c�lculo reverso
               if @cof_inc='S' begin -- (@cof_val>0)
                   set @cof_ise=0.00
                   set @cof_out=0.00
                  if @cof_ali<>0 begin
                     set @cof_bas=round(@cof_val*100/@cof_ali,2)
                  end else begin
                     set @cof_bas=@Val_ms
                  end
               end else begin
                  set @cof_bas=0.00
                  if @cof_cst='07' or @cof_cst='71' begin
                     set @cof_ise=@Val_ms
                     set @cof_out=0.00
                  end else begin
                     set @cof_ise=0.00
                     set @cof_out=@Val_ms
                  end
               end
            end
            -- Atualiza item
            update FTIT set
             FTIT_PIS_CST=@PIS_cst
            ,FTIT_PIS_NAT=@PIS_nat
            ,FTIT_PIS_BAS=@PIS_bas
            ,FTIT_PIS_ALI=@PIS_ALI
            ,FTIT_PIS_VAL=@PIS_VAL
            ,FTIT_PIS_ISE=@PIS_ISE
            ,FTIT_PIS_OUT=@PIS_OUT
            ,FTIT_COF_CST=@COF_cst
            ,FTIT_COF_NAT=@COF_nat
            ,FTIT_COF_BAS=@COF_bas
            ,FTIT_COF_ALI=@COF_ALI
            ,FTIT_COF_VAL=@COF_VAL
            ,FTIT_COF_ISE=@COF_ISE
            ,FTIT_COF_OUT=@COF_OUT
            where FTIT_SIES=@sies and FTIT_SIDO=@sido and FTIT_SISE=@sise and FTIT_FTNF=@cod and FTIT_COD=@codi

            -- Acumula valores
            set @acu_pis_bas=@acu_pis_bas+@pis_bas
            set @acu_pis_val=@acu_pis_val+@pis_val
            set @acu_pis_ise=@acu_pis_ise+@pis_ise
            set @acu_pis_out=@acu_pis_out+@pis_out
            set @acu_cof_bas=@acu_cof_bas+@cof_bas
            set @acu_cof_val=@acu_cof_val+@cof_val
            set @acu_cof_ise=@acu_cof_ise+@cof_ise
            set @acu_cof_out=@acu_cof_out+@cof_out

--           fetch next from cITEM into @codi, @nfop, @cfop, @mtnc, @val_pis, @val_cof, @val_ms, @ipi_bas, @ipi_val, @ipi_out
--         end-- while itens
--      end-- cursor itens
--      close cITEM
--      deallocate cITEM
         fetch next from cCABE into @sies, @sido, @sise, @cod, @dat
         , @codi, @nfop, @cfop, @mtnc, @val_pis, @val_cof, @val_ms, @ipi_bas, @ipi_val, @ipi_out

      end -- terminou a nota
      update FTNF set
       FTNF_pis_bas=@acu_pis_bas
      ,FTNF_pis_val=@acu_pis_val
      ,FTNF_pis_ise=@acu_pis_ise
      ,FTNF_pis_out=@acu_pis_out
      ,FTNF_cof_bas=@acu_cof_bas
      ,FTNF_cof_val=@acu_cof_val
      ,FTNF_cof_ise=@acu_cof_ise
      ,FTNF_cof_out=@acu_cof_out
      where FTNF_sies=@sies_ATU and FTNF_sido=@sido_ATU and FTNF_sise=@sise_ATU and FTNF_cod=@cod_ATU
      COMMIT transaction CABE
print 'Atualizado: '+cast(@sies_atu as varchar)+'/'+@sido_atu+'/'+@sise_atu+'/'+cast(@cod_atu as varchar) +' de '+convert(char(10), @dat_atu, 103)

--      fetch next from cCABE into @sies, @sido, @sise, @cod
   end-- while cabec
end -- cursor cabec
close cCABE
deallocate cCABE
go


go
-- PASSO N : T�rmino do c�digo de atualiza��o de dados aqui ---------- Eof() --------


-- PASSO 1.5 : Recria TR de FTNF

if exists (select 1 from dbo.sysobjects where id = object_id(N'[dbo].[FTNF_ia_GLPG_SMR]') and xType='TR')
   drop trigger [dbo].[FTNF_ia_GLPG_SMR]
go

------------------------------------------------------------------------------------------------------------------
-- DATA             -- AUTOR -- HIST�RICO
-- 11/10/2005 10:26 -- Doddy -- Verifica se condi��o de pagamento est� ativa para venda
-- 02/03/2006 12:58 -- Doddy -- Revista - OK
-- 16/03/2007 18:05 -- Doddy -- S� verifica se GLPG <> '' e '0'
------------------------------------------------------------------------------------------------------------------
CREATE trigger dbo.FTNF_ia_GLPG_SMR on dbo.FTNF
--with encryption
for insert,update
as
begin
-- Importante : NUNCA USAR  "BEGIN TRANSACTION"  ou "COMMIT" numa trigger
-- Importante : par_erro deve ser do tipo : num_erro#proc#tab_erro#cam_erro#chave#
   set nocount on
   declare @par_erro varchar(255), @ok int   -- @ok = 0 Sem erro ; @ok <> 0 Com erro
   select @par_erro='', @ok=0
   declare @campo varchar(30), @atv char(1)
   -- Verifica se existe o registro em GLPG
   if @ok = 0 begin
      select top 1 @campo=isnull(cast(FTNF_GLPG as varchar(30)),'') from inserted
      if @campo<>''  and @campo<>'0' begin
         if not exists (select top 1 * from GLPG,inserted
                                      where GLPG.GLPG_COD=inserted.FTNF_GLPG) begin
            -- Caracteriza o erro
            set @par_erro = '2030#FTNF_ia_GLPG_SMR#GLPG#GLPG_COD#'
            set @par_erro = @par_erro +(select top 1 CAST(FTNF_GLPG AS VARCHAR) from inserted)+'#'
            set @ok=1
         end else begin
            select @atv=glpg_atvv from GLPG,inserted where GLPG.GLPG_COD=inserted.FTNF_GLPG
            if @atv='N' begin
               -- Caracteriza o erro
               set @ok=1
               set @par_erro = '9999#FTNF_ia_GLPG_SMR#GLPG#GLPG_COD#' +(select top 1 cast(FTNF_GLPG as varchar) from inserted)+char(13)+char(13)
               if @@langid=27 or @@langid=9 begin
                  set @par_erro= @par_erro +'N�o est� ativa para venda.#'
               end else if @@langid=5 begin
                  set @par_erro= @par_erro +'No est� activa para venta.#'
               end else begin
                  set @par_erro= @par_erro +'It''s not active for sale.#'
               end
            end
         end
      end
   end
   -- Verifica se ocorreu erro
   if @ok<>0 begin
      exec [dbo].[SI_ERROR_TRIGGER] @par_erro output
      raiserror(51000,16,1,@par_erro)
      rollback transaction
   end
end
return
go

if exists (select 1 from dbo.sysobjects where id = object_id(N'[dbo].[FTNF_ia_SMR]') and xType='TR')
   drop trigger [dbo].[FTNF_ia_SMR]
go

----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Sistema           : SMRASP => MSSQL (SCR)
-- Procedure         : FTNF_ia_SMR => Atualiza n�mero do objeto para sedex caso a
--                   :                Transportadora seja alterada
-- Data              : Historico de atualizacoes
-- 10/06/2005 09:38  : Criada por Doddy Gallo
-- 11/08/2005 15:30  : SCIED -- Multirow
-- 29/09/2005 13:38  : Doddy -- Corre��o bug quando alterava somente o frete
-- 04/10/2005 19:04  : Doddy -- Atualiza campos da transportadora e limpa placa quando muda c�digo
-- 21/04/2009 12:47  : Doddy -- Novo Campo FTCO_MUNT
-- 22/04/2009 15:42  : Doddy -- Novos Campos FTCO_NUMT e FTCO_COMT
-- 02/06/2009 14:23  : Doddy -- Corre��o do tamanho do campo FTCO_MUNT
-- ????_BAI? e ????_CEP? declaradas respectivamente com 50 e 10 nas stp's do banco SMRPlus_des (similaridade com USA/MEX)
-- 05/12/2012 09:34 -- Doddy -- Aumento da vari�vel @????_nomT para varchar(60)
----------------------------------------------------------------------------------------------------------------------------------------------------------------
create trigger [dbo].[FTNF_ia_SMR] on [dbo].[FTNF]
--with encryption
for update
as
begin
-- Importante : NUNCA USAR  "BEGIN TRANSACTION"  ou "COMMIT" numa trigger
-- Importante : par_erro deve ser do tipo : num_erro#proc#tab_erro#cam_erro#chave#
   set nocount on
   declare @par_erro varchar(255), @ok int   -- @ok = 0 Sem erro ; @ok <> 0 Com erro
   select @par_erro='', @ok=0
   -- Para definir envio e avaliar retorno de stp
   declare @modo char(1)
   declare  @campo varchar(30), @campo1 varchar(30), @campo2 varchar(30), @campo3 varchar(30),
   @sies int, @sido varchar(4), @sise varchar(3) , @cod int,
   @gltr int, @frete char(1)  , @nobj varchar(25),
   @placa varchar(9)
   declare  @glbc varchar(3), @cart varchar(3)
   -- declara campos da transportadora
   declare  @FTCO_NOMT  varchar(60),@FTCO_CNPJT varchar(14),
            @FTCO_CPFT  varchar(11),@FTCO_IEST  varchar(20),@FTCO_RGT   varchar(9) ,@FTCO_IMUT  varchar(20),@FTCO_ENDT  varchar(50),@FTCO_NUMT  varchar(5),@FTCO_COMT  varchar(10),
            @FTCO_BAIT  varchar(50),@FTCO_CIDT  varchar(25),@FTCO_PAIST varchar(3) ,@FTCO_ESTT  varchar(2) ,@FTCO_MUNT  varchar(7) ,@FTCO_CEPT  varchar(10)

   -- Verifica se existe o registro em GLCC para posterior verifica��o da carteira
   if @ok = 0 begin
      select top 1 @campo=isnull(cast(FTNF_GLCC as varchar(30)),'') from inserted
      if @campo<>''  and @campo<>'0' begin
         if not exists (select top 1 * from GLCC,inserted
                    where GLCC.GLCC_COD=inserted.FTNF_GLCC) begin
            -- Caracteriza o erro
            set @par_erro = '2030#FTNF_ia#GLCC#GLCC_COD#'
            set @par_erro = @par_erro +(select top 1 CAST(FTNF_GLCC AS VARCHAR) from inserted)+'#'
            set @ok=1
         end else begin
            select top 1 @cart=isnull(cast(FTNF_CART as varchar(30)),'') from inserted
            if @cart<>'' and @cart<>'0' begin
               select @glbc=glcc_glbc from glcc where glcc_cod=@campo
               if not exists(select top 1 * from glpr where glpr_cod='CF_CAR' and glpr_chav=@cart and glpr_depe=@glbc) begin
                  -- Caracteriza o erro
                  set @par_erro = '2030#FTNF_ia_SMR#GLPR#GLPR_COD+GLPR_CHAV+GLPR_DEPE#'
                  set @par_erro = @par_erro +'CF_CAR'+'+'+@cart+'+'+@glbc+'#'
                  set @ok=1
               end
            end
         end
     end
   end
   -- Verifica se existe o registro em FTNF
   if @ok = 0 begin
      select top 1 @campo=isnull(cast(FTNF_GLTR as varchar(30)),''), @campo2=FTNF_FRETE from inserted
      select top 1 @campo1=isnull(cast(FTNF_GLTR as varchar(30)),''), @campo3=FTNF_FRETE  from deleted
      if (@campo<>@campo1) or (@campo2<>@campo3) begin
     select   @sies=inserted.FTNF_SIES, @sido=inserted.FTNF_SIDO, @sise=inserted.FTNF_SISE, @cod =inserted.FTNF_COD ,
                  @gltr=inserted.FTNF_GLTR, @frete=inserted.FTNF_FRETE, @placa=inserted.FTNF_PLACA from inserted
 -- Branqueia a placa
         if (@campo<>@campo1) set @placa=''
         -- C�lculo do n�mero do objeto (FTNF_NOBJ) para sedex
         exec FT_CALC_SEDEX   @modo output, @par_erro output,
                              @gltr, @frete, @nobj output
         if @modo<>'S' set @ok=1
         if @ok = 0 begin
            update FTNF set FTNF_NOBJ=@NOBJ, FTNF_PLACA=@placa
            where FTNF.FTNF_SIES=@sies and FTNF.FTNF_SIDO=@sido and FTNF.FTNF_SISE=@sise and FTNF.FTNF_COD =@cod
            -- verifica se a operac�o gerou erro (segundo foreign key)
            if @@error<>0 begin
               set @ok=1
               set @par_erro='FTNF_ia_SMR: Erro interno. Prov�vel viola��o de FOREIGN KEY'
            end
         end
         -- Se alterou transportadora carrega novos campos
         if @ok = 0 begin
            if (@campo<>@campo1) begin
               set @FTCO_NOMT =''
               set @FTCO_CNPJT=''
               set @FTCO_CPFT =''
               set @FTCO_IEST =''
               set @FTCO_RGT  =''
               set @FTCO_IMUT =''
               set @FTCO_ENDT =''
               set @FTCO_NUMT =''
               set @FTCO_COMT =''
               set @FTCO_BAIT =''
               set @FTCO_CIDT =''
               set @FTCO_PAIST=''
               set @FTCO_ESTT =''
               set @FTCO_MUNT =''
               set @FTCO_CEPT =''
               if exists(select * from GLPA, GLTR where gltr_cod=@gltr and glpa_cod=gltr_glpa) begin
                  select   @FTCO_NOMT =isnull(glpa_nom,'')
                          ,@FTCO_CNPJT=isnull(glpa_cnpj,'')
                          ,@FTCO_CPFT =isnull(glpa_cpf,'')
                          ,@FTCO_IEST =isnull(glpa_ies,'')
                          ,@FTCO_RGT  =isnull(glpa_rg,'')
                          ,@FTCO_IMUT =isnull(glpa_imu,'')
                          ,@FTCO_ENDT =isnull(glpa_end,'')
                          ,@FTCO_NUMT =isnull(glpa_nume,'')
                          ,@FTCO_COMT =isnull(glpa_comp,'')
                          ,@FTCO_BAIT =isnull(glpa_bai,'')
                          ,@FTCO_CIDT =isnull(glpa_cid,'')
                          ,@FTCO_PAIST=isnull(glpa_glps,'')
                          ,@FTCO_ESTT =isnull(glpa_gluf,'')
                          ,@FTCO_MUNT =isnull(glpa_glmn,'')
                          ,@FTCO_CEPT =isnull(glpa_cep,'')
                  from GLPA, GLTR where gltr_cod=@gltr and glpa_cod=gltr_glpa
               end
               update FTCO set FTCO_NOMT =@FTCO_NOMT
                              ,FTCO_CNPJT=@FTCO_CNPJT
                              ,FTCO_CPFT =@FTCO_CPFT
                              ,FTCO_IEST =@FTCO_IEST
                              ,FTCO_RGT  =@FTCO_RGT
                              ,FTCO_IMUT =@FTCO_IMUT
                              ,FTCO_ENDT =@FTCO_ENDT
                              ,FTCO_NUMT =@FTCO_NUMT
                              ,FTCO_COMT =@FTCO_COMT
                              ,FTCO_BAIT =@FTCO_BAIT
                              ,FTCO_CIDT =@FTCO_CIDT
                              ,FTCO_PAIST=@FTCO_PAIST
                              ,FTCO_ESTT =@FTCO_ESTT
                              ,FTCO_MUNT =@FTCO_MUNT
                              ,FTCO_CEPT =@FTCO_CEPT
               where FTCO_SIES=@sies and FTCO_SIDO=@sido and FTCO_SISE=@sise and FTCO_COD=@cod
               -- verifica se a operac�o gerou erro (segundo foreign key)
               if @@error<>0 begin
                  set @ok=1
                  set @par_erro='FTNF_ia_SMR: Erro interno. Prov�vel viola��o de FOREIGN KEY'
               end
            end
         end
      end
   end
   -- Verifica se ocorreu erro
   if @ok<>0 begin
      exec [dbo].[SI_ERROR_TRIGGER] @par_erro output
      raiserror(51000,16,1,@par_erro)
      rollback transaction
   end
end


ALTER TABLE FTIT ENABLE TRIGGER ALL
ALTER TABLE FTNF ENABLE TRIGGER ALL




