
	declare
	@vSies      int          ,
  @vSido      varchar(4)   ,
  @vSise      varchar(3)   ,
  @vCod       int          ,
  @vItem      int=5 ,       
  @vCorre decimal(12,2)


	set   @vSies = 5
	set   @vSido = 'VDCO'
	set   @vSise = '001'
	set   @vCod  = 335257
	set  @vCorre = 1--0.8195

	IF OBJECT_ID('TempDB.dbo.#vdc1') IS NOT NULL DROP TABLE #vdc1
	select *
	into #vdc1
	from vdc1, mtpr, mttp
  where vdc1_sies=@vSies 
  and vdc1_sido=@vSido 
  and vdc1_sise=@vSise 
  and vdc1_vdco=@vCod
  and vdc1_sub > 0
  and vdc1_mtpr = mtpr_cod
  and mtpr_mttp = mttp_cod
  --and vdc1_fmat > 1
	
	--select * from #vdc1
	--21 linhas

	IF OBJECT_ID('TempDB.dbo.#item') IS NOT NULL DROP TABLE #item
	select substring(VDC1_MTPC_NOM,1,charindex('mm',VDC1_MTPC_NOM)+1) [Descri��o]
	,VDC1_PBRU [Quantidade]
	,'KG' [Unidade]
	,round((vdc1_qtde*vdc1_fmat*vdc1_cMat*(100-vdc1_desc)*(100-vdc1_desc)/10000)*@vCorre/VDC1_PBRU ,2)[Pre�o Unit�rio]
	,round((vdc1_qtde*vdc1_fmat*vdc1_cMat*(100-vdc1_desc)*(100-vdc1_desc)/10000)*@vCorre,2)[Pre�o Total]
	,vdc1_mtpr
	into #item
	--,*,vdc1_cod, vdc1_sub, vdc1_mtpc, isnull(vdc1_fatr,0) vdc1_fatr, isnull(vdc1_fmat,0) vdc1_fmat, isnull(vdc1_fmdo,0) vdc1_fmdo, isnull(vdc1_cmdo,0) vdc1_cmdo, isnull(vdc1_cmat,0) vdc1_cmat, isnull(vdc1_puni,0) vdc1_puni, isnull(vdc1_punid,0)vdc1_punid, isnull(vdc1_desc,0)vdc1_desc, isnull(vdc1_qtde,0)vdc1_qtde, VDC1_MTUN
	from #vdc1
  where vdc1_fmat > 1
  order by vdc1_cod, vdc1_sub

select sum([Pre�o Total]) from #item

	insert into #item
	select substring(VDC1_MTPC_NOM,1,51) [Descri��o]
	,vdc1_qtde [Quantidade]
	,'PC' [Unidade]
	,round((vdc1_punid)*@vCorre ,2)[Pre�o Unit�rio]
	,round((vdc1_qtde*vdc1_Puni*(100-vdc1_desc)*(100-vdc1_desc)/10000)*@vCorre,2)[Pre�o Total]
	,vdc1_mtpr
	--,*,vdc1_cod, vdc1_sub, vdc1_mtpc, isnull(vdc1_fatr,0) vdc1_fatr, isnull(vdc1_fmat,0) vdc1_fmat, isnull(vdc1_fmdo,0) vdc1_fmdo, isnull(vdc1_cmdo,0) vdc1_cmdo, isnull(vdc1_cmat,0) vdc1_cmat, isnull(vdc1_puni,0) vdc1_puni, isnull(vdc1_punid,0)vdc1_punid, isnull(vdc1_desc,0)vdc1_desc, isnull(vdc1_qtde,0)vdc1_qtde, VDC1_MTUN
	from #vdc1
  where vdc1_fmat <= 1.00
  and mttp_MS <> 'S'
  and vdc1_mtun = 'KG'
  --and mttp_orde <> 'S'
  order by vdc1_cod, vdc1_sub

	insert into #item
	select substring(VDC1_MTPC_NOM,1,51) [Descri��o]
	,vdc1_qtde [Quantidade]
	,vdc1_mtun [Unidade]
	,round((vdc1_punid)*@vCorre ,2)[Pre�o Unit�rio]
	,round((vdc1_qtde*vdc1_Puni*(100-vdc1_desc)*(100-vdc1_desc)/10000)*@vCorre,2)[Pre�o Total]
	,vdc1_mtpr
	--,*,vdc1_cod, vdc1_sub, vdc1_mtpc, isnull(vdc1_fatr,0) vdc1_fatr, isnull(vdc1_fmat,0) vdc1_fmat, isnull(vdc1_fmdo,0) vdc1_fmdo, isnull(vdc1_cmdo,0) vdc1_cmdo, isnull(vdc1_cmat,0) vdc1_cmat, isnull(vdc1_puni,0) vdc1_puni, isnull(vdc1_punid,0)vdc1_punid, isnull(vdc1_desc,0)vdc1_desc, isnull(vdc1_qtde,0)vdc1_qtde, VDC1_MTUN
	from #vdc1
  where vdc1_fmat <= 1.00
  and mttp_MS <> 'S'
  and vdc1_mtun <> 'KG'
  --and mttp_orde <> 'S'
  order by vdc1_cod, vdc1_sub

select *
from #item
