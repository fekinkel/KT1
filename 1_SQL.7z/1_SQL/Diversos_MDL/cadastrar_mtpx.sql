--925 923 897
--insert into [192.168.1.38\sqlexpress].[s2e].[dbo].[mtpx]
select c.mtpx_mtpu, 10, c.MTPX_COD, a.MTPX_NOM, c.mtpx_exgr, 'KINKEL', GETDATE(), null, null
--select c.mtpx_mtpu, COUNT(c.mtpx_mtpu)
from MTPX a, MTPX b, [192.168.1.38\sqlexpress].[s2e].[dbo].[mtpx] c
where a.MTPX_SIEX = 10
			and b.MTPX_SIEX = 3
			and a.MTPX_MTPU = b.MTPX_MTPU
			and c.mtpx_siex = 3
			and b.MTPX_COD = c.mtpx_cod
--group by c.mtpx_mtpu
order by c.mtpx_mtpu

--select * from [192.168.1.38\sqlexpress].[s2e].[dbo].[mtpx] where mtpx_mtpu = '0000007'


select * 
--delete 
from [192.168.1.38\sqlexpress].[s2e].[dbo].[mtpx]
where MTPX_SIEX = 10
--MTPX_MTPU like '391515%'--MTPX_COD = 'A06.008.020' and MTPX_SIEX = 3
