select *
from vdc1
where vdc1_vdco = 266100

select *
--delete
from OFIT
where OFIT_OFNF = 40648

DROP TABLE #OFITSELECT * INTO #OFIT FROM OFIT WHERE 1 = 0INSERT INTO #OFITSELECT 		OFIT_SIES = CONVERT(int,5)      --CONVERT(int(6),'') E
	, OFIT_SIDO = CONVERT(varchar(4),'OF55')      --CONVERT(varchar(4),'') Tipo
	, OFIT_SISE = CONVERT(varchar(3),'001')      --CONVERT(varchar(3),'') S�rie
	, OFIT_OFNF = CONVERT(int,40648)      --CONVERT(int(6),'') N� Doc.
	, OFIT_COD = CONVERT(int,VDC1_COD)+6      --CONVERT(int(3),'') Item
	, OFIT_CODF = Null      --CONVERT(int(3),'') Item
	, OFIT_SIDP = Null      --CONVERT(varchar(4),'') Tipo
	, OFIT_SISP = Null      --CONVERT(varchar(3),'') S�rie
	, OFIT_CODP = Null      --CONVERT(int(6),'') Pedido
	, OFIT_CODI = Null      --CONVERT(int(3),'') Item
	, OFIT_MTPC = CONVERT(varchar(20),VDC1_MTPC)      --CONVERT(varchar(20),'') Refer�ncia
	, OFIT_NOM = CONVERT(varchar(255),VDC1_MTPC_NOM)      --CONVERT(varchar(255),'') Descri��o
	, OFIT_MTPR = CONVERT(varchar(20),mtpr_cod)      --CONVERT(varchar(20),'') Insumo
	, OFIT_MS = CONVERT(varchar(2),'M')      --CONVERT(varchar(2),'') M/S
	, OFIT_MTUN = CONVERT(varchar(3),'PC')      --CONVERT(varchar(3),'') Unidade
	, OFIT_MTNC = CONVERT(varchar(8),MTPR_MTNC)      --CONVERT(varchar(8),'') NCM
	, OFIT_ORI = CONVERT(char(1),'0')      --CONVERT(char(1),'') Origem
	, OFIT_MTDV = CONVERT(varchar(4),mtpr_mtdv)      --CONVERT(varchar(4),'') Divis�o
	, OFIT_MTLN = CONVERT(varchar(4),mtpr_mtln)      --CONVERT(varchar(4),'') Linha
	, OFIT_MTFM = CONVERT(varchar(4),mtpr_mtfm)      --CONVERT(varchar(4),'') Fam�lia
	, OFIT_PLIQ = CONVERT(decimal(12,2),vdc1_peso) --CONVERT(decimal(12),'') Peso L�q.
	, OFIT_PLQT = CONVERT(decimal(13,3),vdc1_peso*vdc1_qtde)      --CONVERT(decimal(13),'') Peso Tot.
	, OFIT_PBRT = CONVERT(decimal(13,3),vdc1_peso*vdc1_qtde)      --CONVERT(decimal(13),'') Peso Bruto
	, OFIT_EST = CONVERT(char(1),'S')      --CONVERT(char(1),'') Estoque
	, OFIT_MTTR = CONVERT(varchar(6),'NA')      --CONVERT(varchar(6),'') Transa��o
	, OFIT_STA = CONVERT(int,'0')      --CONVERT(int(3),'') Reserva
	, OFIT_CTPC = Null      --CONVERT(varchar(15),'') Cont�bil
	, OFIT_RDPC = Null      --CONVERT(varchar(7),'') Rdz.
	, OFIT_CTCC = Null      --CONVERT(varchar(15),'') C.C.
	, OFIT_RDCC = Null      --CONVERT(varchar(7),'') Rdz.
	, OFIT_QTD = VDC1_QTDE      --CONVERT(decimal(12),'') Quantidade
	, OFIT_PUN = VDC1_PUNI      --CONVERT(decimal(12),'') Valor Unit�rio
	, OFIT_VAL = VDC1_QTDE*VDC1_PUNI      --CONVERT(decimal(12),'') Valor do Item
	, OFIT_REV = CONVERT(char(1),'')      --CONVERT(char(1),'') Destina��o
	, OFIT_DES = 0.00      --CONVERT(decimal(12),'') Desconto
	, OFIT_NFOP = CONVERT(varchar(8),'6.914.Z')      --CONVERT(varchar(8),'') Oper.
	, OFIT_CFOP = '5.914'      --CONVERT(varchar(6),'') CFOP
	, OFIT_TIT = CONVERT(char(1),'N')      --CONVERT(char(1),'') Gera t�tulos
	, OFIT_TBB = '41'      --CONVERT(varchar(2),'') Tabela B
	, OFIT_MEN = 'ICMS Isento: Art.4�, Anexo I, item 61 do RICMS/PR Dec.1980/2007.  IPI Suspenso:  Art. 43, Inciso II do Decreto 7.212/2010.  Retorno em 60 dias'      --CONVERT(varchar(255),'') Mensagem
	, OFIT_IPI_BAS = 0.00      --CONVERT(decimal(12),'') Base IPI
	, OFIT_IPI_ALI = VDC1_IPI_ALI      --CONVERT(decimal(5),'') % IPI
	, OFIT_IPI_VAL = 0.00      --CONVERT(decimal(12),'') Valor IPI
	, OFIT_IPI_ISE = 0.00      --CONVERT(decimal(12),'') IPI Isento
	, OFIT_IPI_OUT = VDC1_IPI_BAS      --CONVERT(decimal(12),'') IPI Outros
	, OFIT_ISS_BAS = 0.00      --CONVERT(decimal(12),'') Base de ISS
	, OFIT_ISS_ALI = 0.00      --CONVERT(decimal(5),'') % ISS
	, OFIT_ISS_VAL = 0.00      --CONVERT(decimal(12),'') Valor do ISS
	, OFIT_ISS_ISE = 0.00      --CONVERT(decimal(12),'') ISS Isento
	, OFIT_ISS_OUT = 0.00      --CONVERT(decimal(12),'') ISS Isento
	, OFIT_ICM_BAS = 0.00      --CONVERT(decimal(12),'') Base ICMS
	, OFIT_ICM_ALI = 0.00      --CONVERT(decimal(5),'') % ICMS
	, OFIT_ICM_VAL = 0.00      --CONVERT(decimal(12),'') Valor do ICMS
	, OFIT_ICM_out = VDC1_IPI_BAS      --CONVERT(decimal(12),'') ICMS Isento
	, OFIT_ICM_ise = 0.00      --CONVERT(decimal(12),'') ICMS Outros
	, OFIT_IST_BAS = 0.00      --CONVERT(decimal(12),'') Base ICMS - ST
	, OFIT_IST_ALI = 0.00      --CONVERT(decimal(5),'') % ICMS - ST
	, OFIT_IST_VAL = 0.00      --CONVERT(decimal(12),'') Valor do ICMS - ST
	, OFIT_IST_ISE = 0.00      --CONVERT(decimal(12),'') ICMS Isento - ST
	, OFIT_IST_OUT = 0.00      --CONVERT(decimal(12),'') ICMS Outros - ST
	, OFIT_IST_IVA = 0.00      --CONVERT(decimal(12),'') ST- IVA %
	, OFIT_ICP_ALI = 0.00      --CONVERT(decimal(6),'') %ICMS Complem.
	, OFIT_ICP_VAL = 0.00      --CONVERT(decimal(12),'') Valor ICMS Complem.
	, OFIT_PIS_CST = '08'      --CONVERT(varchar(2),'') CST PIS
	, OFIT_PIS_NAT = '00'      --CONVERT(varchar(2),'') Nat BC PIS
	, OFIT_PIS_BAS = 0.00      --CONVERT(decimal(12),'') Base PIS
	, OFIT_PIS_ALI = 1.65      --CONVERT(decimal(5),'') % PIS
	, OFIT_PIS_VAL = 0.00      --CONVERT(decimal(12),'') Valor PIS
	, OFIT_PIS_ISE = 0.00      --CONVERT(decimal(12),'') PIS Isento
	, OFIT_PIS_OUT = VDC1_IPI_BAS      --CONVERT(decimal(12),'') PIS Outros
	, OFIT_COF_CST = '08'      --CONVERT(varchar(2),'') CST COF
	, OFIT_COF_NAT = '00'      --CONVERT(varchar(2),'') Nat BC COF
	, OFIT_COF_BAS = 0.00      --CONVERT(decimal(12),'') Base COF
	, OFIT_COF_ALI = 7.60      --CONVERT(decimal(5),'') % COF
	, OFIT_COF_VAL = 0.00      --CONVERT(decimal(12),'') Valor COF
	, OFIT_COF_ISE = 0.00      --CONVERT(decimal(12),'') COF Isento
	, OFIT_COF_OUT = VDC1_IPI_BAS      --CONVERT(decimal(12),'') COF Outros
	, OFIT_VAL_FRE = 0.00      --CONVERT(decimal(12),'') Frete
	, OFIT_VAL_SEG = 0.00      --CONVERT(decimal(12),'') Seguro
	, OFIT_VAL_ACE = 0.00      --CONVERT(decimal(12),'') Desp. Aces.
	, OFIT_IMP_ALI = 0.00      --CONVERT(decimal(5),'') % II
	, OFIT_IMP_ADU = 0.00      --CONVERT(decimal(12),'') Valor Aduaneiro
	, OFIT_IMP_DAD = 0.00      --CONVERT(decimal(12),'') Desp. Aduaneiras
	, OFIT_VAL_PIS = 0.00      --CONVERT(decimal(12),'') Valor do PIS
	, OFIT_VAL_COF = 0.00      --CONVERT(decimal(12),'') Valor da COFINS
	, OFIT_MTTP_SPED = Null      --CONVERT(varchar(2),'') Tipo SPED
	, OFIT_FCIT = '2'      --CONVERT(char(1),'') FCI Tipo
	, OFIT_FCIN = Null      --CONVERT(varchar(36),'') FCI #
	, OFIT_FCIP = 0.00      --CONVERT(decimal(5),'') CI %
	, OFIT_USC = CONVERT(varchar(15),'BIANCAC')      --CONVERT(varchar(15),'') Cadastrado por
	, OFIT_DTC = CONVERT(datetime,GETDATE())      --CONVERT(datetime(10),'') em
	, OFIT_USU = Null      --CONVERT(varchar(15),'') Alterado por
	, OFIT_DTU = Null      --CONVERT(datetime(10),'') em
	--select *
from vdc1, MTPC, MTPR
where vdc1_vdco = 266100
			and vdc1_mtpc = mtpc_cod
			and mtpc_mtpr = mtpr_cod
INSERT INTO OFITSELECT OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF ,OFIT_COD ,OFIT_CODF ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC ,OFIT_NOM ,OFIT_MTPR ,OFIT_MS ,OFIT_MTUN ,OFIT_MTNC ,OFIT_ORI ,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT ,OFIT_PBRT ,OFIT_EST ,OFIT_MTTR ,OFIT_STA ,OFIT_CTPC ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD ,OFIT_PUN ,OFIT_VAL ,OFIT_REV ,OFIT_DES ,OFIT_NFOP ,OFIT_CFOP ,OFIT_TIT ,OFIT_TBB ,OFIT_MEN ,OFIT_IPI_BAS ,OFIT_IPI_ALI ,OFIT_IPI_VAL ,OFIT_IPI_ISE ,OFIT_IPI_OUT ,OFIT_ISS_BAS ,OFIT_ISS_ALI ,OFIT_ISS_VAL ,OFIT_ISS_ISE ,OFIT_ISS_OUT ,OFIT_ICM_BAS ,OFIT_ICM_ALI ,OFIT_ICM_VAL ,OFIT_ICM_ISE ,OFIT_ICM_OUT ,OFIT_IST_BAS ,OFIT_IST_ALI ,OFIT_IST_VAL ,OFIT_IST_ISE ,OFIT_IST_OUT ,OFIT_IST_IVA ,OFIT_ICP_ALI ,OFIT_ICP_VAL ,OFIT_PIS_CST ,OFIT_PIS_NAT ,OFIT_PIS_BAS ,OFIT_PIS_ALI ,OFIT_PIS_VAL ,OFIT_PIS_ISE ,OFIT_PIS_OUT ,OFIT_COF_CST ,OFIT_COF_NAT ,OFIT_COF_BAS ,OFIT_COF_ALI ,OFIT_COF_VAL ,OFIT_COF_ISE ,OFIT_COF_OUT ,OFIT_VAL_FRE ,OFIT_VAL_SEG ,OFIT_VAL_ACE ,OFIT_IMP_ALI ,OFIT_IMP_ADU ,OFIT_IMP_DAD ,OFIT_VAL_PIS ,OFIT_VAL_COF ,OFIT_MTTP_SPED ,OFIT_FCIT ,OFIT_FCIN ,OFIT_FCIP ,OFIT_USC ,OFIT_DTC ,OFIT_USU ,OFIT_DTUFROM #OFIT--WHERE CONVERT(VARCHAR(6),OFIT_GLCL) NOT IN (SELECT CONVERT(VARCHAR(6),OFIT_GLCL)FROM OFIT)
select a.OFIT_ICM_out, a.OFIT_ICM_ise, b.OFIT_ICM_out, b.OFIT_ICM_ise--update ofit set OFIT_ICM_out = a.OFIT_ICM_out, OFIT_ICM_ise = a.OFIT_ICM_isefrom #ofit a, ofit bwhere a.OFIT_SIES = b.OFIT_SIES			and a.OFIT_SIDO = b.OFIT_SIDO			and a.OFIT_SISE = b.OFIT_SISE			and a.OFIT_OFNF = b.OFIT_OFNF			and a.OFIT_COD  = b.OFIT_COD--OFIT_SIES ,OFIT_SIDO ,OFIT_SISE ,OFIT_OFNF ,OFIT_COD ,OFIT_CODF ,OFIT_SIDP ,OFIT_SISP ,OFIT_CODP ,OFIT_CODI ,OFIT_MTPC ,OFIT_NOM ,OFIT_MTPR ,OFIT_MS ,OFIT_MTUN ,OFIT_MTNC ,OFIT_ORI ,OFIT_MTDV ,OFIT_MTLN ,OFIT_MTFM ,OFIT_PLIQ ,OFIT_PLQT ,OFIT_PBRT ,OFIT_EST ,OFIT_MTTR ,OFIT_STA ,OFIT_CTPC ,OFIT_RDPC ,OFIT_CTCC ,OFIT_RDCC ,OFIT_QTD ,OFIT_PUN ,OFIT_VAL ,OFIT_REV ,OFIT_DES ,OFIT_NFOP ,OFIT_CFOP ,OFIT_TIT ,OFIT_TBB ,OFIT_MEN ,OFIT_IPI_BAS ,OFIT_IPI_ALI ,OFIT_IPI_VAL ,OFIT_IPI_ISE ,OFIT_IPI_OUT ,OFIT_ISS_BAS ,OFIT_ISS_ALI ,OFIT_ISS_VAL ,OFIT_ISS_ISE ,OFIT_ISS_OUT ,OFIT_ICM_BAS ,OFIT_ICM_ALI ,OFIT_ICM_VAL ,OFIT_ICM_ISE ,OFIT_ICM_OUT ,OFIT_IST_BAS ,OFIT_IST_ALI ,OFIT_IST_VAL ,OFIT_IST_ISE ,OFIT_IST_OUT ,OFIT_IST_IVA ,OFIT_ICP_ALI ,OFIT_ICP_VAL ,OFIT_PIS_CST ,OFIT_PIS_NAT ,OFIT_PIS_BAS ,OFIT_PIS_ALI ,OFIT_PIS_VAL ,OFIT_PIS_ISE ,OFIT_PIS_OUT ,OFIT_COF_CST ,OFIT_COF_NAT ,OFIT_COF_BAS ,OFIT_COF_ALI ,OFIT_COF_VAL ,OFIT_COF_ISE ,OFIT_COF_OUT ,OFIT_VAL_FRE ,OFIT_VAL_SEG ,OFIT_VAL_ACE ,OFIT_IMP_ALI ,OFIT_IMP_ADU ,OFIT_IMP_DAD ,OFIT_VAL_PIS ,OFIT_VAL_COF ,OFIT_MTTP_SPED ,OFIT_FCIT ,OFIT_FCIN ,OFIT_FCIP ,OFIT_USC ,OFIT_DTC ,OFIT_USU ,OFIT_DTU ,


--select * 
--delete
--from OFIT
--where ofit_ofnf = 39433

insert into OFIT
select NFIT_SIES ,'OF55' NFIT_SIDO ,NFIT_SISE , 40648 NFIT_NFNF ,NFIT_COD ,NFIT_CODF ,null NFIT_SIDP ,null NFIT_SISP ,NFIT_CODP ,NFIT_CODI ,NFIT_MTPC ,NFIT_NOM ,NFIT_MTPR ,NFIT_MS ,NFIT_MTUN ,NFIT_MTNC ,NFIT_ORI ,NFIT_MTDV ,NFIT_MTLN ,NFIT_MTFM ,NFIT_PLIQ ,NFIT_PLQT ,NFIT_PBRT ,NFIT_EST ,NFIT_MTTR ,NFIT_STA ,NFIT_CTPC ,NFIT_RDPC ,NFIT_CTCC ,NFIT_RDCC ,NFIT_QTD ,NFIT_PUN ,NFIT_VAL ,NFIT_REV ,NFIT_DES ,'1.914.ZA' NFIT_NFOP ,'1.914' NFIT_CFOP ,NFIT_TIT ,NFIT_TBB ,NFIT_MEN ,NFIT_IPI_BAS ,NFIT_IPI_ALI ,NFIT_IPI_VAL ,NFIT_IPI_ISE ,NFIT_IPI_OUT ,NFIT_ISS_BAS ,NFIT_ISS_ALI ,NFIT_ISS_VAL ,NFIT_ISS_ISE ,NFIT_ISS_OUT ,NFIT_ICM_BAS ,NFIT_ICM_ALI ,NFIT_ICM_VAL ,NFIT_ICM_ISE ,NFIT_ICM_OUT ,NFIT_IST_BAS ,NFIT_IST_ALI ,NFIT_IST_VAL ,NFIT_IST_ISE ,NFIT_IST_OUT ,NFIT_IST_IVA ,NFIT_ICP_ALI ,NFIT_ICP_VAL ,NFIT_PIS_CST ,NFIT_PIS_NAT ,NFIT_PIS_BAS ,NFIT_PIS_ALI ,NFIT_PIS_VAL ,NFIT_PIS_ISE ,NFIT_PIS_OUT ,NFIT_COF_CST ,NFIT_COF_NAT ,NFIT_COF_BAS ,NFIT_COF_ALI ,NFIT_COF_VAL ,NFIT_COF_ISE ,NFIT_COF_OUT ,NFIT_VAL_FRE ,NFIT_VAL_SEG ,NFIT_VAL_ACE ,NFIT_IMP_ALI ,NFIT_IMP_ADU ,NFIT_IMP_DAD ,NFIT_VAL_PIS ,NFIT_VAL_COF ,NFIT_MTTP_SPED ,NFIT_FCIT ,NFIT_FCIN ,NFIT_FCIP ,NFIT_USC ,NFIT_DTC ,NFIT_USU ,NFIT_DTU
from NFIT
where NFIT_NFNF = 53677--//52466
