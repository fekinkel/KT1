select FTIT_FCIT, FTIT_FCIN, FTIT_FCIP, upper(MTCI_FCI_COD) MTCI_FCI_COD
--update ftit set ftIT_FCIT = 1, ftIT_FCIN = upper(MTCI_FCI_COD)
from FTIT, MTCI
where FTIT_ORI in ('3','5','8')
			and MTCI_MTPC = FTIT_MTPC
			and MTCI_SIES = 5
			and FTIT_FTNF =  56273
			and FTIT_FCIN <> upper(MTCI_FCI_COD)
