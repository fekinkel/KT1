declare
@sql varchar(4000),
@arq varchar(4000)

set @arq = 'Teste'
				set @sql = 'exec master..xp_cmdshell'+CHAR(39)+'pmsgSql /M(teste sql)(kinkel)(192.168.2.39)(S2R Cota��o 12587)(0444)(1) # (192.168.2.3#5772)'+CHAR(39)
				print @sql
				print @arq
			  exec(@sql)
				print @sql


exec master..xp_cmdshell 'pmsgSql /M(teste sql Query analayzer)(kinkel)(192.168.2.39)(S2R Cota��o 12587)(0444)(1) # (192.168.2.3#5772)'
