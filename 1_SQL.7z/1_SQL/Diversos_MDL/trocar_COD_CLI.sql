select *
--update cfcr set cfcr_sta = 'OK'
--update cfcr set CFCR_GLXX = 5814, cfcr_glxx_dig = 9
--update cfcr set cfcr_sta = 'BT'
from CFCR
where CFCR_COD = 15234 and CFCR_SIES = 7--CFCR_GLXX = 17243
--15234

select *
--update vdpd set VDPD_GLCL = 5814, vdpd_glcl_dig = 9, vdpd_glpa = 24595
from VDPD
where VDPD_COD = 161037--VDPD_GLCL = 17243
--161037

select * 
--update ftnf set ftnf_glxx = 5814, ftnf_glxx_dig = 9, ftnf_glpa = 24595
from FTNF
where FTNF_COD= 15234 and FTNF_SIES = 7--FTNF_GLXX = 17243

select *
--update vdco set vdco_glcl = 5814, vdco_glcl_dig = 9, vdco_glpa = 24595
from VDCO
where vdco_cod = 235384--VDCO_GLCL = 17243

--15234

select *
from FTCO 
where FTCO_COD = 15234
