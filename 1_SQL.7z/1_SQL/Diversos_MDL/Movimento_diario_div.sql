
declare
@de varchar(10),
@te varchar(10),
@aux varchar(10),
@data datetime,
@dias int,
@d int

set @de = '01/01/2009'
set @te = '31/07/2013'

drop table #new

select ANO = year(GETDATE()), MES = MONTH(GETDATE()-1), DIAS = DAY(GETDATE()), DATA = GETDATE()
into #new
where 1 = 0

--select @de, CONVERT(datetime,@de,103), convert(varchar(10),convert(datetime,@de,103)+1,102)

--select @ano_ini = YEAR(@de), @mes_ini = MONTH(@de), @ano_fim = YEAR(@te), @mes_fim = MONTH(@te), @dias = DAY(@de)

while convert(datetime,@de,103) <= convert(datetime,@te,103) begin
	set @aux = @de
	set @d = @dias
	while month(@de) = month(@aux) begin
		if (select datepart(dw ,convert(datetime,@de,103))) in(2,3,4,5,6) begin
			--print 'Data = ' + @de
			--print 'Dia da semana � = '+convert(varchar(2),@d)
			set @d = @d +1
			
		end
		select @de = convert(varchar(10),convert(datetime,@de,103)+1,103)
		--print 'Data nova = ' + @de
		 
	end
	--print 'Mudou o M�s'
	set @dias = 1
	select @de = convert(varchar(10),convert(datetime,@de,103)-1,103)
	SELECT @d = @d - COUNT(1) FROM GLCA WHERE convert(varchar(4),YEAR(GLCA_COD))+'/'+CONVERT(varchar(2),month(GLCA_COD)) = convert(varchar(4),YEAR(@de))+'/'+CONVERT(varchar(2),month(@de))
	insert into #new
	select year(@de), month(@de), (@d - 1), @de

	--set @mes_ini = @mes_ini + 1
	--set @mes_ini = 1
	--set @ano_ini = @ano_ini + 1

	drop table #tmpRlmd
	CREATE TABLE #tmpRlmd
   ( --Rlmd_ano			int
	  Rlmd_mtdv    varchar(4)
   , Rlmd_nomd    varchar(50)
   , Rlmd_div_ori varchar(4)
   , Rlmd_mtln    varchar(4)
   , Rlmd_nom     varchar(50)
   , Rlmd_text    varchar(5)
   , Rlmd_sies    int
   , Rlmd_sido    varchar(4)
   , Rlmd_sise    varchar(3)
   , Rlmd_vdpd    int
   , Rlmd_glcl    int
   , Rlmd_dig     int
   , Rlmd_nomc    varchar(50)
   , Rlmd_glvd    int
   , Rlmd_usu     varchar(15)
   , Rlmd_ant     decimal(12,2)
   , Rlmd_dia     decimal(12,2)
   , Rlmd_acu     decimal(12,2)
   , Rlmd_pct     decimal(6,2))


	
--[RL_VDA_MovimentoDiarioDiv]
--year(@de), month(@de), (@d - 1), @de
	set @d = @d - 1
	select @data = CONVERT(datetime,@de) 
	insert into #tmpRlmd exec RL_VDA_MovimentoDiarioDiv 0,'S',0,'0','0',@data, @d,'0','S','N'
	set @d = @d + 1
	drop table ##TAB
	select *, year(@de)ANO, month(@de) MES,(@d - 1) DIAS,@de DATA
	into ##TAB
	from #tmpRlmd

	
	Declare
	@str_NomeArquivo varchar(8000),
	@str_comando varchar(8000) 
	set @str_NomeArquivo = 'C:\MOV\MOV_'+convert(varchar(4),year(@de))+'_'+convert(varchar(2),month(@de))+'.txt'
	set @str_comando = ' sqlcmd -S 192.168.2.39 -U "sa" -P "mdl1680" -d CFG_MDL -q "SELECT * FROM ##TAB " -s ";" -f 65001 -o ' + @str_NomeArquivo
--set @str_comando = ' sqlcmd -S 192.168.2.39 -U "sa" -P "mdl1680" -d CFG_MDL -q "SELECT @@php " -s ";" -f 65001 -o ' + @str_NomeArquivo 
		--							'sqlcmd -S '+@servidor+' -U '+@usuario+' -P '+@senha+' -d '+@banco+' -q "'+@Procedure+'" -s ";" -f 65001 -o '+@arquivoFisico
	Exec xp_cmdshell @str_comando 
	
	select @de = convert(varchar(10),convert(datetime,@de,103)+1,103)

End

/*
Declare
@str_NomeArquivo varchar(8000),
@str_comando varchar(8000) 
set @str_NomeArquivo = 'C:\PHP\'+@tab+'Modelo.php'
set @str_comando = ' sqlcmd -S 192.168.2.39 -U "sa" -P "mdl1680" -d CFG_MDL -q "SELECT campo FROM ##TAB where campo is not null order by num" -s ";" -f 65001 -o ' + @str_NomeArquivo
--set @str_comando = ' sqlcmd -S 192.168.2.39 -U "sa" -P "mdl1680" -d CFG_MDL -q "SELECT @@php " -s ";" -f 65001 -o ' + @str_NomeArquivo 
		--							'sqlcmd -S '+@servidor+' -U '+@usuario+' -P '+@senha+' -d '+@banco+' -q "'+@Procedure+'" -s ";" -f 65001 -o '+@arquivoFisico
Exec xp_cmdshell @str_comando 
*/
