select *
--update nfnf set NFNF_NFE_CHV = FTNF_NFE_CHV, NFNF_NFE_STA = FTNF_NFE_STA , NFNF_NFE_PRO = FTNF_NFE_PRO, NFNF_NFE_DTP = FTNF_NFE_DTP
from NFNF, FTNF
where CONVERT(varchar(10),NFNF_DAT,102) between '2013.05.01' and '2013.05.31'
			--and NFNF_SIDO = 'nf'
			and NFNF_NFE_CHV = '' --NFNF_NFE_STA NFNF_NFE_PRO    NFNF_NFE_DTP
			and NFNF_SIES = FTNF_SIES
			and NFNF_SIDO = FTNF_SIDO
			and NFNF_SISE = FTNF_SISE
			and NFNF_COD  = FTNF_COD
			and FTNF_NFE_CHV <> ''
			
			