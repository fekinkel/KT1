drop table #new
select *
into #new
from mtpc
where mtpc_mtpr like 'PC.%'
			and MTPC_COD like 'PCM%'


drop table #valores
select '           'MTPC_MTPR_NEW, b.MTPC_MTPR, b.MTPC_COD, MTES_PCMR MTES_PCME, 0 MTES_PCMR, MTES_PMIN, MTES_POBJ, MTES_POEM, MTES_PPMI, MTES_PLEM, MTES_PMUL, MTES_PLEC, MTES_UCDO, MTES_LEAD
into #valores
from MTES a, #new b
where MTES_MTPR = MTPC_MTPR
			and MTES_SIES = 5

drop table #valores_n
select MTPC_MTPR, MAX(MTPC_COD)MTPC_COD_N
into #valores_n
from #valores
group by MTPC_MTPR

select *
--update #valores set MTPC_MTPR_NEW = MTPC_COD_N
from #valores a, #valores_n b
where a.MTPC_MTPR = b.MTPC_MTPR

select a.mtpc_mtpr, MTPC_MTPR_NEW, *
--update mtpc set mtpc_mtpr = MTPC_MTPR_NEW
from mtpc a, #valores b
where a.MTPC_COD = b.MTPC_COD

select MTES_MTPR, *
--update MTES set MTES_PCME = a.MTES_PCME, MTES_PCMR = a.MTES_PCMR, MTES_PMIN=a.MTES_PMIN, MTES_POBJ=a.MTES_POBJ, MTES_POEM=a.MTES_POEM, MTES_PPMI=a.MTES_PPMI, MTES_PLEM=a.MTES_PLEM, MTES_PMUL=a.MTES_PMUL, MTES_PLEC=a.MTES_PLEC, MTES_UCDO=a.MTES_UCDO, MTES_LEAD=a.MTES_LEAD
from #valores a, MTES b
where MTES_MTPR = MTPC_COD
			and MTES_SIES = 5

