select *
from GLCL, GLPA
where GLCL_GLPA = GLPA_COD
			and GLPA_GLRG = 'prs'