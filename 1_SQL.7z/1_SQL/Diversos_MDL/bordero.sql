select *--SUM(cfcr_val)
--update [192.168.2.39].[MDL].[dbo].cfcr set cfcr_glcc = '999-01'
from [192.168.2.39].[MDL].[dbo].CFCR, OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\1_Geral\bordero.XLS',plan1$)
where CFCR_SIES  = 5
			--and convert(varchar(10),CFCR_DTV,102) >= '2013.07.25'
			--and CFCR_GLCC = '341-05'
			and CFCR_COD  = cod
			and CFCR_SEQ  = SEQ
order by CFCR_DTV

select *--into #newFROM OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\1_Geral\bordero.XLS',plan1$) 
select *
from [192.168.2.39].[MDL].[dbo].cfel, OPENROWSET ('Microsoft.Jet.OleDB.4.0','EXCEL 8.0;Database=c:\1_Geral\bordero.XLS',plan1$)
where --convert(varchar(10),cfel_dtu,102) >= '2012.06.28'
			CFEL_SIES = 5
			and CFEL_CFER = 48333--49382--49253

