
DECLARE
@S varchar(100)

set @S = 'COPY NUL s:\ti\local\MDL_ENVIADOS_2014.sbd /Y'
set @S = 'if exist s:\ti\local\MDL_ENVIADOS_2014.sbd notepad'

Exec xp_cmdshell @S

print @s
