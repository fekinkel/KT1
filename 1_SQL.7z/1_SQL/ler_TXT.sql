
sp_configure 'allow updates', '0'
RECONFIGURE WITH OVERRIDE

sp_configure 'show advanced options', 1;  
GO  
RECONFIGURE;  
GO  
sp_configure 'Ole Automation Procedures', 1;  
GO  
RECONFIGURE;  
GO  
sp_configure 'allow updates', 1
--sp_configure 'Ole Automation Procedures', 1
--reconfigure

select *
from dbo.uftReadfileAsTable('C:\Users\kinkel.MDL\AppData\Roaming\Mozilla\SeaMonkey\Profiles\czqqste6.default\', 'prefs.js')
where substring(line,1,24) = 'user_pref("mailnews.tags' 
