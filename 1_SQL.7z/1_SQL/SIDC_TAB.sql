select *
--update [mdl].[dbo].sidc set SIDC_PESQ	= a.SIDC_PESQ, SIDC_GNAT = a.SIDC_GNAT
from sidc a, [mdl].[dbo].sidc b
where a.SIDC_SITB = b.SIDC_SITB
and a.SIDC_COD = b.SIDC_COD
and a.sidc_sitb = 'ofrt'
