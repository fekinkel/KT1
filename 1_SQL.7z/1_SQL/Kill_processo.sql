

declare
@i int = -1,
@msg varchar(200),
@base varchar(50)

set @base = 'MDL'

while (select count(1) from sys.sysprocesses, SYS.DATABASES where dbid = database_id and name  = @base and
 convert(varchar(10),login_time,102) < convert(varchar(10),getdate(),102)) > 1 begin

--	select name, *--@output = @output + 'kill ' + cast(spid as varchar(max)) + ';' 
--	from sys.sysprocesses, SYS.DATABASES
--	where dbid = database_id
--	and name  = 'CFG_MDL'
--	and convert(varchar(10),login_time,102) <> convert(varchar(10),getdate(),102)

	select @i = spid
	from sys.sysprocesses, SYS.DATABASES
	where dbid = database_id
	and name  = @base
	and convert(varchar(10),login_time,102) < convert(varchar(10),getdate(),102)

	select @msg = 'kill '+convert(varchar(6),@i)
	--kill @i
	
	print @msg
	
	--exec (@msg)
	
	--waitfor delay '00:00:01'
	
end

