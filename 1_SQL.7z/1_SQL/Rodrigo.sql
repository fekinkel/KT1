drop table ##new
	select Nome = 'fnsdjkfjkfhsdkjfs', Valor = 1
	into ##new
	
	insert into ##new select 'pppppppppppppppp', 2 
	insert into ##new select 'uuuuuuuuuuuuuuuu', 3 	

select *
from ##new

	--		
declare
@sql varchar(4000)	
--	 select SUM(valp) VALP, SUM(vald) VALD from #tmpRldi --order by glvd, glcl, digi, sies, sido, sise, cod
				set @sql = 'master..xp_cmdshell '+char(39)+'bcp " select * from (select ''''flor nova'''' as PEDIDO, ''''INDICE'''' as INDICE) as t" queryout "D:\0_sql\new.txt" -c -U sa -P mdl1680'+CHAR(39)
				--print @sql
			  exec(@sql) 
			  set @sql = 'master..xp_cmdshell '+char(39)+'bcp "select top 1 nome from [MDL].[dbo].##new " queryout "D:\0_sql\txt " -c -U sa -P mdl1680'+CHAR(39)
				--print @sql
			  exec(@sql) 
			  set @sql = 'master..xp_cmdshell '+char(39)+'type D:\0_sql\txt >> "D:\0_sql\new.txt"'+char(39)
				--print @sql
			  exec(@sql) 
			  set @sql = 'master..xp_cmdshell '+char(39)+'del D:\0_sql\txt'+CHAR(39)
				--print @sql
			  exec(@sql) 
