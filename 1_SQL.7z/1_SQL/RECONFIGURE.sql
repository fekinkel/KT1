sp_configure 'show advanced options', 1

RECONFIGURE  

 sp_configure 'Ole Automation Procedures', 1
 
Select line from
 Dbo.uftReadfileAsTable('D:\SQL_CODE_REVIEW','filename.sql')
where line  like '%drop%table%#%'