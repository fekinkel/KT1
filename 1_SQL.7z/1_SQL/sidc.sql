select *
--update sidc set sidc_pesq = 'S', sidc_gnat = 'S'
from sidc
where sidc_sitb = 'vdco'
			and SIDC_COD in ('vdco_email','VDCO_GLUF_DES')

select *
--update sidc set sidc_pesq = 'S', sidc_gnat = 'S'
from sidc
where sidc_sitb = 'prct'
			and SIDC_COD in ('prct_cfix','prct_cvar')


