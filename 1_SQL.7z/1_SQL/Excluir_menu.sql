select *
--delete
from sigm
where sigm_sigr  = 'cqlider'
and SIGM_SIMD <> 'RELAT�RIOS'

select *
--delete
from sigo
where sigo_sigr  = 'cqlider'
and SIGO_SIOP <> 'FRMRELPRODISMDO'
