/*
select distinct VDPD_SIES,	VDPD_SIDO,	VDPD_SISE,	VDPD_COD
from vdpd, vdpi
where vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and convert(varchar(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
and vdpi_mtdv = '3500'
and vdpd_sta = 'OK'
group by VDPD_SIES,	VDPD_SIDO,	VDPD_SISE,	VDPD_COD
*/



/*
select distinct VDco_SIES,	VDco_SIDO,	VDco_SISE,	VDco_COD
from vdco, vdc1
where vdco_sies = vdc1_sies
and vdco_sido = vdc1_sido
and vdco_sise = vdc1_sise
and vdco_cod  = vdc1_vdco
and convert(varchar(10),vdco_dtc,102) between '2015.01.01' and '2015.12.31'
and vdc1_mtdv = '3500'
and vdco_sta = 'OK'
group by VDco_SIES,	VDco_SIDO,	VDco_SISE,	VDco_COD
*/

select distinct VDc1_SIES,	VDc1_SIDO,	VDc1_SISE,	VDc1_vdco, vdc1_cod, vdpi_mtdv
from vdco, vdc1
where vdco_sies = vdc1_sies
and vdco_sido = vdc1_sido
and vdco_sise = vdc1_sise
and vdco_cod  = vdc1_vdco
and convert(varchar(10),vdco_dtc,102) between '2015.01.01' and '2015.12.31'
and vdc1_mtdv = '3500'
and vdco_sta = 'OK'
group by VDc1_SIES,	VDc1_SIDO,	VDc1_SISE,	VDc1_vdco



select distinct VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln
from vdpd, vdpi
where vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and convert(varchar(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
and vdpi_mtdv = '3500'
and vdpi_mtln in ('3950','3900','4100','4150')
--and vdpd_sta = 'OK'
group by VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln


select distinct VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln
from vdpd, vdpi
where vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and convert(varchar(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
and vdpi_mtdv = '3500'
and vdpi_mtln in ('3950')
--and vdpd_sta = 'OK'
group by VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln

select distinct VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln
from vdpd, vdpi
where vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and convert(varchar(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
and vdpi_mtdv = '3500'
and vdpi_mtln in ('3900')
--and vdpd_sta = 'OK'
group by VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln

select distinct VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln
from vdpd, vdpi
where vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and convert(varchar(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
and vdpi_mtdv = '3500'
and vdpi_mtln in ('4100')
--and vdpd_sta = 'OK'
group by VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln

select distinct VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln
from vdpd, vdpi
where vdpd_sies = vdpi_sies
and vdpd_sido = vdpi_sido
and vdpd_sise = vdpi_sise
and vdpd_cod  = vdpi_vdpd
and convert(varchar(10),vdpd_dtc,102) between '2015.01.01' and '2015.12.31'
and vdpi_mtdv = '3500'
and vdpi_mtln in ('4150')
--and vdpd_sta = 'OK'
group by VDpi_SIES,	VDpi_SIDO,	VDpi_SISE,	vdpi_vdpd, VDpi_COD, vdpi_mtdv, vdpi_mtln
