select *
--update ctla set CTLA_ATV = 'N'
from ctla
where ctla_cod between 1142722 and 1143104

select *
--delete
from ctla
where ctla_cod between 1142722 and 1143104

select *
--delete
from ctla
where ctla_cod between 1169310 and 1169730

