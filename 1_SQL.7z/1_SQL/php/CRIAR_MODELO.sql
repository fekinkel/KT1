--CRIAR OS MODELOS DE TABELAS PHP
--FERNANDO KINKEL SEREJO
declare
@tab varchar(20),
@php varchar(8000),
@cam varchar(4000)

set @tab = 'sttb'

select @tab = substring(UPPER(@tab),1,1)+substring(lower(@tab),2,LEN(@tab)-1)

drop table ##tab
drop table #new
Select	object_name(object_id) as Tabela,
				'$'+SUBSTRING(sys.types.name,1,2)+'_'+lower(sys.columns.name) as pri,
				SUBSTRING(sys.types.name,1,2)+'_'+lower(sys.columns.name) as pri_a,
				substring(upper(sys.columns.name),1,1)++substring(lower(sys.columns.name),2,LEN(sys.columns.name)-1) as set_get,
				lower(sys.columns.name) as Campo,
				sys.types.name as Tipo,
				'CP' chave,
				object_id as ID, 
				column_id indice
INTO #new
From	sys.columns	Inner Join sys.types On sys.types.system_type_id = sys.columns.system_type_id and sys.types.user_type_id = sys.columns.user_type_id
where object_name(object_id) = @tab

drop table #ch
select  sc.name, sc.id
into #ch
from sysobjects so
inner join sysindexes si on (si.id=so.parent_obj and si.indid=so.uid)
inner join sysindexkeys sik on (sik.id=si.id and sik.indid=si.indid)
inner join syscolumns sc on (sc.id=so.parent_obj and sc.colid=sik.colid)
where objectproperty(so.id, N'IsPrimaryKey')=1
  and objectproperty(so.parent_obj, N'IsUserTable')=1
  and not object_name(so.parent_obj) like 'dt'
order by so.id, sik.keyno

update #new set chave = 'PK'
from #new a, #ch b
where name = Campo
			and a.ID = b.id

select @php = '<?php'+char(13)+
'/**'+char(13)+
'* @package Backup'+char(13)+ 
'* @author Fernando Kinkel Serejo'+char(13)+ 
'* @version 0.1'+char(13)+ 
'*'+char(13)+  
'* Camada - Modelo '+char(13)+
'* Diret�rio Pai - modelo'+char(13)+ 
'* Arquivo - '+@tab+char(13)+
'*'+char(13)+
'* Respons�vel por gerenciar e persistir os dados dos  '+char(13)+
'* Agenda de Backup'+char(13)+ 
'**/'+char(13)+
'class '+@tab+'Modelo'+' extends ConexaoPDO {'+char(13)

--select identity(int,1,1) num, @php campo
--into ##tab
--set @php=''
select @php = @php + '	private '+pri+';'+CHAR(13)
from #new

--insert into ##tab
--select @php

--set @php=''
select @php = @php + '	function __construct() {'+CHAR(13)
--insert into ##tab
--select @php

--set @php=''
select @php = @php + '		parent::__constructor();'+CHAR(13)+
				'		$this->criarTabela'+@tab+'();'+CHAR(13)+
				'	}'+CHAR(13)
				
--insert into ##tab
--select @php

--set @php=''
select @php = @php + '	/**'+CHAR(13)+
	 '	* Setters e Getters da'+CHAR(13)+
	 '	* classe '+@tab++CHAR(13)+
	 '	*/'+CHAR(13)

select @php = @php + '	public function set'+set_get+'( '+pri+' ){'+CHAR(13)+
		'		$this->'+lower(pri_a)+' = '+pri+';'+CHAR(13)+
		'		return $this;'+CHAR(13)+
		'	}'+CHAR(13)+
		'	public function get'+set_get+'(){'+CHAR(13)+
		'		return $this->'+lower(pri_a)+';'+CHAR(13)+
		'	}'+CHAR(13)
from #new
--insert into ##tab
--select @php

select @php = @php + '	/**'+CHAR(13)+
	 '	* Criar o CRUD'+CHAR(13)+
	 '	* Porem a order sera:'+CHAR(13)+
	 '	*		C->INCLUIR'+CHAR(13)+
	 '	*		D->EXCLUIR'+CHAR(13)+
	 '	*		U->ALTERA��O'+CHAR(13)+
	 '	*		R->LISTAR (AUTOMATICO) TUDO OU SOMENTE A CHAVE'+CHAR(13)+
	 '	*/'+CHAR(13)


select @php = @php + '	/**'+CHAR(13)+
	 '	*		C->INCLUIR'+CHAR(13)+
	 '	*/'+CHAR(13)

select @php = @php + '	public function salvar'+'('+'){'+CHAR(13)+
		'		$st_query = "INSERT INTO '+UPPER(@tab)+char(13)+
		'				('+CHAR(13)
set @cam = ''
select @cam = @cam+'					'+Campo+', '+CHAR(13)
from #new
select @cam = SUBSTRING(@cam,1,len(@cam)-3) +CHAR(13)
select @php = @php+@cam
select @php = @php + '				)VALUES'+CHAR(13)+
		'				('+CHAR(13)
set @cam = ''
select @cam = @cam+'					'+CHAR(39)+'$this->'+pri_a+CHAR(39)+', '+CHAR(13)
from #new
select @cam = SUBSTRING(@cam,1,len(@cam)-3) +CHAR(13)
select @php = @php+@cam
select @php = @php + '				)";'+CHAR(13)+
		'		return $this->'
set @cam = ''
select @cam = @cam+pri_a+' + '+CHAR(39)+'/'+CHAR(39)+' + '
from #new
where chave = 'PK'
select @cam = SUBSTRING(@cam,1,len(@cam)-8) +';'+CHAR(13)+'	}'+CHAR(13)
select @php = @php+@cam

select @php = @php + '	/**'+CHAR(13)+
	 '	*		D->EXCLUIR'+CHAR(13)+
	 '	*/'+CHAR(13)

select @php = @php + '	public function excluir'+'('+'){'+CHAR(13)+
		'		if('
set @cam = ''
select @cam = @cam+'!is_null($this->'+pri_a+') and '
from #new
where chave = 'PK'
select @cam = SUBSTRING(@cam,1,len(@cam)-4) +'){'+CHAR(13)
select @php = @php+@cam
select @php = @php + '			$st_query = "DELETE FROM '+UPPER(@tab)+char(13)+
		'				WHERE '
set @cam = ''
select @cam = @cam+campo+' = $this->'+pri_a+' and '
from #new
where chave = 'PK'
select @cam = SUBSTRING(@cam,1,len(@cam)-4) +'";'+CHAR(13)
select @php = @php+@cam
select @php = @php + '			if($this->o_db->exec($st_query) > 0)'+CHAR(13)+
		'			return true;'+CHAR(13)+
		'		}'+char(13)+
		'		return false;'+CHAR(13)+
		'	}'+CHAR(13)

select @php = @php + '	/**'+CHAR(13)+
	 '	*		U->ALTERA��O'+CHAR(13)+
	 '	*/'+CHAR(13)
		
select @php = @php + '	public function alterar'+'('+'){'+CHAR(13)+
		'		if('
set @cam = ''
select @cam = @cam+'!is_null($this->'+pri_a+') and '
from #new
where chave = 'PK'
select @cam = SUBSTRING(@cam,1,len(@cam)-4) +'){'+CHAR(13)
select @php = @php+@cam
select @php = @php + '			$st_query = "UPDATE '+UPPER(@tab)+char(13)+
		'				SET '
set @cam = ''
select @cam = @cam+campo+' = $this->'+pri_a+', '+CHAR(13)+'					'
from #new
where chave <> 'PK'
select @cam = SUBSTRING(@cam,1,len(@cam)-8) +''+CHAR(13)
select @php = @php+@cam
select @php = @php + 		'				WHERE '
set @cam = ''
select @cam = @cam+campo+' = $this->'+pri_a+' and '
from #new
where chave = 'PK'
select @cam = SUBSTRING(@cam,1,len(@cam)-4) +'";'+CHAR(13)
select @php = @php+@cam
select @php = @php + '			if($this->o_db->exec($st_query) > 0)'+CHAR(13)+
		'			return true;'+CHAR(13)+
		'		}'+char(13)+
		'		return false;'+CHAR(13)+
		'	}'+CHAR(13)

select @php = @php + '	/**'+CHAR(13)+
	 '	*		R->LISTAR (AUTOMATICO) TUDO OU SOMENTE A CHAVE'+CHAR(13)+
	 '	*/'+CHAR(13)

select @php = @php + '	public function listarTudo'+'('+'){'+CHAR(13)+
		'		$st_query = "SELECT TOP 50 '
set @cam = ''
select @cam = @cam+ campo+', '
from #new
select @cam = SUBSTRING(@cam,1,len(@cam)-1) +CHAR(13)
select @php = @php + @cam+' FROM '+UPPER(@tab)+'";'+CHAR(13)+
		'		$v_'+lower(@tab)+' = array();'+CHAR(13)+
		'		try {'+CHAR(13)+
		'			$o_dados = $this->o_db->query($st_query);'+CHAR(13)+
		'			while($o_ret = $o_dados->fetchObject()){'+CHAR(13)+
		'				$o_'+lower(@tab)+' = new '+@tab+'Modelo();'+CHAR(13)
set @cam = ''
select @cam = @cam+'				$o_'+lower(@tab)+'->set'+set_get+'($o_ret->'+campo+');'+CHAR(13)
from #new
select @cam = SUBSTRING(@cam,1,len(@cam)-2) +';'+CHAR(13)
select @php = @php+@cam
select @php = @php + '				array_push($v_'+lower(@tab)+', $o_'+lower(@tab)+');'+CHAR(13)+
		'			}'+CHAR(13)+
		'		}'+CHAR(13)+
		'		catch(PDOException $e)'+CHAR(13)+
		'		{}'+CHAR(13)+				
		'		return $v_'++lower(@tab)+';'+CHAR(13)+
		'	}'+CHAR(13)+
	'}'+CHAR(13)+
	'?>'+CHAR(13)

select identity(int,1,1) num, @php campo
into ##tab

--SALAVAR O SELECT EM TXT
--OBS.: O ARQUIVO � SALVO NO DIRET�RIO DE INSTALA��O DO SQL
Declare
@str_NomeArquivo varchar(8000),
@str_comando varchar(8000) 
set @str_NomeArquivo = 'C:\PHP\'+@tab+'Modelo.php'
set @str_comando = ' sqlcmd -S 192.168.2.39 -U "sa" -P "mdl1680" -d CFG_MDL -q "SELECT campo FROM ##TAB where campo is not null order by num" -s ";" -f 65001 -o ' + @str_NomeArquivo
--set @str_comando = ' sqlcmd -S 192.168.2.39 -U "sa" -P "mdl1680" -d CFG_MDL -q "SELECT @@php " -s ";" -f 65001 -o ' + @str_NomeArquivo 
		--							'sqlcmd -S '+@servidor+' -U '+@usuario+' -P '+@senha+' -d '+@banco+' -q "'+@Procedure+'" -s ";" -f 65001 -o '+@arquivoFisico
Exec xp_cmdshell @str_comando 


select campo
from ##tab
where campo is not null
			or campo <> ''
order by num

if (select COUNT(1) from [sitio].[dbo].[sttb] where STTB_TAB = @tab) = 0 BEGIN
	insert into [sitio].[dbo].[sttb]
	select tabela STTB_TAB, campo  STTB_CAMPO, ''  STTB_NOME, 0 STTB_TOP, 0 STTB_LEFT, 10 STTB_WIDTH, replace(REPLACE(chave,'PK',0),'CP',1) STTB_CHAVE, 0 STTB_CASE, 0 STTB_TIPO, '' STTB_MASC, 1 STTB_VISI, indice STTB_INDICE, indice STTB_SEQ,   indice  STTB_ORDER
	from #new
END