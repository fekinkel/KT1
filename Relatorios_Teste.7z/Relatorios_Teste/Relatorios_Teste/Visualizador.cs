﻿using PrimeiroAppSharp.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Microsoft.Reporting.WinForms;
using SkiaSharp;
using BarcodeStandard;
using Type = BarcodeStandard.Type;

//using BarcodeStandard;

namespace Relatorios_Teste
{
    public partial class Visualizador : Form
    {
        public Visualizador(string Tipo)
        {
            InitializeComponent();

            if (Tipo == "rptMegaSena") 
            { 

            /*var dt = new BoletoPP_HOMOLOGDataSet.PP_CARNERow(null)
            {
                Codigo = "Fernando",
                Parcela = 99,
                Observacao = "sem",
                Valor_Real = 12345
            };*/

            var dt = Megas.ObterMega();

            

            reportViewer1.LocalReport.ReportEmbeddedResource = "Relatorios_Teste.rptMegaSena.rdlc";

            reportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("dsMegaSena", dt));

            reportViewer1.RefreshReport();
            }
            else if (Tipo == "BoletoPP") 
            {
                string imgParam = "";
                var vlPath = "D:\\0_Projetos_C#\\Relatorios_Teste\\Relatorios_Teste";// Directory.GetCurrentDirectory();
                string vlFile = vlPath + "\\img\\qrcode.bmp";
                using (var b = new Bitmap(vlFile))
                {
                    using (var ms = new MemoryStream())
                    {
                        b.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                        imgParam = Convert.ToBase64String(ms.ToArray());
                    }
                }

                Barcode barlinear = new Barcode();

                SKImage imgBarcode = barlinear.Encode(Type.Interleaved2Of5, "1234567890", SKColors.Black, SKColors.White, 290, 120);
                SKData imdData = imgBarcode.Encode();   

                var imgBar = Convert.ToBase64String(imdData.ToArray());

                var dt = Boletos.ObterBoleto();

                String texto = $"\"Id_Guia\":27,\"CodigoBarra\":22, \"Data_Vencimento\":\'28/07/2024\', \"NossoNumero\":\"12354687\", \"img_CodigoBarras\":{imgBar}";

                JArray srcArray = JArray.Parse("[{\"Id_Guia\":27,\"CodigoBarra\":22, \"Data_Vencimento\":\'28/07/2024\', \"NossoNumero\":\"12354687\"}]");

                var trgArray = new JArray();

                foreach (JObject row in srcArray.Children<JObject>())
                {
                    var cleanRow = new JObject();
                    foreach (JProperty column in row.Properties())
                    {
                        // Only include JValue types
                        if (column.Value is JValue)
                        {
                            cleanRow.Add(column.Name, column.Value);
                        }
                    }

                    trgArray.Add(cleanRow);
                }

                DataTable dt1 =  JsonConvert.DeserializeObject<DataTable>(srcArray.ToString());

 
                //linear.Type = Barcode.BarcodeType.CODE128;
                //linear.Data = this.Message;
                //linear.Format = SkiaSharp.SKEncodedImageFormat.Png;

                var param = new[]
                {
                    new ReportParameter("imgQRCode", imgParam),
                    new ReportParameter("CodeBarras", imgBar)
            };
                
                


                reportViewer1.LocalReport.ReportEmbeddedResource = "Relatorios_Teste.rptBoletoPP.rdlc";

                reportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("dsBoletoPP", dt1));
                reportViewer1.LocalReport.EnableExternalImages = true;
                var vlPa = reportViewer1.LocalReport.GetParameters();

                reportViewer1.LocalReport.SetParameters(param);


                reportViewer1.RefreshReport();
            }
        }
    }
}
