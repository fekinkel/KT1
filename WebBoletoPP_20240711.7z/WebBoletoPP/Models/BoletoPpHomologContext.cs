﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebBoletoPP.Models;

public partial class BoletoPpHomologContext : DbContext
{
    public BoletoPpHomologContext()
    {
    }

    public BoletoPpHomologContext(DbContextOptions<BoletoPpHomologContext> options)
        : base(options)
    {
    }

    public virtual DbSet<PpCarne> PpCarnes { get; set; }

    public virtual DbSet<PpPrecoPublico> PpPrecoPublicos { get; set; }

    public virtual DbSet<PpUsuario> PpUsuarios { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=187.103.145.68;Database=BoletoPP_HOMOLOG;user id=tecnosysnet;password=tecno1999;trustservercertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PpCarne>(entity =>
        {
            entity.HasKey(e => e.Codigo).HasName("PK_PP_GUIA");

            entity.ToTable("PP_CARNE");

            entity.Property(e => e.Codigo)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.DataPagamento)
                .HasColumnType("datetime")
                .HasColumnName("Data_Pagamento");
            entity.Property(e => e.DataVencimento)
                .HasColumnType("datetime")
                .HasColumnName("Data_Vencimento");
            entity.Property(e => e.Login)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Observacao).HasColumnType("ntext");
            entity.Property(e => e.Parcela).HasDefaultValueSql("((99))");
            entity.Property(e => e.PpId).HasColumnName("PpID");
            entity.Property(e => e.ValorReal).HasColumnName("Valor_Real");
            entity.Property(e => e.ValorUfm).HasColumnName("Valor_UFM");

            entity.HasOne(d => d.LoginNavigation).WithMany(p => p.PpCarnes)
                .HasForeignKey(d => d.Login)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PP_CARNE_PP_USUARIO");

            entity.HasOne(d => d.Pp).WithMany(p => p.PpCarnes)
                .HasForeignKey(d => d.PpId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PP_CARNE_PP_PRECO_PUBLICO");
        });

        modelBuilder.Entity<PpPrecoPublico>(entity =>
        {
            entity.ToTable("PP_PRECO_PUBLICO");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.CodOrcamentario).HasColumnName("Cod_Orcamentario");
            entity.Property(e => e.Descricao)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ValorUfm).HasColumnName("Valor_UFM");
        });

        modelBuilder.Entity<PpUsuario>(entity =>
        {
            entity.HasKey(e => e.Login);

            entity.ToTable("PP_USUARIO");

            entity.Property(e => e.Login)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.AlterarSenha)
                .HasDefaultValueSql("((1))")
                .HasColumnName("Alterar_Senha");
            entity.Property(e => e.Ativo)
                .IsRequired()
                .HasDefaultValueSql("((1))");
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Secretaria)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.Senha)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValueSql("((1234))");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
