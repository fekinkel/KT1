﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text.Json;
using WebBoletoPP.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static WebBoletoPP.Pages.Carne.CreateModel;

namespace WebBoletoPP.Pages.Carne
{
    public class CreateModel : PageModel
    {

        [BindProperty]
        public CreateModelView ModelView { get; set; } = default!;
        public PpCarne PpCarne { get; set; } = default!;
        public int IndexListaPP { get; set; }

        private readonly BoletoPpHomologContext _context;

        public CreateModel(BoletoPpHomologContext context)
        {
            _context = context;
            ModelView = new CreateModelView();
        }
        public IActionResult OnGet(CreateModelView modview, string TipoGet)
        {
            
            ModelView.Codigo = "0";
            ModelView.Quantidade = 1;
            ModelView.DesQtde = "reais /h";
            
            ModelView.DataVencimento = DateOnly.FromDateTime(DateTime.Now);
            //CreateModelView.ListaPrecoPublicos = CarregarListaPP(0);
            ModelView.ListaPrecoPublicos = CarregarListaPP(0);
            return Page();

        }
        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public void OnPost(CreateModelView modelView, string Action, string CriarCarne)
        {
            if (!Action.IsNullOrEmpty())
            {
                if (Action == "CriarCarne")
                {
                    if (!ModelState.IsValid || _context.PpCarnes == null || PpCarne == null)
                    {
                        ModelView.Codigo = "55";// ModelView.ListaPrecoPublicos.Count.ToString();
                        ModelView.ListaPrecoPublicos = CarregarListaPP(0);
                        //return Page();
                    }
                    else
                    {
                        _context.PpCarnes.Add(PpCarne);
                        _context.SaveChangesAsync();
                        //return RedirectToPage("./Index");
                    }
                }
                else
                {
                    int val = int.Parse(Action);
                    ModelView.PpId = val;
                    ModelView.ListaPrecoPublicos = CarregarListaPP(val);
                    ValorPP valPP = BuscarValorUfir(ModelView.DataVencimento.ToString(), val);
                    ModelView.ValorUFIR = valPP.valorufirdia;
                    ModelView.ValorUfm = valPP.valorufmpp;
                    ModelView.DesQtde = valPP.descricao;
                    ModelView.ValorReal = Decimal.Multiply(Decimal.Multiply(valPP.valorufirdia, valPP.valorufmpp), ModelView.Quantidade);
                    //return Page();
                }
            }
            //return Page();
        }
        public ValorPP BuscarValorUfir(string DataVencimento, int valIdPP)
        {
            if (valIdPP > 0)
            {
                string sSql = $"Select (Select convert(decimal(12,6), dbo.Valor_Ufir_dia(\'{DataVencimento}\')) as valorufirdia, convert(decimal(12,6), Valor_UFM) as valorufmpp, B.Descricao From PP_PRECO_PUBLICO A INNER JOIN PP_TIPO_DESCRICAO B on B.ID_TD = A.ID_TD Where ID = {valIdPP} For Json Path) as value";

                var retorno =  _context.Database.SqlQueryRaw<string>(sSql).FirstOrDefault();

                if (retorno != null)
                {
                    retorno = retorno.Trim(new char[] { ']', '[' });

                    ValorPP valPP = JsonConvert.DeserializeObject<ValorPP>(retorno);

                    return valPP;
                }
                else
                {
                    return new ValorPP();
                }
            }
            else
            {
                return new ValorPP();
            }
        }
        public List<SelectListItem> CarregarListaPP(int IdPP)
        {
            var lista = new List<SelectListItem>();

            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            var precopublico = PrecoPublicoQuery.ToList();


            try
            {
                foreach (var item in precopublico)
                {
                    var option = new SelectListItem()
                    {
                        Text = item.Descricao,
                        Value = item.Id.ToString(),
                        Selected = (item.Id == IdPP)
                    };
                    lista.Add(option);
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return lista;
        }

    }

    public class ValorPP
    {
        public decimal valorufirdia { get; set; }
        public decimal valorufmpp { get; set; }
        public string descricao {  get; set; }
    }
    public class CreateModelView
    {
        [Display(Name = "Código")]
        public string Codigo { get; set; } = null!;
        [Display(Name = "Parcela")]
        public int Parcela { get; set; }
        [Display(Name = "Valor do Serviço")]
        [DisplayFormat(DataFormatString = "{0:N4}", ApplyFormatInEditMode = true)]
        public decimal ValorUfm { get; set; }
        [Display(Name = "Valor da Ufir")]
        [DisplayFormat(DataFormatString = "{0:N4}", ApplyFormatInEditMode = true)]
        public decimal ValorUFIR { get; set; }
        public decimal Quantidade { get; set; }
        public string DesQtde {  get; set; }

        [Display(Name = "Valor Total")]
        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        public decimal ValorReal { get; set; }
        public string Observacao { get; set; } = null!;
        public string Login { get; set; } = null!;
        [Display(Name = "Selecione o serviço:")]
        public int PpId { get; set; }
        [Display(Name = "Data de Vencimento")]
        public DateOnly DataVencimento { get; set; }
        public DateOnly? DataPagamento { get; set; } = null;
        public List<SelectListItem> ListaPrecoPublicos { get; set; }
        public CreateModelView() { }

        #region Métodos


        #endregion
    }
}
