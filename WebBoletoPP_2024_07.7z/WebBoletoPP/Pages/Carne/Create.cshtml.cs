﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text.Json;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Carne
{
    public class CreateModel : PageModel
    {

        [BindProperty]
        public CreateModelView ModelView { get; set; } = default!;
        public PpCarne PpCarne { get; set; } = default!;
        public int IndexListaPP { get; set; }

        private readonly BoletoPpHomologContext _context;

        public CreateModel(BoletoPpHomologContext context)
        {
            _context = context;
        }
        public IActionResult OnGet(CreateModelView modview, string TipoGet)
        {
            ModelView = new CreateModelView();
            ModelView.Codigo = "0";
            ModelView.Quantidade = 1;
            ModelView.DataVencimento = DateOnly.FromDateTime(DateTime.Now);
            CreateModelView.ListaPrecoPublicos = CarregarListaPP(0);
            return Page();

            //if (jsonString.IsNullOrEmpty())
            //{
            //    ModelView = new CreateModelView(_context);
            //    ModelView.Codigo = "0";
            //    ModelView.Quantidade = 1;
            //    ModelView.DataVencimento = DateOnly.FromDateTime(DateTime.Now);
            //    return Page();
            //}
            //else
            //{
            //    Valor_PP val;
            //    try
            //    {
            //        val = JsonSerializer.Deserialize<Valor_PP>(jsonString);
            //    }
            //    catch (Exception ex)
            //    {
            //        throw;
            //        //return RedirectToPage("./Error");
            //    }
            //    if (val != null)
            //    {
            //        var valor1 = BuscarValorPP(val);
            //        return new JsonResult(new { valorufm = valor1, valorufir = 10 });
            //    }
            //    else
            //    {
            //        return new JsonResult(new { erro = "sem valor" });
            //    }
            //}
        }
        public IActionResult OnGetAction(CreateModelView modview)
        {
            Valor_PP retorno = BuscarValorUfir("02/05/2024", modview.PpId);
            modview.ValorUFIR = retorno.valorufirdia;
            modview.ValorUfm = retorno.valorufmpp;
            return Page();
        }

        public IActionResult OnPostAction(CreateModelView modview)
        {
            Valor_PP retorno = BuscarValorUfir("02/05/2024", modview.PpId);
            modview.ValorUFIR = retorno.valorufirdia;
            modview.ValorUfm = retorno.valorufmpp;
            return Page();
        }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public IActionResult OnPost(CreateModelView modelView, string Action)
        {
            if (!ModelState.IsValid || _context.PpCarnes == null || PpCarne == null)
            {                
                ModelView.Codigo = "55";// ModelView.ListaPrecoPublicos.Count.ToString();
                CreateModelView.ListaPrecoPublicos = CarregarListaPP(0);
                return Page();
            }

            _context.PpCarnes.Add(PpCarne);
            _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
        public double BuscarValorPP(Valor_PP valIdPP)
        {
            /*if (valIdPP.vid > 0)
            {
                var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                        where d.Id == valIdPP.id // Sort by name.
                                        select d.ValorUfm;

                return PrecoPublicoQuery.FirstOrDefault();

            }
            else
            {
                return 0;
            }
            */
            return 0;
        }
        public Valor_PP BuscarValorUfir(string DataVencimento, int valIdPP)
        {
            if (valIdPP > 0)
            {
                string sSql = $"Select (Select convert(decimal(12,6), dbo.Valor_Ufir_dia(\'{DataVencimento}\')) as valorufirdia, convert(decimal(12,6), Valor_UFM) as valorufmpp From PP_PRECO_PUBLICO Where ID = {valIdPP} For Json Path) as value";

                var retorno =  _context.Database.SqlQueryRaw<string>(sSql).FirstOrDefault();

                if (retorno != null)
                {
                    retorno = retorno.Trim(new char[] { ']', '[' });

                    Valor_PP valPP = JsonConvert.DeserializeObject<Valor_PP>(retorno);

                    return valPP;
                }
                else
                {
                    return new Valor_PP();
                }
            }
            else
            {
                return new Valor_PP();
            }
        }
        public List<SelectListItem> CarregarListaPP(int IdPP)
        {
            var lista = new List<SelectListItem>();

            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            var precopublico = PrecoPublicoQuery.ToList();


            try
            {
                foreach (var item in precopublico)
                {
                    var option = new SelectListItem()
                    {
                        Text = item.Descricao,
                        Value = item.Id.ToString(),
                        Selected = (item.Id == IdPP)
                    };
                    lista.Add(option);
                }

            }
            catch (Exception ex)
            {
                throw;
            }

            return lista;
        }

    }

    public class Valor_PP
    {
        public decimal valorufirdia { get; set; }
        public decimal valorufmpp { get; set; }
    }
    public class CreateModelView
    {
        [Display(Name = "Código")]
        public string Codigo { get; set; } = null!;
        [Display(Name = "Parcela")]
        public int Parcela { get; set; }
        [Display(Name = "Valor do Serviço em UFM")]
        public decimal ValorUfm { get; set; }
        [Display(Name = "Valor da UFIR")]
        [DisplayFormat(DataFormatString="{0:C2}",ApplyFormatInEditMode = true)]
        public decimal ValorUFIR { get; set; }
        public double Quantidade { get; set; }
        public double ValorReal { get; set; }
        public string Observacao { get; set; } = null!;
        public string Login { get; set; } = null!;
        [Display(Name = "Selecione o serviço:")]
        public int PpId { get; set; }
        public IEnumerable<SelectListItem> ePPid {  get; set; }

        [Display(Name = "Data de Vencimento")]
        public DateOnly DataVencimento { get; set; }
        public DateOnly? DataPagamento { get; set; } = null;
        public static List<SelectListItem> ListaPrecoPublicos { get; set; }
        public CreateModelView() { }

        #region Métodos


        #endregion
    }
}
