using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using WebBoletoPP.Models;
using NToastNotify;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;

namespace WebBoletoPP.Pages.Usuario
{
    public class LoginModel : PageModel
    {
        #region "ViewModel"
        [BindProperty]
        public LoginModelView ModelView { get; set; } = default!;
        #endregion

        private readonly ILogger<LoginModel> _logger;
        //private readonly BoletoPpHomologContext _context;
        private readonly IToastNotification _toastNotification;

        public LoginModel(ILogger<LoginModel> logger, IToastNotification toastNotification)
        {
            _logger = logger;
            //_context = context;
            _toastNotification = toastNotification;
        }


        public void OnGet()
        {
            string returnUrl = HttpContext.Request.Query["ReturnUrl"];

            ModelView ??= new LoginModelView()
            {
                Login = string.Empty,
                Senha = string.Empty,
                ReturnUrl = returnUrl,
            };
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            BoletoPpHomologContext context = new();

            var usuario = context.PpUsuarios.FirstOrDefault(item => item.Login == ModelView.Login);
            //usuario.ToList();
            //    .ToList();

            if (usuario == null)
            {
                ModelState.AddModelError(string.Empty, "Login/senha incorreta.");
                _toastNotification.AddErrorToastMessage("Login/senha incorreta.",
                                                          new ToastrOptions() { Title = "Erro" });
                return Page();
            }
            else if (usuario.Senha != ModelView.Senha)
            {
                ModelState.AddModelError(string.Empty, "Login/senha incorreta.");
                _toastNotification.AddErrorToastMessage("Login/senha incorreta.",
                                                        new ToastrOptions() { Title = "Erro" });
                return Page();
            }
            var claims = new List<Claim>()
            {
                new Claim(ClaimTypes.NameIdentifier, Convert.ToString(usuario.Login)),
                new Claim(ClaimTypes.Name, usuario.Login),
                new Claim(ClaimTypes.Role, "Usuario")
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal,
                    new AuthenticationProperties()
                    {
                        IsPersistent = true,
                        ExpiresUtc = DateTime.UtcNow.AddMinutes(20)
                    });
            return !string.IsNullOrEmpty(ModelView.ReturnUrl) ? RedirectPermanent(ModelView.ReturnUrl) :
                    RedirectToPagePermanent("/TelaInicial");
        }
        public async Task<IActionResult> OnGetLogoutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            _toastNotification.AddSuccessToastMessage("Logout realizado com sucesso.",
                                                          new ToastrOptions() { Title = "Desconectado" });

            return RedirectToPagePermanent("/Index");
        }

    }

    public class LoginModelView
    {
        [Required(ErrorMessage = "Campo obrigat�rio!")]
        public required string Login { get; set; }
        [Required(ErrorMessage = "Campo obrigat�rio!")]
        [DataType(DataType.Password)]
        public required string Senha { get; set; }

        public string? ReturnUrl { get; set; }
        public LoginModelView()
        {

        }
    }
}
