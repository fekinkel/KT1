using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebBoletoPP.Pages.Usuario
{
    public class TrocarSenhaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
