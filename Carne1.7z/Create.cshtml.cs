﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.IdentityModel.Tokens;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Carne
{
    public class CreateModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        [BindProperty] 
        public CreateModelView ModelView { get; set; } = default!;

        public CreateModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;

            PpCarne = new PpCarne();

            ModelView = new CreateModelView(_context);
        }
        public ActionResult ListarPP(string sigla) 
        {

            return Page();// JsonResult(new {Resultado = lista }, jsonrequestBe);
        }
        public ActionResult Index(CalcularIMCModel model)
        {
            var selectedValue = model.ModelView.SelectTipoBebida;
            //ViewBag.TipoBebida = selectedValue.ToString();
            return NotFound();
        }
        public IActionResult OnGet(string sigla)
        {
            if (sigla.IsNullOrEmpty())
            {
                //var buscaPP = BuscarPrecoPublico(int.Parse("34"));
                //return new JsonResult(new { Resultado = buscaPP });
                return Page();
            }
            else
            {
                var buscaPP = BuscarPrecoPublico(int.Parse(sigla));

                return new JsonResult(new {Resultado = buscaPP });
            }
        }

        
        public PpCarne PpCarne { get; set; } = default!;
        
        public int IdListaPreco {  get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync(int Id)
        {
            /*if (!ModelState.IsValid || _context.PpCarnes == null || PpCarne == null)
              {
                  ModelView.Codigo = ModelView.ListaPrecoPublicos.Count.ToString();
                  return Page();
              }

              _context.PpCarnes.Add(PpCarne);
              await _context.SaveChangesAsync();
              return RedirectToPage("./Index");
            */
            ModelView.Codigo = "1";
            return Page();
        }
        public string BuscarPrecoPublico(int IdPP)
        {
            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    where d.Id == IdPP // Sort by name.
                                    select d.ValorUfm;
            var precopublico = PrecoPublicoQuery.FirstOrDefault();

            return precopublico.ToString();
        }
    }
    public class CreateModelView
    {
        public string Codigo { get; set; } = null!;
        public int Parcela { get; set; }
        public double ValorUfm { get; set; }
        public double ValorReal { get; set; }
        public string Observacao { get; set; } = null!;
        public string Login { get; set; } = null!;
        public int PpId { get; set; }
        public DateTime DataVencimento { get; set; }
        public DateTime? DataPagamento { get; set; } = null;
        [ValidateNever]
        public double Quantidade { get; set; }

        private readonly BoletoPpHomologContext _contextview;

        private SelectListItem _ItemLista {  get; set; }
        public int IdListaPreco { get; set; }
        public SelectListItem ListaPrecoPublico 
        { 
            get
            {
                return _ItemLista;
            }
            set
            {
                _ItemLista = value;
                this.Codigo = "15";
            }
        }
        public List<SelectListItem> ListaPrecoPublicos { get; set; }

        //public ListaPrecoPublicos ItemLista {  get; set; }

        public CreateModelView(BoletoPpHomologContext _context, object SelectPrecoPublico = null)
        {
/*            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            ListaPrecoPublico = PrecoPublicoQuery.ToList();
*/            
            _contextview = _context;

            ListaPrecoPublicos = CarregarListaPP(0);
            this.ValorReal = 12;
            this.ValorUfm = 13;
        }

        #region Métodos

        public List<SelectListItem> CarregarListaPP(int IdPP)
        {
            var lista = new List<SelectListItem>();

            var PrecoPublicoQuery = from d in _contextview.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            var precopublico = PrecoPublicoQuery.ToList();


            try
            {
                foreach (var item in precopublico)
                {
                    var option = new SelectListItem()
                    {
                        Text = item.Descricao,
                        Value = item.Id.ToString(),
                        Selected = (item.Id == IdPP)
                    };
                    lista.Add(option);
                }

            }
            catch(Exception ex)
            {
                throw;
            }
            return lista;
        }

        #endregion
    }
}
