using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebBoletoPP.Pages
{
    [Authorize(Roles = "Usuario")]
    public class TelaInicialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
