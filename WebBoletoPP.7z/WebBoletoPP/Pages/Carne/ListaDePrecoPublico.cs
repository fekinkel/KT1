﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;

namespace WebBoletoPP.Pages.Carne
{
    public class ListaDePrecoPublico : PageModel
    {
        public SelectList ListaPrecoPublico { get; set; }

        public void PopularDropDonwPP(BoletoPpHomologContext _context , object SelectPrecoPublico = null )
        {
            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            ListaPrecoPublico = new SelectList(PrecoPublicoQuery.AsNoTracking(),
                nameof(PpPrecoPublico.Id),
                nameof(PpPrecoPublico.Descricao),
                SelectPrecoPublico);

        }
    }
}
