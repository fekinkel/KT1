﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebBoletoPP.Models;
using WebBoletoPP.Pages.Usuario;

namespace WebBoletoPP.Pages.Carne
{
    public class CreateModel : PageModel
    {
        private readonly BoletoPpHomologContext _context;
        public CreateModelView ModelView { get; set; } = default!;
        public PpCarne Carne { get; set; } = default!;
        public CreateModel(BoletoPpHomologContext context)
        {
            _context = context;
            Carne = new PpCarne();
        }

        public void OnGet()
        {
            ModelView = new (_context);

        }

        //[BindProperty]
        
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPost(string command)
        {
            if (command == "Gerar")
            {
                if (!ModelState.IsValid || _context.PpCarnes == null || Carne == null)
                {
                    return Page();
                }


                _context.PpCarnes.Add(Carne);
                await _context.SaveChangesAsync();

                return RedirectToPage("./Index");
            }
            else if (command == "Calcular")
            {
                if (Carne.ValorUfm > 0)
                {
                    Carne.ValorReal = Carne.ValorUfm * Carne.Quantidade;
                }
                return Page();
            }
            else
            { 
                return Page(); 
            }
        }
    }

    public class CreateModelView
    {
        [ValidateNever]
        public string Codigo { get; set; } = null!;
        public int Parcela { get; set; }
        public double ValorUfm { get; set; }
        public double ValorReal { get; set; }
        [ValidateNever] 
        public string Observacao { get; set; } = null!;
        public string Login { get; set; } = null!;
        [ValidateNever] 
        public int PpId { get; set; }
        public DateTime DataVencimento { get; set; }
        public DateTime? DataPagamento { get; set; } = null;
        public double Quantidade { get; set; }
        public List<PpPrecoPublico> ListaPrecoPublico { get; set; }
        public List<SelectListItem> ListaPrecoPublicos { get; set; }
        public CreateModelView()
        {
        }
        public CreateModelView(BoletoPpHomologContext _context, object SelectPrecoPublico = null)
        {
            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Id // Sort by name.
                                    select d;
            ListaPrecoPublico = PrecoPublicoQuery.ToList();

            //ListaPrecoPublico = new SelectList(PrecoPublicoQuery.AsNoTracking(),
            //    nameof(PpPrecoPublico.Id),
            //    nameof(PpPrecoPublico.Descricao),
            //    SelectPrecoPublico);
        }
    }
}
