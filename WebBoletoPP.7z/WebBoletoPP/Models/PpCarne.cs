﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebBoletoPP.Models;

public partial class PpCarne
{
    public string Codigo { get; set; } = null!;

    public int Parcela { get; set; }

    public double ValorUfm { get; set; }

    public double ValorReal { get; set; }

    public string Observacao { get; set; } = null!;

    public string Login { get; set; } = null!;

    public int PpId { get; set; }

    public DateTime DataVencimento { get; set; }

    public DateTime? DataPagamento { get; set; } = null;

    [ValidateNever]
    public double Quantidade { get; set; } 
    [ValidateNever]
    public virtual PpUsuario LoginNavigation { get; set; } = null!;
    [ValidateNever]
    public virtual PpPrecoPublico Pp { get; set; } = null!;
}
