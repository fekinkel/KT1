﻿using ExportarRdlcToPdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportarPdf
{
    public class Class1
    {
        public string ExpRdlcToPDF(string NomeRdlc, string DsRdlc, string DadosRdlc)
        {
            //NomeRdlc - Nome do relatório
            //DcRdlc - Nome do DataSource do Relatório
            //DadosRdlc - Dados para o Relatório
            string Error = "";
                if (String.IsNullOrEmpty(NomeRdlc))
                {
                    Error = "Nome não é válido!";
                }
                else
                {
                    string vlPath = Directory.GetCurrentDirectory();

                    string vlFile = vlPath + "\\rpt\\" + NomeRdlc;

                    if (File.Exists(vlFile))
                    {
                        LerRdlc ler = new LerRdlc();

                        Error = ler.SaidaPdf(vlFile, DsRdlc, DadosRdlc);
                    }
                    else
                    {
                        Error = "Arquivo não existe";
                    }
                    //Console.WriteLine(File.Exists(vlFile) ? "File exists." : "File does not exist.");
                }
            
            return (Error);
        }
    }
}
