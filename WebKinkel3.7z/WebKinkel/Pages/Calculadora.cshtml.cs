using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using WebKinkel.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace WebKinkel.Pages
{
    public class CalculadoraModel : PageModel
    {
        public void OnGet()
        {
            ModeloCalc.A = 12;
            ModeloCalc.B = 13;
        }
        [BindProperty]
        public ModeloCalc ModeloCalc { get; set; } = default!;
        public CalculadoraModel() { 
            ModeloCalc = new ModeloCalc();
        }   
        [HttpGet]
        public ActionResult Index()
        {
            return Page();
        }
        [HttpPost]
        public void OnPost(string command)
        {
            var model = ModeloCalc;

            if (command == "add")
            {
                model.Resultado = model.A + model.B;
            }
            if (command == "sub")
            {
                model.Resultado = model.A - model.B;
            }
            if (command == "mul")
            {
                model.Resultado = model.A * model.B;
            }
            if (command == "div")
            {
                model.Resultado = model.A / model.B;
            }
            //return model;
        }
    }
}
