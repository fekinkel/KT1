﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Carne
{
    public class DetailsModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public DetailsModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

      public PpCarne PpCarne { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.PpCarnes == null)
            {
                return NotFound();
            }

            var ppcarne = await _context.PpCarnes.FirstOrDefaultAsync(m => m.Codigo == id);
            if (ppcarne == null)
            {
                return NotFound();
            }
            else 
            {
                PpCarne = ppcarne;
            }
            return Page();
        }
    }
}
