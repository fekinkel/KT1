﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Carne
{
    public class IndexModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public IndexModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

        public IList<PpCarne> PpCarne { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.PpCarnes != null)
            {
                PpCarne = await _context.PpCarnes.ToListAsync();
            }
        }
    }
}
