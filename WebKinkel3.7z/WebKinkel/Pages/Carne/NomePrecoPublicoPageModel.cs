﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Carne
{
    public class NomePrecoPublicoPageModel:PageModel
    {
        public SelectList NomePrecoPublicoSL { get; set; }

        public void PupularPPDropDownLista(BoletoPpHomologContext _context, object selectedPrecoPublico = null) 
        {
            var PrecoPublicoQuery = from d in _context.PpPrecoPublicos
                                    orderby d.Descricao
                                    select d;
            NomePrecoPublicoSL = new SelectList(PrecoPublicoQuery.AsNoTracking(),
                /*nameof(PpPrecoPublico.Id),*/
                nameof(PpPrecoPublico.ValorUfm),
                nameof(PpPrecoPublico.Descricao),
                selectedPrecoPublico);
        }
    }
}
