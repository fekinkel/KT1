﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Carne
{
    public class EditModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public EditModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PpCarne PpCarne { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.PpCarnes == null)
            {
                return NotFound();
            }

            var ppcarne =  await _context.PpCarnes.FirstOrDefaultAsync(m => m.Codigo == id);
            if (ppcarne == null)
            {
                return NotFound();
            }
            PpCarne = ppcarne;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(PpCarne).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PpCarneExists(PpCarne.Codigo))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool PpCarneExists(string id)
        {
          return (_context.PpCarnes?.Any(e => e.Codigo == id)).GetValueOrDefault();
        }
    }
}
