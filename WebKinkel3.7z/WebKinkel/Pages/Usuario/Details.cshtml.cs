﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Usuario
{
    public class DetailsModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public DetailsModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

      public PpUsuario PpUsuario { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.PpUsuarios == null)
            {
                return NotFound();
            }

            var ppusuario = await _context.PpUsuarios.FirstOrDefaultAsync(m => m.Login == id);
            if (ppusuario == null)
            {
                return NotFound();
            }
            else 
            {
                PpUsuario = ppusuario;
            }
            return Page();
        }
    }
}
