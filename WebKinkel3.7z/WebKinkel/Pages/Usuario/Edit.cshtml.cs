﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Usuario
{
    public class EditModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public EditModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PpUsuario PpUsuario { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.PpUsuarios == null)
            {
                return NotFound();
            }

            var ppusuario =  await _context.PpUsuarios.FirstOrDefaultAsync(m => m.Login == id);
            if (ppusuario == null)
            {
                return NotFound();
            }
            PpUsuario = ppusuario;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(PpUsuario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PpUsuarioExists(PpUsuario.Login))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool PpUsuarioExists(string id)
        {
          return (_context.PpUsuarios?.Any(e => e.Login == id)).GetValueOrDefault();
        }
    }
}
