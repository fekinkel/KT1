﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebKinkel.Data;
using WebKinkel.Models;

namespace WebKinkel.Pages.Usuario
{
    public class DeleteModel : PageModel
    {
        private readonly WebKinkel.Data.BoletoPpHomologContext _context;

        public DeleteModel(WebKinkel.Data.BoletoPpHomologContext context)
        {
            _context = context;
        }

        [BindProperty]
      public PpUsuario PpUsuario { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.PpUsuarios == null)
            {
                return NotFound();
            }

            var ppusuario = await _context.PpUsuarios.FirstOrDefaultAsync(m => m.Login == id);

            if (ppusuario == null)
            {
                return NotFound();
            }
            else 
            {
                PpUsuario = ppusuario;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string id)
        {
            if (id == null || _context.PpUsuarios == null)
            {
                return NotFound();
            }
            var ppusuario = await _context.PpUsuarios.FindAsync(id);

            if (ppusuario != null)
            {
                PpUsuario = ppusuario;
                _context.PpUsuarios.Remove(PpUsuario);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
