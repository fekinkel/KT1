using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebKinkel.Pages
{
    public class EstudanteModel : PageModel
    {
        public string Name { get; set; }
        public void OnGet()
        {
            Name = "Kinkel Serejo";
        }
    }
}
