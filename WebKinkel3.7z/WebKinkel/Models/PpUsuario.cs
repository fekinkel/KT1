﻿using System;
using System.Collections.Generic;

namespace WebKinkel.Models;

public partial class PpUsuario
{
    public string Login { get; set; } = null!;

    public string? Nome { get; set; }

    public int? Matricula { get; set; }

    public string? Secretaria { get; set; }

    public string? Senha { get; set; }

    public bool? AlterarSenha { get; set; }

    public bool Administrador { get; set; }

    public bool? Ativo { get; set; }
}
