﻿using Microsoft.AspNetCore.Mvc;
using WebKinkel.Models;

namespace Addition.Controllers
{
    public class HomeController : Controller
    {
        //    
        // GET: /Home/    
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(ModeloCalc model, string command)
        {
            if (command == "add")
            {
                model.Resultado = model.A + model.B;
            }
            if (command == "sub")
            {
                model.Resultado = model.A - model.B;
            }
            if (command == "mul")
            {
                model.Resultado = model.A * model.B;
            }
            if (command == "div")
            {
                model.Resultado = model.A / model.B;
            }
            return View(model);
        }
    }
}