﻿function setMedicoValueDiv(value) {
    $("#medico-id-value").text(value);
}
$(document).ready(function () {
    setMedicoValueDiv($("#MedicoId").val());
    $("#MedicoId").change(function () {
        setMedicoValueDiv($(this).val());
    });
});