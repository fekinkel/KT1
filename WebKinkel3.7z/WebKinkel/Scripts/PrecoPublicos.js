﻿$(document).ready(function () {

    $(#IdEstado).change(function () {
        var value = $("#ListaPrecoPublico option:selected").val();

        if (value !== "" || value !== undefined) {
            ListarPrecoPublicos(value);
        }
    });
})

function ListarPrecoPublicos(value) {
    var url = "Create/ListarPP";
    var data = { sigla: value };

    $.ajax({
        url: url,
        type: "GET",
        datatype: "json",
        data: data
    }).done(function (data) {
        if (data.Resultado.length > 0) {

        }
    })
}