﻿$(document).ready(function () {

    $(#IdEstado).change(function () {
        var value = $("#IdEstado option:selected").val();

        if (value !== "" || value !== undefined) {
            ListaCidades(value);
        }
    });
})

function ListarCidades(value) {
    var url = "Create/ListarPP";
    var data = { sigla: value };

    $.ajax({
        url: url,
        type: "GET",
        datatype: "json",
        data: data
    }).done(function (data) {
        if (data.Resultado.length > 0) {

        }
    })
}